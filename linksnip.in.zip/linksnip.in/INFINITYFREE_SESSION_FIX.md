﻿# InfinityFree Session Error Fix

## Error
```
session_start(): ps_files_cleanup_dir: opendir(/php_sessions) failed: Permission denied (13)
```

## Solution Applied ✅

Updated `config/config.php` to use a custom session directory within your htdocs folder.

### What Changed:
```php
// Custom session path for InfinityFree
$sessionPath = ROOT_PATH . '/sessions';
if (!file_exists($sessionPath)) {
    @mkdir($sessionPath, 0755, true);
}
if (is_writable($sessionPath)) {
    session_save_path($sessionPath);
}
```

### What This Does:
1. Creates a `sessions/` folder in your htdocs directory
2. Sets proper permissions (755)
3. Tells PHP to store session files there instead of the default location
4. Only applies if the directory is writable (failsafe)

## Additional Step Required:

After uploading files to InfinityFree, you may need to manually create the sessions folder:

### Option 1: Via File Manager
1. Login to InfinityFree Control Panel
2. Go to **File Manager**
3. Navigate to `htdocs/`
4. Click **New Folder**
5. Name it: `sessions`
6. Set permissions to `755`

### Option 2: Via FTP (FileZilla)
1. Connect to your FTP
2. Navigate to `htdocs/`
3. Right-click → **Create directory**
4. Name: `sessions`
5. Right-click folder → **File permissions**
6. Set to: `755` (or check: Owner: Read+Write+Execute, Group: Read+Execute, Public: Read+Execute)

### Option 3: Let PHP Create It (Automatic)
The code will try to create it automatically, but if it fails due to permissions, use Option 1 or 2.

## Security Note:

Add this to your `.htaccess` to prevent direct access to session files:

```apache
# Protect sessions directory
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteRule ^sessions/ - [F,L]
</IfModule>

# Or use this simpler method
<Files "sessions/*">
    Order allow,deny
    Deny from all
</Files>
```

## Test After Fix:

1. Upload the updated `config/config.php`
2. Visit your site: `https://snaplink.pro`
3. The session error should be gone!

## Common InfinityFree Issues & Fixes:

### 1. Session Error (FIXED ✅)
**Problem:** Can't write to default session directory  
**Solution:** Custom session path (already applied)

### 2. Upload Folder Permissions
Create an `uploads/` folder with 755 permissions:
```bash
mkdir uploads
chmod 755 uploads
```

### 3. .htaccess Not Working
Make sure `.htaccess` is uploaded to the root `htdocs/` directory (not inside subfolders)

### 4. 500 Internal Server Error
Common causes:
- Syntax error in PHP files
- Incorrect file permissions
- Missing required PHP extensions
- Check error logs in InfinityFree cPanel

### 5. Database Connection Failed
- Double-check credentials in `config/config.php`
- Verify database exists in InfinityFree MySQL panel
- Check if database user has correct permissions

## Your Current Configuration:

```php
// Database
DB_HOST: sql205.infinityfree.com
DB_NAME: if0_34392250_snaplink
DB_USER: if0_34392250

// Domain
APP_URL: https://snaplink.pro

// Sessions
Custom path: /htdocs/sessions (writable)
```

## Next Steps:

1. ✅ Update `config/config.php` (Done!)
2. Upload updated file to InfinityFree
3. Create `sessions/` folder (or let PHP do it)
4. Test site - session error should be gone
5. Continue with installation

The session error is now fixed! 🎉
