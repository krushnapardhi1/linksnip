﻿<?php
/**
 * User API Analytics Page
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

// Must be logged in
if (!is_logged_in()) {
    redirect(base_url('login.php'));
}

$user = current_user();
$userId = $user['id'];

// Get overall stats
$stats = db()->fetchOne('
    SELECT 
        COUNT(*) as total_requests,
        COUNT(DISTINCT DATE(created_at)) as active_days,
        MAX(created_at) as last_request,
        MIN(created_at) as first_request
    FROM api_requests 
    WHERE user_id = ?
', [$userId]) ?? ['total_requests' => 0, 'active_days' => 0, 'last_request' => null, 'first_request' => null];

// Get today's requests
$todayRequests = db()->fetchOne('
    SELECT COUNT(*) as count 
    FROM api_requests 
    WHERE user_id = ? AND DATE(created_at) = CURDATE()
', [$userId])['count'] ?? 0;

// Get requests by endpoint
$endpointStats = db()->fetchAll('
    SELECT 
        endpoint,
        COUNT(*) as count,
        AVG(response_time_ms) as avg_response_time
    FROM api_requests 
    WHERE user_id = ?
    GROUP BY endpoint
    ORDER BY count DESC
', [$userId]) ?? [];

// Get last 7 days data for chart
$dailyStats = db()->fetchAll('
    SELECT 
        DATE(created_at) as date,
        COUNT(*) as count
    FROM api_requests
    WHERE user_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    GROUP BY DATE(created_at)
    ORDER BY date ASC
', [$userId]) ?? [];

// Get recent requests
$recentRequests = db()->fetchAll('
    SELECT 
        endpoint,
        method,
        response_code,
        response_time_ms,
        ip_address,
        created_at
    FROM api_requests
    WHERE user_id = ?
    ORDER BY created_at DESC
    LIMIT 20
', [$userId]) ?? [];

// Prepare chart data
$chartDates = [];
$chartCounts = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $chartDates[] = date('M d', strtotime($date));
    $found = false;
    foreach ($dailyStats as $stat) {
        if ($stat['date'] === $date) {
            $chartCounts[] = (int)$stat['count'];
            $found = true;
            break;
        }
    }
    if (!$found) {
        $chartCounts[] = 0;
    }
}

$pageTitle = 'API Analytics';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?> - SnapLink Pro</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gray-50">
    <?php require_once ROOT_PATH . '/components/header.php'; ?>

    <div class="max-w-7xl mx-auto px-4 py-8">
        <!-- Header -->
        <div class="flex items-center justify-between mb-8">
            <div>
                <h1 class="text-3xl font-bold text-gray-900 mb-2">
                    <i class="fas fa-chart-line text-purple-600 mr-2"></i>API Analytics
                </h1>
                <p class="text-gray-600">Monitor your API usage and performance</p>
            </div>
            <a href="api-docs.php" class="px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition">
                <i class="fas fa-book mr-2"></i>View Documentation
            </a>
        </div>

        <!-- Stats Cards -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div class="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl shadow-lg p-6 text-white">
                <div class="flex items-center justify-between mb-2">
                    <div class="text-sm font-medium opacity-90">Total Requests</div>
                    <i class="fas fa-server text-2xl opacity-75"></i>
                </div>
                <div class="text-3xl font-bold"><?= number_format($stats['total_requests']) ?></div>
                <div class="text-xs opacity-75 mt-1">All time</div>
            </div>

            <div class="bg-gradient-to-br from-green-500 to-green-600 rounded-xl shadow-lg p-6 text-white">
                <div class="flex items-center justify-between mb-2">
                    <div class="text-sm font-medium opacity-90">Today's Requests</div>
                    <i class="fas fa-calendar-day text-2xl opacity-75"></i>
                </div>
                <div class="text-3xl font-bold"><?= number_format($todayRequests) ?></div>
                <div class="text-xs opacity-75 mt-1"><?= date('M d, Y') ?></div>
            </div>

            <div class="bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl shadow-lg p-6 text-white">
                <div class="flex items-center justify-between mb-2">
                    <div class="text-sm font-medium opacity-90">Active Days</div>
                    <i class="fas fa-fire text-2xl opacity-75"></i>
                </div>
                <div class="text-3xl font-bold"><?= $stats['active_days'] ?></div>
                <div class="text-xs opacity-75 mt-1">Days with activity</div>
            </div>

            <div class="bg-gradient-to-br from-pink-500 to-pink-600 rounded-xl shadow-lg p-6 text-white">
                <div class="flex items-center justify-between mb-2">
                    <div class="text-sm font-medium opacity-90">Last Request</div>
                    <i class="fas fa-clock text-2xl opacity-75"></i>
                </div>
                <div class="text-lg font-bold">
                    <?= $stats['last_request'] ? date('M d', strtotime($stats['last_request'])) : 'Never' ?>
                </div>
                <div class="text-xs opacity-75 mt-1">
                    <?= $stats['last_request'] ? date('h:i A', strtotime($stats['last_request'])) : '-' ?>
                </div>
            </div>
        </div>

        <!-- Chart -->
        <div class="bg-white rounded-xl shadow-sm p-6 mb-6 border border-gray-200">
            <h2 class="text-xl font-bold text-gray-900 mb-4">
                <i class="fas fa-chart-area text-purple-600 mr-2"></i>Last 7 Days
            </h2>
            <canvas id="requestsChart" height="80"></canvas>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <!-- Endpoint Statistics -->
            <div class="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
                <h2 class="text-xl font-bold text-gray-900 mb-4">
                    <i class="fas fa-plug text-purple-600 mr-2"></i>Requests by Endpoint
                </h2>
                <?php if (empty($endpointStats)): ?>
                    <div class="text-center py-8 text-gray-500">
                        <i class="fas fa-inbox text-4xl mb-3"></i>
                        <p>No API requests yet</p>
                    </div>
                <?php else: ?>
                    <div class="space-y-3">
                        <?php foreach ($endpointStats as $stat): ?>
                            <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                                <div class="flex-1">
                                    <div class="font-medium text-gray-900"><?= htmlspecialchars($stat['endpoint']) ?></div>
                                    <div class="text-sm text-gray-500">
                                        Avg: <?= number_format($stat['avg_response_time']) ?>ms
                                    </div>
                                </div>
                                <div class="text-right">
                                    <div class="text-2xl font-bold text-purple-600"><?= number_format($stat['count']) ?></div>
                                    <div class="text-xs text-gray-500">requests</div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Response Codes -->
            <div class="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
                <h2 class="text-xl font-bold text-gray-900 mb-4">
                    <i class="fas fa-check-circle text-purple-600 mr-2"></i>Response Codes
                </h2>
                <?php
                $responseCodes = db()->fetchAll('
                    SELECT response_code, COUNT(*) as count
                    FROM api_requests
                    WHERE user_id = ?
                    GROUP BY response_code
                    ORDER BY count DESC
                ', [$userId]) ?? [];
                ?>
                <?php if (empty($responseCodes)): ?>
                    <div class="text-center py-8 text-gray-500">
                        <i class="fas fa-inbox text-4xl mb-3"></i>
                        <p>No data available</p>
                    </div>
                <?php else: ?>
                    <div class="space-y-3">
                        <?php foreach ($responseCodes as $code): ?>
                            <?php
                            $codeClass = 'bg-gray-100 text-gray-800';
                            if ($code['response_code'] >= 200 && $code['response_code'] < 300) {
                                $codeClass = 'bg-green-100 text-green-800';
                            } elseif ($code['response_code'] >= 400) {
                                $codeClass = 'bg-red-100 text-red-800';
                            }
                            ?>
                            <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                                <div class="flex items-center gap-3">
                                    <span class="px-3 py-1 <?= $codeClass ?> rounded-full font-mono font-bold text-sm">
                                        <?= $code['response_code'] ?>
                                    </span>
                                    <span class="text-gray-600">
                                        <?php
                                        $messages = [
                                            200 => 'OK', 201 => 'Created', 400 => 'Bad Request',
                                            401 => 'Unauthorized', 403 => 'Forbidden', 404 => 'Not Found',
                                            409 => 'Conflict', 500 => 'Server Error'
                                        ];
                                        echo $messages[$code['response_code']] ?? 'Unknown';
                                        ?>
                                    </span>
                                </div>
                                <div class="text-xl font-bold text-gray-900"><?= number_format($code['count']) ?></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Recent Requests -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div class="p-6 border-b border-gray-200">
                <h2 class="text-xl font-bold text-gray-900">
                    <i class="fas fa-history text-purple-600 mr-2"></i>Recent Requests
                </h2>
            </div>
            <div class="overflow-x-auto">
                <?php if (empty($recentRequests)): ?>
                    <div class="text-center py-12 text-gray-500">
                        <i class="fas fa-inbox text-5xl mb-4"></i>
                        <p class="text-lg font-medium mb-2">No API requests yet</p>
                        <p class="text-sm">Start using the API to see analytics here</p>
                        <a href="api-docs.php" class="inline-block mt-4 px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition">
                            View API Docs
                        </a>
                    </div>
                <?php else: ?>
                    <table class="w-full text-sm">
                        <thead class="bg-gray-50 border-b border-gray-200">
                            <tr>
                                <th class="text-left py-3 px-4 font-semibold text-gray-900">Endpoint</th>
                                <th class="text-left py-3 px-4 font-semibold text-gray-900">Method</th>
                                <th class="text-left py-3 px-4 font-semibold text-gray-900">Status</th>
                                <th class="text-left py-3 px-4 font-semibold text-gray-900">Response Time</th>
                                <th class="text-left py-3 px-4 font-semibold text-gray-900">IP Address</th>
                                <th class="text-left py-3 px-4 font-semibold text-gray-900">Time</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            <?php foreach ($recentRequests as $req): ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="py-3 px-4 font-mono text-xs"><?= htmlspecialchars($req['endpoint']) ?></td>
                                    <td class="py-3 px-4">
                                        <span class="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs font-medium">
                                            <?= htmlspecialchars($req['method']) ?>
                                        </span>
                                    </td>
                                    <td class="py-3 px-4">
                                        <?php
                                        $statusClass = 'bg-gray-100 text-gray-800';
                                        if ($req['response_code'] >= 200 && $req['response_code'] < 300) {
                                            $statusClass = 'bg-green-100 text-green-800';
                                        } elseif ($req['response_code'] >= 400) {
                                            $statusClass = 'bg-red-100 text-red-800';
                                        }
                                        ?>
                                        <span class="px-2 py-1 <?= $statusClass ?> rounded text-xs font-medium">
                                            <?= $req['response_code'] ?>
                                        </span>
                                    </td>
                                    <td class="py-3 px-4 text-gray-600"><?= $req['response_time_ms'] ?>ms</td>
                                    <td class="py-3 px-4 font-mono text-xs text-gray-600"><?= htmlspecialchars($req['ip_address']) ?></td>
                                    <td class="py-3 px-4 text-gray-600"><?= date('M d, H:i', strtotime($req['created_at'])) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        // Chart
        const ctx = document.getElementById('requestsChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?= json_encode($chartDates) ?>,
                datasets: [{
                    label: 'API Requests',
                    data: <?= json_encode($chartCounts) ?>,
                    borderColor: 'rgb(147, 51, 234)',
                    backgroundColor: 'rgba(147, 51, 234, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>
