﻿<?php
/**
 * User Settings Page
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

require_login();

$user = current_user();
$flash = get_flash();

// Get full user data
$userData = db()->fetchOne('SELECT * FROM users WHERE id = ?', [$user['id']]);

// Get API keys
$apiKeys = db()->fetchAll('SELECT * FROM api_keys WHERE user_id = ? ORDER BY created_at DESC', [$user['id']]);

// Handle AJAX actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'update_profile':
            $name = sanitize($_POST['name'] ?? '');
            $email = sanitize($_POST['email'] ?? '');
            $theme = sanitize($_POST['theme'] ?? 'light');
            
            if (empty($name) || empty($email)) {
                json_response(['error' => 'Name and email are required'], 400);
            }
            
            // Check if email is taken by another user
            $existing = db()->fetchOne('SELECT id FROM users WHERE email = ? AND id != ?', [$email, $user['id']]);
            if ($existing) {
                json_response(['error' => 'Email is already taken'], 400);
            }
            
            db()->execute(
                'UPDATE users SET name = ?, email = ?, theme = ? WHERE id = ?',
                [$name, $email, $theme, $user['id']]
            );
            
            // Update session
            $_SESSION['user_name'] = $name;
            $_SESSION['user_email'] = $email;
            $_SESSION['user_theme'] = $theme;
            
            json_response(['success' => true, 'message' => 'Profile updated successfully']);
            break;
            
        case 'update_bio':
            $bio = sanitize($_POST['bio'] ?? '');
            $bioTitle = sanitize($_POST['bio_title'] ?? '');
            
            db()->execute(
                'UPDATE users SET bio = ?, bio_title = ? WHERE id = ?',
                [$bio, $bioTitle, $user['id']]
            );
            
            json_response(['success' => true, 'message' => 'Bio updated successfully']);
            break;
            
        case 'change_password':
            $currentPassword = $_POST['current_password'] ?? '';
            $newPassword = $_POST['new_password'] ?? '';
            $confirmPassword = $_POST['confirm_password'] ?? '';
            
            if (empty($currentPassword) || empty($newPassword)) {
                json_response(['error' => 'All fields are required'], 400);
            }
            
            if (strlen($newPassword) < 6) {
                json_response(['error' => 'New password must be at least 6 characters'], 400);
            }
            
            if ($newPassword !== $confirmPassword) {
                json_response(['error' => 'Passwords do not match'], 400);
            }
            
            // Verify current password
            if (!password_verify($currentPassword, $userData['password'])) {
                json_response(['error' => 'Current password is incorrect'], 400);
            }
            
            $newHash = password_hash($newPassword, PASSWORD_BCRYPT, ['cost' => HASH_COST]);
            db()->execute('UPDATE users SET password = ? WHERE id = ?', [$newHash, $user['id']]);
            
            json_response(['success' => true, 'message' => 'Password changed successfully']);
            break;
            
        case 'generate_api_key':
            $keyName = sanitize($_POST['key_name'] ?? 'Default');
            $apiKey = bin2hex(random_bytes(32));
            
            db()->insert(
                'INSERT INTO api_keys (user_id, api_key, name) VALUES (?, ?, ?)',
                [$user['id'], $apiKey, $keyName]
            );
            
            json_response(['success' => true, 'apiKey' => $apiKey]);
            break;
            
        case 'delete_api_key':
            $keyId = $_POST['key_id'] ?? null;
            db()->execute('DELETE FROM api_keys WHERE id = ? AND user_id = ?', [$keyId, $user['id']]);
            json_response(['success' => true]);
            break;
            
        default:
            json_response(['error' => 'Invalid action'], 400);
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - SnapLink Pro</title>
    <?php meta_canonical('php-version/settings.php'); ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Inter', 'sans-serif'] },
                    colors: { brand: { purple: '#7F00FF', pink: '#E100FF' } }
                }
            }
        }
    </script>
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-50 min-h-screen">
    <!-- Top Bar -->
    <header class="bg-white border-b border-gray-200 px-4 lg:px-8 py-4">
        <div class="max-w-4xl mx-auto flex items-center justify-between">
            <div class="flex items-center gap-4">
                <a href="dashboard.php" class="text-gray-500 hover:text-purple-600">
                    <i class="fas fa-arrow-left"></i>
                </a>
                <h1 class="text-xl font-bold text-gray-900">Settings</h1>
            </div>
        </div>
    </header>

    <div class="max-w-4xl mx-auto p-4 lg:p-8">
        <!-- Profile Settings -->
        <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm mb-6">
            <h2 class="text-lg font-bold text-gray-900 mb-4">Profile Settings</h2>
            <form id="profileForm" class="space-y-4">
                <input type="hidden" name="action" value="update_profile">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                        <input type="text" name="name" value="<?= htmlspecialchars($userData['name']) ?>" required
                            class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                        <input type="email" name="email" value="<?= htmlspecialchars($userData['email']) ?>" required
                            class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500">
                    </div>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Theme</label>
                    <select name="theme" class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500">
                        <option value="light" <?= ($userData['theme'] ?? 'light') === 'light' ? 'selected' : '' ?>>Light</option>
                        <option value="dark" <?= ($userData['theme'] ?? 'light') === 'dark' ? 'selected' : '' ?>>Dark</option>
                    </select>
                </div>
                <div class="flex justify-end">
                    <button type="submit" class="px-6 py-3 bg-purple-600 text-white font-semibold rounded-xl hover:bg-purple-700 transition">
                        Save Changes
                    </button>
                </div>
            </form>
        </div>

        <!-- Bio Link Settings -->
        <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm mb-6">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-lg font-bold text-gray-900">Bio Link Page</h2>
                <a href="<?= base_url('@' . urlencode($userData['name'])) ?>" target="_blank" 
                   class="text-sm text-purple-600 hover:text-purple-700 font-medium">
                    <i class="fas fa-external-link-alt mr-1"></i>View Your Bio
                </a>
            </div>
            <form id="bioForm" class="space-y-4">
                <input type="hidden" name="action" value="update_bio">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Bio Title/Headline</label>
                    <input type="text" name="bio_title" value="<?= htmlspecialchars($userData['bio_title'] ?? '') ?>" 
                           placeholder="e.g., Content Creator | Developer | Entrepreneur"
                           class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Bio Description</label>
                    <textarea name="bio" rows="3" placeholder="Tell your visitors about yourself..."
                              class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500"><?= htmlspecialchars($userData['bio'] ?? '') ?></textarea>
                    <p class="text-xs text-gray-500 mt-1">This will appear on your bio page at <?= base_url('@' . htmlspecialchars($userData['name'])) ?></p>
                </div>
                <div class="flex justify-end">
                    <button type="submit" class="px-6 py-3 bg-purple-600 text-white font-semibold rounded-xl hover:bg-purple-700 transition">
                        Save Bio
                    </button>
                </div>
            </form>
        </div>

        <!-- Change Password -->
        <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm mb-6">
            <h2 class="text-lg font-bold text-gray-900 mb-4">Change Password</h2>
            <form id="passwordForm" class="space-y-4">
                <input type="hidden" name="action" value="change_password">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Current Password</label>
                    <input type="password" name="current_password" required
                        class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500">
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">New Password</label>
                        <input type="password" name="new_password" required minlength="6"
                            class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Confirm New Password</label>
                        <input type="password" name="confirm_password" required
                            class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500">
                    </div>
                </div>
                <div class="flex justify-end">
                    <button type="submit" class="px-6 py-3 bg-purple-600 text-white font-semibold rounded-xl hover:bg-purple-700 transition">
                        Update Password
                    </button>
                </div>
            </form>
        </div>

        <!-- API Keys -->
        <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm mb-6">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-lg font-bold text-gray-900">API Keys</h2>
                <button onclick="generateApiKey()" class="px-4 py-2 bg-purple-600 text-white text-sm font-semibold rounded-lg hover:bg-purple-700 transition">
                    <i class="fas fa-plus mr-1"></i> Generate Key
                </button>
            </div>
            
            <div id="newKeyAlert" class="hidden mb-4 p-4 bg-green-50 border border-green-200 rounded-xl">
                <p class="text-green-700 text-sm mb-2"><strong>New API Key Generated!</strong> Copy it now - it won't be shown again.</p>
                <div class="flex items-center gap-2">
                    <code id="newKeyValue" class="flex-1 p-2 bg-white rounded border font-mono text-sm"></code>
                    <button onclick="copyApiKey()" class="p-2 text-green-600 hover:text-green-700">
                        <i class="far fa-copy"></i>
                    </button>
                </div>
            </div>
            
            <?php if (empty($apiKeys)): ?>
                <p class="text-gray-500 text-center py-8">No API keys yet. Generate one to integrate with your apps.</p>
            <?php else: ?>
                <div class="space-y-3">
                    <?php foreach ($apiKeys as $key): ?>
                        <div class="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                            <div>
                                <p class="font-medium text-gray-900"><?= htmlspecialchars($key['name']) ?></p>
                                <p class="text-sm text-gray-500 font-mono"><?= substr($key['api_key'], 0, 12) ?>...<?= substr($key['api_key'], -4) ?></p>
                            </div>
                            <div class="flex items-center gap-4">
                                <span class="text-xs text-gray-400"><?= $key['requests_today'] ?> requests today</span>
                                <button onclick="deleteApiKey(<?= $key['id'] ?>)" class="text-gray-400 hover:text-red-600">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Account Info -->
        <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
            <h2 class="text-lg font-bold text-gray-900 mb-4">Account Information</h2>
            <div class="grid grid-cols-2 gap-4">
                <div class="p-4 bg-gray-50 rounded-xl">
                    <p class="text-sm text-gray-500">Current Plan</p>
                    <p class="font-bold text-gray-900 capitalize"><?= $userData['plan'] ?? 'Free' ?></p>
                </div>
                <div class="p-4 bg-gray-50 rounded-xl">
                    <p class="text-sm text-gray-500">Member Since</p>
                    <p class="font-bold text-gray-900"><?= date('M j, Y', strtotime($userData['created_at'])) ?></p>
                </div>
            </div>
        </div>
    </div>

    <script>
        async function submitForm(form, action) {
            const formData = new FormData(form);
            
            try {
                const res = await fetch('settings.php', { method: 'POST', body: formData });
                const data = await res.json();
                
                if (data.success) {
                    alert(data.message || 'Success!');
                    if (action === 'change_password') {
                        form.reset();
                    }
                } else {
                    alert(data.error || 'Action failed');
                }
            } catch (err) {
                alert('An error occurred');
            }
        }

        document.getElementById('profileForm').addEventListener('submit', function(e) {
            e.preventDefault();
            submitForm(this, 'update_profile');
        });

        document.getElementById('passwordForm').addEventListener('submit', function(e) {
            e.preventDefault();
            submitForm(this, 'change_password');
        });

        async function generateApiKey() {
            const name = prompt('Enter a name for this API key:') || 'Default';
            
            const formData = new FormData();
            formData.append('action', 'generate_api_key');
            formData.append('key_name', name);
            
            try {
                const res = await fetch('settings.php', { method: 'POST', body: formData });
                const data = await res.json();
                
                if (data.success) {
                    document.getElementById('newKeyValue').textContent = data.apiKey;
                    document.getElementById('newKeyAlert').classList.remove('hidden');
                    setTimeout(() => location.reload(), 5000);
                } else {
                    alert(data.error || 'Failed to generate key');
                }
            } catch (err) {
                alert('An error occurred');
            }
        }

        function copyApiKey() {
            const key = document.getElementById('newKeyValue').textContent;
            navigator.clipboard.writeText(key).then(() => alert('Copied!'));
        }

        async function deleteApiKey(id) {
            if (!confirm('Delete this API key? This cannot be undone.')) return;
            
            const formData = new FormData();
            formData.append('action', 'delete_api_key');
            formData.append('key_id', id);
            
            const res = await fetch('settings.php', { method: 'POST', body: formData });
            const data = await res.json();
            
            if (data.success) location.reload();
            else alert(data.error || 'Failed to delete');
        }

        document.getElementById('bioForm').addEventListener('submit', function(e) {
            e.preventDefault();
            submitForm(this, 'update_bio');
        });
    </script>

    <?php require_once ROOT_PATH . '/components/cookie-consent.php'; ?>
</body>
</html>
