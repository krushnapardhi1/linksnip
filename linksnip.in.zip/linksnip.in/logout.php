<?php
/**
 * Logout Handler
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';

// Destroy session
session_unset();
session_destroy();

// Clear session cookie
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Redirect to login
header("Location: login.php");
exit;
