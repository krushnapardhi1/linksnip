﻿<?php
/**
 * Pricing Page
 * Display subscription plans with Razorpay & Stripe support
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

require_login();
$user = current_user();
$db = db()->getConnection();

// Fetch plans
$stmt = $db->query("SELECT * FROM subscription_plans WHERE is_active = 1 ORDER BY price_monthly ASC");
$plans = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get user's current subscription
$stmt = $db->prepare("SELECT * FROM user_subscriptions WHERE user_id = ? AND status = 'active' ORDER BY id DESC LIMIT 1");
$stmt->execute([$user['id']]);
$currentSub = $stmt->fetch(PDO::FETCH_ASSOC);
$currentPlanId = $currentSub['plan_id'] ?? 1;

// Get current plan details
$stmt = $db->prepare("SELECT * FROM subscription_plans WHERE id = ?");
$stmt->execute([$currentPlanId]);
$activePlan = $stmt->fetch(PDO::FETCH_ASSOC);

// Get payment gateway settings
$settings = [];
$rows = db()->fetchAll("SELECT * FROM site_settings WHERE key_name LIKE 'razorpay%' OR key_name LIKE 'stripe%'");
foreach ($rows as $row) {
    $settings[$row['key_name']] = $row['value'];
}

$razorpayEnabled = !empty($settings['razorpay_enabled']) && $settings['razorpay_enabled'] == '1';
$razorpayKeyId = $settings['razorpay_key_id'] ?? '';
$stripeEnabled = !empty($settings['stripe_publishable_key']);

$pageTitle = "Pricing - SnapLink Pro";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <?php if ($razorpayEnabled): ?>
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <?php endif; ?>
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gray-50">

    <!-- Navbar -->
    <nav class="bg-white shadow-sm border-b sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <a href="index.php" class="flex items-center gap-2">
                    <div class="w-10 h-10 rounded-xl bg-purple-600 flex items-center justify-center text-white">
                        <i class="fas fa-link"></i>
                    </div>
                    <span class="text-xl font-bold">SnapLink Pro</span>
                </a>
                
                <div class="flex items-center gap-4">
                    <a href="dashboard.php" class="text-gray-700 hover:text-purple-600">
                        <i class="fas fa-arrow-left mr-2"></i>Dashboard
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Header -->
    <div class="bg-gradient-to-r from-purple-700 to-pink-600 py-16 text-center text-white">
        <h1 class="text-4xl font-bold mb-4">Simple, Transparent Pricing</h1>
        <p class="text-xl text-purple-100 max-w-2xl mx-auto px-4">Choose the plan that fits your needs. Upgrade anytime.</p>
        
        <!-- Payment Method Badges -->
        <div class="flex items-center justify-center gap-4 mt-6">
            <?php if ($razorpayEnabled): ?>
                <span class="px-3 py-1 bg-white/20 rounded-full text-sm backdrop-blur-sm"><i class="fas fa-rupee-sign mr-1"></i>Razorpay</span>
            <?php endif; ?>
            <?php if ($stripeEnabled): ?>
                <span class="px-3 py-1 bg-white/20 rounded-full text-sm backdrop-blur-sm"><i class="fab fa-stripe-s mr-1"></i>Stripe</span>
            <?php endif; ?>
        </div>
    </div>

    <!-- Pricing Cards -->
    <div class="max-w-7xl mx-auto px-4 py-12 -mt-10">
        <div class="grid md:grid-cols-3 gap-8">
            <?php foreach ($plans as $plan): 
                $features = json_decode($plan['features'], true) ?: [];
                $isCurrent = $plan['id'] == $currentPlanId;
                $isFree = $plan['price_monthly'] == 0;
                $isPopular = strtolower($plan['name']) === 'pro';
            ?>
                <div class="bg-white rounded-2xl shadow-xl overflow-hidden transform hover:-translate-y-1 transition-all duration-300 relative border <?= $isCurrent ? 'border-purple-500 ring-2 ring-purple-100' : ($isPopular ? 'border-purple-300' : 'border-gray-100') ?>">
                    <?php if ($isCurrent): ?>
                        <div class="absolute top-0 right-0 bg-purple-600 text-white text-xs font-bold px-3 py-1 rounded-bl-lg">
                            CURRENT PLAN
                        </div>
                    <?php elseif ($isPopular): ?>
                        <div class="absolute top-0 right-0 bg-pink-600 text-white text-xs font-bold px-3 py-1 rounded-bl-lg">
                            POPULAR
                        </div>
                    <?php endif; ?>

                    <div class="p-8">
                        <h3 class="text-xl font-bold text-gray-900 mb-2"><?= htmlspecialchars($plan['name']) ?></h3>
                        <p class="text-gray-500 text-sm mb-6"><?= htmlspecialchars($plan['description']) ?></p>
                        
                        <div class="flex items-baseline mb-6">
                            <?php if ($razorpayEnabled): ?>
                                <span class="text-4xl font-extrabold text-gray-900">₹<?= number_format($plan['price_monthly'] * 83, 0) ?></span>
                            <?php else: ?>
                                <span class="text-4xl font-extrabold text-gray-900">$<?= number_format($plan['price_monthly'], 2) ?></span>
                            <?php endif; ?>
                            <span class="text-gray-500 ml-1">/month</span>
                        </div>
                        
                        <div class="space-y-4 mb-8">
                            <?php foreach ($features as $feature): ?>
                                <div class="flex items-start gap-3">
                                    <div class="flex-shrink-0 w-5 h-5 rounded-full bg-green-100 text-green-600 flex items-center justify-center mt-0.5">
                                        <i class="fas fa-check text-xs"></i>
                                    </div>
                                    <span class="text-gray-600 text-sm"><?= htmlspecialchars($feature) ?></span>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <?php if ($isCurrent): ?>
                            <button disabled class="w-full py-3 bg-gray-100 text-gray-400 font-bold rounded-xl cursor-not-allowed">
                                Current Plan
                            </button>
                        <?php elseif ($isFree): ?>
                            <button disabled class="w-full py-3 bg-gray-100 text-gray-500 font-bold rounded-xl">
                                Your Default
                            </button>
                        <?php else: ?>
                            <!-- Payment Options -->
                            <div class="space-y-2">
                                <?php if ($razorpayEnabled): ?>
                                    <button onclick="razorpayCheckout(<?= $plan['id'] ?>)" class="w-full py-3 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 transition shadow-lg shadow-blue-200 flex items-center justify-center gap-2">
                                        <i class="fas fa-rupee-sign"></i>
                                        Pay with Razorpay
                                    </button>
                                <?php endif; ?>
                                
                                <?php if ($stripeEnabled): ?>
                                    <button onclick="stripeCheckout(<?= $plan['id'] ?>)" class="w-full py-3 <?= $razorpayEnabled ? 'bg-gray-100 text-gray-700 hover:bg-gray-200' : 'bg-purple-600 text-white hover:bg-purple-700 shadow-lg shadow-purple-200' ?> font-bold rounded-xl transition flex items-center justify-center gap-2">
                                        <i class="fab fa-stripe-s"></i>
                                        Pay with Stripe (USD)
                                    </button>
                                <?php endif; ?>
                                
                                <?php if (!$razorpayEnabled && !$stripeEnabled): ?>
                                    <button disabled class="w-full py-3 bg-gray-100 text-gray-400 font-bold rounded-xl cursor-not-allowed">
                                        Payment Not Configured
                                    </button>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <div class="mt-12 text-center">
             <p class="text-gray-500">Need a custom plan? <a href="contact.php" class="text-purple-600 font-semibold">Contact Sales</a></p>
        </div>
    </div>

    <!-- Processing Modal -->
    <div id="processing" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
        <div class="bg-white rounded-2xl p-8 max-w-sm w-full text-center">
            <div class="animate-spin w-12 h-12 border-4 border-purple-600 border-t-transparent rounded-full mx-auto mb-4"></div>
            <h3 class="text-xl font-bold text-gray-900 mb-2">Processing...</h3>
            <p id="processingText" class="text-gray-500">Initializing payment</p>
        </div>
    </div>

    <script>
        // Razorpay Checkout
        async function razorpayCheckout(planId) {
            showProcessing('Creating order...');
            
            try {
                const response = await fetch('api/razorpay-create-order.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ plan_id: planId })
                });
                
                const data = await response.json();
                
                if (!data.success) {
                    throw new Error(data.error || 'Failed to create order');
                }
                
                hideProcessing();
                
                // Open Razorpay Checkout
                const options = {
                    key: data.key_id,
                    amount: data.amount,
                    currency: data.currency,
                    name: data.name,
                    description: data.description,
                    order_id: data.order_id,
                    prefill: data.prefill,
                    theme: {
                        color: '#7F00FF'
                    },
                    handler: async function(response) {
                        showProcessing('Verifying payment...');
                        
                        // Verify payment
                        const verifyResponse = await fetch('api/razorpay-verify.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({
                                razorpay_order_id: response.razorpay_order_id,
                                razorpay_payment_id: response.razorpay_payment_id,
                                razorpay_signature: response.razorpay_signature
                            })
                        });
                        
                        const result = await verifyResponse.json();
                        
                        if (result.success) {
                            alert('Payment successful! Your plan has been upgraded.');
                            window.location.href = result.redirect || 'billing.php';
                        } else {
                            hideProcessing();
                            alert(result.error || 'Payment verification failed');
                        }
                    },
                    modal: {
                        ondismiss: function() {
                            hideProcessing();
                        }
                    }
                };
                
                const rzp = new Razorpay(options);
                rzp.open();
                
            } catch (error) {
                hideProcessing();
                alert(error.message || 'An error occurred. Please try again.');
            }
        }

        // Stripe Checkout
        async function stripeCheckout(planId) {
            showProcessing('Redirecting to Stripe...');
            
            try {
                const response = await fetch('api/create-checkout-session.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ plan_id: planId })
                });
                
                const result = await response.json();
                
                if (result.url) {
                    window.location.href = result.url;
                } else {
                    throw new Error(result.error || 'Failed to initiate checkout');
                }
            } catch (error) {
                hideProcessing();
                alert(error.message || 'An error occurred. Please try again.');
            }
        }

        function showProcessing(text) {
            document.getElementById('processingText').textContent = text;
            document.getElementById('processing').classList.remove('hidden');
        }

        function hideProcessing() {
            document.getElementById('processing').classList.add('hidden');
        }
    </script>
</body>
</html>
