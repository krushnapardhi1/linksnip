<?php
/**
 * Stripe Client Wrapper
 * Handles Stripe API interactions
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';

class StripeClient {
    private $stripe;
    private $currency;

    public function __construct() {
        $settings = $this->getSettings();
        $apiKey = $settings['stripe_secret_key'] ?? '';
        $this->currency = $settings['stripe_currency'] ?? 'USD';

        if (empty($apiKey)) {
            // Keys not configured
            return;
        }

        // Check if Stripe library is installed
        if (!class_exists('Stripe\Stripe')) {
            // Try connection via autoloader if not globally available
            if (file_exists(ROOT_PATH . '/vendor/autoload.php')) {
                require_once ROOT_PATH . '/vendor/autoload.php';
            }
        }

        if (class_exists('Stripe\Stripe')) {
            \Stripe\Stripe::setApiKey($apiKey);
            $this->stripe = new \Stripe\StripeClient($apiKey);
        }
    }

    public function isConfigured() {
        return !empty($this->stripe);
    }

    public function createCheckoutSession($userId, $userEmail, $priceId, $successUrl, $cancelUrl) {
        if (!$this->isConfigured()) return ['error' => 'Stripe not configured'];

        try {
            $session = \Stripe\Checkout\Session::create([
                'customer_email' => $userEmail,
                'payment_method_types' => ['card'],
                'line_items' => [[
                    'price' => $priceId,
                    'quantity' => 1,
                ]],
                'mode' => 'subscription', // or payment for one-time
                'success_url' => $successUrl,
                'cancel_url' => $cancelUrl,
                'metadata' => [
                    'user_id' => $userId
                ],
            ]);
            return ['url' => $session->url];
        } catch (Exception $e) {
            return ['error' => $e->getMessage()];
        }
    }

    public function createCustomerPortalSession($customerId, $returnUrl) {
        if (!$this->isConfigured()) return ['error' => 'Stripe not configured'];

        try {
            $session = \Stripe\BillingPortal\Session::create([
                'customer' => $customerId,
                'return_url' => $returnUrl,
            ]);
            return ['url' => $session->url];
        } catch (Exception $e) {
            return ['error' => $e->getMessage()];
        }
    }
    
    public function getSettings() {
        $db = Database::getInstance()->getConnection();
        $stmt = $db->query("SELECT * FROM site_settings LIMIT 1");
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
    }
}
