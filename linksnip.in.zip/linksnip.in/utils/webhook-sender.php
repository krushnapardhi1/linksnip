﻿<?php
/**
 * Webhook Sender Utility
 * Triggers webhooks when events occur
 */

class WebhookSender {
    
    /**
     * Trigger webhooks for a specific event
     */
    public static function trigger($event_type, $url_id, $url_data = []) {
        try {
            $db = db()->getConnection();
            
            // Get webhooks for this event and URL
            $stmt = $db->prepare("
                SELECT w.* FROM webhooks w
                WHERE w.event_type = ? 
                AND w.is_active = 1
                AND (w.url_id = ? OR w.url_id IS NULL)
            ");
            $stmt->execute([$event_type, $url_id]);
            $webhooks = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($webhooks as $webhook) {
                // Check milestone condition
                if ($event_type === 'milestone') {
                    $clicks = $url_data['clicks'] ?? 0;
                    if ($clicks != $webhook['milestone']) {
                        continue; // Skip if clicks don't match milestone
                    }
                }
                
                self::send($webhook['webhook_url'], $event_type, $url_data);
            }
            
        } catch (Exception $e) {
            error_log("Webhook Trigger Error: " . $e->getMessage());
        }
    }
    
    /**
     * Send HTTP POST request to webhook URL
     */
    private static function send($webhook_url, $event, $link_data) {
        $payload = [
            'event' => $event,
            'link' => $link_data,
            'timestamp' => date('c')
        ];
        
        // Use cURL to send async webhook
        $ch = curl_init($webhook_url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'User-Agent: SnapLink Pro-Webhook/1.0'
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5); // 5 second timeout
        
        curl_exec($ch);
        curl_close($ch);
    }
    
    /**
     * Trigger first click webhook
     */
    public static function onFirstClick($url_id, $url_data) {
        self::trigger('first_click', $url_id, $url_data);
    }
    
    /**
     * Trigger milestone webhook
     */
    public static function onMilestone($url_id, $url_data) {
        self::trigger('milestone', $url_id, $url_data);
    }
    
    /**
     * Trigger expiry webhook
     */
    public static function onExpiry($url_id, $url_data) {
        self::trigger('expiry', $url_id, $url_data);
    }
}
