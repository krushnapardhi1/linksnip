﻿# Cloudflare Setup for snaplink.pro

Quick setup guide specifically for your **snaplink.pro** domain.

## Step 1: Add Site to Cloudflare

1. Go to https://dash.cloudflare.com/
2. Click **+ Add a Site**
3. Enter: `snaplink.pro`
4. Select **Free Plan**
5. Click **Continue**

## Step 2: DNS Records

Cloudflare will scan your DNS. Add/verify these records:

### Find Your InfinityFree IP

First, get your InfinityFree server IP:

**Method 1 - Check InfinityFree Panel:**
1. Login to InfinityFree
2. Go to your website details
3. Look for "Server IP" or "Website IP"

**Method 2 - Ping your infinityfreeapp subdomain:**
```bash
# Windows CMD/PowerShell
ping yoursite.infinityfreeapp.com

# Note the IP address shown
```

### Add DNS Records in Cloudflare

| Type | Name | Content | Proxy Status | TTL |
|------|------|---------|--------------|-----|
| A | @ | [Your InfinityFree IP] | Proxied 🟠 | Auto |
| A | www | [Your InfinityFree IP] | Proxied 🟠 | Auto |

**Example IP:** `185.27.134.XXX` (your actual IP)

Make sure the cloud icon is **ORANGE** (Proxied) for both records!

## Step 3: Update Nameservers at GoDaddy

Cloudflare will show you 2 nameservers like:

```
aria.ns.cloudflare.com
nash.ns.cloudflare.com
```

### Update at GoDaddy:

1. Login to https://account.godaddy.com/
2. Click **My Products**
3. Find **snaplink.pro** → Click **DNS** or **Manage DNS**
4. Scroll to **Nameservers** section
5. Click **Change Nameservers**
6. Select **"I'll use my own nameservers"**
7. Enter Cloudflare nameservers:
   - Nameserver 1: `aria.ns.cloudflare.com`
   - Nameserver 2: `nash.ns.cloudflare.com`
8. Click **Save**

⏱️ **Wait 1-2 hours** (can take up to 24 hours)

## Step 4: Cloudflare Configuration

### 4.1 SSL/TLS Settings

1. Go to **SSL/TLS** tab
2. Select encryption mode: **Full**
3. Go to **Edge Certificates** (under SSL/TLS)
   - ✅ Enable **Always Use HTTPS**
   - ✅ Enable **Automatic HTTPS Rewrites**
   - ✅ Enable **Minimum TLS Version** → 1.2

### 4.2 Speed Optimization

1. Go to **Speed** → **Optimization**
2. Enable:
   - ✅ **Auto Minify** → Check HTML, CSS, JavaScript
   - ✅ **Brotli**
   - ✅ **Early Hints**
   - ✅ **HTTP/2** and **HTTP/3**
3. **Rocket Loader**: Start with OFF (test later)

### 4.3 Caching

1. Go to **Caching** → **Configuration**
2. **Caching Level**: Standard
3. **Browser Cache TTL**: 4 hours

**Create Cache Rule:**
1. Go to **Caching** → **Cache Rules**
2. Click **Create Rule**
3. Rule name: `Cache Static Assets`
4. When incoming requests match:
   ```
   URI Path ends with ".css" OR
   URI Path ends with ".js" OR
   URI Path ends with ".jpg" OR
   URI Path ends with ".png" OR
   URI Path ends with ".gif" OR
   URI Path ends with ".ico" OR
   URI Path ends with ".woff" OR
   URI Path ends with ".woff2"
   ```
5. Then → Cache eligibility: **Eligible for cache**
6. Edge TTL: **1 month**
7. Click **Deploy**

### 4.4 Page Rules

1. Go to **Rules** → **Page Rules**
2. Click **Create Page Rule**

**Rule 1 - Bypass Admin/API:**
```
URL pattern: *snaplink.pro/admin/* OR *snaplink.pro/api/*
Settings:
  - Cache Level: Bypass
```

**Rule 2 - Cache Homepage:**
```
URL pattern: *snaplink.pro/*
Settings:
  - Cache Level: Standard
```

### 4.5 Security

1. Go to **Security** → **Settings**
2. **Security Level**: Medium
3. Go to **Bots**
4. Enable **Bot Fight Mode**
5. Go to **WAF** (Web Application Firewall)
6. Enable **OWASP Core Ruleset**

## Step 5: Verify Setup

### Check DNS Propagation
Visit: https://www.whatsmydns.net/
- Enter: `snaplink.pro`
- Type: `A`
- Should show Cloudflare IPs worldwide (like `104.21.x.x` or `172.67.x.x`)

### Check Cloudflare is Active
```bash
# Windows - Check if Cloudflare is serving your site
nslookup snaplink.pro

# Should return Cloudflare IPs, not InfinityFree IPs
```

### Test SSL Certificate
1. Visit: `https://snaplink.pro`
2. Click padlock 🔒 in browser
3. Should say "Certificate issued by: Cloudflare"

### Verify Headers
1. Open DevTools (F12)
2. Go to Network tab
3. Refresh page
4. Click any request
5. Check Response Headers for:
   ```
   cf-cache-status: HIT or MISS
   cf-ray: [some ID]
   server: cloudflare
   ```

### Test Performance
Visit: https://www.webpagetest.org/
- Enter: `https://snaplink.pro`
- Location: Choose closest to India
- Click **Start Test**
- Check load time and grades

## Step 6: Update SnapLink Pro for Cloudflare

### Get Real Visitor IPs

Update `config/config.php` - add this function:

```php
/**
 * Get real client IP (Cloudflare compatible)
 */
function get_client_ip() {
    // Cloudflare passes real IP in this header
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        return $_SERVER['HTTP_CF_CONNECTING_IP'];
    }
    
    // Fallback for other proxies
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        return trim($ips[0]);
    }
    
    // Direct connection
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}
```

Use this function instead of `$_SERVER['REMOTE_ADDR']` in your code.

### Update .htaccess

Add to the top of your `.htaccess`:

```apache
# Cloudflare Compatibility
<IfModule mod_rewrite.c>
    RewriteEngine On
    
    # Force HTTPS via Cloudflare
    RewriteCond %{HTTP:CF-Visitor} '"scheme":"http"'
    RewriteRule ^(.*)$ https://%{HTTP_HOST}/$1 [R=301,L]
</IfModule>
```

## Timeline

| Time | What Happens |
|------|--------------|
| 0 min | Nameservers changed at GoDaddy |
| 15-30 min | DNS starts propagating |
| 1-2 hours | Most locations see Cloudflare |
| 24-48 hours | Full global propagation |
| After propagation | SSL certificate active |

## Quick Stats

Once live, check Cloudflare Analytics:

1. Go to **Analytics & Logs**
2. View:
   - **Traffic**: Requests, bandwidth saved
   - **Security**: Threats blocked
   - **Performance**: Cache hit ratio
   - **DNS**: Query volume

Target metrics:
- Cache Hit Ratio: >80%
- Bandwidth Saved: >30%
- Page Load Time: <2 seconds

## After Setup

### Daily (First Week)
- Check if site loads properly
- Monitor Cloudflare dashboard for errors
- Test short URLs work

### Weekly
- Review analytics
- Check cache hit ratio
- Monitor threat statistics

### Monthly
- Purge cache if major updates made
- Review firewall rules
- Update Page Rules if needed

## Troubleshooting

### DNS Not Propagating
- Use `nslookup snaplink.pro 1.1.1.1` to check Cloudflare's DNS
- Wait longer (up to 48 hours)
- Clear local DNS cache: `ipconfig /flushdns` (Windows)

### "Too Many Redirects" Error
- Change SSL mode from **Flexible** to **Full**
- Clear browser cache
- Wait 5 minutes for changes to propagate

### Site Shows Old Content
- Purge Cloudflare cache:
  1. **Caching** → **Configuration**
  2. Click **Purge Everything**
  3. Wait 30 seconds, refresh

### Origin IP Exposed
- Make sure DNS records are **Proxied** (orange cloud)
- Don't use **DNS Only** (grey cloud) for web traffic

## Support

- Cloudflare Discord: https://discord.cloudflare.com/
- Cloudflare Docs: https://developers.cloudflare.com/
- Status Page: https://www.cloudflarestatus.com/

---

**Status Check:**
Current: Setting up Cloudflare for snaplink.pro
Next: Test everything works together

🚀 Your site will be **faster**, **safer**, and **more reliable** with Cloudflare!
