﻿# 🚀 Guest Links Setup - Quick Fix Guide

## Problem: Features Not Working

The guest links feature requires **database changes** to work. Follow these simple steps:

---

## ✅ Solution: 3 Easy Steps

### **Step 1: Start XAMPP**
Make sure Apache and MySQL are running in XAMPP Control Panel

### **Step 2: Run Setup Page**
Open your browser and visit:
```
http://localhost/urlshortener/php-version/setup-guest-links.php
```

This page will:
- ✅ Check if database is configured correctly
- ✅ Show what's missing
- ✅ Provide a "Run Migration Now" button

### **Step 3: Click "Run Migration Now"**
Or visit directly:
```
http://localhost/urlshortener/php-version/update_database.php
```

---

## 🎉 That's It!

After running the migration, the features will work. Then test:

### **Test Page:**
```
http://localhost/urlshortener/php-version/test-shortener.php
```

### **Homepage:**
```
http://localhost/urlshortener/php-version/
```

---

## 📋 Manual Setup (If Browser Method Fails)

### Option A: phpMyAdmin
1. Open: `http://localhost/phpmyadmin/`
2. Select database: `if0_34392250_snaplink`
3. Click "SQL" tab
4. Open file: `guest_links_migration.sql`
5. Copy all SQL code
6. Paste in phpMyAdmin
7. Click "Go"

### Option B: MySQL Command Line
```bash
cd C:\xampp\htdocs\htdocs\urlshortener\php-version
mysql -u if0_34392250 -p if0_34392250_snaplink < guest_links_migration.sql
```
(Enter password: `2FNbOe0JDsw5` when prompted)

---

## 🔍 What Gets Changed

The migration adds:

1. **Modified `urls` table:**
   - Makes `user_id` nullable (allows guest links)
   - Adds `created_by_ip` column (track guest IPs)
   - Adds `is_guest` flag

2. **New `guest_rate_limits` table:**
   - Tracks daily link creation per IP
   - Prevents spam

3. **New `guest_sessions` table:**
   - For future session tracking

---

## ✅ Verification

After migration, visit:
```
http://localhost/urlshortener/php-version/setup-guest-links.php
```

You should see:
- ✅ All Systems Ready!
- ✅ Green checkmarks for all components

---

## 🧪 Testing

1. **Open test page:**
   ```
   http://localhost/urlshortener/php-version/test-shortener.php
   ```

2. **Click "Shorten" button**
   - Should create a short link ✅

3. **Click "Copy" button**
   - Should show "Copied to clipboard!" ✅

4. **Create 6 links total**
   - 6th link should show rate limit error ✅

---

## ❌ Troubleshooting

### Issue: "Table doesn't exist"
**Fix:** Run the migration (Step 2 above)

### Issue: "Column 'user_id' cannot be null"
**Fix:** Run the migration to make it nullable

### Issue: "Function get_client_ip() not found"
**Fix:** The function is in `config/config.php` - already added!

### Issue: Still not working
**Fix:** 
1. Check XAMPP is running
2. Check database credentials in `config/config.php`
3. Run `setup-guest-links.php` to see diagnostic info

---

## 📂 Files Overview

### New Files:
- ✅ `setup-guest-links.php` - Diagnostic & setup page
- ✅ `test-shortener.php` - Beautiful test interface
- ✅ `my-guest-links.php` - View guest links
- ✅ `guest_links_migration.sql` - SQL migration script
- ✅ `SETUP_FIX.md` - This file

### Modified Files:
- ✅ `api/shorten.php` - Now supports guest users
- ✅ `config/config.php` - Added `get_client_ip()` function
- ✅ `update_database.php` - Added migration code
- ✅ `index.php` - Updated UI for guests

---

## 🎯 Quick Commands Reference

### Start
```
1. Open: http://localhost/urlshortener/php-version/setup-guest-links.php
2. Click "Run Migration Now"
3. Open: http://localhost/urlshortener/php-version/test-shortener.php
4. Click "Shorten"
5. Click "Copy"
6. Done! ✅
```

---

## 💡 Tips

- **First time?** Use `setup-guest-links.php` to verify everything
- **Testing?** Use `test-shortener.php` for best experience
- **Problems?** Check `setup-guest-links.php` for diagnostics
- **Production?** Make sure to run migration on live server too!

---

## 🔗 Quick Links

- **Setup:** `http://localhost/urlshortener/php-version/setup-guest-links.php`
- **Test:** `http://localhost/urlshortener/php-version/test-shortener.php`
- **Home:** `http://localhost/urlshortener/php-version/`
- **My Links:** `http://localhost/urlshortener/php-version/my-guest-links.php`

---

**Need help?** Check the diagnostic page for detailed status:
```
http://localhost/urlshortener/php-version/setup-guest-links.php
```

It will tell you exactly what's wrong and how to fix it! 🚀
