﻿# 404 Error Troubleshooting for SnapLink Pro

## Common Causes & Solutions

### 1. Missing .htaccess File ❌
**Problem:** URL rewriting not working  
**Solution:** Upload `.htaccess` to root `htdocs/` directory

**Check:**
- File must be named `.htaccess` (with the dot!)
- Must be in `/htdocs/` (not in subfolders)
- Must have proper rewrite rules

### 2. Wrong File Structure 📁
**Problem:** Files uploaded to wrong location

**Correct Structure:**
```
htdocs/
├── .htaccess          ← Must be here!
├── index.php          ← Must be here!
├── r.php              ← Short URL handler
├── login.php
├── register.php
├── dashboard.php
├── api/
│   ├── shorten.php
│   └── ...
├── admin/
│   ├── index.php
│   └── ...
├── config/
│   ├── config.php
│   └── database.php
├── components/
└── assets/
```

**WRONG:**
```
htdocs/
└── php-version/      ← DON'T put files in subfolder!
    ├── index.php
    ├── .htaccess
    └── ...
```

### 3. Trying to Access /install.php
**If already installed:**
- Delete `install.php` file
- Database is already set up
- Go to: `https://snaplink.pro/` (homepage)
- Or: `https://snaplink.pro/login.php`

### 4. Short URL 404
**Example:** `snaplink.pro/abc123` shows 404

**Causes:**
- .htaccess not uploaded
- .htaccess not working
- No URL exists with code "abc123"
- mod_rewrite disabled (unlikely on InfinityFree)

**Fix:**
1. Upload `.htaccess` to htdocs root
2. Create a test short URL first
3. Use the exact short code generated

### 5. Admin Pages 404
**Example:** `snaplink.pro/admin` shows 404

**Fix:**
- Folder should be `/htdocs/admin/`
- Access: `https://snaplink.pro/admin/index.php`
- Or just: `https://snaplink.pro/admin/`

## Quick Diagnostic

### Test These URLs:

1. **Homepage:**
   ```
   https://snaplink.pro/
   https://snaplink.pro/index.php
   ```
   Should show: SnapLink Pro homepage

2. **Login:**
   ```
   https://snaplink.pro/login.php
   ```
   Should show: Login page

3. **Dashboard:**
   ```
   https://snaplink.pro/dashboard.php
   ```
   Should show: Login page (if not logged in) or Dashboard

4. **Admin:**
   ```
   https://snaplink.pro/admin/
   https://snaplink.pro/admin/index.php
   ```
   Should show: Admin login or panel

5. **API Docs:**
   ```
   https://snaplink.pro/api-docs.php
   ```
   Should show: API documentation

### What URL Are You Trying to Access?

Tell me the exact URL showing 404, and I can help diagnose!

## File Upload Checklist

Verify all these files are uploaded to `/htdocs/`:

### Root Files:
- [ ] `.htaccess`
- [ ] `index.php`
- [ ] `r.php`
- [ ] `login.php`
- [ ] `register.php`
- [ ] `dashboard.php`
- [ ] `analytics.php`
- [ ] `settings.php`
- [ ] `bio.php`
- [ ] `blog.php`
- [ ] `pricing.php`
- [ ] `webhooks.php`
- [ ] `page.php`
- [ ] `qr.php`
- [ ] `error.php`
- [ ] `api-docs.php`
- [ ] `api-analytics.php`
- [ ] `manifest.json`
- [ ] `sw.js`

### Folders:
- [ ] `api/` (with all PHP files inside)
- [ ] `admin/` (with all PHP files inside)
- [ ] `auth/google/` (with callback.php inside)
- [ ] `config/` (with config.php and database.php)
- [ ] `components/` (with header.php, footer.php, etc.)
- [ ] `sessions/` (created automatically or manually - 755 permissions)
- [ ] `uploads/` (if needed - 755 permissions)

## InfinityFree Specific

### File Manager Path:
When using InfinityFree File Manager, navigate to:
```
/htdocs/
```
All your files go HERE, not in a subfolder!

### FTP Path:
When using FileZilla:
```
Remote site: /htdocs
Local site: C:\xampp\htdocs\urlshortener\php-version\
```
Upload the CONTENTS of php-version folder, not the folder itself!

## Still Getting 404?

### Check InfinityFree Error Logs:
1. Login to InfinityFree Control Panel  
2. Go to **Error Logs**
3. Look for recent errors
4. Share them with me for diagnosis!

### Common Error Messages:

**"No input file specified"**
- .htaccess issue
- RewriteBase might need adjustment

**"Internal Server Error (500)"**
- Syntax error in .htaccess
- PHP error
- Check error logs

**"Forbidden (403)"**
- File permissions issue
- Directory browsing blocked (this is OK)
- Trying to access protected folder

## Pro Tip: Test Locally First

Before debugging on InfinityFree, test locally:

```bash
# Windows - Start XAMPP
# Visit: http://localhost/urlshortener/php-version/

# If it works locally but not on InfinityFree:
# → File upload or path issue
# → Check file structure on server
```

## Emergency Reset

If nothing works:

1. **Delete all files** from InfinityFree htdocs
2. **Re-upload** from scratch
3. **Verify structure**: Files in htdocs root, not subfolder
4. **Upload .htaccess** first
5. **Test**: Visit snaplink.pro/index.php
6. **Then** run install.php if database not set up

---

**What specific URL is giving you 404?** Tell me and I'll help fix it! 🔧
