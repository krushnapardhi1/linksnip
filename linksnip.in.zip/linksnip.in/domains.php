﻿<?php
/**
 * Custom Domains Management
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

require_login();

$user = current_user();
$flash = get_flash();

// This feature requires Pro or Enterprise plan
$hasAccess = in_array($user['plan'], ['pro', 'enterprise']);

// Get user's custom domains (if any)
$domains = [];
if ($hasAccess) {
    // Try to fetch custom domains if table exists
    try {
        $domains = db()->fetchAll(
            "SELECT * FROM custom_domains WHERE user_id = ? ORDER BY created_at DESC",
            [$user['id']]
        ) ?? [];
    } catch (Exception $e) {
        // Table doesn't exist yet - that's okay, just show empty state
        $domains = [];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Custom Domains - SnapLink Pro</title>
    <?php meta_canonical('php-version/domains.php'); ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-50 min-h-screen">
    <!-- Header -->
    <header class="bg-white border-b border-gray-200 px-4 lg:px-8 py-4">
        <div class="max-w-6xl mx-auto flex items-center justify-between">
            <div class="flex items-center gap-4">
                <a href="dashboard.php" class="text-gray-500 hover:text-purple-600">
                    <i class="fas fa-arrow-left"></i>
                </a>
                <h1 class="text-xl font-bold text-gray-900">Custom Domains</h1>
            </div>
            <?php if ($user['plan'] === 'free'): ?>
                <a href="#upgrade" class="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition text-sm font-medium">
                    <i class="fas fa-crown mr-1"></i>Upgrade to Pro
                </a>
            <?php endif; ?>
        </div>
    </header>

    <div class="max-w-6xl mx-auto p-4 lg:p-8">
        <?php if (!$hasAccess): ?>
            <!-- Upgrade Required -->
            <div class="bg-gradient-to-br from-purple-600 to-pink-600 rounded-2xl p-8 text-white text-center mb-8">
                <div class="w-20 h-20 bg-white/20 rounded-full mx-auto mb-6 flex items-center justify-center">
                    <i class="fas fa-globe text-4xl"></i>
                </div>
                <h2 class="text-3xl font-bold mb-4">Custom Domains</h2>
                <p class="text-white/90 mb-6 max-w-2xl mx-auto">
                    Use your own branded domain (e.g., link.yourbrand.com) instead of snaplink.pro for all your short links. 
                    Build trust and strengthen your brand identity.
                </p>
                <div class="bg-white/10 backdrop-blur-sm rounded-xl p-6 max-w-2xl mx-auto mb-6">
                    <h3 class="font-bold text-lg mb-4">Benefits:</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-left">
                        <div class="flex items-start gap-3">
                            <i class="fas fa-check-circle text-green-300 mt-1"></i>
                            <div>
                                <p class="font-semibold">Brand Recognition</p>
                                <p class="text-sm text-white/80">Use your own domain</p>
                            </div>
                        </div>
                        <div class="flex items-start gap-3">
                            <i class="fas fa-check-circle text-green-300 mt-1"></i>
                            <div>
                                <p class="font-semibold">SSL Included</p>
                                <p class="text-sm text-white/80">Free HTTPS certificates</p>
                            </div>
                        </div>
                        <div class="flex items-start gap-3">
                            <i class="fas fa-check-circle text-green-300 mt-1"></i>
                            <div>
                                <p class="font-semibold">Unlimited Links</p>
                                <p class="text-sm text-white/80">No restrictions</p>
                            </div>
                        </div>
                        <div class="flex items-start gap-3">
                            <i class="fas fa-check-circle text-green-300 mt-1"></i>
                            <div>
                                <p class="font-semibold">DNS Support</p>
                                <p class="text-sm text-white/80">Easy setup guide</p>
                            </div>
                        </div>
                    </div>
                </div>
                <a href="index.php#pricing" class="inline-block px-8 py-4 bg-white text-purple-600 rounded-xl font-bold hover:bg-gray-100 transition shadow-lg">
                    View Pro Plans
                </a>
            </div>
        <?php else: ?>
            <!-- Domain Management for Pro/Enterprise Users -->
            <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm mb-6">
                <div class="flex items-center justify-between mb-6">
                    <h2 class="text-lg font-bold text-gray-900">Your Custom Domains</h2>
                    <button onclick="showAddDomainModal()" class="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition text-sm font-medium">
                        <i class="fas fa-plus mr-1"></i>Add Domain
                    </button>
                </div>

                <?php if (empty($domains)): ?>
                    <div class="text-center py-12">
                        <i class="fas fa-globe text-6xl text-gray-200 mb-4"></i>
                        <h3 class="text-xl font-bold text-gray-900 mb-2">No Custom Domains Yet</h3>
                        <p class="text-gray-500 mb-6">Add your first custom domain to get started</p>
                        <button onclick="showAddDomainModal()" class="px-6 py-3 bg-purple-600 text-white rounded-xl hover:bg-purple-700 transition font-medium">
                            Add Your First Domain
                        </button>
                    </div>
                <?php else: ?>
                    <div class="space-y-4">
                        <?php foreach ($domains as $domain): ?>
                            <div class="border border-gray-200 rounded-xl p-4 hover:border-purple-300 transition">
                                <div class="flex items-center justify-between">
                                    <div class="flex-1">
                                        <div class="flex items-center gap-3 mb-2">
                                            <h3 class="text-lg font-bold text-gray-900"><?= htmlspecialchars($domain['domain']) ?></h3>
                                            <span class="px-2 py-1 rounded-full text-xs font-medium <?= $domain['status'] === 'active' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700' ?>">
                                                <?= ucfirst($domain['status']) ?>
                                            </span>
                                        </div>
                                        <p class="text-sm text-gray-500">
                                            Added <?= date('M j, Y', strtotime($domain['created_at'])) ?>
                                        </p>
                                    </div>
                                    <div class="flex items-center gap-2">
                                        <button class="p-2 text-gray-400 hover:text-purple-600 transition">
                                            <i class="fas fa-cog"></i>
                                        </button>
                                        <button class="p-2 text-gray-400 hover:text-red-600 transition">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Setup Instructions -->
            <div class="bg-blue-50 border border-blue-200 rounded-2xl p-6">
                <h3 class="font-bold text-gray-900 mb-4 flex items-center gap-2">
                    <i class="fas fa-book text-blue-600"></i>
                    How to Set Up Your Custom Domain
                </h3>
                <ol class="space-y-3 text-sm text-gray-700">
                    <li class="flex items-start gap-3">
                        <span class="flex-shrink-0 w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-bold">1</span>
                        <div>
                            <strong>Add Your Domain:</strong> Click "Add Domain" and enter your domain (e.g., link.yourdomain.com)
                        </div>
                    </li>
                    <li class="flex items-start gap-3">
                        <span class="flex-shrink-0 w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-bold">2</span>
                        <div>
                            <strong>Configure DNS:</strong> Add a CNAME record pointing to <code class="bg-blue-100 px-2 py-1 rounded">snaplink.pro</code>
                        </div>
                    </li>
                    <li class="flex items-start gap-3">
                        <span class="flex-shrink-0 w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-bold">3</span>
                        <div>
                            <strong>Verify:</strong> We'll automatically verify your domain and issue an SSL certificate
                        </div>
                    </li>
                    <li class="flex items-start gap-3">
                        <span class="flex-shrink-0 w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-bold">4</span>
                        <div>
                            <strong>Start Using:</strong> All your new short links will use your custom domain!
                        </div>
                    </li>
                </ol>
            </div>
        <?php endif; ?>
    </div>

    <script>
        function showAddDomainModal() {
            const domain = prompt('Enter your custom domain (e.g., link.yourdomain.com):');
            if (domain) {
                alert('Custom domain feature is coming soon! For now, please contact support@snaplink.pro to set up your domain.');
                // In production, this would submit to an API endpoint
            }
        }
    </script>

    <?php require_once ROOT_PATH . '/components/cookie-consent.php'; ?>
</body>
</html>
