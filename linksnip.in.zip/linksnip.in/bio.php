﻿<?php
/**
 * Bio / Link-in-Bio Page
 * Display user's bio page with their links
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

// Get username from URL (?u=username or /bio/username)
$username = $_GET['u'] ?? $_GET['username'] ?? null;

if (!$username) {
    http_response_code(404);
    echo "<!DOCTYPE html><html><head><title>404 - Bio Not Found</title></head><body>
    <h1>Bio Page Not Found</h1>
    <p>Please provide a username: /bio.php?u=username</p>
    </body></html>";
    exit;
}

// Get user info
$user = db()->fetchOne("SELECT * FROM users WHERE name = ? OR email = ? AND status = 'active'", [$username, $username]);

if (!$user) {
    http_response_code(404);
    echo "<!DOCTYPE html><html><head><title>404 - User Not Found</title></head><body>
    <h1>User Not Found</h1>
    <p>No active user found with username: " . htmlspecialchars($username) . "</p>
    </body></html>";
    exit;
}

// Get user's active URLs
$urls = db()->fetchAll(
    "SELECT * FROM urls WHERE user_id = ? AND is_active = 1 ORDER BY created_at DESC LIMIT 50",
    [$user['id']]
);

$baseUrl = APP_URL;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($user['name']) ?> - SnapLink Pro Bio</title>
    <?php meta_canonical('php-version/bio.php?u=' . urlencode($username)); ?>
    <meta name="description" content="Check out <?= htmlspecialchars($user['name']) ?>'s links">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body { font-family: 'Inter', sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center p-4">
    <div class="w-full max-w-2xl">
        <!-- Profile Card -->
        <div class="text-center mb-8">
            <?php if (!empty($user['avatar'])): ?>
                <img src="<?= htmlspecialchars($user['avatar']) ?>" alt="<?= htmlspecialchars($user['name']) ?>" 
                     class="w-24 h-24 rounded-full mx-auto mb-4 border-4 border-white shadow-xl">
            <?php else: ?>
                <div class="w-24 h-24 rounded-full mx-auto mb-4 border-4 border-white shadow-xl bg-purple-500 flex items-center justify-center text-white text-3xl font-bold">
                    <?= strtoupper(substr($user['name'], 0, 1)) ?>
                </div>
            <?php endif; ?>
            
            <h1 class="text-3xl font-bold text-white mb-2"><?= htmlspecialchars($user['name']) ?></h1>
            
            <?php if (!empty($user['bio_title'])): ?>
                <p class="text-white/90 text-lg font-medium mb-2"><?= htmlspecialchars($user['bio_title']) ?></p>
            <?php endif; ?>
            
            <?php if (!empty($user['bio'])): ?>
                <p class="text-white/80 mb-4 max-w-md mx-auto"><?= nl2br(htmlspecialchars($user['bio'])) ?></p>
            <?php else: ?>
                <p class="text-white/80 text-lg mb-4"><?= htmlspecialchars($user['email']) ?></p>
            <?php endif; ?>
            
            <div class="flex items-center justify-center gap-6 text-white/90">
                <div>
                    <span class="block text-2xl font-bold"><?= count($urls) ?></span>
                    <span class="text-sm">Links</span>
                </div>
                <div>
                    <span class="block text-2xl font-bold"><?= $user['plan'] ?></span>
                    <span class="text-sm">Plan</span>
                </div>
            </div>
        </div>

        <!-- Links List -->
        <div class="space-y-3">
            <?php if (empty($urls)): ?>
                <div class="bg-white/90 backdrop-blur-sm rounded-2xl p-8 text-center">
                    <i class="fas fa-link text-4xl text-gray-300 mb-3"></i>
                    <p class="text-gray-500">No links to display yet</p>
                </div>
            <?php else: ?>
                <?php foreach ($urls as $url): ?>
                    <a href="<?= $baseUrl ?>/<?= $url['short_code'] ?>" 
                       target="_blank"
                       class="block bg-white/90 backdrop-blur-sm hover:bg-white transition-all rounded-2xl p-5 shadow-lg hover:shadow-xl transform hover:-translate-y-1 duration-200">
                        <div class="flex items-center justify-between">
                            <div class="flex-1 min-w-0">
                                <?php if (!empty($url['notes'])): ?>
                                    <h3 class="font-bold text-gray-900 mb-1 truncate"><?= htmlspecialchars($url['notes']) ?></h3>
                                <?php endif; ?>
                                <p class="text-sm text-purple-600 font-medium mb-1">
                                    <?= $baseUrl ?>/<?= $url['short_code'] ?>
                                </p>
                                <p class="text-xs text-gray-500 truncate"><?= htmlspecialchars($url['long_url']) ?></p>
                            </div>
                            <div class="ml-4 flex items-center gap-3 text-gray-400">
                                <?php if ($url['clicks'] > 0): ?>
                                    <div class="text-center">
                                        <i class="fas fa-mouse-pointer text-purple-500"></i>
                                        <span class="block text-xs font-medium text-gray-600"><?= number_format($url['clicks']) ?></span>
                                    </div>
                                <?php endif; ?>
                                <i class="fas fa-external-link-alt"></i>
                            </div>
                        </div>
                    </a>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- Footer -->
        <div class="text-center mt-8">
            <a href="<?= base_url('') ?>" class="inline-flex items-center gap-2 text-white/80 hover:text-white transition">
                <i class="fas fa-link"></i>
                <span class="text-sm">Create your own with SnapLink Pro</span>
            </a>
        </div>
    </div>

    <?php require_once ROOT_PATH . '/components/cookie-consent.php'; ?>
</body>
</html>
