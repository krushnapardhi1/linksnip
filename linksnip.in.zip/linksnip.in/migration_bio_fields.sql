-- Add bio fields to users table
-- Run this migration if your users table doesn't have bio fields yet

ALTER TABLE users 
ADD COLUMN IF NOT EXISTS bio TEXT DEFAULT NULL AFTER avatar,
ADD COLUMN IF NOT EXISTS bio_title VARCHAR(255) DEFAULT NULL AFTER bio;
