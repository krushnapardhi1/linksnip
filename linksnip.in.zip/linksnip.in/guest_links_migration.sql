-- Guest Links Feature - Database Migration
-- Run this in phpMyAdmin or MySQL command line

-- Step 1: Make user_id nullable in urls table
-- First, try to drop the old foreign key constraint
SET FOREIGN_KEY_CHECKS = 0;

ALTER TABLE `urls` DROP FOREIGN KEY IF EXISTS `urls_ibfk_1`;

-- Make user_id nullable
ALTER TABLE `urls` MODIFY COLUMN `user_id` INT NULL DEFAULT NULL;

-- Add new columns if they don't exist
ALTER TABLE `urls` ADD COLUMN IF NOT EXISTS `created_by_ip` VARCHAR(45) NULL DEFAULT NULL AFTER `user_id`;
ALTER TABLE `urls` ADD COLUMN IF NOT EXISTS `is_guest` BOOLEAN DEFAULT FALSE AFTER `created_by_ip`;

-- Add indexes
ALTER TABLE `urls` ADD INDEX IF NOT EXISTS `idx_created_by_ip` (`created_by_ip`);

-- Add back the foreign key with ON DELETE SET NULL
ALTER TABLE `urls` ADD CONSTRAINT `fk_urls_user_id` 
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL;

SET FOREIGN_KEY_CHECKS = 1;

-- Step 2: Create guest_rate_limits table
CREATE TABLE IF NOT EXISTS `guest_rate_limits` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `ip_address` VARCHAR(45) NOT NULL,
    `links_created_today` INT DEFAULT 1,
    `last_reset_date` DATE NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `unique_ip` (`ip_address`),
    INDEX `idx_last_reset` (`last_reset_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Step 3: Create guest_sessions table
CREATE TABLE IF NOT EXISTS `guest_sessions` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `session_id` VARCHAR(128) NOT NULL,
    `ip_address` VARCHAR(45) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_session_id` (`session_id`),
    INDEX `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Verify the changes
SELECT 'Database migration completed!' AS Status;

-- Check if columns were added
SHOW COLUMNS FROM urls LIKE 'created_by_ip';
SHOW COLUMNS FROM urls LIKE 'is_guest';

-- Check if tables were created
SHOW TABLES LIKE 'guest_%';
