﻿<?php
/**
 * Database Reset & Reinstall Script
 * WARNING: This will DELETE ALL DATA and reinstall the database
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/database.php';

// Configuration
$confirmToken = $_GET['confirm'] ?? '';
$requiredToken = 'RESET_DATABASE_NOW';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Reset - SnapLink Pro</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body class="bg-gray-900">
    <div class="min-h-screen flex items-center justify-center p-4">
        <div class="max-w-2xl w-full bg-white rounded-xl shadow-2xl overflow-hidden">
            
            <?php if ($confirmToken !== $requiredToken): ?>
                
                <!-- Warning Screen -->
                <div class="bg-red-600 text-white p-6">
                    <h1 class="text-3xl font-bold flex items-center">
                        <i class="fas fa-exclamation-triangle mr-3"></i>
                        ⚠️ Database Reset Warning
                    </h1>
                </div>
                
                <div class="p-8">
                    <div class="bg-yellow-50 border-l-4 border-yellow-500 p-4 mb-6">
                        <div class="flex">
                            <div class="flex-shrink-0">
                                <i class="fas fa-exclamation-circle text-yellow-400 text-xl"></i>
                            </div>
                            <div class="ml-3">
                                <p class="text-sm text-yellow-700 font-bold">
                                    This will permanently delete ALL data including:
                                </p>
                                <ul class="mt-2 text-sm text-yellow-700 list-disc list-inside space-y-1">
                                    <li>All user accounts</li>
                                    <li>All shortened URLs</li>
                                    <li>All analytics data</li>
                                    <li>All settings and configurations</li>
                                    <li>Guest links data</li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <h2 class="text-xl font-bold text-gray-900 mb-4">What This Does:</h2>
                    <div class="space-y-3 mb-6">
                        <div class="flex items-start">
                            <i class="fas fa-trash text-red-500 mt-1 mr-3"></i>
                            <div>
                                <p class="font-semibold text-gray-900">Step 1: Drop All Tables</p>
                                <p class="text-sm text-gray-600">Removes all existing database tables</p>
                            </div>
                        </div>
                        <div class="flex items-start">
                            <i class="fas fa-database text-blue-500 mt-1 mr-3"></i>
                            <div>
                                <p class="font-semibold text-gray-900">Step 2: Create Fresh Tables</p>
                                <p class="text-sm text-gray-600">Installs a clean database schema</p>
                            </div>
                        </div>
                        <div class="flex items-start">
                            <i class="fas fa-user-shield text-green-500 mt-1 mr-3"></i>
                            <div>
                                <p class="font-semibold text-gray-900">Step 3: Create Admin Account</p>
                                <p class="text-sm text-gray-600">Sets up default admin credentials</p>
                            </div>
                        </div>
                    </div>

                    <div class="bg-blue-50 border-l-4 border-blue-500 p-4 mb-6">
                        <p class="text-sm text-blue-700">
                            <i class="fas fa-info-circle mr-2"></i>
                            <strong>Recommended:</strong> Instead of resetting, you can run the 
                            <a href="auto-fix-database.php" class="underline font-bold">Auto-Fix Database</a> 
                            script to fix issues without losing data.
                        </p>
                    </div>

                    <div class="flex gap-4">
                        <a href="auto-fix-database.php" 
                           class="flex-1 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition font-bold text-center">
                            <i class="fas fa-wrench mr-2"></i>
                            Try Auto-Fix Instead
                        </a>
                        <a href="?confirm=<?= $requiredToken ?>" 
                           class="flex-1 px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 transition font-bold text-center"
                           onclick="return confirm('Are you ABSOLUTELY SURE? This cannot be undone!')">
                            <i class="fas fa-skull-crossbones mr-2"></i>
                            Reset Database
                        </a>
                    </div>
                    
                    <div class="mt-6 text-center">
                        <a href="index.php" class="text-gray-600 hover:text-gray-800">
                            <i class="fas fa-arrow-left mr-2"></i>
                            Cancel and Go Back
                        </a>
                    </div>
                </div>
                
            <?php else: ?>
                
                <!-- Reset Process -->
                <div class="bg-purple-600 text-white p-6">
                    <h1 class="text-3xl font-bold flex items-center">
                        <i class="fas fa-sync-alt fa-spin mr-3"></i>
                        Resetting Database...
                    </h1>
                </div>
                
                <div class="p-8">
                    <?php
                    try {
                        $pdo = db();
                        $errors = [];
                        $success = [];
                        
                        echo "<div class='space-y-4'>";
                        
                        // Get all tables
                        echo "<p class='text-gray-700'><i class='fas fa-search mr-2'></i>Finding all tables...</p>";
                        $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
                        echo "<p class='text-green-600'><i class='fas fa-check mr-2'></i>Found " . count($tables) . " tables</p>";
                        
                        // Drop all tables
                        echo "<p class='text-yellow-600 mt-4'><i class='fas fa-trash mr-2'></i>Dropping all tables...</p>";
                        $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
                        
                        foreach ($tables as $table) {
                            try {
                                $pdo->exec("DROP TABLE IF EXISTS `$table`");
                                echo "<p class='text-sm text-gray-600 ml-6'>✓ Dropped: $table</p>";
                                $success[] = "Dropped table: $table";
                            } catch (Exception $e) {
                                echo "<p class='text-sm text-red-600 ml-6'>✗ Failed: $table</p>";
                                $errors[] = "Failed to drop $table: " . $e->getMessage();
                            }
                        }
                        
                        $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
                        echo "<p class='text-green-600 mt-2'><i class='fas fa-check mr-2'></i>All tables dropped</p>";
                        
                        echo "</div>";
                        
                        // Show success message
                        echo "<div class='mt-8 p-6 bg-green-50 border-2 border-green-500 rounded-lg'>";
                        echo "<h2 class='text-2xl font-bold text-green-700 mb-4'>";
                        echo "<i class='fas fa-check-circle mr-2'></i>✅ Database Reset Complete!";
                        echo "</h2>";
                        echo "<p class='text-green-700 mb-4'>The database has been completely cleared.</p>";
                        
                        echo "<div class='space-y-3'>";
                        echo "<a href='install.php' class='block px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 font-bold text-center'>";
                        echo "<i class='fas fa-play-circle mr-2'></i>Run Installer Now";
                        echo "</a>";
                        echo "<a href='index.php' class='block px-6 py-3 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 font-bold text-center'>";
                        echo "<i class='fas fa-home mr-2'></i>Go to Homepage";
                        echo "</a>";
                        echo "</div>";
                        echo "</div>";
                        
                        if (!empty($errors)) {
                            echo "<div class='mt-4 p-4 bg-yellow-50 border border-yellow-300 rounded-lg'>";
                            echo "<h3 class='font-bold text-yellow-800 mb-2'>Warnings:</h3>";
                            echo "<ul class='list-disc list-inside text-sm text-yellow-700'>";
                            foreach ($errors as $error) {
                                echo "<li>" . htmlspecialchars($error) . "</li>";
                            }
                            echo "</ul>";
                            echo "</div>";
                        }
                        
                    } catch (Exception $e) {
                        echo "<div class='p-4 bg-red-50 border-2 border-red-500 rounded-lg'>";
                        echo "<h2 class='text-xl font-bold text-red-700 mb-2'>❌ Error!</h2>";
                        echo "<p class='text-red-600'>" . htmlspecialchars($e->getMessage()) . "</p>";
                        echo "<a href='reset-database.php' class='mt-4 inline-block px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700'>Try Again</a>";
                        echo "</div>";
                    }
                    ?>
                </div>
                
            <?php endif; ?>
            
        </div>
    </div>
</body>
</html>
