﻿<?php
/**
 * QR Code Generator
 * Create custom QR codes instantly
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

$user = current_user();
$pageTitle = "QR Code Generator - SnapLink Pro";

// Pre-fill URL if passed in query string
$inputUrl = $_GET['url'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style> body { font-family: 'Inter', sans-serif; } </style>
</head>
<body class="bg-gray-50 min-h-screen flex flex-col">

    <!-- Navbar -->
    <nav class="bg-white shadow-sm border-b sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <a href="index.php" class="flex items-center gap-2">
                    <div class="w-10 h-10 rounded-xl bg-purple-600 flex items-center justify-center text-white">
                        <i class="fas fa-link"></i>
                    </div>
                    <span class="text-xl font-bold">SnapLink Pro</span>
                </a>
                
                <div class="flex items-center gap-4">
                    <a href="index.php" class="text-gray-700 hover:text-purple-600 font-medium">Home</a>
                    <?php if ($user): ?>
                        <a href="dashboard.php" class="px-4 py-2 bg-purple-100 text-purple-700 rounded-lg hover:bg-purple-200 font-medium">Dashboard</a>
                    <?php else: ?>
                        <a href="login.php" class="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 font-medium">Login</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="flex-grow max-w-7xl mx-auto px-4 py-12 w-full">
        <div class="text-center mb-12">
            <h1 class="text-3xl md:text-5xl font-bold text-gray-900 mb-4">QR Code Generator</h1>
            <p class="text-lg text-gray-600">Create permanent, high-quality QR codes for your links.</p>
        </div>

        <div class="grid lg:grid-cols-2 gap-8 items-start">
            
            <!-- Controls -->
            <div class="bg-white rounded-2xl shadow-lg p-6 md:p-8">
                <div class="space-y-6">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Destination URL</label>
                        <div class="relative">
                            <span class="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-400">
                                <i class="fas fa-link"></i>
                            </span>
                            <input type="url" id="qrInput" value="<?= htmlspecialchars($inputUrl) ?>"
                                   class="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 transition"
                                   placeholder="https://example.com"
                                   oninput="generateQR()">
                        </div>
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Color</label>
                            <div class="flex items-center gap-2">
                                <input type="color" id="qrColor" value="#000000" onchange="generateQR()" 
                                       class="h-10 w-10 p-1 rounded cursor-pointer border border-gray-200">
                                <span class="text-sm text-gray-500">Pick color</span>
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Size</label>
                            <select id="qrSize" onchange="generateQR()" class="w-full px-3 py-2 border border-gray-200 rounded-lg">
                                <option value="200">200 x 200</option>
                                <option value="300" selected>300 x 300</option>
                                <option value="500">500 x 500</option>
                                <option value="1000">1000 x 1000</option>
                            </select>
                        </div>
                    </div>

                    <button onclick="downloadQR()" class="w-full py-4 bg-purple-600 text-white rounded-xl font-bold hover:bg-purple-700 transition shadow-lg shadow-purple-200">
                        <i class="fas fa-download mr-2"></i> Download QR Code
                    </button>
                </div>
            </div>

            <!-- Preview -->
            <div class="bg-white rounded-2xl shadow-lg p-6 md:p-8 flex flex-col items-center justify-center min-h-[400px]">
                <div id="loading" class="hidden">
                    <i class="fas fa-spinner fa-spin text-4xl text-purple-600"></i>
                </div>
                <div id="qrPreviewContainer" class="p-4 border-2 border-dashed border-gray-200 rounded-xl">
                    <img id="qrImage" src="" alt="QR Code" class="max-w-full hidden shadow-sm rounded-lg">
                    <div id="placeholder" class="text-center text-gray-400 p-8">
                        <i class="fas fa-qrcode text-6xl mb-4 opacity-20"></i>
                        <p>Enter a URL to generate your QR code</p>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-white border-t py-8 mt-auto">
        <div class="max-w-7xl mx-auto px-4 text-center text-gray-500 text-sm">
            &copy; <?= date('Y') ?> SnapLink Pro. All rights reserved.
        </div>
    </footer>

    <script>
        // Init if URL provided
        window.addEventListener('DOMContentLoaded', () => {
            if (document.getElementById('qrInput').value) {
                generateQR();
            }
        });

        function generateQR() {
            const input = document.getElementById('qrInput').value;
            const size = document.getElementById('qrSize').value;
            const color = document.getElementById('qrColor').value.replace('#', '');
            const img = document.getElementById('qrImage');
            const placeholder = document.getElementById('placeholder');
            const loading = document.getElementById('loading');

            if (!input) {
                img.classList.add('hidden');
                placeholder.classList.remove('hidden');
                return;
            }

            // Show loading
            placeholder.classList.add('hidden');
            // img.classList.add('hidden'); // Keep showing old one until new one loads for smoothness
            
            // Construct API URL
            // Using generic qrserver api
            const apiUrl = `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(input)}&color=${color}&margin=10`;

            img.onload = () => {
                img.classList.remove('hidden');
                loading.classList.add('hidden');
            };
            
            img.src = apiUrl;
        }

        async function downloadQR() {
            const img = document.getElementById('qrImage');
            if (!img.src || img.classList.contains('hidden')) {
                alert('Please generate a QR code first.');
                return;
            }

            try {
                const response = await fetch(img.src);
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.style.display = 'none';
                a.href = url;
                a.download = 'qrcode-' + Date.now() + '.png';
                document.body.appendChild(a);
                a.click();
                window.URL.revokeObjectURL(url);
                document.body.removeChild(a);
            } catch (e) {
                alert('Failed to download directly. Opening in new tab instead.');
                window.open(img.src, '_blank');
            }
        }
    </script>
</body>
</html>
