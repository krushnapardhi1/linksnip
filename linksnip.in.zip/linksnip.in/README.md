﻿# SnapLink Pro - PHP URL Shortener for InfinityFree

A fully-featured URL shortener converted from Node.js to PHP for InfinityFree hosting compatibility.

## Features

- ✅ **User Authentication** - Register, Login, Logout with secure sessions
- ✅ **URL Shortening** - Create short links with custom aliases
- ✅ **Password Protection** - Secure links with passwords
- ✅ **Link Expiration** - Set expiry dates and click limits
- ✅ **Analytics** - Track clicks, browsers, devices, countries, referrers
- ✅ **QR Code Generation** - Auto-generate QR codes for links
- ✅ **Device Targeting** - Different URLs for mobile/iOS/Android
- ✅ **A/B Testing** - Split traffic between two URLs
- ✅ **Ad Interstitials** - Show ads before redirecting
- ✅ **Admin Panel** - Manage users, links, settings
- ✅ **API Access** - REST API with API key authentication
- ✅ **SEO Friendly** - Clean URLs with .htaccess rewriting

## Requirements

- PHP 7.4 or higher
- MySQL 5.7 or higher
- Apache with mod_rewrite enabled

## Installation on InfinityFree

### Step 1: Create Database

1. Login to your InfinityFree control panel
2. Go to **MySQL Databases**
3. Create a new database
4. Note down:
   - Database Name (e.g., `epiz_12345678_urlshortener`)
   - Username (e.g., `epiz_12345678`)
   - Password
   - Host (e.g., `sql.infinityfreeapp.com` or `sqlXXX.infinityfreeapp.com`)

### Step 2: Configure the Application

1. Open `config/config.php`
2. Update the database settings:

```php
define('DB_HOST', 'sql.infinityfreeapp.com'); // Your MySQL host
define('DB_NAME', 'epiz_12345678_urlshortener'); // Your database name
define('DB_USER', 'epiz_12345678'); // Your username
define('DB_PASS', 'your_password'); // Your password
```

3. Update the application URL:

```php
define('APP_URL', 'https://your-site.infinityfreeapp.com');
```

### Step 3: Upload Files

1. Upload all files to your `htdocs` folder via FTP or File Manager
2. Make sure the `.htaccess` file is uploaded (it may be hidden)

### Step 4: Run Installation

1. Visit `https://your-site.infinityfreeapp.com/install.php`
2. Click **Install Database Tables**
3. Wait for the installation to complete
4. **DELETE `install.php` immediately for security!**

### Step 5: Login

Default admin credentials:
- **Email:** admin@snaplink.com
- **Password:** admin123

**⚠️ IMPORTANT: Change this password immediately after login!**

## File Structure

```
urlshortener-php/
├── admin/                  # Admin panel
│   ├── partials/
│   │   └── sidebar.php     # Admin sidebar
│   ├── index.php           # Admin dashboard
│   ├── users.php           # User management
│   └── settings.php        # Site settings
├── api/                    # API endpoints
│   ├── shorten.php         # Create short URL
│   └── url.php             # Update/Delete URL
├── config/
│   ├── config.php          # Main configuration
│   └── database.php        # Database class
├── .htaccess               # URL rewriting rules
├── index.php               # Homepage
├── login.php               # Login page
├── register.php            # Registration page
├── logout.php              # Logout handler
├── dashboard.php           # User dashboard
├── analytics.php           # URL analytics
├── settings.php            # User settings
├── r.php                   # URL redirect handler
├── error.php               # Error pages
├── privacy.php             # Privacy policy
├── terms.php               # Terms of service
├── install.php             # Installation script
└── README.md               # This file
```

## API Usage

### Authentication

Include your API key in requests:
```
X-API-Key: your_api_key_here
```

### Shorten URL

```bash
POST /api/shorten.php
Content-Type: application/json

{
  "url": "https://example.com/very-long-url",
  "customAlias": "optional-alias",
  "password": "optional-password",
  "expiresAt": "2024-12-31T23:59:59",
  "maxClicks": 1000
}
```

Response:
```json
{
  "success": true,
  "data": {
    "id": 123,
    "shortCode": "abc123",
    "shortUrl": "https://your-site.com/abc123",
    "longUrl": "https://example.com/very-long-url"
  }
}
```

## InfinityFree Limitations

Be aware of these InfinityFree limitations:

1. **No Node.js** - This is why we converted to PHP
2. **File size limit** - 10MB per file
3. **Daily hits** - 50,000 hits/day on free plan
4. **No external connections** - Some GeoIP APIs may not work
5. **No cron jobs** - Scheduled tasks not available
6. **Subdomain only** - Custom domains require premium hosting

## Troubleshooting

### Links not redirecting?
- Check if `.htaccess` was uploaded
- Ensure mod_rewrite is enabled
- Check if the file permissions are correct (644 for files, 755 for folders)

### Database connection failed?
- Verify your database credentials in `config/config.php`
- InfinityFree MySQL hosts can be different - check your control panel

### 500 Internal Server Error?
- Check PHP error logs in control panel
- Verify PHP version is 7.4 or higher
- Check file permissions

### CSS/JS not loading?
- Make sure all files were uploaded correctly
- Check browser console for errors
- Clear browser cache

## Upgrading from Node.js Version

If you're migrating from the Node.js version:

1. Export your MySQL database from the old setup
2. Import it to InfinityFree MySQL
3. Update `config/config.php` with new credentials
4. Upload all PHP files
5. Test the installation

The database schema is compatible - no changes needed.

## Security Recommendations

1. ✅ Delete `install.php` after installation
2. ✅ Change default admin password
3. ✅ Use HTTPS (InfinityFree provides free SSL)
4. ✅ Keep PHP updated
5. ✅ Regularly backup your database

## Support

For issues or feature requests, please open an issue on GitHub.

## License

MIT License - Feel free to use and modify.
