# Quick Start: Testing Guest Links Feature

## Installation Steps

### 1. Run Database Migration
Visit: `http://localhost/urlshortener/php-version/update_database.php`

This will:
- ✅ Make `user_id` nullable in `urls` table
- ✅ Add `created_by_ip` column to track guest IPs
- ✅ Add `is_guest` flag column
- ✅ Create `guest_rate_limits` table
- ✅ Create `guest_sessions` table

### 2. Test Guest Link Creation

**Test as Guest User:**
1. Open incognito/private browser window
2. Go to: `http://localhost/urlshortener/php-version/`
3. Enter a long URL (e.g., `https://www.google.com`)
4. Click "Shorten"
5. ✅ You should see a short link created!
6. ✅ You should see a "View My Links" button
7. ✅ You should see an upsell message about signing up

**View Your Guest Links:**
1. Click "View My Links" button
2. Or go to: `http://localhost/urlshortener/php-version/my-guest-links.php`
3. ✅ You should see all links you created
4. ✅ You should see "5 links remaining today" counter

**Test Rate Limiting:**
1. In the same incognito browser, create 5 short links
2. Try to create a 6th link
3. ✅ You should see: "Daily limit reached. Guest users can create 5 links per day..."
4. ✅ A confirmation dialog should ask if you want to sign up

**Test Feature Restrictions:**
Try to create a link with advanced features (you can't from the homepage, but if you tried via API):
- Custom alias → Should show error about needing to be registered
- Password protection → Should show error
- Expiration date → Should show error

## What Changed

### Files Modified:
1. ✅ `update_database.php` - Added database migrations
2. ✅ `api/shorten.php` - Now supports guest users with rate limiting
3. ✅ `config/config.php` - Added `get_client_ip()` helper function
4. ✅ `index.php` - Updated UI for guest users

### Files Created:
1. ✅ `my-guest-links.php` - Page for viewing guest links
2. ✅ `GUEST_LINKS_FEATURE.md` - Full documentation
3. ✅ `QUICK_START.md` - This file

## Features Added

### For Guest Users:
- ✅ Create up to 5 short links per day (no signup required)
- ✅ View their links on a dedicated page
- ✅ See click counts and creation dates
- ✅ Copy links easily
- ✅ Clear messaging about premium features

### For Registered Users:
- ✅ All existing features remain unchanged
- ✅ Unlimited links
- ✅ Custom aliases
- ✅ Password protection
- ✅ Analytics
- ✅ And more...

## Rate Limiting

**Guest Users:**
- 5 links per day per IP address
- Resets at midnight daily
- Tracked by IP address
- CloudFlare compatible

**To Change Limit:**
Edit `api/shorten.php` line ~58:
```php
$GUEST_DAILY_LIMIT = 5; // Change this number
```

## User Flow

```
Guest User
    ↓
Creates Link (1-5 per day)
    ↓
Sees Result + Upsell Message
    ↓
Options:
    - View My Links → my-guest-links.php
    - Sign Up → register.php
    ↓
Rate Limit Reached
    ↓
Prompted to Sign Up
    ↓
Creates Account
    ↓
Gets Unlimited Access
```

## Testing Checklist

- [ ] Database migration runs successfully
- [ ] Guest can create links without logging in
- [ ] Short link works and redirects correctly
- [ ] Guest can view their links on my-guest-links.php
- [ ] Rate limiting works (5 links max per day)
- [ ] Rate limit shows error message with signup CTA
- [ ] Upsell messages appear for guest users
- [ ] Logged-in users see normal "Manage" button
- [ ] Guest users see "View My Links" button
- [ ] Clicking links increments click counter
- [ ] Copy button works

## Common Issues

**Q: "Column 'user_id' cannot be null" error**
A: Run `update_database.php` to make user_id nullable

**Q: Guest links don't show up**
A: Check that `is_guest = 1` and `created_by_ip` matches your IP

**Q: Rate limit always shows 0 remaining**
A: Check `guest_rate_limits` table, verify date comparison logic

**Q: Can't test from localhost**
A: Use different browsers or incognito mode for different IP tests

## Next Steps

### Optional Enhancements:
1. **Auto-claim feature** - Assign guest links to user after signup
2. **Session-based tracking** - Alternative to IP-based tracking
3. **Guest analytics** - Show basic stats on guest links page
4. **Email verification** - Send link list to email before signup
5. **Link expiration** - Auto-delete guest links after 30 days

### Admin Features:
- View all guest links in admin panel
- Monitor rate limit abuse
- Adjust daily limits per IP
- Bulk delete old guest links

## Support

Questions? Check:
- `GUEST_LINKS_FEATURE.md` for full documentation
- Database tables via phpMyAdmin
- Browser console for JavaScript errors
- PHP error logs for backend issues

---

**Ready to test!** Start with step 1 above. 🚀
