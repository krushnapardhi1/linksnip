﻿<?php
/**
 * Guest Links Feature - Diagnostic & Setup Page
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

$status = [];
$errors = [];
$warnings = [];

// Check database connection
try {
    $db = db()->getConnection();
    $status['database'] = '✅ Connected';
} catch (Exception $e) {
    $errors[] = '❌ Database connection failed: ' . $e->getMessage();
    $status['database'] = '❌ Failed';
}

// Check if columns exist
if ($db) {
    // Check user_id in urls
    try {
        $result = $db->query("SHOW COLUMNS FROM urls LIKE 'user_id'")->fetch();
        if ($result && strtoupper($result['Null']) === 'YES') {
            $status['user_id_nullable'] = '✅ user_id is nullable';
        } else {
            $warnings[] = '⚠️ user_id is NOT nullable - migration needed';
            $status['user_id_nullable'] = '❌ Not nullable';
        }
    } catch (Exception $e) {
        $errors[] = '❌ Error checking user_id: ' . $e->getMessage();
    }

    // Check created_by_ip column
    try {
        $result = $db->query("SHOW COLUMNS FROM urls LIKE 'created_by_ip'")->fetch();
        if ($result) {
            $status['created_by_ip'] = '✅ Column exists';
        } else {
            $warnings[] = '⚠️ created_by_ip column missing - migration needed';
            $status['created_by_ip'] = '❌ Missing';
        }
    } catch (Exception $e) {
        $errors[] = '❌ Error checking created_by_ip: ' . $e->getMessage();
    }

    // Check is_guest column
    try {
        $result = $db->query("SHOW COLUMNS FROM urls LIKE 'is_guest'")->fetch();
        if ($result) {
            $status['is_guest'] = '✅ Column exists';
        } else {
            $warnings[] = '⚠️ is_guest column missing - migration needed';
            $status['is_guest'] = '❌ Missing';
        }
    } catch (Exception $e) {
        $errors[] = '❌ Error checking is_guest: ' . $e->getMessage();
    }

    // Check guest_rate_limits table
    try {
        $result = $db->query("SHOW TABLES LIKE 'guest_rate_limits'")->fetch();
        if ($result) {
            $status['guest_rate_limits'] = '✅ Table exists';
        } else {
            $warnings[] = '⚠️ guest_rate_limits table missing - migration needed';
            $status['guest_rate_limits'] = '❌ Missing';
        }
    } catch (Exception $e) {
        $errors[] = '❌ Error checking guest_rate_limits: ' . $e->getMessage();
    }

    // Check guest_sessions table
    try {
        $result = $db->query("SHOW TABLES LIKE 'guest_sessions'")->fetch();
        if ($result) {
            $status['guest_sessions'] = '✅ Table exists';
        } else {
            $warnings[] = '⚠️ guest_sessions table missing - migration needed';
            $status['guest_sessions'] = '❌ Missing';
        }
    } catch (Exception $e) {
        $errors[] = '❌ Error checking guest_sessions: ' . $e->getMessage();
    }
}

// Check helper function
$status['get_client_ip'] = function_exists('get_client_ip') ? '✅ Function exists' : '❌ Missing';
if (!function_exists('get_client_ip')) {
    $errors[] = '❌ get_client_ip() function not found in config.php';
}

// Test IP detection
try {
    $clientIp = function_exists('get_client_ip') ? get_client_ip() : $_SERVER['REMOTE_ADDR'];
    $status['client_ip'] = '✅ Detected: ' . $clientIp;
} catch (Exception $e) {
    $errors[] = '❌ Error detecting IP: ' . $e->getMessage();
}

// Overall status
$allGood = empty($errors) && empty($warnings);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Guest Links Diagnostic - SnapLink Pro</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body class="bg-gray-50 min-h-screen p-8">
    <div class="max-w-4xl mx-auto">
        <!-- Header -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <div class="flex items-center gap-4">
                <div class="w-16 h-16 <?= $allGood ? 'bg-green-500' : 'bg-orange-500' ?> rounded-xl flex items-center justify-center">
                    <i class="fas <?= $allGood ? 'fa-check-circle' : 'fa-exclamation-triangle' ?> text-white text-3xl"></i>
                </div>
                <div>
                    <h1 class="text-3xl font-bold text-gray-900">Guest Links Feature Diagnostic</h1>
                    <p class="text-gray-600">Check if all components are properly installed</p>
                </div>
            </div>
        </div>

        <!-- Overall Status -->
        <div class="bg-<?= $allGood ? 'green' : 'orange' ?>-50 border-2 border-<?= $allGood ? 'green' : 'orange' ?>-200 rounded-xl p-6 mb-6">
            <h2 class="text-xl font-bold text-<?= $allGood ? 'green' : 'orange' ?>-900 mb-2">
                <?= $allGood ? '✅ All Systems Ready!' : '⚠️ Setup Required' ?>
            </h2>
            <p class="text-<?= $allGood ? 'green' : 'orange' ?>-700">
                <?= $allGood 
                    ? 'Your guest links feature is fully configured and ready to use!' 
                    : 'Some components need to be set up. Follow the instructions below.' 
                ?>
            </p>
        </div>

        <!-- Component Status -->
        <div class="bg-white rounded-xl shadow-lg p-6 mb-6">
            <h2 class="text-xl font-bold text-gray-900 mb-4">
                <i class="fas fa-list-check text-purple-600 mr-2"></i>
                Component Status
            </h2>
            <div class="space-y-3">
                <?php foreach ($status as $component => $componentStatus): ?>
                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <span class="font-medium text-gray-700"><?= ucfirst(str_replace('_', ' ', $component)) ?></span>
                        <span class="font-mono text-sm"><?= $componentStatus ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Errors -->
        <?php if (!empty($errors)): ?>
            <div class="bg-red-50 border-2 border-red-200 rounded-xl p-6 mb-6">
                <h2 class="text-xl font-bold text-red-900 mb-4">
                    <i class="fas fa-times-circle mr-2"></i>
                    Errors
                </h2>
                <ul class="space-y-2">
                    <?php foreach ($errors as $error): ?>
                        <li class="text-red-700"><?= $error ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <!-- Warnings -->
        <?php if (!empty($warnings)): ?>
            <div class="bg-orange-50 border-2 border-orange-200 rounded-xl p-6 mb-6">
                <h2 class="text-xl font-bold text-orange-900 mb-4">
                    <i class="fas fa-exclamation-triangle mr-2"></i>
                    Warnings (Migration Needed)
                </h2>
                <ul class="space-y-2">
                    <?php foreach ($warnings as $warning): ?>
                        <li class="text-orange-700"><?= $warning ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <!-- Setup Instructions -->
        <?php if (!$allGood): ?>
            <div class="bg-blue-50 border-2 border-blue-200 rounded-xl p-6 mb-6">
                <h2 class="text-xl font-bold text-blue-900 mb-4">
                    <i class="fas fa-tools mr-2"></i>
                    How to Fix
                </h2>
                <div class="space-y-4 text-blue-800">
                    <div>
                        <h3 class="font-bold mb-2">Option 1: Run Migration via Browser</h3>
                        <p class="mb-2">Visit this page in your browser:</p>
                        <code class="block bg-white p-3 rounded border border-blue-300 mb-2">
                            http://localhost/urlshortener/php-version/update_database.php
                        </code>
                        <a href="update_database.php" class="inline-block px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-semibold">
                            <i class="fas fa-database mr-2"></i>Run Migration Now
                        </a>
                    </div>
                    
                    <div class="border-t border-blue-300 pt-4">
                        <h3 class="font-bold mb-2">Option 2: Run SQL Script Manually</h3>
                        <ol class="list-decimal list-inside space-y-2 mb-3">
                            <li>Open phpMyAdmin</li>
                            <li>Select your database: <code class="bg-white px-2 py-1 rounded">if0_34392250_snaplink</code></li>
                            <li>Go to SQL tab</li>
                            <li>Copy and paste the SQL from: <code class="bg-white px-2 py-1 rounded">guest_links_migration.sql</code></li>
                            <li>Click "Go"</li>
                        </ol>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Test API -->
        <?php if ($allGood): ?>
            <div class="bg-green-50 border-2 border-green-200 rounded-xl p-6 mb-6">
                <h2 class="text-xl font-bold text-green-900 mb-4">
                    <i class="fas fa-vial text-green-600 mr-2"></i>
                    Ready to Test!
                </h2>
                <p class="text-green-700 mb-4">
                    Everything is set up correctly. You can now test the guest link feature:
                </p>
                <div class="flex gap-3">
                    <a href="test-shortener.php" class="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 font-semibold">
                        <i class="fas fa-flask mr-2"></i>Open Test Page
                    </a>
                    <a href="index.php" class="px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 font-semibold">
                        <i class="fas fa-home mr-2"></i>Go to Homepage
                    </a>
                    <a href="my-guest-links.php" class="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-semibold">
                        <i class="fas fa-list mr-2"></i>My Guest Links
                    </a>
                </div>
            </div>
        <?php endif; ?>

        <!-- Refresh Button -->
        <div class="text-center">
            <button onclick="location.reload()" class="px-6 py-3 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 font-semibold">
                <i class="fas fa-sync-alt mr-2"></i>Refresh Status
            </button>
        </div>
    </div>
</body>
</html>
