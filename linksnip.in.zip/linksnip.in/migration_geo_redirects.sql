-- Geo Redirects Migration
-- Create table for country-based redirects

CREATE TABLE IF NOT EXISTS `geo_redirects` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `url_id` INT NOT NULL,
    `country` VARCHAR(2) NOT NULL,
    `redirect_url` VARCHAR(2000) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_url_id` (`url_id`),
    INDEX `idx_country` (`country`),
    UNIQUE KEY `unique_url_country` (`url_id`, `country`),
    FOREIGN KEY (`url_id`) REFERENCES `urls`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
