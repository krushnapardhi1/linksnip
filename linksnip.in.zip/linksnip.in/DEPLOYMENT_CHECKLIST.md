﻿# SnapLink Pro Production Deployment Checklist
## Domain: snaplink.pro

## ✅ Pre-Deployment Checklist

### 1. Configuration Files Updated
- [x] `config/config.php` - APP_URL set to `https://snaplink.pro`
- [ ] `config/database.php` - InfinityFree MySQL credentials added
- [x] `auth/google/callback.php` - Redirect URI updated
- [ ] `.env` file created (if needed for sensitive data)

### 2. Domain Setup
- [ ] Domain purchased: **snaplink.pro** (GoDaddy) ✓
- [ ] InfinityFree account created
- [ ] Domain added to InfinityFree as Addon Domain
- [ ] Nameservers updated (Choose one):
  - [ ] **Option A:** InfinityFree nameservers (`ns1.byet.org`, `ns2.byet.org`)
  - [ ] **Option B:** Cloudflare nameservers (recommended)

### 3. Cloudflare Setup (Recommended)
- [ ] Cloudflare account created
- [ ] Site `snaplink.pro` added to Cloudflare
- [ ] Nameservers updated at GoDaddy to Cloudflare's
- [ ] DNS A records added:
  - [ ] `@` → InfinityFree IP (Proxied - Orange cloud)
  - [ ] `www` → InfinityFree IP (Proxied - Orange cloud)
- [ ] SSL mode set to **Full**
- [ ] **Always Use HTTPS** enabled
- [ ] Auto Minify enabled (HTML, CSS, JS)
- [ ] Page Rules created (cache static assets)

### 4. Google OAuth Configuration
- [ ] Google Cloud Console → OAuth 2.0 credentials created
- [ ] Authorized redirect URI added: `https://snaplink.pro/auth/google/callback.php`
- [ ] Client ID copied
- [ ] Client Secret copied
- [ ] Credentials added to:
  - [ ] `auth/google/callback.php` (lines 12-13)
  - [ ] `login.php` (line 181)
  - [ ] `register.php` (line 214)

### 5. File Upload to InfinityFree
- [ ] All files uploaded via FTP/File Manager to `htdocs/`
- [ ] `.htaccess` file uploaded
- [ ] File permissions verified:
  - [ ] `htdocs/` = 755
  - [ ] All `.php` files = 644
  - [ ] `uploads/` folder = 755 (writable)

### 6. Database Setup
- [ ] MySQL database created in InfinityFree panel
- [ ] Database credentials noted:
  - Host: `sqlXXX.infinityfreeapp.com`
  - Database: `epiz_XXXXXXXX_snaplink`
  - Username: `epiz_XXXXXXXX`
  - Password: `************`
- [ ] Credentials added to `config/database.php`
- [ ] Visit `https://snaplink.pro/install.php`
- [ ] Click "Install Database Tables"
- [ ] ⚠️ **DELETE `install.php` after installation!**

### 7. Initial Configuration
- [ ] Login with default admin credentials:
  - Email: `admin@snaplink.com`
  - Password: `admin123`
- [ ] **IMMEDIATELY** change admin password in settings
- [ ] Update site settings in admin panel
- [ ] Generate API key for testing

### 8. Feature Testing
- [ ] Homepage loads: `https://snaplink.pro`
- [ ] User registration works
- [ ] User login works (email/password)
- [ ] Google OAuth login works
- [ ] Create short URL works
- [ ] Short URL redirect works: `snaplink.pro/abc123`
- [ ] Analytics tracking works
- [ ] QR code generation works
- [ ] Bio page creation works
- [ ] Blog posts display
- [ ] API documentation page loads
- [ ] API key generation works
- [ ] API request works (test with cURL)
- [ ] Admin panel accessible: `snaplink.pro/admin`

### 9. Security
- [ ] Default admin password changed
- [ ] `install.php` deleted
- [ ] Error reporting disabled in production:
  - [ ] `config/config.php`: Set `error_reporting(0)` and `display_errors = 0`
- [ ] HTTPS working (green padlock in browser)
- [ ] Cloudflare firewall enabled
- [ ] Bot Fight Mode enabled (Cloudflare)

### 10. Performance Optimization
- [ ] Cloudflare caching enabled
- [ ] Browser cache TTL set (4+ hours)
- [ ] Auto Minify enabled (HTML, CSS, JS)
- [ ] Brotli compression enabled
- [ ] Images optimized before upload

### 11. Monitoring & Analytics
- [ ] Google Analytics tracking code active
- [ ] Cloudflare analytics accessible
- [ ] Error logs location identified
- [ ] Backup plan established

---

## 📝 Quick Commands Reference

### FTP Upload (FileZilla)
```
Host: ftpupload.net
Username: epiz_XXXXXXXX
Password: [your FTP password]
Port: 21
Directory: /htdocs
```

### Test Site is Live
```bash
# Windows CMD
ping snaplink.pro

# PowerShell
Test-NetConnection snaplink.pro -Port 443
```

### Test Short URL
```bash
curl -I https://snaplink.pro/test123
```

### Test API
```bash
curl -X POST https://snaplink.pro/api/shorten.php \
  -H "X-API-Key: your_api_key" \
  -H "Content-Type: application/json" \
  -d '{"url":"https://google.com"}'
```

---

## 🆘 Troubleshooting

### Site Not Loading
1. Check DNS propagation: https://www.whatsmydns.net/
2. Verify nameservers at GoDaddy
3. Check InfinityFree server status
4. Clear Cloudflare cache

### Database Connection Error
1. Verify credentials in `config/database.php`
2. Check database exists in InfinityFree panel
3. Ensure database user has permissions
4. Check InfinityFree MySQL host address

### Google OAuth Not Working
1. Verify redirect URI exactly matches in Google Console
2. Check Client ID and Secret are correct
3. Ensure domain uses HTTPS
4. Clear browser cookies and try again

### Short URLs Not Working (404)
1. Check `.htaccess` file uploaded
2. Verify mod_rewrite enabled (InfinityFree has it)
3. Test with simple URL: `snaplink.pro/test`
4. Check database for URL entry

### SSL Certificate Issues
1. Wait 15-30 minutes for Cloudflare SSL
2. Set Cloudflare SSL mode to **Full**
3. Force HTTPS in `.htaccess`
4. Check SSL settings in Cloudflare

---

## 📊 Post-Launch

### Week 1
- [ ] Monitor error logs daily
- [ ] Test all features thoroughly
- [ ] Gather user feedback
- [ ] Fix any bugs found

### Monthly
- [ ] Database backup
- [ ] File backup via FTP
- [ ] Review analytics
- [ ] Update dependencies if needed

---

## 🎉 Launch Complete!

Once all checklist items are ✅:
1. Share your short URL service: **snaplink.pro**
2. Create sample links to showcase
3. Test with friends/colleagues
4. Promote on social media
5. Enjoy your live URL shortener!

---

**Support Resources:**
- InfinityFree Forum: https://forum.infinityfree.net/
- Cloudflare Docs: https://developers.cloudflare.com/
- SnapLink Pro Issues: Check error logs in InfinityFree cPanel
