<?php
/**
 * Setup Links Table
 * Creates the 'links' table based on user specification
 */
// Enable error reporting to verify the fix
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';

try {
    $db = db();
    
    // SQL provided by user
    $sql = "CREATE TABLE IF NOT EXISTS links (
        id INT AUTO_INCREMENT PRIMARY KEY,
        long_url TEXT NOT NULL,
        short_code VARCHAR(10) NOT NULL UNIQUE,
        user_id INT NULL,
        guest_ip VARCHAR(45) NULL,
        title VARCHAR(255) NULL,
        description TEXT NULL,
        clicks INT DEFAULT 0,
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_short_code (short_code),
        INDEX idx_user_id (user_id),
        INDEX idx_guest_ip (guest_ip),
        INDEX idx_created_at (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";

    $db->execute($sql);
    
    echo "<h1>✅ Success!</h1>";
    echo "<p>Table <code>links</code> has been created/checked successfully.</p>";
    echo "<a href='index.php'>Go Back to Home</a>";

} catch (Exception $e) {
    echo "<h1>❌ Error</h1>";
    echo "<p>" . $e->getMessage() . "</p>";
}
