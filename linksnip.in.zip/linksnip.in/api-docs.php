﻿<?php
/**
 * API Documentation Page
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

// Must be logged in
if (!is_logged_in()) {
    redirect(base_url('login.php'));
}

$user = current_user();
$userId = $user['id'];

// Get user's API key
$apiKey = db()->fetchOne('SELECT api_key FROM api_keys WHERE user_id = ? LIMIT 1', [$userId]);
$hasApiKey = !empty($apiKey);
$apiKeyValue = $hasApiKey ? $apiKey['api_key'] : '';

// Get API usage stats
$stats = db()->fetchOne('
    SELECT 
        COUNT(*) as total_requests,
        COUNT(DISTINCT DATE(created_at)) as active_days,
        MAX(created_at) as last_used
    FROM api_requests 
    WHERE user_id = ?
', [$userId]) ?? ['total_requests' => 0, 'active_days' => 0, 'last_used' => null];

$pageTitle = 'API Documentation';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?> - SnapLink Pro</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/themes/prism-tomorrow.min.css">
    <style>
        body { font-family: 'Inter', sans-serif; }
        .code-block { position: relative; }
        .copy-btn { 
            position: absolute; 
            top: 10px; 
            right: 10px; 
            opacity: 0;
            transition: opacity 0.2s;
        }
        .code-block:hover .copy-btn { opacity: 1; }
    </style>
</head>
<body class="bg-gray-50">
    <?php require_once ROOT_PATH . '/components/header.php'; ?>

    <div class="max-w-7xl mx-auto px-4 py-8">
        <!-- Header -->
        <div class="mb-8">
            <h1 class="text-3xl font-bold text-gray-900 mb-2">
                <i class="fas fa-code text-purple-600 mr-2"></i>API Documentation
            </h1>
            <p class="text-gray-600">Integrate SnapLink Pro URL shortening into your applications</p>
        </div>

        <!-- API Key Section -->
        <div class="bg-white rounded-xl shadow-sm p-6 mb-6 border border-gray-200">
            <h2 class="text-xl font-bold text-gray-900 mb-4">
                <i class="fas fa-key text-purple-600 mr-2"></i>Your API Key
            </h2>
            
            <?php if ($hasApiKey): ?>
                <div class="bg-gray-50 rounded-lg p-4 mb-4">
                    <div class="flex items-center justify-between">
                        <code class="text-sm font-mono text-gray-800" id="apiKeyDisplay"><?= htmlspecialchars($apiKeyValue) ?></code>
                        <button onclick="copyApiKey()" class="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition text-sm">
                            <i class="fas fa-copy mr-2"></i>Copy
                        </button>
                    </div>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                    <div class="bg-blue-50 rounded-lg p-3 border border-blue-200">
                        <div class="text-blue-600 font-medium mb-1">Total Requests</div>
                        <div class="text-2xl font-bold text-blue-900"><?= number_format($stats['total_requests']) ?></div>
                    </div>
                    <div class="bg-green-50 rounded-lg p-3 border border-green-200">
                        <div class="text-green-600 font-medium mb-1">Active Days</div>
                        <div class="text-2xl font-bold text-green-900"><?= $stats['active_days'] ?></div>
                    </div>
                    <div class="bg-purple-50 rounded-lg p-3 border border-purple-200">
                        <div class="text-purple-600 font-medium mb-1">Last Used</div>
                        <div class="text-sm font-medium text-purple-900">
                            <?= $stats['last_used'] ? date('M d, Y', strtotime($stats['last_used'])) : 'Never' ?>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4">
                    <p class="text-yellow-800 mb-3">You don't have an API key yet. Generate one to get started!</p>
                    <button onclick="generateApiKey()" id="generateBtn" class="px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition">
                        <i class="fas fa-plus mr-2"></i>Generate API Key
                    </button>
                </div>
            <?php endif; ?>

            <div class="mt-4 flex gap-2">
                <a href="settings.php#api" class="text-purple-600 hover:text-purple-700 text-sm font-medium">
                    <i class="fas fa-cog mr-1"></i>Manage API Keys
                </a>
                <span class="text-gray-300">|</span>
                <a href="#rate-limits" class="text-purple-600 hover:text-purple-700 text-sm font-medium">
                    <i class="fas fa-tachometer-alt mr-1"></i>Rate Limits
                </a>
            </div>
        </div>

        <!-- Quick Start -->
        <div class="bg-gradient-to-br from-purple-600 to-pink-500 rounded-xl shadow-lg p-6 mb-6 text-white">
            <h2 class="text-2xl font-bold mb-3">
                <i class="fas fa-rocket mr-2"></i>Quick Start
            </h2>
            <p class="mb-4 text-purple-100">Get started with the SnapLink Pro API in under 5 minutes</p>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div class="bg-white/10 backdrop-blur rounded-lg p-4">
                    <div class="text-3xl mb-2">1️⃣</div>
                    <div class="font-semibold mb-1">Get API Key</div>
                    <div class="text-sm text-purple-100">Generate your API key above</div>
                </div>
                <div class="bg-white/10 backdrop-blur rounded-lg p-4">
                    <div class="text-3xl mb-2">2️⃣</div>
                    <div class="font-semibold mb-1">Make Request</div>
                    <div class="text-sm text-purple-100">Send POST to /api/shorten.php</div>
                </div>
                <div class="bg-white/10 backdrop-blur rounded-lg p-4">
                    <div class="text-3xl mb-2">3️⃣</div>
                    <div class="font-semibold mb-1">Get Short URL</div>
                    <div class="text-sm text-purple-100">Receive your shortened link</div>
                </div>
            </div>
        </div>

        <!-- Endpoints -->
        <div class="bg-white rounded-xl shadow-sm p-6 mb-6 border border-gray-200">
            <h2 class="text-2xl font-bold text-gray-900 mb-6">API Endpoints</h2>

            <!-- Shorten URL -->
            <div class="mb-8 pb-8 border-b border-gray-200">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-xl font-bold text-gray-900">Create Short URL</h3>
                    <span class="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium">POST</span>
                </div>
                <code class="block bg-gray-900 text-green-400 px-4 py-2 rounded-lg mb-4 text-sm">
                    POST <?= base_url('api/shorten.php') ?>
                </code>

                <h4 class="font-semibold text-gray-900 mb-2">Headers</h4>
                <div class="bg-gray-50 rounded-lg p-3 mb-4 text-sm font-mono">
                    X-API-Key: your_api_key_here
                </div>

                <h4 class="font-semibold text-gray-900 mb-2">Request Body (JSON)</h4>
                <div class="code-block">
                    <button class="copy-btn px-3 py-1 bg-gray-700 text-white rounded text-xs hover:bg-gray-600" onclick="copyCode(this)">
                        <i class="fas fa-copy mr-1"></i>Copy
                    </button>
                    <pre class="bg-gray-900 rounded-lg p-4 overflow-x-auto"><code class="language-json">{
  "url": "https://example.com/very/long/url",
  "custom_alias": "mylink",        // Optional
  "password": "secret123",         // Optional
  "expires_at": "2024-12-31",      // Optional (YYYY-MM-DD)
  "max_clicks": 100                // Optional
}</code></pre>
                </div>

                <h4 class="font-semibold text-gray-900 mb-2 mt-4">Response (200 OK)</h4>
                <div class="code-block">
                    <button class="copy-btn px-3 py-1 bg-gray-700 text-white rounded text-xs hover:bg-gray-600" onclick="copyCode(this)">
                        <i class="fas fa-copy mr-1"></i>Copy
                    </button>
                    <pre class="bg-gray-900 rounded-lg p-4 overflow-x-auto"><code class="language-json">{
  "success": true,
  "short_url": "<?= base_url('abc123') ?>",
  "short_code": "abc123",
  "qr_code": "<?= base_url('qr.php?code=abc123') ?>"
}</code></pre>
                </div>
            </div>

            <!-- Get URL Stats -->
            <div class="mb-8 pb-8 border-b border-gray-200">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-xl font-bold text-gray-900">Get URL Statistics</h3>
                    <span class="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">GET</span>
                </div>
                <code class="block bg-gray-900 text-green-400 px-4 py-2 rounded-lg mb-4 text-sm">
                    GET <?= base_url('api/stats.php?code={short_code}') ?>
                </code>

                <h4 class="font-semibold text-gray-900 mb-2">Response</h4>
                <div class="code-block">
                    <button class="copy-btn px-3 py-1 bg-gray-700 text-white rounded text-xs hover:bg-gray-600" onclick="copyCode(this)">
                        <i class="fas fa-copy mr-1"></i>Copy
                    </button>
                    <pre class="bg-gray-900 rounded-lg p-4 overflow-x-auto"><code class="language-json">{
  "success": true,
  "data": {
    "short_code": "abc123",
    "long_url": "https://example.com/very/long/url",
    "clicks": 42,
    "qr_scans": 5,
    "created_at": "2024-01-15 10:30:00"
  }
}</code></pre>
                </div>
            </div>
        </div>

        <!-- Code Examples -->
        <div class="bg-white rounded-xl shadow-sm p-6 mb-6 border border-gray-200">
            <h2 class="text-2xl font-bold text-gray-900 mb-6">Code Examples</h2>

            <!-- Tabs -->
            <div class="flex border-b border-gray-200 mb-6">
                <button class="tab-btn px-6 py-3 font-medium border-b-2 border-purple-600 text-purple-600" data-tab="curl">
                    <i class="fas fa-terminal mr-2"></i>cURL
                </button>
                <button class="tab-btn px-6 py-3 font-medium text-gray-600 hover:text-gray-900" data-tab="php">
                    <i class="fab fa-php mr-2"></i>PHP
                </button>
                <button class="tab-btn px-6 py-3 font-medium text-gray-600 hover:text-gray-900" data-tab="javascript">
                    <i class="fab fa-js mr-2"></i>JavaScript
                </button>
                <button class="tab-btn px-6 py-3 font-medium text-gray-600 hover:text-gray-900" data-tab="python">
                    <i class="fab fa-python mr-2"></i>Python
                </button>
            </div>

            <!-- cURL -->
            <div class="tab-content" data-tab="curl">
                <div class="code-block">
                    <button class="copy-btn px-3 py-1 bg-gray-700 text-white rounded text-xs hover:bg-gray-600" onclick="copyCode(this)">
                        <i class="fas fa-copy mr-1"></i>Copy
                    </button>
                    <pre class="bg-gray-900 rounded-lg p-4 overflow-x-auto"><code class="language-bash">curl -X POST <?= base_url('api/shorten.php') ?> \
  -H "X-API-Key: <?= $hasApiKey ? $apiKeyValue : 'your_api_key_here' ?>" \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://example.com/very/long/url",
    "custom_alias": "mylink"
  }'</code></pre>
                </div>
            </div>

            <!-- PHP -->
            <div class="tab-content hidden" data-tab="php">
                <div class="code-block">
                    <button class="copy-btn px-3 py-1 bg-gray-700 text-white rounded text-xs hover:bg-gray-600" onclick="copyCode(this)">
                        <i class="fas fa-copy mr-1"></i>Copy
                    </button>
                    <pre class="bg-gray-900 rounded-lg p-4 overflow-x-auto"><code class="language-php">&lt;?php
$apiKey = '<?= $hasApiKey ? $apiKeyValue : 'your_api_key_here' ?>';
$url = '<?= base_url('api/shorten.php') ?>';

$data = [
    'url' => 'https://example.com/very/long/url',
    'custom_alias' => 'mylink'
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-API-Key: ' . $apiKey,
    'Content-Type: application/json'
]);

$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);
echo $result['short_url'];
?&gt;</code></pre>
                </div>
            </div>

            <!-- JavaScript -->
            <div class="tab-content hidden" data-tab="javascript">
                <div class="code-block">
                    <button class="copy-btn px-3 py-1 bg-gray-700 text-white rounded text-xs hover:bg-gray-600" onclick="copyCode(this)">
                        <i class="fas fa-copy mr-1"></i>Copy
                    </button>
                    <pre class="bg-gray-900 rounded-lg p-4 overflow-x-auto"><code class="language-javascript">const apiKey = '<?= $hasApiKey ? $apiKeyValue : 'your_api_key_here' ?>';
const apiUrl = '<?= base_url('api/shorten.php') ?>';

const data = {
  url: 'https://example.com/very/long/url',
  custom_alias: 'mylink'
};

fetch(apiUrl, {
  method: 'POST',
  headers: {
    'X-API-Key': apiKey,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify(data)
})
.then(response => response.json())
.then(result => {
  console.log('Short URL:', result.short_url);
})
.catch(error => {
  console.error('Error:', error);
});</code></pre>
                </div>
            </div>

            <!-- Python -->
            <div class="tab-content hidden" data-tab="python">
                <div class="code-block">
                    <button class="copy-btn px-3 py-1 bg-gray-700 text-white rounded text-xs hover:bg-gray-600" onclick="copyCode(this)">
                        <i class="fas fa-copy mr-1"></i>Copy
                    </button>
                    <pre class="bg-gray-900 rounded-lg p-4 overflow-x-auto"><code class="language-python">import requests
import json

api_key = '<?= $hasApiKey ? $apiKeyValue : 'your_api_key_here' ?>'
api_url = '<?= base_url('api/shorten.php') ?>'

headers = {
    'X-API-Key': api_key,
    'Content-Type': 'application/json'
}

data = {
    'url': 'https://example.com/very/long/url',
    'custom_alias': 'mylink'
}

response = requests.post(api_url, headers=headers, data=json.dumps(data))
result = response.json()

print('Short URL:', result['short_url'])</code></pre>
                </div>
            </div>
        </div>

        <!-- Rate Limits -->
        <div id="rate-limits" class="bg-white rounded-xl shadow-sm p-6 mb-6 border border-gray-200">
            <h2 class="text-2xl font-bold text-gray-900 mb-4">
                <i class="fas fa-tachometer-alt text-purple-600 mr-2"></i>Rate Limits
            </h2>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div class="border border-gray-200 rounded-lg p-4">
                    <div class="text-gray-600 text-sm mb-1">Free Plan</div>
                    <div class="text-2xl font-bold text-gray-900">100</div>
                    <div class="text-gray-600 text-sm">requests/day</div>
                </div>
                <div class="border border-purple-200 rounded-lg p-4 bg-purple-50">
                    <div class="text-purple-600 text-sm mb-1">Pro Plan</div>
                    <div class="text-2xl font-bold text-purple-900">10,000</div>
                    <div class="text-purple-600 text-sm">requests/day</div>
                </div>
                <div class="border border-pink-200 rounded-lg p-4 bg-pink-50">
                    <div class="text-pink-600 text-sm mb-1">Enterprise Plan</div>
                    <div class="text-2xl font-bold text-pink-900">Unlimited</div>
                    <div class="text-pink-600 text-sm">requests/day</div>
                </div>
            </div>
            <div class="mt-4 bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p class="text-blue-800 text-sm">
                    <i class="fas fa-info-circle mr-2"></i>
                    Your current plan: <strong><?= ucfirst($user['plan']) ?></strong>
                    <?php if ($user['plan'] === 'free'): ?>
                        - <a href="pricing.php" class="text-blue-600 hover:underline">Upgrade for more requests</a>
                    <?php endif; ?>
                </p>
            </div>
        </div>

        <!-- Error Codes -->
        <div class="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
            <h2 class="text-2xl font-bold text-gray-900 mb-4">Error Codes</h2>
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead class="bg-gray-50 border-b border-gray-200">
                        <tr>
                            <th class="text-left py-3 px-4 font-semibold text-gray-900">Code</th>
                            <th class="text-left py-3 px-4 font-semibold text-gray-900">Message</th>
                            <th class="text-left py-3 px-4 font-semibold text-gray-900">Description</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <tr>
                            <td class="py-3 px-4 font-mono text-red-600">400</td>
                            <td class="py-3 px-4">Bad Request</td>
                            <td class="py-3 px-4 text-gray-600">Invalid or missing parameters</td>
                        </tr>
                        <tr>
                            <td class="py-3 px-4 font-mono text-red-600">401</td>
                            <td class="py-3 px-4">Unauthorized</td>
                            <td class="py-3 px-4 text-gray-600">Invalid or missing API key</td>
                        </tr>
                        <tr>
                            <td class="py-3 px-4 font-mono text-red-600">403</td>
                            <td class="py-3 px-4">Forbidden</td>
                            <td class="py-3 px-4 text-gray-600">Account suspended or rate limit exceeded</td>
                        </tr>
                        <tr>
                            <td class="py-3 px-4 font-mono text-yellow-600">409</td>
                            <td class="py-3 px-4">Conflict</td>
                            <td class="py-3 px-4 text-gray-600">Custom alias already exists</td>
                        </tr>
                        <tr>
                            <td class="py-3 px-4 font-mono text-red-600">500</td>
                            <td class="py-3 px-4">Server Error</td>
                            <td class="py-3 px-4 text-gray-600">Internal server error</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/prism.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-bash.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-php.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-javascript.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-python.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.29.0/components/prism-json.min.js"></script>

    <script>
        // Tab switching
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const tab = this.dataset.tab;
                
                // Update buttons
                document.querySelectorAll('.tab-btn').forEach(b => {
                    b.classList.remove('border-purple-600', 'text-purple-600');
                    b.classList.add('text-gray-600');
                });
                this.classList.add('border-purple-600', 'text-purple-600');
                this.classList.remove('text-gray-600');
                
                // Update content
                document.querySelectorAll('.tab-content').forEach(content => {
                    content.classList.add('hidden');
                });
                document.querySelector(`[data-tab="${tab}"].tab-content`).classList.remove('hidden');
            });
        });

        // Copy code
        function copyCode(btn) {
            const code = btn.nextElementSibling.textContent;
            navigator.clipboard.writeText(code).then(() => {
                btn.innerHTML = '<i class="fas fa-check mr-1"></i>Copied!';
                setTimeout(() => {
                    btn.innerHTML = '<i class="fas fa-copy mr-1"></i>Copy';
                }, 2000);
            });
        }

        // Copy API key
        function copyApiKey() {
            const apiKey = document.getElementById('apiKeyDisplay').textContent;
            navigator.clipboard.writeText(apiKey).then(() => {
                alert('API Key copied to clipboard!');
            });
        }

        // Generate API key
        async function generateApiKey() {
            if (!confirm('Generate a new API key? This will create your first API key.')) return;
            
            const btn = document.getElementById('generateBtn');
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Generating...';
            
            try {
                const response = await fetch('api/generate-key.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' }
                });
                const data = await response.json();
                
                if (data.success) {
                    location.reload();
                } else {
                    alert(data.error || 'Failed to generate API key');
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-plus mr-2"></i>Generate API Key';
                }
            } catch (error) {
                alert('Error generating API key');
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-plus mr-2"></i>Generate API Key';
            }
        }
    </script>
</body>
</html>
