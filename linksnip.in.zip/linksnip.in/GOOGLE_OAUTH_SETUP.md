﻿# Google OAuth Setup Guide

This guide will help you set up Google OAuth authentication for SnapLink Pro.

## Step 1: Create Google Cloud Project

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select an existing one
3. Enable the **Google+ API** (or People API)

## Step 2: Create OAuth 2.0 Credentials

1. Navigate to **APIs & Services** > **Credentials**
2. Click **Create Credentials** > **OAuth client ID**
3. Select **Web application**
4. Configure the following:
   - **Name**: SnapLink Pro OAuth
   - **Authorized JavaScript origins**: 
     - `http://localhost` (for local development)
     - `https://yourdomain.com` (for production)
   - **Authorized redirect URIs**:
     - `http://localhost/urlshortener/php-version/auth/google/callback.php` (local)
     - `https://yourdomain.com/auth/google/callback.php` (production)

5. Click **Create** and copy your:
   - Client ID
   - Client Secret

## Step 3: Configure SnapLink Pro

Update the following files with your Google OAuth credentials:

### 1. `auth/google/callback.php`

Replace these lines (around line 12-14):

```php
define('GOOGLE_CLIENT_ID', 'YOUR_GOOGLE_CLIENT_ID');
define('GOOGLE_CLIENT_SECRET', 'YOUR_GOOGLE_CLIENT_SECRET');
define('GOOGLE_REDIRECT_URI', 'http://localhost/urlshortener/php-version/auth/google/callback.php');
```

With your actual credentials:

```php
define('GOOGLE_CLIENT_ID', 'your-actual-client-id-here.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', 'your-actual-client-secret-here');
define('GOOGLE_REDIRECT_URI', 'https://yourdomain.com/auth/google/callback.php');
```

### 2. `login.php`

Replace line 181:

```php
$googleClientId = 'YOUR_GOOGLE_CLIENT_ID'; // TODO: Replace with actual client ID
```

With:

```php
$googleClientId = 'your-actual-client-id-here.apps.googleusercontent.com';
```

### 3. `register.php`

Replace line 214:

```php
$googleClientId = 'YOUR_GOOGLE_CLIENT_ID'; // TODO: Replace with actual client ID
```

With:

```php
$googleClientId = 'your-actual-client-id-here.apps.googleusercontent.com';
```

## Step 4: Database Migration (For Existing Installations)

If you've already installed SnapLink Pro before this update, run the migration script:

```bash
mysql -u your_username -p your_database_name < migration_google_oauth.sql
```

Or manually run the SQL commands in phpMyAdmin.

## Step 5: Test the Integration

1. Navigate to your login or register page
2. Click the "Continue with Google" button
3. You should be redirected to Google's authorization page
4. After authorization, you should be logged in to SnapLink Pro

## Troubleshooting

### Error: "redirect_uri_mismatch"

Make sure the redirect URI in your Google Cloud Console matches exactly with the one in your code.

### Error: "Invalid client"

Double-check that your Client ID and Client Secret are correct.

### Users can't login with Google

1. Check that the `google_id` and `avatar` columns exist in your `users` table
2. Verify your database credentials in `config/database.php`
3. Check error logs in `error_log` or browser console

## Security Notes

- **Never commit your Client Secret** to version control
- Use environment variables in production (update `config/config.php` to read from `.env`)
- Make sure SSL/HTTPS is enabled in production

## Features

Once configured, users can:
- Sign up with their Google account (no password required)
- Login with their Google account
- Link their Google account to an existing email-based account
- See their Google profile picture as their avatar

New users signing up with Google will be:
- Automatically assigned the "free" plan
- Created with their Google name and email
- Given their Google profile picture as their avatar
