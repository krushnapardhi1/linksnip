﻿<?php
/**
 * Guest Links Page
 * Shows links created by guest users and allows claiming them after signup
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

$user = current_user();

// Get guest IP
$guestIp = get_client_ip();

// Fetch guest links for this IP
$guestLinks = [];
$rateLimit = null;

$guestLinks = db()->fetchAll(
    "SELECT id, long_url, short_code, clicks, created_at 
     FROM urls 
     WHERE is_guest = 1 AND created_by_ip = ? 
     ORDER BY created_at DESC 
     LIMIT 20",
    [$guestIp]
);

// Get rate limit info
$today = date('Y-m-d');
$rateLimit = db()->fetchOne(
    "SELECT links_created_today, last_reset_date FROM guest_rate_limits WHERE ip_address = ?",
    [$guestIp]
);

$linksToday = 0;
if ($rateLimit) {
    if ($rateLimit['last_reset_date'] === $today) {
        $linksToday = (int)$rateLimit['links_created_today'];
    }
}

$GUEST_DAILY_LIMIT = 5;
$linksRemaining = max(0, $GUEST_DAILY_LIMIT - $linksToday);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Guest Links - <?= APP_NAME ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body {
            font-family: 'Inter', sans-serif;
        }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <?php if ($user): ?>
        <!-- User is logged in - show navbar -->
        <nav class="bg-white border-b border-gray-200">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex items-center justify-between h-16">
                    <div class="flex items-center gap-2">
                        <a href="index.php" class="text-xl font-bold text-purple-600">SnapLink Pro</a>
                    </div>
                    <div class="flex items-center gap-4">
                        <a href="dashboard.php" class="text-gray-700 hover:text-purple-600">Dashboard</a>
                        <a href="logout.php" class="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600">Logout</a>
                    </div>
                </div>
            </div>
        </nav>
    <?php else: ?>
        <!-- Guest user - show simple header -->
        <nav class="bg-gradient-to-r from-purple-600 to-pink-500 text-white">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex items-center justify-between h-16">
                    <div class="flex items-center gap-2">
                        <a href="index.php" class="text-xl font-bold">SnapLink Pro</a>
                    </div>
                    <div class="flex items-center gap-4">
                        <a href="login.php" class="text-white/90 hover:text-white">Login</a>
                        <a href="register.php" class="px-4 py-2 bg-white text-purple-600 rounded-lg hover:bg-white/90 font-semibold">Sign Up Free</a>
                    </div>
                </div>
            </div>
        </nav>
    <?php endif; ?>

    <div class="max-w-4xl mx-auto px-4 py-12">
        <div class="bg-white rounded-2xl shadow-sm p-8 mb-8">
            <div class="flex items-center justify-between mb-6">
                <div>
                    <h1 class="text-3xl font-bold text-gray-900 mb-2">
                        <?= $user ? 'Links Created as Guest' : 'Your Short Links' ?>
                    </h1>
                    <p class="text-gray-600">
                        <?= $user ? 'These are links you created before signing up.' : 'You can create up to ' . $GUEST_DAILY_LIMIT . ' links per day as a guest.' ?>
                    </p>
                </div>
                <?php if (!$user): ?>
                    <div class="text-right">
                        <div class="text-2xl font-bold text-purple-600"><?= $linksRemaining ?></div>
                        <div class="text-sm text-gray-500">links remaining today</div>
                    </div>
                <?php endif; ?>
            </div>

            <?php if (!$user): ?>
                <!-- Call to Action for Guest Users -->
                <div class="bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl p-6 mb-8 border border-purple-200">
                    <div class="flex items-start gap-4">
                        <div class="w-12 h-12 bg-purple-600 rounded-xl flex items-center justify-center flex-shrink-0">
                            <i class="fas fa-rocket text-white text-xl"></i>
                        </div>
                        <div class="flex-1">
                            <h3 class="text-xl font-bold text-gray-900 mb-2">Unlock Unlimited Features!</h3>
                            <p class="text-gray-600 mb-4">
                                Sign up for free to get unlimited links, custom aliases, analytics, password protection, and much more!
                            </p>
                            <a href="register.php" class="inline-flex items-center gap-2 px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 font-semibold transition">
                                <span>Sign Up Free</span>
                                <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Links List -->
            <?php if (empty($guestLinks)): ?>
                <div class="text-center py-12">
                    <div class="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-link text-gray-400 text-2xl"></i>
                    </div>
                    <h3 class="text-lg font-semibold text-gray-900 mb-2">No links yet</h3>
                    <p class="text-gray-600 mb-6">Create your first short link to get started!</p>
                    <a href="index.php" class="inline-flex items-center gap-2 px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 font-semibold">
                        <i class="fas fa-plus"></i>
                        <span>Create Link</span>
                    </a>
                </div>
            <?php else: ?>
                <div class="space-y-4">
                    <?php foreach ($guestLinks as $link): ?>
                        <div class="border border-gray-200 rounded-xl p-4 hover:border-purple-300 transition">
                            <div class="flex items-center justify-between gap-4">
                                <div class="flex-1 min-w-0">
                                    <div class="flex items-center gap-3 mb-2">
                                        <a href="<?= APP_URL ?>/<?= htmlspecialchars($link['short_code']) ?>" 
                                           target="_blank"
                                           class="text-lg font-semibold text-purple-600 hover:text-purple-700 truncate">
                                            <?= APP_URL ?>/<?= htmlspecialchars($link['short_code']) ?>
                                        </a>
                                        <button onclick="copyLink('<?= APP_URL ?>/<?= htmlspecialchars($link['short_code']) ?>')" 
                                                class="p-2 hover:bg-gray-100 rounded-lg transition" 
                                                title="Copy">
                                            <i class="fas fa-copy text-gray-500"></i>
                                        </button>
                                    </div>
                                    <div class="text-sm text-gray-600 truncate mb-2">
                                        <i class="fas fa-long-arrow-alt-right text-gray-400"></i>
                                        <?= htmlspecialchars($link['long_url']) ?>
                                    </div>
                                    <div class="flex items-center gap-4 text-xs text-gray-500">
                                        <span>
                                            <i class="fas fa-mouse-pointer"></i>
                                            <?= number_format($link['clicks']) ?> clicks
                                        </span>
                                        <span>
                                            <i class="fas fa-calendar"></i>
                                            <?= date('M j, Y', strtotime($link['created_at'])) ?>
                                        </span>
                                    </div>
                                </div>
                                <div class="flex items-center gap-2">
                                    <a href="<?= APP_URL ?>/<?= htmlspecialchars($link['short_code']) ?>" 
                                       target="_blank"
                                       class="p-2 hover:bg-purple-50 text-purple-600 rounded-lg transition" 
                                       title="Visit">
                                        <i class="fas fa-external-link-alt"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <?php if (!$user): ?>
                    <div class="mt-8 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                        <p class="text-sm text-blue-800">
                            <i class="fas fa-info-circle"></i>
                            <strong>Note:</strong> These links are tied to your IP address. Sign up to claim them and manage all your links in one place!
                        </p>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <!-- Back to Home -->
        <div class="text-center">
            <a href="index.php" class="text-purple-600 hover:text-purple-700 font-semibold">
                <i class="fas fa-arrow-left mr-2"></i>
                Back to Home
            </a>
        </div>
    </div>

    <script>
        function copyLink(url) {
            navigator.clipboard.writeText(url).then(() => {
                alert('Link copied to clipboard!');
            }).catch(err => {
                console.error('Failed to copy:', err);
            });
        }
    </script>
</body>
</html>
