﻿<?php
/**
 * Login Page
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

// Redirect if already logged in
if (is_logged_in()) {
    redirect(base_url('dashboard.php'));
}

$error = null;
$flash = get_flash();
$recaptchaKey = '';
$settings = [];

// Safely fetch settings
try {
    $rows = db()->fetchAll("SELECT * FROM site_settings WHERE key_name IN ('recaptcha_site_key', 'recaptcha_secret_key')");
    foreach ($rows as $row) {
        $settings[$row['key_name']] = $row['value'];
    }
    $recaptchaKey = $settings['recaptcha_site_key'] ?? '';
} catch (Exception $e) {
    // Table might not exist yet if migrations weren't run
    $recaptchaKey = '';
}

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = 'Email and password are required';
    } else {
        // Verify reCAPTCHA
        $secretKey = $settings['recaptcha_secret_key'] ?? '';
        if (!empty($recaptchaKey) && !empty($secretKey)) {
            $token = $_POST['recaptcha_token'] ?? '';
            $verifyUrl = 'https://www.google.com/recaptcha/api/siteverify';
            $data = [
                'secret' => $secretKey,
                'response' => $token
            ];
            
            $options = [
                'http' => [
                    'header' => "Content-type: application/x-www-form-urlencoded\r\n",
                    'method' => 'POST',
                    'content' => http_build_query($data),
                    'timeout' => 5
                ]
            ];
            $context = stream_context_create($options);
            $result = @file_get_contents($verifyUrl, false, $context);
            if ($result) {
                $response = json_decode($result);
                if (!$response || !$response->success || ($response->score ?? 0) < 0.5) {
                    $error = 'Security check failed. Please try again.';
                }
            }
        }

        if (!$error) {
            try {
                $user = db()->fetchOne('SELECT * FROM users WHERE email = ?', [$email]);

                if (!$user || !password_verify($password, $user['password'])) {
                    $error = 'Invalid email or password';
                } elseif ($user['status'] === 'banned') {
                    $error = 'Your account has been restricted.';
                } else {
                    // Check if 2FA is enabled
                    if (!empty($user['two_factor_enabled']) && $user['two_factor_enabled'] == 1) {
                        $_SESSION['partial_user_id'] = $user['id'];
                        
                        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH'])) {
                            json_response(['success' => true, 'redirect' => 'login-verify.php']);
                        }
                        redirect('login-verify.php');
                        exit;
                    }

                    // Successful Login (No 2FA)
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['user_name'] = $user['name'];
                    $_SESSION['user_email'] = $user['email'];
                    $_SESSION['user_role'] = $user['role'];
                    $_SESSION['user_plan'] = $user['plan'];
                    $_SESSION['user_theme'] = $user['theme'];

                    $defaultRedirect = $user['role'] === 'admin' ? base_url('admin/index.php') : base_url('dashboard.php');
                    $redirectUrl = $_SESSION['redirect_after_login'] ?? $defaultRedirect;
                    unset($_SESSION['redirect_after_login']);

                    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH'])) {
                        json_response(['success' => true, 'redirect' => $redirectUrl]);
                    }
                    redirect($redirectUrl);
                }
            } catch (Exception $e) {
                error_log("Login error: " . $e->getMessage());
                $error = 'Login failed. Please try again.';
            }
        }
    }

    // If AJAX request, return error as JSON
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        json_response(['error' => $error], 400);
    }
}

$csrf = csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - SnapLink Pro</title>
    <?php if (function_exists('meta_canonical')) meta_canonical('php-version/login.php'); ?>
    <script src="https://accounts.google.com/gsi/client" async defer></script>
    <meta name="google-signin-client_id" content="<?= defined('GOOGLE_CLIENT_ID') ? GOOGLE_CLIENT_ID : '' ?>">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Inter', 'sans-serif'] },
                    colors: {
                        brand: { purple: '#7F00FF', pink: '#E100FF' }
                    }
                }
            }
        }
    </script>
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
    <?php if ($recaptchaKey): ?>
    <script src="https://www.google.com/recaptcha/api.js?render=<?= $recaptchaKey ?>"></script>
    <?php endif; ?>
</head>
<body class="bg-gradient-to-br from-purple-600 to-pink-500 min-h-screen flex items-center justify-center p-4">
    <div class="w-full max-w-md">
        <!-- Logo -->
        <div class="text-center mb-8">
            <a href="index.php" class="inline-flex items-center gap-2 text-white">
                <div class="w-12 h-12 rounded-xl bg-white flex items-center justify-center text-brand-purple shadow-lg">
                    <i class="fas fa-link text-xl"></i>
                </div>
                <span class="text-3xl font-bold">Link<span class="text-yellow-300">Snip</span></span>
            </a>
        </div>

        <!-- Login Card -->
        <div class="bg-white rounded-2xl shadow-2xl p-8">
            <h2 class="text-2xl font-bold text-gray-900 text-center mb-2">Welcome Back!</h2>
            <p class="text-gray-500 text-center mb-8">Login to manage your links</p>

            <?php if ($flash): ?>
                <div class="mb-6 p-4 rounded-lg <?= $flash['type'] === 'success' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200' ?>">
                    <?= $flash['message'] ?>
                </div>
            <?php endif; ?>

            <div id="errorAlert" class="mb-6 p-4 rounded-lg bg-red-50 text-red-700 border border-red-200 hidden"></div>

            <?php if ($error): ?>
                <div class="mb-6 p-4 rounded-lg bg-red-50 text-red-700 border border-red-200">
                    <i class="fas fa-exclamation-circle mr-2"></i><?= $error ?>
                </div>
            <?php endif; ?>

            <form id="loginForm" method="POST" class="space-y-5">
                <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-gray-400">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <input type="email" name="email" required
                            class="w-full pl-11 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition"
                            placeholder="you@example.com"
                            value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                    </div>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Password</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-gray-400">
                            <i class="fas fa-lock"></i>
                        </div>
                        <input type="password" name="password" id="password" required
                            class="w-full pl-11 pr-12 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition"
                            placeholder="Enter your password">
                        <button type="button" onclick="togglePassword()" class="absolute inset-y-0 right-0 pr-4 flex items-center text-gray-400 hover:text-gray-600">
                            <i class="fas fa-eye" id="toggleIcon"></i>
                        </button>
                    </div>
                </div>

                <div class="flex items-center justify-between">
                    <label class="flex items-center">
                        <input type="checkbox" name="remember" class="w-4 h-4 rounded border-gray-300 text-purple-600 focus:ring-purple-500">
                        <span class="ml-2 text-sm text-gray-600">Remember me</span>
                    </label>
                    <a href="forgot-password.php" class="text-sm text-purple-600 hover:text-purple-700 font-medium">Forgot password?</a>
                </div>

                <button type="submit" id="submitBtn"
                    class="w-full py-3 bg-gradient-to-r from-purple-600 to-pink-500 text-white rounded-xl font-semibold hover:opacity-90 transition flex items-center justify-center gap-2">
                    <span>Login</span>
                    <i class="fas fa-arrow-right"></i>
                </button>
            </form>

            <!-- OAuth Divider -->
            <div class="flex items-center my-6">
                <div class="flex-1 border-t border-gray-200"></div>
                <span class="px-4 text-sm text-gray-500">or continue with</span>
                <div class="flex-1 border-t border-gray-200"></div>
            </div>

            <!-- Google OAuth Button -->
            <div id="g_id_onload"
                 data-client_id="<?= defined('GOOGLE_CLIENT_ID') ? GOOGLE_CLIENT_ID : '' ?>"
                 data-login_uri="https://snaplink.pro/php-version/auth/google/callback"
                 data-auto_prompt="false">
            </div>

            <div class="g_id_signin"
                 data-type="standard"
                 data-size="large"
                 data-theme="outline"
                 data-text="signin_with"
                 data-shape="rectangular"
                 data-logo_alignment="left">
            </div>

            <div class="mt-8 text-center">
                <p class="text-gray-500">
                    Don't have an account?
                    <a href="register.php" class="text-purple-600 font-semibold hover:text-purple-700">Sign up free</a>
                </p>
            </div>
        </div>

        <!-- Back to Home -->
        <div class="text-center mt-6">
            <a href="index.php" class="text-white/80 hover:text-white transition">
                <i class="fas fa-arrow-left mr-2"></i>Back to Home
            </a>
        </div>
    </div>

    <script>
        function togglePassword() {
            const input = document.getElementById('password');
            const icon = document.getElementById('toggleIcon');
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.replace('fa-eye', 'fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.replace('fa-eye-slash', 'fa-eye');
            }
        }

        // AJAX Form Submit
        const form = document.getElementById('loginForm');
        const submitLogic = async (e) => {
            if(e) e.preventDefault();
            
            const btn = document.getElementById('submitBtn');
            const originalText = btn.innerHTML;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Logging in...';
            btn.disabled = true;

            try {
                const formData = new FormData(form);
                const res = await fetch('login.php', {
                    method: 'POST',
                    body: formData,
                    headers: { 'X-Requested-With': 'XMLHttpRequest' }
                });
                
                // Check if response is JSON (sometimes 500 html returns)
                const contentType = res.headers.get("content-type");
                if (!contentType || !contentType.includes("application/json")) {
                    throw new Error("Server error (500)");
                }

                const data = await res.json();

                if (data.success) {
                    window.location.href = data.redirect;
                } else {
                    const errorDiv = document.getElementById('errorAlert');
                    errorDiv.innerHTML = '<i class="fas fa-exclamation-circle mr-2"></i>' + (data.error || 'Login failed');
                    errorDiv.classList.remove('hidden');
                    
                    btn.innerHTML = originalText;
                    btn.disabled = false;
                }
            } catch (err) {
                console.error(err);
                if (err.message.includes("500")) {
                    alert("Server Error. Please write to support.");
                } else {
                    form.submit(); // Fallback if regular error
                }
                btn.innerHTML = originalText;
                btn.disabled = false;
            }
        };

        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            <?php if ($recaptchaKey): ?>
                grecaptcha.ready(function() {
                    grecaptcha.execute('<?= $recaptchaKey ?>', {action: 'login'}).then(function(token) {
                        let input = document.getElementById('recaptcha_token');
                        if (!input) {
                            input = document.createElement('input');
                            input.type = 'hidden';
                            input.name = 'recaptcha_token';
                            input.id = 'recaptcha_token';
                            form.appendChild(input);
                        }
                        input.value = token;
                        submitLogic();
                    });
                });
            <?php else: ?>
                submitLogic();
            <?php endif; ?>
        });
    </script>
    <?php require_once ROOT_PATH . '/components/cookie-consent.php'; ?>
</body>
</html>
