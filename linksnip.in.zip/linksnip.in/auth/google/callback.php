<?php
/**
 * Google OAuth Callback Handler (Composer-less version)
 */
define('ROOT_PATH', dirname(dirname(__DIR__)));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

// Get ID Token from POST
// Google One Tap / Sign-In with data-login_uri sends it in 'credential'
$id_token = $_POST['credential'] ?? $_POST['token'] ?? null;

if (!$id_token) {
    redirect(base_url('login.php?error=' . urlencode('No ID token received')));
}

try {
    // Verify token via Google API (No Composer required)
    $url = "https://oauth2.googleapis.com/tokeninfo?id_token=" . urlencode($id_token);
    
    // Try cURL first (more reliable on shared hosting)
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // For some shared hosts
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($response === false || $httpCode !== 200) {
            throw new Exception("Failed to verify token with Google (cURL)");
        }
    } elseif (ini_get('allow_url_fopen')) {
        // Fallback to file_get_contents if cURL unavailable
        $response = @file_get_contents($url);
        if ($response === false) {
            throw new Exception("Failed to verify token with Google (fopen)");
        }
    } else {
        throw new Exception("Neither cURL nor allow_url_fopen is enabled on this server");
    }
    
    $payload = json_decode($response, true);
    
    // Check if token is valid and audience matches
    if (($payload['aud'] ?? '') !== GOOGLE_CLIENT_ID) {
        throw new Exception("Invalid Client ID");
    }

    if (isset($payload['email'])) {
        $googleId = $payload['sub'];
        $email = $payload['email'];
        $name = $payload['name'];
        $picture = $payload['picture'] ?? '';

        // Check if user exists
        $user = db()->fetchOne("SELECT * FROM users WHERE email = ?", [$email]);

        if ($user) {
            // User exists - Login
            // Update Google ID/Avatar if missing
            if (empty($user['google_id']) || empty($user['avatar'])) {
                db()->execute(
                    "UPDATE users SET google_id = ?, avatar = ? WHERE id = ?", 
                    [$googleId, $picture, $user['id']]
                );
            }
        } else {
            // Register new user
            $randomPass = bin2hex(random_bytes(10)); // Random password
            $hashedPass = password_hash($randomPass, PASSWORD_BCRYPT);
            
            $userId = db()->insert(
                "INSERT INTO users (name, email, password, google_id, avatar, role, plan, status, theme) 
                 VALUES (?, ?, ?, ?, ?, 'user', 'free', 'active', 'light')",
                [$name, $email, $hashedPass, $googleId, $picture]
            );
            
            $user = db()->fetchOne("SELECT * FROM users WHERE id = ?", [$userId]);
        }
        
        // Handle banned users
        if (($user['status'] ?? 'active') === 'banned') {
            redirect(base_url('login.php?error=' . urlencode('Account suspended')));
        }

        // Set Session
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['email'] = $user['email']; // Compatibility alias
        $_SESSION['user_role'] = $user['role'] ?? 'user';
        $_SESSION['user_plan'] = $user['plan'] ?? 'free';
        $_SESSION['user_theme'] = $user['theme'] ?? 'light';
        $_SESSION['user_avatar'] = $user['avatar'] ?? $picture;

        // Redirect to Dashboard
        $redirectUrl = ($user['role'] ?? 'user') === 'admin' ? base_url('admin/index.php') : base_url('dashboard.php');
        redirect($redirectUrl);

    } else {
        redirect(base_url('login.php?error=' . urlencode('Invalid Google ID token')));
    }
} catch (Exception $e) {
    error_log("Google Auth Error: " . $e->getMessage());
    error_log("Stack trace: " . $e->getTraceAsString());
    
    // More detailed error for debugging (remove in production)
    $errorMsg = 'Authentication failed: ' . $e->getMessage();
    redirect(base_url('login.php?error=' . urlencode($errorMsg)));
}
