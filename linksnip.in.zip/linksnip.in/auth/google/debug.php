<?php
// Enhanced error debug script
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h2>Callback Debug Information</h2>";

// 1. Check ROOT_PATH
define('ROOT_PATH', dirname(dirname(__DIR__)));
echo "<strong>ROOT_PATH:</strong> " . ROOT_PATH . "<br>";

// 2. Check config file
$config_path = ROOT_PATH . '/config/config.php';
echo "<strong>Config path:</strong> " . $config_path . "<br>";
echo "<strong>Config exists:</strong> " . (file_exists($config_path) ? 'YES ✓' : 'NO ✗') . "<br><br>";

// 3. Try loading config
if (file_exists($config_path)) {
    try {
        require_once $config_path;
        echo "<strong>Config loaded:</strong> YES ✓<br>";
        echo "<strong>GOOGLE_CLIENT_ID defined:</strong> " . (defined('GOOGLE_CLIENT_ID') ? 'YES ✓' : 'NO ✗') . "<br>";
        if (defined('GOOGLE_CLIENT_ID')) {
            echo "<strong>GOOGLE_CLIENT_ID:</strong> " . GOOGLE_CLIENT_ID . "<br>";
        }
    } catch (Exception $e) {
        echo "<strong style='color:red'>Config Error:</strong> " . $e->getMessage() . "<br>";
    }
} else {
    echo "<strong style='color:red'>ERROR:</strong> Config file not found!<br>";
}

echo "<br>";

// 4. Check database connection
$db_path = ROOT_PATH . '/config/database.php';
echo "<strong>Database file exists:</strong> " . (file_exists($db_path) ? 'YES ✓' : 'NO ✗') . "<br>";

if (file_exists($db_path)) {
    try {
        require_once $db_path;
        echo "<strong>Database loaded:</strong> YES ✓<br>";
        
        // Test DB connection
        $testQuery = db()->fetchOne("SELECT COUNT(*) as count FROM users");
        echo "<strong>DB Connection:</strong> Working ✓ (Users count: " . $testQuery['count'] . ")<br>";
    } catch (Exception $e) {
        echo "<strong style='color:red'>DB Error:</strong> " . $e->getMessage() . "<br>";
    }
}

echo "<br>";

// 5. Check cURL and allow_url_fopen
echo "<strong>cURL available:</strong> " . (function_exists('curl_init') ? 'YES ✓' : 'NO ✗') . "<br>";
echo "<strong>allow_url_fopen:</strong> " . (ini_get('allow_url_fopen') ? 'YES ✓' : 'NO ✗') . "<br>";

echo "<br>";

// 6. Test Google API call
if (function_exists('curl_init')) {
    echo "<h3>Testing Google Token Verification</h3>";
    echo "<em>Using a dummy token to test connection...</em><br>";
    
    $testUrl = "https://oauth2.googleapis.com/tokeninfo?id_token=test";
    $ch = curl_init($testUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);
    
    echo "<strong>HTTP Code:</strong> " . $httpCode . "<br>";
    if ($curlError) {
        echo "<strong style='color:red'>cURL Error:</strong> " . $curlError . "<br>";
    }
    echo "<strong>Response:</strong> " . htmlspecialchars(substr($response, 0, 200)) . "...<br>";
}

echo "<br>";

// 7. Show POST data if any
echo "<h3>POST Data</h3>";
if (empty($_POST)) {
    echo "<em>No POST data (this is normal for direct access)</em><br>";
} else {
    echo "<pre>";
    var_dump($_POST);
    echo "</pre>";
}

echo "<br><hr>";
echo "<p><strong>Note:</strong> If you see this page, the basic PHP file is working. Check for any red ✗ marks above.</p>";
