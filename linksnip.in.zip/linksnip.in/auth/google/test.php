<?php
// Minimal test - no dependencies
echo "PHP is working!<br>";
echo "PHP Version: " . phpversion() . "<br>";
echo "Current file: " . __FILE__ . "<br>";
echo "Current dir: " . __DIR__ . "<br>";
echo "Parent dir: " . dirname(__DIR__) . "<br>";
echo "Root would be: " . dirname(dirname(__DIR__)) . "<br>";

$root = dirname(dirname(__DIR__));
echo "<br>Checking config path: " . $root . '/config/config.php' . "<br>";
echo "Config exists: " . (file_exists($root . '/config/config.php') ? 'YES' : 'NO') . "<br>";

if (file_exists($root . '/config/config.php')) {
    echo "<br>Trying to read first few lines of config:<br>";
    $lines = file($root . '/config/config.php', FILE_IGNORE_NEW_LINES);
    echo "<pre>";
    for ($i = 0; $i < min(10, count($lines)); $i++) {
        echo htmlspecialchars($lines[$i]) . "\n";
    }
    echo "</pre>";
}
