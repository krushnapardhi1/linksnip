﻿<?php
/**
 * Dynamic Page Handler
 * Displays content for pages like About Us, Terms, Privacy, etc.
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

$slug = $_GET['slug'] ?? '';
$slug = preg_replace('/[^a-z0-9-]/', '', strtolower($slug)); // Sanitize

$page = null;
if ($slug) {
    try {
        $page = db()->fetchOne("SELECT * FROM pages WHERE slug = ?", [$slug]);
    } catch (Exception $e) {
        // Table might not exist
        $page = null;
    }
}

// 404 if not found
if (!$page) {
    http_response_code(404);
    $page = [
        'title' => 'Page Not Found',
        'content' => '<div class="text-center py-12"><i class="fas fa-file-circle-question text-6xl text-gray-300 mb-4"></i><p class="text-xl text-gray-600">The page you are looking for does not exist.</p><a href="index.php" class="mt-6 inline-block px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700">Go Home</a></div>',
        'updated_at' => date('Y-m-d H:i:s')
    ];
}

$user = current_user();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page['title']) ?> - SnapLink Pro</title>
    <meta name="description" content="<?= substr(strip_tags($page['content']), 0, 160) ?>">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style> 
        body { font-family: 'Inter', sans-serif; } 
        /* Typography for user content */
        .prose h1 { font-size: 2.25rem; font-weight: 700; margin-bottom: 1.5rem; color: #111827; }
        .prose h2 { font-size: 1.5rem; font-weight: 600; margin-top: 2rem; margin-bottom: 1rem; color: #1f2937; }
        .prose h3 { font-size: 1.25rem; font-weight: 600; margin-top: 1.5rem; margin-bottom: 0.75rem; color: #374151; }
        .prose p { margin-bottom: 1.25rem; line-height: 1.75; color: #4b5563; }
        .prose ul { list-style-type: disc; padding-left: 1.5rem; margin-bottom: 1.25rem; }
        .prose ol { list-style-type: decimal; padding-left: 1.5rem; margin-bottom: 1.25rem; }
        .prose a { color: #7c3aed; text-decoration: underline; }
        .prose a:hover { color: #6d28d9; }
    </style>
</head>
<body class="bg-gray-50 flex flex-col min-h-screen">

    <!-- Navbar -->
    <nav class="bg-white shadow-sm border-b sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <a href="index.php" class="flex items-center gap-2">
                    <div class="w-10 h-10 rounded-xl bg-purple-600 flex items-center justify-center text-white">
                        <i class="fas fa-link"></i>
                    </div>
                    <span class="text-xl font-bold">SnapLink Pro</span>
                </a>
                
                <div class="flex items-center gap-4">
                    <a href="index.php" class="text-gray-700 hover:text-purple-600 font-medium">Home</a>
                    <?php if ($user): ?>
                        <a href="dashboard.php" class="px-4 py-2 bg-purple-100 text-purple-700 rounded-lg hover:bg-purple-200 font-medium">Dashboard</a>
                    <?php else: ?>
                        <a href="login.php" class="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 font-medium">Login</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="flex-grow max-w-4xl mx-auto px-4 py-12 w-full">
        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 md:p-12">
            <header class="mb-8 border-b border-gray-100 pb-8">
                <h1 class="text-3xl md:text-4xl font-bold text-gray-900 mb-4"><?= htmlspecialchars($page['title']) ?></h1>
                <div class="text-sm text-gray-500">
                    Last updated: <?= date('F j, Y', strtotime($page['updated_at'])) ?>
                </div>
            </header>
            
            <div class="prose max-w-none">
                <?= $page['content'] ?>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-white border-t py-8 mt-auto">
        <div class="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-4">
            <div class="text-gray-500 text-sm">
                &copy; <?= date('Y') ?> SnapLink Pro. All rights reserved.
            </div>
            <div class="flex gap-6 text-sm">
                <a href="page.php?slug=privacy-policy" class="text-gray-600 hover:text-purple-600">Privacy Policy</a>
                <a href="page.php?slug=terms-of-service" class="text-gray-600 hover:text-purple-600">Terms of Service</a>
                <a href="page.php?slug=about-us" class="text-gray-600 hover:text-purple-600">About Us</a>
            </div>
        </div>
    </footer>

</body>
</html>
