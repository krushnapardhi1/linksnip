<?php
/**
 * Quick Diagnostic Test Page
 * Test if PHP and the API are working correctly
 */
echo "<h1>✅ PHP is Working!</h1>";
echo "<p><strong>PHP Version:</strong> " . PHP_VERSION . "</p>";
echo "<p><strong>Server:</strong> " . $_SERVER['SERVER_SOFTWARE'] . "</p>";
echo "<p><strong>Document Root:</strong> " . $_SERVER['DOCUMENT_ROOT'] . "</p>";
echo "<p><strong>Current File:</strong> " . __FILE__ . "</p>";
echo "<hr>";

// Test if config files exist
$configFile = __DIR__ . '/config/config.php';
$dbFile = __DIR__ . '/config/database.php';

echo "<h2>Configuration Files:</h2>";
echo "<p>config.php: " . (file_exists($configFile) ? "✅ Found" : "❌ Missing") . "</p>";
echo "<p>database.php: " . (file_exists($dbFile) ? "✅ Found" : "❌ Missing") . "</p>";
echo "<hr>";

// Test database connection
try {
    define('ROOT_PATH', __DIR__);
    require_once $configFile;
    require_once $dbFile;
    
    $pdo = db()->getConnection();
    echo "<h2>✅ Database Connection Successful!</h2>";
    
    // Test guest links tables
    echo "<h3>Testing Guest Links Tables:</h3>";
    
    $tables = ['urls', 'guest_rate_limits', 'guest_sessions'];
    foreach ($tables as $table) {
        try {
            $stmt = $pdo->query("SELECT COUNT(*) FROM $table");
            $count = $stmt->fetchColumn();
            echo "<p>✅ Table '$table' exists ($count rows)</p>";
        } catch (Exception $e) {
            echo "<p>❌ Table '$table' error: " . $e->getMessage() . "</p>";
        }
    }
    
    // Check for required columns
    echo "<h3>Checking URLs Table Columns:</h3>";
    try {
        $stmt = $pdo->query("SHOW COLUMNS FROM urls");
        $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        $requiredColumns = ['user_id', 'created_by_ip', 'is_guest'];
        foreach ($requiredColumns as $col) {
            if (in_array($col, $columns)) {
                echo "<p>✅ Column '$col' exists</p>";
            } else {
                echo "<p>❌ Column '$col' missing - <a href='update_database.php'>Run Migration</a></p>";
            }
        }
    } catch (Exception $e) {
        echo "<p>❌ Error checking columns: " . $e->getMessage() . "</p>";
    }
    
} catch (Exception $e) {
    echo "<h2>❌ Database Connection Failed!</h2>";
    echo "<p style='color: red;'>" . $e->getMessage() . "</p>";
    echo "<p>Please check your database credentials in config/database.php</p>";
}

echo "<hr>";
echo "<h2>Next Steps:</h2>";
echo "<ol>";
echo "<li><a href='setup-guest-links.php'>Run Setup Diagnostic</a></li>";
echo "<li><a href='update_database.php'>Run Database Migration</a></li>";
echo "<li><a href='index.php'>Back to Homepage</a></li>";
echo "</ol>";
?>
<!DOCTYPE html>
<html>
<head>
    <title>System Diagnostic</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; max-width: 800px; margin: 0 auto; }
        h1 { color: #10b981; }
        h2 { color: #3b82f6; border-bottom: 2px solid #e5e7eb; padding-bottom: 10px; }
        h3 { color: #6366f1; }
        p { line-height: 1.6; }
        a { color: #7c3aed; text-decoration: none; font-weight: bold; }
        a:hover { text-decoration: underline; }
        hr { margin: 30px 0; border: none; border-top: 2px solid #e5e7eb; }
    </style>
</head>
</html>
