﻿<?php
/**
 * Bulk Upload Page
 * Upload multiple URLs via CSV file
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

require_login();
$user = current_user();

$pageTitle = "Bulk Upload - SnapLink Pro";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        .drop-zone {
            border: 2px dashed #d1d5db;
            transition: all 0.3s;
        }
        .drop-zone.dragover {
            border-color: #7F00FF;
            background-color: #f3f4f6;
        }
    </style>
</head>
<body class="bg-gray-50">

    <!-- Navbar -->
    <nav class="bg-white shadow-sm border-b sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <a href="index.php" class="flex items-center gap-2">
                    <div class="w-10 h-10 rounded-xl bg-purple-600 flex items-center justify-center text-white">
                        <i class="fas fa-link"></i>
                    </div>
                    <span class="text-xl font-bold">SnapLink Pro</span>
                </a>
                
                <div class="flex items-center gap-4">
                    <a href="dashboard.php" class="text-gray-700 hover:text-purple-600">
                        <i class="fas fa-arrow-left mr-2"></i>Back to Dashboard
                    </a>
                    <a href="logout.php" class="text-gray-500 hover:text-red-600">
                        <i class="fas fa-sign-out-alt"></i>
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="max-w-5xl mx-auto px-4 py-8">
        
        <!-- Header -->
        <div class="mb-8">
            <h1 class="text-3xl font-bold text-gray-900 mb-2">Bulk Upload & Export</h1>
            <p class="text-gray-600">Upload multiple URLs at once or export all your links</p>
        </div>

        <!-- Quick Actions -->
        <div class="grid md:grid-cols-2 gap-6 mb-8">
            <div class="bg-gradient-to-r from-purple-600 to-pink-600 rounded-2xl p-8 text-white">
                <i class="fas fa-file-csv text-4xl mb-4"></i>
                <h2 class="text-2xl font-bold mb-2">Download Sample CSV</h2>
                <p class="mb-4 opacity-90">Get a template file to see the correct format</p>
                <button onclick="downloadSample()" class="px-6 py-3 bg-white text-purple-600 rounded-lg font-bold hover:bg-gray-100">
                    <i class="fas fa-download mr-2"></i>Download Template
                </button>
            </div>
            
            <div class="bg-gradient-to-r from-green-600 to-teal-600 rounded-2xl p-8 text-white">
                <i class="fas fa-file-export text-4xl mb-4"></i>
                <h2 class="text-2xl font-bold mb-2">Export All Links</h2>
                <p class="mb-4 opacity-90">Download all your shortened links as CSV</p>
                <button onclick="exportAll()" class="px-6 py-3 bg-white text-green-600 rounded-lg font-bold hover:bg-gray-100">
                    <i class="fas fa-file-download mr-2"></i>Export Links
                </button>
            </div>
        </div>

        <!-- Upload Section -->
        <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
            <div class="p-6 border-b">
                <h3 class="text-xl font-bold text-gray-900">Upload CSV File</h3>
                <p class="text-sm text-gray-500 mt-1">Import multiple URLs from a CSV file</p>
            </div>
            
            <div class="p-8">
                <!-- Drop Zone -->
                <div id="dropZone" class="drop-zone rounded-2xl p-12 text-center cursor-pointer">
                    <input type="file" id="csvFile" accept=".csv" class="hidden">
                    <i class="fas fa-cloud-upload-alt text-6xl text-gray-300 mb-4"></i>
                    <h3 class="text-xl font-bold text-gray-900 mb-2">Drop CSV file here</h3>
                    <p class="text-gray-500 mb-4">or click to browse</p>
                    <button type="button" onclick="document.getElementById('csvFile').click()" 
                            class="px-6 py-3 bg-purple-600 text-white rounded-lg font-semibold hover:bg-purple-700">
                        Choose File
                    </button>
                </div>
                
                <!-- Selected File Info -->
                <div id="fileInfo" class="hidden mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center gap-3">
                            <i class="fas fa-file-csv text-2xl text-blue-600"></i>
                            <div>
                                <p class="font-semibold text-gray-900" id="fileName"></p>
                                <p class="text-sm text-gray-500" id="fileSize"></p>
                            </div>
                        </div>
                        <button onclick="uploadCSV()" id="uploadBtn"
                                class="px-6 py-3 bg-purple-600 text-white rounded-lg font-semibold hover:bg-purple-700">
                            <i class="fas fa-upload mr-2"></i>Upload & Process
                        </button>
                    </div>
                </div>
                
                <!-- Progress -->
                <div id="progress" class="hidden mt-6">
                    <div class="flex items-center justify-between mb-2">
                        <span class="text-sm font-medium text-gray-700">Processing...</span>
                        <span class="text-sm font-medium text-gray-700" id="progressText">0%</span>
                    </div>
                    <div class="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
                        <div id="progressBar" class="h-full bg-purple-600 transition-all" style="width: 0%"></div>
                    </div>
                </div>
                
                <!-- Results -->
                <div id="results" class="hidden mt-6 p-6 bg-green-50 border border-green-200 rounded-lg">
                    <div class="flex items-start gap-3">
                        <i class="fas fa-check-circle text-2xl text-green-600 mt-1"></i>
                        <div class="flex-1">
                            <h4 class="font-bold text-green-900 mb-2">Upload Complete!</h4>
                            <p class="text-green-700" id="resultsText"></p>
                        </div>
                    </div>
                </div>
                
                <!-- Errors -->
                <div id="errors" class="hidden mt-6 p-6 bg-red-50 border border-red-200 rounded-lg">
                    <div class="flex items-start gap-3">
                        <i class="fas fa-exclamation-circle text-2xl text-red-600 mt-1"></i>
                        <div class="flex-1">
                            <h4 class="font-bold text-red-900 mb-2">Errors</h4>
                            <ul class="list-disc list-inside text-red-700" id="errorsList"></ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- CSV Format Guide -->
        <div class="mt-8 bg-blue-50 border border-blue-200 rounded-xl p-6">
            <h3 class="text-lg font-bold text-gray-900 mb-4 flex items-center gap-2">
                <i class="fas fa-info-circle text-blue-600"></i>
                CSV Format Guide
            </h3>
            <p class="text-gray-700 mb-4">Your CSV file should have the following columns:</p>
            <div class="bg-gray-900 text-green-400 p-4 rounded-lg font-mono text-sm overflow-x-auto">
                <div>url,custom_alias,password,expires_at,max_clicks,notes</div>
                <div class="opacity-60">https://example.com,mylink,,2026-12-31,100,My note</div>
                <div class="opacity-60">https://google.com,,,,,Google link</div>
            </div>
            <ul class="mt-4 space-y-2 text-sm text-gray-700">
                <li><i class="fas fa-check text-green-600 mr-2"></i><strong>url</strong> - Required. The long URL to shorten</li>
                <li><i class="fas fa-check text-green-600 mr-2"></i><strong>custom_alias</strong> - Optional. Custom short code</li>
                <li><i class="fas fa-check text-green-600 mr-2"></i><strong>password</strong> - Optional. Password protection</li>
                <li><i class="fas fa-check text-green-600 mr-2"></i><strong>expires_at</strong> - Optional. Expiry date (YYYY-MM-DD)</li>
                <li><i class="fas fa-check text-green-600 mr-2"></i><strong>max_clicks</strong> - Optional. Maximum clicks allowed</li>
                <li><i class="fas fa-check text-green-600 mr-2"></i><strong>notes</strong> - Optional. Internal notes</li>
            </ul>
        </div>

    </div>

    <script>
        let selectedFile = null;
        
        // Drop zone functionality
        const dropZone = document.getElementById('dropZone');
        const fileInput = document.getElementById('csvFile');
        
        dropZone.addEventListener('click', () => fileInput.click());
        
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('dragover');
        });
        
        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('dragover');
        });
        
        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('dragover');
            
            if (e.dataTransfer.files.length) {
                fileInput.files = e.dataTransfer.files;
                handleFileSelect();
            }
        });
        
        fileInput.addEventListener('change', handleFileSelect);
        
        function handleFileSelect() {
            const file = fileInput.files[0];
            if (!file) return;
            
            if (!file.name.endsWith('.csv')) {
                alert('Please select a CSV file');
                return;
            }
            
            selectedFile = file;
            document.getElementById('fileName').textContent = file.name;
            document.getElementById('fileSize').textContent = formatFileSize(file.size);
            document.getElementById('fileInfo').classList.remove('hidden');
            document.getElementById('results').classList.add('hidden');
            document.getElementById('errors').classList.add('hidden');
        }
        
        async function uploadCSV() {
            if (!selectedFile) return;
            
            const uploadBtn = document.getElementById('uploadBtn');
            const progress = document.getElementById('progress');
            const progressBar = document.getElementById('progressBar');
            const progressText = document.getElementById('progressText');
            
            uploadBtn.disabled = true;
            uploadBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Processing...';
            progress.classList.remove('hidden');
            
            const formData = new FormData();
            formData.append('csv_file', selectedFile);
            
            try {
                const response = await fetch('api/bulk-import.php', {
                    method: 'POST',
                    body: formData
                });
                
                const data = await response.json();
                
                // Animate progress
                let currentProgress = 0;
                const interval = setInterval(() => {
                    currentProgress += 10;
                    if (currentProgress >= 100) {
                        clearInterval(interval);
                        showResults(data);
                    }
                    progressBar.style.width = currentProgress + '%';
                    progressText.textContent = currentProgress + '%';
                }, 100);
                
            } catch (error) {
                showError('An error occurred while processing the file');
            } finally {
                uploadBtn.disabled = false;
                uploadBtn.innerHTML = '<i class="fas fa-upload mr-2"></i>Upload & Process';
            }
        }
        
        function showResults(data) {
            document.getElementById('progress').classList.add('hidden');
            
            if (data.success) {
                document.getElementById('results').classList.remove('hidden');
                document.getElementById('resultsText').textContent = 
                    `Successfully created ${data.created} link(s). ${data.failed > 0 ? data.failed + ' failed.' : ''}`;
                
                if (data.errors && data.errors.length > 0) {
                    document.getElementById('errors').classList.remove('hidden');
                    const errorsList = document.getElementById('errorsList');
                    errorsList.innerHTML = '';
                    data.errors.forEach(error => {
                        const li = document.createElement('li');
                        li.textContent = error;
                        errorsList.appendChild(li);
                    });
                }
                
                // Redirect after 3 seconds
                setTimeout(() => {
                    window.location.href = 'dashboard.php';
                }, 3000);
            } else {
                showError(data.error || 'Failed to process CSV file');
            }
        }
        
        function showError(message) {
            document.getElementById('progress').classList.add('hidden');
            document.getElementById('errors').classList.remove('hidden');
            document.getElementById('errorsList').innerHTML = `<li>${message}</li>`;
        }
        
        function formatFileSize(bytes) {
            if (bytes < 1024) return bytes + ' B';
            if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
            return (bytes / 1048576).toFixed(1) + ' MB';
        }
        
        function downloadSample() {
            const csv = `url,custom_alias,password,expires_at,max_clicks,notes
https://example.com,mylink,,2026-12-31,100,Example link
https://google.com,google,,,500,Google homepage
https://github.com,,,,,GitHub`;
            
            const blob = new Blob([csv], { type: 'text/csv' });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'snaplink_bulk_upload_template.csv';
            a.click();
        }
        
        function exportAll() {
            window.location.href = 'api/bulk-export.php';
        }
    </script>

</body>
</html>
