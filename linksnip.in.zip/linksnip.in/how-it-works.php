﻿<?php
/**
 * How It Works Page - SEO Optimized
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

$user = current_user();
$pageTitle = "How It Works - Step by Step Guide | SnapLink Pro";
$pageDescription = "Learn how to shorten URLs with SnapLink Pro in 3 easy steps. Create short links, track clicks, and analyze performance with our simple guide.";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?></title>
    
    <!-- SEO Meta Tags -->
    <meta name="description" content="<?= $pageDescription ?>">
    <meta name="keywords" content="how to shorten url, url shortener guide, create short link, link tracking tutorial">
    <link rel="canonical" href="https://snaplink.pro/how-it-works.php">
    
    <!-- Open Graph -->
    <meta property="og:title" content="<?= $pageTitle ?>">
    <meta property="og:description" content="<?= $pageDescription ?>">
    <meta property="og:type" content="website">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gray-50">

    <!-- Navbar -->
    <nav class="bg-white shadow-sm border-b sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <a href="index.php" class="flex items-center gap-2">
                    <div class="w-10 h-10 rounded-xl bg-purple-600 flex items-center justify-center text-white">
                        <i class="fas fa-link"></i>
                    </div>
                    <span class="text-xl font-bold">SnapLink Pro</span>
                </a>
                
                <div class="hidden md:flex items-center space-x-6">
                    <a href="index.php" class="text-gray-700 hover:text-purple-600">Home</a>
                    <a href="features.php" class="text-gray-700 hover:text-purple-600">Features</a>
                    <a href="how-it-works.php" class="text-purple-600 font-semibold">How It Works</a>
                    <a href="faq.php" class="text-gray-700 hover:text-purple-600">FAQ</a>
                    <a href="blog.php" class="text-gray-700 hover:text-purple-600">Blog</a>
                </div>
                
                <div class="flex items-center gap-4">
                    <?php if ($user): ?>
                        <a href="dashboard.php" class="px-4 py-2 bg-purple-600 text-white rounded-lg font-semibold">Dashboard</a>
                    <?php else: ?>
                        <a href="login.php" class="text-gray-700">Login</a>
                        <a href="register.php" class="px-4 py-2 bg-purple-600 text-white rounded-lg font-semibold">Get Started</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero -->
    <section class="py-20 bg-gradient-to-r from-purple-600 to-pink-600 text-white">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <h1 class="text-5xl font-extrabold mb-6">How to Shorten URLs for Free in India</h1>
            <p class="text-xl opacity-90 max-w-3xl mx-auto">Get started with SnapLink Pro in 3 simple steps. No technical knowledge required!</p>
        </div>
    </section>

    <!-- Steps Section -->
    <section class="py-20">
        <div class="max-w-5xl mx-auto px-4">
            
            <!-- Step 1 -->
            <div class="flex flex-col md:flex-row items-center gap-12 mb-20">
                <div class="md:w-1/2">
                    <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-purple-600 text-white text-2xl font-bold mb-6">1</div>
                    <h2 class="text-3xl font-bold text-gray-900 mb-4">Create Your Free Account</h2>
                    <p class="text-lg text-gray-600 mb-4">Sign up in seconds with your email or Google account. No credit card required to get started.</p>
                    <ul class="space-y-3 text-gray-700">
                        <li class="flex items-center gap-3">
                            <i class="fas fa-check-circle text-green-500"></i>
                            <span>Enter your email and password</span>
                        </li>
                        <li class="flex items-center gap-3">
                            <i class="fas fa-check-circle text-green-500"></i>
                            <span>Or sign up with Google OAuth</span>
                        </li>
                        <li class="flex items-center gap-3">
                            <i class="fas fa-check-circle text-green-500"></i>
                            <span>Verify your email address</span>
                        </li>
                        <li class="flex items-center gap-3">
                            <i class="fas fa-check-circle text-green-500"></i>
                            <span>Access your dashboard instantly</span>
                        </li>
                    </ul>
                </div>
                <div class="md:w-1/2 bg-white p-8 rounded-2xl shadow-xl">
                    <div class="text-sm text-gray-500 mb-2">Step 1 Visual</div>
                    <div class="bg-gradient-to-br from-purple-100 to-pink-100 h-64 rounded-xl flex items-center justify-center">
                        <i class="fas fa-user-plus text-6xl text-purple-600"></i>
                    </div>
                </div>
            </div>

            <!-- Step 2 -->
            <div class="flex flex-col md:flex-row-reverse items-center gap-12 mb-20">
                <div class="md:w-1/2">
                    <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-pink-600 text-white text-2xl font-bold mb-6">2</div>
                    <h2 class="text-3xl font-bold text-gray-900 mb-4">Shorten Links Instantly</h2>
                    <p class="text-lg text-gray-600 mb-4">Paste your long URL and get a shortened link in seconds. Customize it with a custom alias if you want.</p>
                    <ul class="space-y-3 text-gray-700">
                        <li class="flex items-center gap-3">
                            <i class="fas fa-check-circle text-green-500"></i>
                            <span>Paste your long URL</span>
                        </li>
                        <li class="flex items-center gap-3">
                            <i class="fas fa-check-circle text-green-500"></i>
                            <span>Add a custom alias (optional)</span>
                        </li>
                        <li class="flex items-center gap-3">
                            <i class="fas fa-check-circle text-green-500"></i>
                            <span>Set password protection (optional)</span>
                        </li>
                        <li class="flex items-center gap-3">
                            <i class="fas fa-check-circle text-green-500"></i>
                            <span>Click "Shorten" and get your link</span>
                        </li>
                    </ul>
                </div>
                <div class="md:w-1/2 bg-white p-8 rounded-2xl shadow-xl">
                    <div class="text-sm text-gray-500 mb-2">Step 2 Visual</div>
                    <div class="bg-gradient-to-br from-blue-100 to-purple-100 h-64 rounded-xl flex items-center justify-center">
                        <i class="fas fa-link text-6xl text-pink-600"></i>
                    </div>
                </div>
            </div>

            <!-- Step 3 -->
            <div class="flex flex-col md:flex-row items-center gap-12">
                <div class="md:w-1/2">
                    <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-blue-600 text-white text-2xl font-bold mb-6">3</div>
                    <h2 class="text-3xl font-bold text-gray-900 mb-4">Track Clicks Effectively</h2>
                    <p class="text-lg text-gray-600 mb-4">View detailed analytics for every click. See where your traffic comes from and optimize your campaigns.</p>
                    <ul class="space-y-3 text-gray-700">
                        <li class="flex items-center gap-3">
                            <i class="fas fa-check-circle text-green-500"></i>
                            <span>Real-time click statistics</span>
                        </li>
                        <li class="flex items-center gap-3">
                            <i class="fas fa-check-circle text-green-500"></i>
                            <span>Geographic location data</span>
                        </li>
                        <li class="flex items-center gap-3">
                            <i class="fas fa-check-circle text-green-500"></i>
                            <span>Device and browser analytics</span>
                        </li>
                        <li class="flex items-center gap-3">
                            <i class="fas fa-check-circle text-green-500"></i>
                            <span>Referrer source tracking</span>
                        </li>
                    </ul>
                </div>
                <div class="md:w-1/2 bg-white p-8 rounded-2xl shadow-xl">
                    <div class="text-sm text-gray-500 mb-2">Step 3 Visual</div>
                    <div class="bg-gradient-to-br from-green-100 to-blue-100 h-64 rounded-xl flex items-center justify-center">
                        <i class="fas fa-chart-bar text-6xl text-blue-600"></i>
                    </div>
                </div>
            </div>

        </div>
    </section>

    <!-- Additional Features -->
    <section class="py-20 bg-white">
        <div class="max-w-7xl mx-auto px-4">
            <h2 class="text-3xl font-bold text-center text-gray-900 mb-12">Advanced Features You'll Love</h2>
            
            <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div class="p-6 bg-gray-50 rounded-xl">
                    <i class="fas fa-qrcode text-4xl text-purple-600 mb-4"></i>
                    <h3 class="font-bold text-lg mb-2">QR Codes</h3>
                    <p class="text-gray-600 text-sm">Auto-generated QR codes for offline marketing</p>
                </div>
                
                <div class="p-6 bg-gray-50 rounded-xl">
                    <i class="fas fa-globe text-4xl text-blue-600 mb-4"></i>
                    <h3 class="font-bold text-lg mb-2">Custom Domains</h3>
                    <p class="text-gray-600 text-sm">Use your own branded domain</p>
                </div>
                
                <div class="p-6 bg-gray-50 rounded-xl">
                    <i class="fas fa-code text-4xl text-green-600 mb-4"></i>
                    <h3 class="font-bold text-lg mb-2">API Access</h3>
                    <p class="text-gray-600 text-sm">Integrate with your applications</p>
                </div>
                
                <div class="p-6 bg-gray-50 rounded-xl">
                    <i class="fas fa-shield-alt text-4xl text-red-600 mb-4"></i>
                    <h3 class="font-bold text-lg mb-2">Spam Protection</h3>
                    <p class="text-gray-600 text-sm">Safe and spam-free links</p>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA -->
    <section class="py-16 bg-gradient-to-r from-purple-600 to-pink-600">
        <div class="max-w-4xl mx-auto px-4 text-center">
            <h2 class="text-4xl font-bold text-white mb-6">Ready to Shorten Your First Link?</h2>
            <p class="text-xl text-white/90 mb-8">Join thousands of users who trust SnapLink Pro</p>
            <a href="register.php" class="inline-block px-8 py-4 bg-white text-purple-600 rounded-lg font-bold text-lg hover:bg-gray-100 transition">
                Create Free Account
            </a>
        </div>
    </section>

    <!-- Footer -->
    <?php include ROOT_PATH . '/components/footer.php'; ?>

</body>
</html>
