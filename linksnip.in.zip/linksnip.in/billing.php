﻿<?php
/**
 * Billing Management Page
 * View subscription and invoices
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

require_login();
$user = current_user();
$db = db()->getConnection();

// Get active subscription
$stmt = $db->prepare("
    SELECT s.*, p.name as plan_name, p.price_monthly 
    FROM user_subscriptions s 
    JOIN subscription_plans p ON s.plan_id = p.id 
    WHERE s.user_id = ? AND s.status IN ('active', 'trialing')
    ORDER BY s.id DESC LIMIT 1
");
$stmt->execute([$user['id']]);
$subscription = $stmt->fetch(PDO::FETCH_ASSOC);

// Get invoices
$stmt = $db->prepare("SELECT * FROM user_invoices WHERE user_id = ? ORDER BY created_at DESC LIMIT 20");
$stmt->execute([$user['id']]);
$invoices = $stmt->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = "Billing - SnapLink Pro";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gray-50">

    <!-- Navbar -->
    <nav class="bg-white shadow-sm border-b sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <a href="index.php" class="flex items-center gap-2">
                    <div class="w-10 h-10 rounded-xl bg-purple-600 flex items-center justify-center text-white">
                        <i class="fas fa-link"></i>
                    </div>
                    <span class="text-xl font-bold">SnapLink Pro</span>
                </a>
                
                <div class="flex items-center gap-4">
                    <a href="dashboard.php" class="text-gray-700 hover:text-purple-600">
                        <i class="fas fa-arrow-left mr-2"></i>Dashboard
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="max-w-4xl mx-auto px-4 py-8">
        
        <h1 class="text-3xl font-bold text-gray-900 mb-8">Billing & Subscription</h1>

        <!-- Current Plan -->
        <div class="bg-white rounded-2xl shadow-lg p-6 mb-8">
            <div class="flex items-center justify-between mb-6">
                <h2 class="text-xl font-bold text-gray-900">Current Plan</h2>
                <?php if ($subscription): ?>
                    <span class="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-semibold capitalize">
                        <?= htmlspecialchars($subscription['status']) ?>
                    </span>
                <?php else: ?>
                    <span class="px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-sm font-semibold">Free Plan</span>
                <?php endif; ?>
            </div>

            <?php if ($subscription): ?>
                <div class="grid md:grid-cols-2 gap-6">
                    <div>
                        <p class="text-gray-500 text-sm mb-1">Plan Name</p>
                        <p class="text-lg font-bold text-gray-900"><?= htmlspecialchars($subscription['plan_name']) ?></p>
                        <p class="text-gray-600 text-sm">$<?= number_format($subscription['price_monthly'], 2) ?> / month</p>
                    </div>
                    <div>
                        <p class="text-gray-500 text-sm mb-1">Renewal Date</p>
                        <p class="text-lg font-bold text-gray-900">
                            <?= date('M j, Y', strtotime($subscription['current_period_end'])) ?>
                        </p>
                        <?php if ($subscription['cancel_at_period_end']): ?>
                            <p class="text-red-500 text-xs mt-1">Cancels at end of period</p>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="mt-8 flex gap-4">
                    <button onclick="openPortal()" class="px-6 py-2 bg-gray-900 text-white rounded-lg hover:bg-gray-800 font-semibold transition">
                        Manage Subscription
                    </button>
                    <a href="pricing.php" class="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 font-semibold transition">
                        Change Plan
                    </a>
                </div>
            <?php else: ?>
                <div class="bg-purple-50 rounded-xl p-6 text-center">
                    <p class="text-purple-900 mb-4">You are currently on the Free Plan. Upgrade to unlock more features.</p>
                    <a href="pricing.php" class="inline-block px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 font-bold shadow-lg shadow-purple-200 transition">
                        Upgrade to Pro
                    </a>
                </div>
            <?php endif; ?>
        </div>

        <!-- Invoices -->
        <h2 class="text-xl font-bold text-gray-900 mb-4">Invoice History</h2>
        <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
            <?php if (empty($invoices)): ?>
                <div class="p-8 text-center text-gray-500">
                    <div class="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-file-invoice text-2xl text-gray-400"></i>
                    </div>
                    <p>No invoices found</p>
                </div>
            <?php else: ?>
                <table class="w-full text-left">
                    <thead class="bg-gray-50 border-b">
                        <tr>
                            <th class="px-6 py-4 text-xs font-semibold text-gray-500 uppercase">Date</th>
                            <th class="px-6 py-4 text-xs font-semibold text-gray-500 uppercase">Amount</th>
                            <th class="px-6 py-4 text-xs font-semibold text-gray-500 uppercase">Status</th>
                            <th class="px-6 py-4 text-xs font-semibold text-gray-500 uppercase text-right">Invoice</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        <?php foreach ($invoices as $inv): ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-6 py-4 text-sm text-gray-900">
                                    <?= date('M j, Y', strtotime($inv['created_at'])) ?>
                                </td>
                                <td class="px-6 py-4 text-sm font-medium text-gray-900">
                                    $<?= number_format($inv['amount'], 2) ?>
                                </td>
                                <td class="px-6 py-4">
                                    <span class="px-2 py-1 bg-green-100 text-green-700 text-xs rounded-full capitalize">
                                        <?= htmlspecialchars($inv['status']) ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 text-right">
                                    <?php if ($inv['invoice_pdf']): ?>
                                        <a href="<?= htmlspecialchars($inv['invoice_pdf']) ?>" target="_blank" class="text-purple-600 hover:text-purple-800 text-sm font-medium">
                                            Download
                                        </a>
                                    <?php else: ?>
                                        <span class="text-gray-400 text-sm">-</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>

    <!-- Processing Modal -->
    <div id="processing" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
        <div class="bg-white rounded-2xl p-8 max-w-sm w-full text-center">
            <div class="animate-spin w-12 h-12 border-4 border-purple-600 border-t-transparent rounded-full mx-auto mb-4"></div>
            <h3 class="text-xl font-bold text-gray-900 mb-2">Redirecting...</h3>
            <p class="text-gray-500">Opening secure billing portal</p>
        </div>
    </div>

    <script>
        async function openPortal() {
            document.getElementById('processing').classList.remove('hidden');
            try {
                const response = await fetch('api/billing-portal.php', { method: 'POST' });
                const result = await response.json();
                
                if (result.url) {
                    window.location.href = result.url;
                } else {
                    alert(result.error || 'Failed to open portal');
                    document.getElementById('processing').classList.add('hidden');
                }
            } catch (error) {
                alert('An error occurred');
                document.getElementById('processing').classList.add('hidden');
            }
        }
    </script>
</body>
</html>
