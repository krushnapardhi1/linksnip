﻿<footer class="bg-gray-900 text-white pt-16 pb-8">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
            
            <!-- Brand Column -->
            <div class="space-y-6">
                <div class="flex items-center gap-2">
                    <div class="w-8 h-8 rounded-lg bg-purple-600 flex items-center justify-center text-white">
                        <i class="fas fa-link"></i>
                    </div>
                    <span class="text-xl font-bold">SnapLink Pro</span>
                </div>
                <p class="text-gray-400 text-sm leading-relaxed">
                    The smartest way to shorten, track, and manage your links. Enhancing your digital reach with powerful analytics.
                </p>
                <div class="flex items-center gap-4">
                    <a href="#" class="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center text-gray-400 hover:bg-purple-600 hover:text-white transition">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a href="#" class="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center text-gray-400 hover:bg-purple-600 hover:text-white transition">
                        <i class="fab fa-telegram-plane"></i>
                    </a>
                    <a href="mailto:support@snaplink.pro" class="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center text-gray-400 hover:bg-purple-600 hover:text-white transition">
                        <i class="fas fa-envelope"></i>
                    </a>
                </div>
            </div>
            
            <!-- Product -->
            <div>
                <h3 class="font-bold text-lg mb-6 text-white">Product</h3>
                <ul class="space-y-4 text-sm text-gray-400">
                    <li><a href="features.php" class="hover:text-purple-400 transition">Features</a></li>
                    <li><a href="pricing.php" class="hover:text-purple-400 transition">Pricing</a></li>
                    <li><a href="api-docs.php" class="hover:text-purple-400 transition">API Documentation</a></li>
                    <li><a href="how-it-works.php" class="hover:text-purple-400 transition">How It Works</a></li>
                </ul>
            </div>
            
            <!-- Resources -->
            <div>
                <h3 class="font-bold text-lg mb-6 text-white">Resources</h3>
                <ul class="space-y-4 text-sm text-gray-400">
                    <li><a href="blog/" class="hover:text-purple-400 transition">Blog</a></li>
                    <li><a href="faq" class="hover:text-purple-400 transition">FAQ</a></li>
                    <li><a href="support.php" class="hover:text-purple-400 transition">Help Center</a></li>
                    <li><a href="about-us" class="hover:text-purple-400 transition">About Us</a></li>
                </ul>
            </div>
            
            <!-- Legal & Support -->
            <div>
                <h3 class="font-bold text-lg mb-6 text-white">Legal & Support</h3>
                <ul class="space-y-4 text-sm text-gray-400">
                    <li><a href="privacy-policy" class="hover:text-purple-400 transition">Privacy Policy</a></li>
                    <li><a href="terms-of-service" class="hover:text-purple-400 transition">Terms of Service</a></li>
                    <li><a href="report.php" class="hover:text-purple-400 transition">Report Abuse</a></li>
                    <li><a href="contact" class="hover:text-purple-400 transition">Contact Us</a></li>
                </ul>
            </div>
        </div>
        
        <!-- Bottom Bar -->
        <div class="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm">
            <div class="text-gray-500 text-center md:text-left">
                <p>&copy; <?= date('Y') ?> SnapLink Pro. All rights reserved.</p>
                <p class="mt-1">Powered by <a href="#" class="text-purple-400 hover:text-purple-300 font-medium">Pardhi WebWorks</a></p>
            </div>
            <div class="flex items-center gap-6 text-gray-500">
                <a href="privacy-policy" class="hover:text-white transition">Privacy</a>
                <a href="terms-of-service" class="hover:text-white transition">Terms</a>
                <a href="sitemap.xml" class="hover:text-white transition">Sitemap</a>
            </div>
        </div>
    </div>
</footer>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-6887255096375113"
     crossorigin="anonymous"></script>
