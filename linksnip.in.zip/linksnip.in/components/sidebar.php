﻿<?php
/**
 * Admin Sidebar Component
 */
$currentPage = basename($_SERVER['PHP_SELF']);
$user = current_user();
?>
<div class="w-64 bg-gradient-to-b from-purple-600 to-purple-800 min-h-screen text-white flex flex-col">
    <!-- Logo -->
    <div class="p-6 border-b border-purple-500">
        <a href="<?= base_url('dashboard.php') ?>" class="flex items-center gap-3">
            <div class="w-10 h-10 bg-white rounded-lg flex items-center justify-center text-purple-600">
                <i class="fas fa-link text-xl"></i>
            </div>
            <div>
                <div class="text-xl font-bold">SnapLink Pro</div>
                <div class="text-xs text-purple-200">Admin Panel</div>
            </div>
        </a>
    </div>

    <!-- Admin Info -->
    <div class="p-4 border-b border-purple-500">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 bg-purple-500 rounded-full flex items-center justify-center">
                <i class="fas fa-user-shield"></i>
            </div>
            <div class="flex-1 min-w-0">
                <div class="font-medium truncate"><?= htmlspecialchars($user['name']) ?></div>
                <div class="text-xs text-purple-200 truncate"><?= htmlspecialchars($user['email']) ?></div>
            </div>
        </div>
    </div>

    <!-- Navigation -->
    <nav class="flex-1 p-4 space-y-1">
        <a href="<?= base_url('admin/index.php') ?>" 
           class="flex items-center gap-3 px-4 py-3 rounded-lg transition <?= $currentPage === 'index.php' ? 'bg-white text-purple-600' : 'text-white hover:bg-purple-500' ?>">
            <i class="fas fa-tachometer-alt w-5"></i>
            <span>Dashboard</span>
        </a>

        <a href="<?= base_url('admin/urls.php') ?>" 
           class="flex items-center gap-3 px-4 py-3 rounded-lg transition <?= $currentPage === 'urls.php' ? 'bg-white text-purple-600' : 'text-white hover:bg-purple-500' ?>">
            <i class="fas fa-link w-5"></i>
            <span>URLs</span>
        </a>

        <a href="<?= base_url('admin/users.php') ?>" 
           class="flex items-center gap-3 px-4 py-3 rounded-lg transition <?= $currentPage === 'users.php' ? 'bg-white text-purple-600' : 'text-white hover:bg-purple-500' ?>">
            <i class="fas fa-users w-5"></i>
            <span>Users</span>
        </a>

        <a href="<?= base_url('admin/api-analytics.php') ?>" 
           class="flex items-center gap-3 px-4 py-3 rounded-lg transition <?= $currentPage === 'api-analytics.php' ? 'bg-white text-purple-600' : 'text-white hover:bg-purple-500' ?>">
            <i class="fas fa-chart-bar w-5"></i>
            <span>API Analytics</span>
        </a>

        <a href="<?= base_url('admin/blog.php') ?>" 
           class="flex items-center gap-3 px-4 py-3 rounded-lg transition <?= $currentPage === 'blog.php' ? 'bg-white text-purple-600' : 'text-white hover:bg-purple-500' ?>">
            <i class="fas fa-blog w-5"></i>
            <span>Blog Posts</span>
        </a>

        <a href="<?= base_url('admin/pages.php') ?>" 
           class="flex items-center gap-3 px-4 py-3 rounded-lg transition <?= $currentPage === 'pages.php' ? 'bg-white text-purple-600' : 'text-white hover:bg-purple-500' ?>">
            <i class="fas fa-file-alt w-5"></i>
            <span>Pages</span>
        </a>

        <a href="<?= base_url('admin/settings.php') ?>" 
           class="flex items-center gap-3 px-4 py-3 rounded-lg transition <?= $currentPage === 'settings.php' ? 'bg-white text-purple-600' : 'text-white hover:bg-purple-500' ?>">
            <i class="fas fa-cog w-5"></i>
            <span>Settings</span>
        </a>
    </nav>

    <!-- Footer -->
    <div class="p-4 border-t border-purple-500 space-y-2">
        <a href="<?= base_url('dashboard.php') ?>" 
           class="flex items-center gap-3 px-4 py-2 text-purple-200 hover:text-white transition">
            <i class="fas fa-home w-5"></i>
            <span>User Dashboard</span>
        </a>
        <a href="<?= base_url('logout.php') ?>" 
           class="flex items-center gap-3 px-4 py-2 text-purple-200 hover:text-white transition">
            <i class="fas fa-sign-out-alt w-5"></i>
            <span>Logout</span>
        </a>
    </div>
</div>
