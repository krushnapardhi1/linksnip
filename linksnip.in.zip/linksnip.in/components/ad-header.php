<?php
/**
 * Ad Header Component
 * Displays the header ad if configured in site settings
 */
$headerAd = get_site_setting('header_ad_code');
if (!empty(trim($headerAd))):
?>
<div class="w-full bg-gray-50 border-b border-gray-200 py-4 flex justify-center items-center">
    <div class="text-center text-xs text-gray-400 mb-1 w-full max-w-7xl px-4">Advertisement</div>
    <div class="w-full max-w-7xl px-4 flex justify-center overflow-hidden">
        <?= $headerAd ?>
    </div>
</div>
<?php endif; ?>
