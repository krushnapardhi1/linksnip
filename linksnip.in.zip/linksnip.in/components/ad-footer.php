<?php
/**
 * Ad Footer Component
 * Displays the footer ad if configured in site settings
 */
$footerAd = get_site_setting('footer_ad_code');
if (!empty(trim($footerAd))):
?>
<div class="w-full bg-gray-50 border-t border-gray-200 py-6 mt-8 flex justify-center items-center">
    <div class="w-full max-w-7xl px-4 flex flex-col items-center">
        <div class="text-xs text-gray-400 mb-2">Advertisement</div>
        <div class="w-full flex justify-center overflow-hidden">
            <?= $footerAd ?>
        </div>
    </div>
</div>
<?php endif; ?>
