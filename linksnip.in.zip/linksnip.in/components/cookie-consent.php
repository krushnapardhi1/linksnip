﻿<!-- Cookie Consent Banner -->
<style>
    .cookie-consent-banner {
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        background: rgba(15, 23, 42, 0.95);
        backdrop-filter: blur(20px);
        border-top: 1px solid rgba(255, 255, 255, 0.1);
        padding: 1.5rem;
        z-index: 9999;
        transform: translateY(100%);
        transition: transform 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        box-shadow: 0 -8px 32px 0 rgba(0, 0, 0, 0.3);
    }

    .cookie-consent-banner.show {
        transform: translateY(0);
    }

    .cookie-consent-content {
        max-width: 1200px;
        margin: 0 auto;
        display: flex;
        flex-direction: column;
        gap: 1rem;
    }

    @media (min-width: 768px) {
        .cookie-consent-content {
            flex-direction: row;
            align-items: center;
            justify-content: space-between;
        }
    }

    .cookie-consent-text {
        color: rgba(255, 255, 255, 0.9);
        font-size: 0.9rem;
        line-height: 1.6;
        flex: 1;
    }

    .cookie-consent-text a {
        color: #E100FF;
        text-decoration: underline;
        transition: color 0.2s;
    }

    .cookie-consent-text a:hover {
        color: #7F00FF;
    }

    .cookie-consent-actions {
        display: flex;
        gap: 0.75rem;
        flex-shrink: 0;
    }

    .cookie-btn {
        padding: 0.75rem 1.5rem;
        border-radius: 0.75rem;
        font-weight: 600;
        font-size: 0.9rem;
        cursor: pointer;
        transition: all 0.3s ease;
        border: none;
        white-space: nowrap;
    }

    .cookie-btn-accept {
        background: linear-gradient(135deg, #7F00FF 0%, #E100FF 100%);
        color: white;
        box-shadow: 0 4px 12px rgba(127, 0, 255, 0.3);
    }

    .cookie-btn-accept:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 16px rgba(127, 0, 255, 0.4);
    }

    .cookie-btn-decline {
        background: rgba(255, 255, 255, 0.1);
        color: rgba(255, 255, 255, 0.9);
        border: 1px solid rgba(255, 255, 255, 0.2);
    }

    .cookie-btn-decline:hover {
        background: rgba(255, 255, 255, 0.15);
        border-color: rgba(255, 255, 255, 0.3);
    }

    .cookie-icon {
        display: inline-block;
        margin-right: 0.5rem;
        font-size: 1.2rem;
    }
</style>

<div id="cookieConsentBanner" class="cookie-consent-banner">
    <div class="cookie-consent-content">
        <div class="cookie-consent-text">
            <span class="cookie-icon">🍪</span>
            <strong>We use cookies</strong> to enhance your browsing experience, analyze site traffic, and provide personalized content. 
            By clicking "Accept", you consent to our use of cookies. 
            <a href="privacy.php" target="_blank">Privacy Policy</a>
        </div>
        <div class="cookie-consent-actions">
            <button class="cookie-btn cookie-btn-decline" onclick="handleCookieConsent(false)">
                Decline
            </button>
            <button class="cookie-btn cookie-btn-accept" onclick="handleCookieConsent(true)">
                Accept
            </button>
        </div>
    </div>
</div>

<script>
    // Cookie Consent Management
    const COOKIE_CONSENT_KEY = 'snaplink_cookie_consent';
    
    function handleCookieConsent(accepted) {
        // Store consent preference in localStorage
        localStorage.setItem(COOKIE_CONSENT_KEY, accepted ? 'accepted' : 'declined');
        
        // Hide banner with animation
        const banner = document.getElementById('cookieConsentBanner');
        banner.classList.remove('show');
        
        // Optional: Send consent to analytics or backend
        if (accepted) {
            console.log('User accepted cookies');
            initializeAnalytics();
        } else {
            console.log('User declined cookies');
            // Disable analytics, tracking, etc.
        }
    }
    
    function checkCookieConsent() {
        const consent = localStorage.getItem(COOKIE_CONSENT_KEY);
        
        // If no consent preference is stored, show the banner
        if (consent === null) {
            setTimeout(() => {
                const banner = document.getElementById('cookieConsentBanner');
                banner.classList.add('show');
            }, 500); // Small delay for better UX
        } else if (consent === 'accepted') {
            // User previously accepted cookies
            console.log('Cookies previously accepted');
            initializeAnalytics();
        } else {
            // User previously declined cookies
            console.log('Cookies previously declined');
        }
    }
    
    function initializeAnalytics() {
        if (window.analyticsInitialized) return;
        window.analyticsInitialized = true;
        
        const script = document.createElement('script');
        script.async = true;
        script.src = 'https://www.googletagmanager.com/gtag/js?id=G-P66C14PX21';
        document.head.appendChild(script);

        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'G-P66C14PX21');
    }
    
    // Check consent when page loads
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', checkCookieConsent);
    } else {
        checkCookieConsent();
    }
</script>
