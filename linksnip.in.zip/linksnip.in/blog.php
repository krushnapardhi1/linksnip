﻿<?php
/**
 * Blog Listing Page - SEO Optimized
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

$user = current_user();

// Fetch published blog posts - with error handling
$posts = [];
try {
    $db = db()->getConnection();
    $stmt = $db->prepare("SELECT id, title, slug, excerpt, author, created_at FROM blog_posts WHERE status = 'published' ORDER BY created_at DESC");
    $stmt->execute();
    $posts = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    // If blog_posts table doesn't exist, posts will stay empty and placeholder content will show
    error_log("Blog posts fetch error: " . $e->getMessage());
}

$pageTitle = "Blog - URL Shortening Tips & Guides | SnapLink Pro";
$pageDescription = "Read our blog for tips on URL shortening, link tracking, digital marketing strategies, and how to use SnapLink Pro effectively.";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?></title>
    
    <!-- SEO Meta Tags -->
    <meta name="description" content="<?= $pageDescription ?>">
    <meta name="keywords" content="url shortener blog, link tracking tips, digital marketing, custom domain setup guide">
    <link rel="canonical" href="https://snaplink.pro/blog.php">
    
    <!-- Open Graph -->
    <meta property="og:title" content="<?= $pageTitle ?>">
    <meta property="og:description" content="<?= $pageDescription ?>">
    <meta property="og:type" content="website">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gray-50">

    <!-- Navbar -->
    <nav class="bg-white shadow-sm border-b sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <a href="index.php" class="flex items-center gap-2">
                    <div class="w-10 h-10 rounded-xl bg-purple-600 flex items-center justify-center text-white">
                        <i class="fas fa-link"></i>
                    </div>
                    <span class="text-xl font-bold">SnapLink Pro</span>
                </a>
                
                <div class="hidden md:flex items-center space-x-6">
                    <a href="index.php" class="text-gray-700 hover:text-purple-600">Home</a>
                    <a href="features.php" class="text-gray-700 hover:text-purple-600">Features</a>
                    <a href="how-it-works.php" class="text-gray-700 hover:text-purple-600">How It Works</a>
                    <a href="faq.php" class="text-gray-700 hover:text-purple-600">FAQ</a>
                    <a href="blog.php" class="text-purple-600 font-semibold">Blog</a>
                </div>
                
                <div class="flex items-center gap-4">
                    <?php if ($user): ?>
                        <a href="dashboard.php" class="px-4 py-2 bg-purple-600 text-white rounded-lg font-semibold">Dashboard</a>
                    <?php else: ?>
                        <a href="login.php" class="text-gray-700">Login</a>
                        <a href="register.php" class="px-4 py-2 bg-purple-600 text-white rounded-lg font-semibold">Get Started</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero -->
    <section class="py-16 bg-gradient-to-r from-purple-600 to-pink-600">
        <div class="max-w-5xl mx-auto px-4 text-center text-white">
            <h1 class="text-5xl font-extrabold mb-6">SnapLink Pro Blog</h1>
            <p class="text-xl opacity-90">Tips, guides, and best practices for URL shortening and link management</p>
        </div>
    </section>

    <!-- Blog Posts -->
    <section class="py-20">
        <div class="max-w-6xl mx-auto px-4">
            
            <?php if (empty($posts)): ?>
                <!-- Placeholder Blog Posts if Database is Empty -->
                <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                    
                    <!-- Blog Post 1 -->
                    <article class="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all">
                        <div class="h-48 bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                            <i class="fas fa-link text-6xl text-white"></i>
                        </div>
                        <div class="p-6">
                            <div class="text-sm text-gray-500 mb-3">
                                <i class="far fa-calendar mr-2"></i>January 29, 2026
                            </div>
                            <h2 class="text-2xl font-bold text-gray-900 mb-3 hover:text-purple-600 transition-colors">
                                <a href="#post1">How to Shorten URLs for Free in India</a>
                            </h2>
                            <p class="text-gray-600 mb-4">
                                Learn how to create short links for free using SnapLink Pro. Perfect for social media marketing, email campaigns, and WhatsApp sharing in India.
                            </p>
                            <a href="#post1" class="text-purple-600 font-semibold hover:text-purple-700 inline-flex items-center gap-2">
                                Read More <i class="fas fa-arrow-right text-sm"></i>
                            </a>
                        </div>
                    </article>

                    <!-- Blog Post 2 -->
                    <article class="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all">
                        <div class="h-48 bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center">
                            <i class="fas fa-chart-line text-6xl text-white"></i>
                        </div>
                        <div class="p-6">
                            <div class="text-sm text-gray-500 mb-3">
                                <i class="far fa-calendar mr-2"></i>January 28, 2026
                            </div>
                            <h2 class="text-2xl font-bold text-gray-900 mb-3 hover:text-purple-600 transition-colors">
                                <a href="#post2">Best Free URL Shortener in 2026</a>
                            </h2>
                            <p class="text-gray-600 mb-4">
                                Discover why SnapLink Pro is the best free URL shortener in 2026. Compare features, pricing, and analytics with Bitly, TinyURL, and other alternatives.
                            </p>
                            <a href="#post2" class="text-purple-600 font-semibold hover:text-purple-700 inline-flex items-center gap-2">
                                Read More <i class="fas fa-arrow-right text-sm"></i>
                            </a>
                        </div>
                    </article>

                    <!-- Blog Post 3 -->
                    <article class="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all">
                        <div class="h-48 bg-gradient-to-br from-green-500 to-blue-500 flex items-center justify-center">
                            <i class="fas fa-globe text-6xl text-white"></i>
                        </div>
                        <div class="p-6">
                            <div class="text-sm text-gray-500 mb-3">
                                <i class="far fa-calendar mr-2"></i>January 27, 2026
                            </div>
                            <h2 class="text-2xl font-bold text-gray-900 mb-3 hover:text-purple-600 transition-colors">
                                <a href="#post3">Custom Domain URL Shortener – Step by Step Guide</a>
                            </h2>
                            <p class="text-gray-600 mb-4">
                                Set up your own branded short links with a custom domain. Follow our complete guide to add your domain, configure DNS, and start creating branded URLs.
                            </p>
                            <a href="#post3" class="text-purple-600 font-semibold hover:text-purple-700 inline-flex items-center gap-2">
                                Read More <i class="fas fa-arrow-right text-sm"></i>
                            </a>
                        </div>
                    </article>

                    <!-- Blog Post 4 -->
                    <article class="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all">
                        <div class="h-48 bg-gradient-to-br from-orange-500 to-red-500 flex items-center justify-center">
                            <i class="fas fa-mouse-pointer text-6xl text-white"></i>
                        </div>
                        <div class="p-6">
                            <div class="text-sm text-gray-500 mb-3">
                                <i class="far fa-calendar mr-2"></i>January 26, 2026
                            </div>
                            <h2 class="text-2xl font-bold text-gray-900 mb-3 hover:text-purple-600 transition-colors">
                                <a href="#post4">How to Track Link Clicks Effectively</a>
                            </h2>
                            <p class="text-gray-600 mb-4">
                                Master link analytics with SnapLink Pro. Learn how to track clicks, understand your audience demographics, and optimize your marketing campaigns.
                            </p>
                            <a href="#post4" class="text-purple-600 font-semibold hover:text-purple-700 inline-flex items-center gap-2">
                                Read More <i class="fas fa-arrow-right text-sm"></i>
                            </a>
                        </div>
                    </article>

                    <!-- Blog Post 5 -->
                    <article class="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all">
                        <div class="h-48 bg-gradient-to-br from-pink-500 to-purple-500 flex items-center justify-center">
                            <i class="fas fa-qrcode text-6xl text-white"></i>
                        </div>
                        <div class="p-6">
                            <div class="text-sm text-gray-500 mb-3">
                                <i class="far fa-calendar mr-2"></i>January 25, 2026
                            </div>
                            <h2 class="text-2xl font-bold text-gray-900 mb-3 hover:text-purple-600 transition-colors">
                                <a href="#post5">QR Code Generator for Short Links</a>
                            </h2>
                            <p class="text-gray-600 mb-4">
                                Create QR codes for your short links in seconds. Perfect for posters, flyers, business cards, and offline marketing campaigns.
                            </p>
                            <a href="#post5" class="text-purple-600 font-semibold hover:text-purple-700 inline-flex items-center gap-2">
                                Read More <i class="fas fa-arrow-right text-sm"></i>
                            </a>
                        </div>
                    </article>

                    <!-- Blog Post 6 -->
                    <article class="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all">
                        <div class="h-48 bg-gradient-to-br from-indigo-500 to-purple-500 flex items-center justify-center">
                            <i class="fas fa-shield-alt text-6xl text-white"></i>
                        </div>
                        <div class="p-6">
                            <div class="text-sm text-gray-500 mb-3">
                                <i class="far fa-calendar mr-2"></i>January 24, 2026
                            </div>
                            <h2 class="text-2xl font-bold text-gray-900 mb-3 hover:text-purple-600 transition-colors">
                                <a href="#post6">Bitly Alternative Free - Why Choose SnapLink Pro</a>
                            </h2>
                            <p class="text-gray-600 mb-4">
                                Looking for a free Bitly alternative? Discover why SnapLink Pro offers more features at zero cost, including custom domains and advanced analytics.
                            </p>
                            <a href="#post6" class="text-purple-600 font-semibold hover:text-purple-700 inline-flex items-center gap-2">
                                Read More <i class="fas fa-arrow-right text-sm"></i>
                            </a>
                        </div>
                    </article>

                </div>
            <?php else: ?>
                <!-- Display Database Blog Posts -->
                <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <?php foreach ($posts as $post): ?>
                        <article class="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all">
                            <div class="h-48 bg-gradient-to-br from-purple-500 to-pink-500"></div>
                            <div class="p-6">
                                <div class="text-sm text-gray-500 mb-3">
                                    <i class="far fa-calendar mr-2"></i><?= date('F d, Y', strtotime($post['created_at'])) ?>
                                </div>
                                <h2 class="text-2xl font-bold text-gray-900 mb-3">
                                    <a href="blog-post.php?slug=<?= htmlspecialchars($post['slug']) ?>" class="hover:text-purple-600"><?= htmlspecialchars($post['title']) ?></a>
                                </h2>
                                <p class="text-gray-600 mb-4"><?= htmlspecialchars($post['excerpt']) ?></p>
                                <a href="blog-post.php?slug=<?= htmlspecialchars($post['slug']) ?>" class="text-purple-600 font-semibold hover:text-purple-700 inline-flex items-center gap-2">
                                    Read More <i class="fas fa-arrow-right text-sm"></i>
                                </a>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

        </div>
    </section>

    <!-- Newsletter CTA -->
    <section class="py-16 bg-gradient-to-r from-purple-600 to-pink-600">
        <div class="max-w-4xl mx-auto px-4 text-center">
            <h2 class="text-4xl font-bold text-white mb-6">Stay Updated</h2>
            <p class="text-xl text-white/90 mb-8">Get the latest tips and guides delivered to your inbox</p>
            <div class="flex gap-4 max-w-md mx-auto">
                <input type="email" placeholder="Enter your email" class="flex-1 px-4 py-3 rounded-lg border-none focus:ring-2 focus:ring-white">
                <button class="px-6 py-3 bg-white text-purple-600 rounded-lg font-bold hover:bg-gray-100 transition">
                    Subscribe
                </button>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <?php include ROOT_PATH . '/components/footer.php'; ?>

</body>
</html>
