﻿<?php
/**
 * Folders Management Page
 * Organize links in colored folders
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

require_login();
$user = current_user();

$db = db()->getConnection();

// Fetch user's folders with link count
$stmt = $db->prepare("
    SELECT 
        f.*,
        COUNT(u.id) as link_count
    FROM link_folders f
    LEFT JOIN urls u ON f.id = u.folder_id
    WHERE f.user_id = ?
    GROUP BY f.id
    ORDER BY f.name
");
$stmt->execute([$user['id']]);
$folders = $stmt->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = "Folders - SnapLink Pro";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gray-50">

    <!-- Navbar -->
    <nav class="bg-white shadow-sm border-b sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <a href="index.php" class="flex items-center gap-2">
                    <div class="w-10 h-10 rounded-xl bg-purple-600 flex items-center justify-center text-white">
                        <i class="fas fa-link"></i>
                    </div>
                    <span class="text-xl font-bold">SnapLink Pro</span>
                </a>
                
                <div class="flex items-center gap-4">
                    <a href="dashboard.php" class="text-gray-700 hover:text-purple-600">
                        <i class="fas fa-arrow-left mr-2"></i>Back to Dashboard
                    </a>
                    <a href="logout.php" class="text-gray-500 hover:text-red-600">
                        <i class="fas fa-sign-out-alt"></i>
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="max-w-6xl mx-auto px-4 py-8">
        
        <!-- Header -->
        <div class="mb-8 flex items-center justify-between">
            <div>
                <h1 class="text-3xl font-bold text-gray-900 mb-2">Link Folders</h1>
                <p class="text-gray-600">Organize your links with folders</p>
            </div>
            <button onclick="openCreateModal()" class="px-6 py-3 bg-purple-600 text-white rounded-lg font-semibold hover:bg-purple-700">
                <i class="fas fa-plus mr-2"></i>Create Folder
            </button>
        </div>

        <!-- Folders Grid -->
        <?php if (empty($folders)): ?>
            <div class="bg-white rounded-2xl shadow-lg p-12 text-center">
                <div class="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-folder text-4xl text-gray-400"></i>
                </div>
                <h3 class="text-xl font-semibold text-gray-900 mb-2">No Folders Yet</h3>
                <p class="text-gray-500 mb-6">Create your first folder to organize your links</p>
                <button onclick="openCreateModal()" class="px-6 py-3 bg-purple-600 text-white rounded-lg font-semibold hover:bg-purple-700">
                    <i class="fas fa-plus mr-2"></i>Create First Folder
                </button>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php foreach ($folders as $folder): ?>
                    <div class="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition">
                        <div class="p-6" style="background: linear-gradient(135deg, <?= htmlspecialchars($folder['color']) ?> 0%, <?= htmlspecialchars($folder['color']) ?>CC 100%);">
                            <div class="flex items-center justify-between mb-4">
                                <i class="fas fa-<?= htmlspecialchars($folder['icon']) ?> text-4xl text-white"></i>
                                <div class="flex items-center gap-2">
                                    <button onclick="editFolder(<?= $folder['id'] ?>, '<?= htmlspecialchars($folder['name']) ?>', '<?= htmlspecialchars($folder['color']) ?>', '<?= htmlspecialchars($folder['icon']) ?>')" 
                                            class="w-8 h-8 bg-white/20 backdrop-blur rounded-lg flex items-center justify-center text-white hover:bg-white/30">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button onclick="deleteFolder(<?= $folder['id'] ?>)" 
                                            class="w-8 h-8 bg-white/20 backdrop-blur rounded-lg flex items-center justify-center text-white hover:bg-white/30">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </div>
                            <h3 class="text-xl font-bold text-white mb-2"><?= htmlspecialchars($folder['name']) ?></h3>
                            <p class="text-white/80 text-sm"><?= $folder['link_count'] ?> link(s)</p>
                        </div>
                        <div class="p-4 bg-gray-50 border-t">
                            <a href="dashboard.php?folder=<?= $folder['id'] ?>" class="text-purple-600 hover:text-purple-700 font-semibold text-sm">
                                <i class="fas fa-arrow-right mr-2"></i>View Links
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

    </div>

    <!-- Create/Edit Modal -->
    <div id="folderModal" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-2xl p-8 max-w-md w-full">
            <div class="flex items-center justify-between mb-6">
                <h3 class="text-2xl font-bold" id="modalTitle">Create Folder</h3>
                <button onclick="closeModal()" class="text-gray-400 hover:text-gray-600">
                    <i class="fas fa-times text-xl"></i>
                </button>
            </div>
            
            <form id="folderForm" class="space-y-4">
                <input type="hidden" id="folderId" name="folder_id">
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Folder Name</label>
                    <input type="text" id="folderName" name="name" required
                           class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500"
                           placeholder="e.g., Social Media">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Color</label>
                    <div class="grid grid-cols-6 gap-3">
                        <button type="button" onclick="selectColor('#3B82F6')" data-color="#3B82F6" class="w-10 h-10 rounded-lg bg-blue-500 hover:scale-110 transition"></button>
                        <button type="button" onclick="selectColor('#10B981')" data-color="#10B981" class="w-10 h-10 rounded-lg bg-green-500 hover:scale-110 transition"></button>
                        <button type="button" onclick="selectColor('#F59E0B')" data-color="#F59E0B" class="w-10 h-10 rounded-lg bg-yellow-500 hover:scale-110 transition"></button>
                        <button type="button" onclick="selectColor('#EF4444')" data-color="#EF4444" class="w-10 h-10 rounded-lg bg-red-500 hover:scale-110 transition"></button>
                        <button type="button" onclick="selectColor('#8B5CF6')" data-color="#8B5CF6" class="w-10 h-10 rounded-lg bg-purple-500 hover:scale-110 transition"></button>
                        <button type="button" onclick="selectColor('#EC4899')" data-color="#EC4899" class="w-10 h-10 rounded-lg bg-pink-500 hover:scale-110 transition"></button>
                        <button type="button" onclick="selectColor('#14B8A6')" data-color="#14B8A6" class="w-10 h-10 rounded-lg bg-teal-500 hover:scale-110 transition"></button>
                        <button type="button" onclick="selectColor('#F97316')" data-color="#F97316" class="w-10 h-10 rounded-lg bg-orange-500 hover:scale-110 transition"></button>
                        <button type="button" onclick="selectColor('#6366F1')" data-color="#6366F1" class="w-10 h-10 rounded-lg bg-indigo-500 hover:scale-110 transition"></button>
                        <button type="button" onclick="selectColor('#06B6D4')" data-color="#06B6D4" class="w-10 h-10 rounded-lg bg-cyan-500 hover:scale-110 transition"></button>
                        <button type="button" onclick="selectColor('#84CC16')" data-color="#84CC16" class="w-10 h-10 rounded-lg bg-lime-500 hover:scale-110 transition"></button>
                        <button type="button" onclick="selectColor('#64748B')" data-color="#64748B" class="w-10 h-10 rounded-lg bg-slate-500 hover:scale-110 transition"></button>
                    </div>
                    <input type="hidden" id="folderColor" name="color" value="#3B82F6">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Icon</label>
                    <div class="grid grid-cols-6 gap-3">
                        <button type="button" onclick="selectIcon('folder')" data-icon="folder" class="w-10 h-10 rounded-lg border-2 border-gray-200 hover:border-purple-500 flex items-center justify-center">
                            <i class="fas fa-folder text-gray-600"></i>
                        </button>
                        <button type="button" onclick="selectIcon('briefcase')" data-icon="briefcase" class="w-10 h-10 rounded-lg border-2 border-gray-200 hover:border-purple-500 flex items-center justify-center">
                            <i class="fas fa-briefcase text-gray-600"></i>
                        </button>
                        <button type="button" onclick="selectIcon('heart')" data-icon="heart" class="w-10 h-10 rounded-lg border-2 border-gray-200 hover:border-purple-500 flex items-center justify-center">
                            <i class="fas fa-heart text-gray-600"></i>
                        </button>
                        <button type="button" onclick="selectIcon('star')" data-icon="star" class="w-10 h-10 rounded-lg border-2 border-gray-200 hover:border-purple-500 flex items-center justify-center">
                            <i class="fas fa-star text-gray-600"></i>
                        </button>
                        <button type="button" onclick="selectIcon('globe')" data-icon="globe" class="w-10 h-10 rounded-lg border-2 border-gray-200 hover:border-purple-500 flex items-center justify-center">
                            <i class="fas fa-globe text-gray-600"></i>
                        </button>
                        <button type="button" onclick="selectIcon('shopping-cart')" data-icon="shopping-cart" class="w-10 h-10 rounded-lg border-2 border-gray-200 hover:border-purple-500 flex items-center justify-center">
                            <i class="fas fa-shopping-cart text-gray-600"></i>
                        </button>
                        <button type="button" onclick="selectIcon('code')" data-icon="code" class="w-10 h-10 rounded-lg border-2 border-gray-200 hover:border-purple-500 flex items-center justify-center">
                            <i class="fas fa-code text-gray-600"></i>
                        </button>
                        <button type="button" onclick="selectIcon('camera')" data-icon="camera" class="w-10 h-10 rounded-lg border-2 border-gray-200 hover:border-purple-500 flex items-center justify-center">
                            <i class="fas fa-camera text-gray-600"></i>
                        </button>
                        <button type="button" onclick="selectIcon('music')" data-icon="music" class="w-10 h-10 rounded-lg border-2 border-gray-200 hover:border-purple-500 flex items-center justify-center">
                            <i class="fas fa-music text-gray-600"></i>
                        </button>
                        <button type="button" onclick="selectIcon('gamepad')" data-icon="gamepad" class="w-10 h-10 rounded-lg border-2 border-gray-200 hover:border-purple-500 flex items-center justify-center">
                            <i class="fas fa-gamepad text-gray-600"></i>
                        </button>
                        <button type="button" onclick="selectIcon('book')" data-icon="book" class="w-10 h-10 rounded-lg border-2 border-gray-200 hover:border-purple-500 flex items-center justify-center">
                            <i class="fas fa-book text-gray-600"></i>
                        </button>
                        <button type="button" onclick="selectIcon('users')" data-icon="users" class="w-10 h-10 rounded-lg border-2 border-gray-200 hover:border-purple-500 flex items-center justify-center">
                            <i class="fas fa-users text-gray-600"></i>
                        </button>
                    </div>
                    <input type="hidden" id="folderIcon" name="icon" value="folder">
                </div>
                
                <button type="submit" class="w-full px-6 py-3 bg-purple-600 text-white rounded-lg font-semibold hover:bg-purple-700">
                    <i class="fas fa-save mr-2"></i><span id="submitText">Create Folder</span>
                </button>
            </form>
        </div>
    </div>

    <!-- Toast -->
    <div id="toast" class="hidden fixed top-4 right-4 bg-green-600 text-white px-6 py-4 rounded-lg shadow-lg z-50">
        <div class="flex items-center gap-3">
            <i class="fas fa-check-circle text-xl"></i>
            <span id="toast-message">Success!</span>
        </div>
    </div>

    <script>
        let isEditMode = false;

        function showToast(message, type = 'success') {
            const toast = document.getElementById('toast');
            toast.className = `fixed top-4 right-4 px-6 py-4 rounded-lg shadow-lg z-50 ${
                type === 'success' ? 'bg-green-600' : 'bg-red-600'
            } text-white`;
            document.getElementById('toast-message').textContent = message;
            toast.classList.remove('hidden');
            setTimeout(() => toast.classList.add('hidden'), 3000);
        }

        function openCreateModal() {
            isEditMode = false;
            document.getElementById('modalTitle').textContent = 'Create Folder';
            document.getElementById('submitText').textContent = 'Create Folder';
            document.getElementById('folderForm').reset();
            document.getElementById('folderId').value = '';
            document.getElementById('folderModal').classList.remove('hidden');
        }

        function editFolder(id, name, color, icon) {
            isEditMode = true;
            document.getElementById('modalTitle').textContent = 'Edit Folder';
            document.getElementById('submitText').textContent = 'Update Folder';
            document.getElementById('folderId').value = id;
            document.getElementById('folderName').value = name;
            document.getElementById('folderColor').value = color;
            document.getElementById('folderIcon').value = icon;
            
            // Highlight selected color and icon
            document.querySelectorAll('[data-color]').forEach(btn => {
                btn.classList.toggle('ring-4', btn.dataset.color === color);
            });
            document.querySelectorAll('[data-icon]').forEach(btn => {
                btn.classList.toggle('border-purple-500', btn.dataset.icon === icon);
                btn.classList.toggle('border-gray-200', btn.dataset.icon !== icon);
            });
            
            document.getElementById('folderModal').classList.remove('hidden');
        }

        function closeModal() {
            document.getElementById('folderModal').classList.add('hidden');
        }

        function selectColor(color) {
            document.getElementById('folderColor').value = color;
            document.querySelectorAll('[data-color]').forEach(btn => {
                btn.classList.toggle('ring-4', btn.dataset.color === color);
            });
        }

        function selectIcon(icon) {
            document.getElementById('folderIcon').value = icon;
            document.querySelectorAll('[data-icon]').forEach(btn => {
                btn.classList.toggle('border-purple-500', btn.dataset.icon === icon);
                btn.classList.toggle('border-gray-200', btn.dataset.icon !== icon);
            });
        }

        document.getElementById('folderForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const data = {
                name: formData.get('name'),
                color: formData.get('color'),
                icon: formData.get('icon')
            };
            
            if (isEditMode) {
                data.id = formData.get('folder_id');
            }
            
            const url = isEditMode ? 'api/folders.php?action=update' : 'api/folders.php?action=create';
            
            try {
                const response = await fetch(url, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showToast(isEditMode ? 'Folder updated!' : 'Folder created!');
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showToast(result.error || 'Failed to save folder', 'error');
                }
            } catch (error) {
                showToast('An error occurred', 'error');
            }
        });

        async function deleteFolder(id) {
            if (!confirm('Are you sure? Links in this folder will not be deleted, just unassigned.')) return;
            
            try {
                const response = await fetch('api/folders.php?action=delete', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showToast('Folder deleted!');
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showToast(result.error || 'Failed to delete folder', 'error');
                }
            } catch (error) {
                showToast('An error occurred', 'error');
            }
        }
    </script>

</body>
</html>
