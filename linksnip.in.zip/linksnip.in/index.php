﻿<?php

/**
 * Main Entry Point / Homepage
 * Mobile-Responsive Design with Guest Link Support
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

$user = current_user();
$flash = get_flash();

// Fetch plans for pricing preview (if DB tables exist)
$plans = [];
try {
    $stmt = db()->query("SELECT * FROM subscription_plans WHERE is_active = 1 ORDER BY price_monthly ASC LIMIT 3");
    $plans = $stmt->fetchAll();
} catch (Exception $e) {
    // Ignore if table doesn't exist yet
}
?>
<!DOCTYPE html>
<html lang="en" itemscope itemtype="https://schema.org/WebSite">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">

    <!-- Primary Meta Tags -->
    <title>SnapLink Pro | Free URL Shortener - Custom Domains & Advanced Analytics</title>
    <meta name="title" content="SnapLink Pro | Free URL Shortener - Custom Domains & Advanced Analytics">
    <meta name="description" content="SnapLink Pro is a free, secure URL shortener platform. Create branded short links, track detailed analytics, generate QR codes, and manage custom domains. Perfect for marketers, businesses, and creators.">
    <meta name="keywords" content="free url shortener, custom domain url shortener, link tracking, URL analytics, shorten links, bio link, QR code generator, link management, brand links">
    <meta name="author" content="SnapLink Pro">
    <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">

    <!-- Canonical & Alternate -->
    <link rel="canonical" href="https://snaplink.pro/">
    <link rel="manifest" href="manifest.json">

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://snaplink.pro/">
    <meta property="og:title" content="SnapLink Pro - Free URL Shortener with Custom Domain & Analytics">
    <meta property="og:description" content="Create branded short links, track clicks, generate QR codes, and analyze traffic with our free URL shortener.">
    <meta property="og:image" content="https://snaplink.pro/assets/images/og-image.png">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:site_name" content="SnapLink Pro">

    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="https://snaplink.pro/">
    <meta property="twitter:title" content="SnapLink Pro - Free URL Shortener with Custom Domain & Analytics">
    <meta property="twitter:description" content="Create branded short links, track clicks, generate QR codes, and analyze traffic with our free URL shortener.">
    <meta property="twitter:image" content="https://snaplink.pro/assets/images/twitter-card.png">

    <!-- PWA Meta Tags -->
    <meta name="theme-color" content="#7F00FF">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="apple-mobile-web-app-title" content="SnapLink Pro">
    <link rel="apple-touch-icon" href="/assets/icons/apple-touch-icon.png">

    <!-- Schema.org Structured Data -->
    <script type="application/ld+json">
        {
            "@context": "https://schema.org",
            "@type": "WebApplication",
            "name": "SnapLink Pro URL Shortener",
            "url": "https://snaplink.pro",
            "description": "Free URL shortener service with custom domains, analytics, and QR code generation",
            "applicationCategory": "UtilityApplication",
            "operatingSystem": "Web",
            "offers": {
                "@type": "Offer",
                "price": "0",
                "priceCurrency": "USD"
            },
            "aggregateRating": {
                "@type": "AggregateRating",
                "ratingValue": "4.8",
                "ratingCount": "1247"
            },
            "featureList": [
                "URL Shortening",
                "Custom Domains",
                "Link Analytics",
                "QR Code Generation",
                "Bio Link Pages"
            ]
        }
    </script>

    <!-- CSS & Fonts -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <!-- Preload Critical Assets -->
    <link rel="preload" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" as="style">
    <link rel="preload" as="image" href="https://snaplink.pro/assets/images/hero-bg.svg">

    <style>
        :root {
            --brand-purple: #7F00FF;
            --brand-pink: #E100FF;
            --brand-dark: #0F172A;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html {
            scroll-behavior: smooth;
            font-size: 16px;
        }

        body {
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
            background-color: #f8fafc;
            color: var(--brand-dark);
            line-height: 1.6;
            overflow-x: hidden;
        }

        .sr-only {
            position: absolute;
            width: 1px;
            height: 1px;
            padding: 0;
            margin: -1px;
            overflow: hidden;
            clip: rect(0, 0, 0, 0);
            white-space: nowrap;
            border: 0;
        }

        /* Hero Background */
        .hero-gradient {
            background: linear-gradient(135deg, var(--brand-purple) 0%, var(--brand-pink) 100%);
            border-bottom-left-radius: 3rem;
            border-bottom-right-radius: 3rem;
        }

        @media (max-width: 768px) {
            .hero-gradient {
                border-bottom-left-radius: 2rem;
                border-bottom-right-radius: 2rem;
            }
        }

        /* Glass Effects */
        .glass-nav {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.2);
        }

        .glass-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid rgba(255, 255, 255, 0.5);
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.15);
        }

        /* Animations */
        .fade-in-up {
            animation: fadeInUp 0.6s ease-out forwards;
            opacity: 0;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Accessibility */
        button,
        .btn-like,
        a[role="button"] {
            min-height: 44px;
            min-width: 44px;
        }

        .focus-ring:focus {
            outline: 2px solid var(--brand-purple);
            outline-offset: 2px;
        }

        /* Typography Scale */
        h1 {
            font-size: clamp(2.5rem, 5vw, 4rem);
        }

        h2 {
            font-size: clamp(2rem, 4vw, 3rem);
        }

        h3 {
            font-size: clamp(1.5rem, 3vw, 2rem);
        }

        /* Performance Optimizations */
        img {
            max-width: 100%;
            height: auto;
        }

        .lazy {
            opacity: 0;
            transition: opacity 0.3s;
        }

        .lazy.loaded {
            opacity: 1;
        }
    </style>
</head>

<body class="text-gray-900 antialiased">
    <!-- Skip to Content Link (Accessibility) -->
    <a href="#main-content" class="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 bg-brand-purple text-white px-4 py-2 rounded-lg z-50">
        Skip to main content
    </a>

    <!-- Navigation -->
    <nav class="fixed top-0 left-0 right-0 z-50 glass-nav" role="navigation" aria-label="Main navigation">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16 md:h-20">
                <!-- Logo with Schema.org markup -->
                <div class="flex items-center gap-2" itemprop="publisher" itemscope itemtype="https://schema.org/Organization">
                    <meta itemprop="name" content="SnapLink Pro">
                    <meta itemprop="url" content="https://snaplink.pro">
                    <a href="/" class="flex items-center gap-2 focus-ring rounded-lg p-1" aria-label="SnapLink Pro Home">
                        <div class="w-8 h-8 md:w-10 md:h-10 rounded-xl bg-white flex items-center justify-center text-brand-purple shadow-lg" aria-hidden="true">
                            <i class="fas fa-link text-lg md:text-xl"></i>
                        </div>
                        <span class="text-xl md:text-2xl font-bold text-white tracking-tight">
                            Link<span class="text-yellow-300">Snip</span>
                        </span>
                    </a>
                </div>

                <!-- Desktop Menu -->
                <div class="hidden md:flex items-center space-x-8" role="menubar">
                    <a href="/" class="text-white/90 hover:text-white font-medium transition-colors focus-ring rounded-lg px-3 py-2" role="menuitem" aria-current="page">Home</a>
                    <a href="#features" class="text-white/80 hover:text-white font-medium transition-colors focus-ring rounded-lg px-3 py-2" role="menuitem">Features</a>
                    <a href="how-it-works.php" class="text-white/80 hover:text-white font-medium transition-colors focus-ring rounded-lg px-3 py-2" role="menuitem">How It Works</a>
                    <a href="#pricing" class="text-white/80 hover:text-white font-medium transition-colors focus-ring rounded-lg px-3 py-2" role="menuitem">Pricing</a>
                    <a href="blog/" class="text-white/80 hover:text-white font-medium transition-colors focus-ring rounded-lg px-3 py-2" role="menuitem">Blog</a>
                </div>

                <!-- User Actions -->
                <div class="flex items-center space-x-3 md:space-x-4">
                    <?php if ($user): ?>
                        <span class="text-white/70 text-sm hidden md:inline">Welcome, <?= htmlspecialchars($user['name']) ?></span>
                        <a href="dashboard.php" class="px-4 py-2 md:px-5 md:py-2.5 bg-white text-purple-600 font-bold rounded-xl hover:bg-white/90 transition shadow-lg shadow-purple-900/20 text-sm md:text-base focus-ring">
                            Dashboard
                        </a>
                    <?php else: ?>
                        <!-- Hidden on mobile to save space -->
                        <a href="login.php" class="hidden md:inline-block text-white font-medium hover:text-white/80 transition text-sm md:text-base focus-ring rounded-lg px-3 py-2">Login</a>

                        <!-- Compact button for mobile -->
                        <a href="register.php" class="px-3 py-1.5 md:px-6 md:py-2.5 bg-white text-purple-600 font-bold rounded-lg md:rounded-xl hover:bg-white/90 transition shadow-lg shadow-purple-900/20 text-xs md:text-base focus-ring whitespace-nowrap" aria-label="Sign up for free">
                            <span class="md:hidden">Sign Up</span>
                            <span class="hidden md:inline">Get Started Free</span>
                        </a>
                    <?php endif; ?>

                    <!-- Mobile Menu Button -->
                    <button id="mobileMenuButton" class="md:hidden text-white text-xl focus-ring rounded-lg p-2" aria-label="Toggle menu" aria-expanded="false" aria-controls="mobileMenu">
                        <i class="fas fa-bars"></i>
                    </button>
                </div>
            </div>

            <!-- Mobile Menu -->
            <div id="mobileMenu" class="md:hidden hidden bg-white/10 backdrop-blur-lg rounded-xl mt-2 p-4 border border-white/20" role="menu" aria-labelledby="mobileMenuButton">
                <div class="flex flex-col space-y-3">
                    <a href="/" class="text-white font-medium hover:text-white/80 transition py-2 px-3 rounded-lg hover:bg-white/10" role="menuitem">Home</a>
                    <a href="#features" class="text-white font-medium hover:text-white/80 transition py-2 px-3 rounded-lg hover:bg-white/10" role="menuitem">Features</a>
                    <a href="how-it-works.php" class="text-white font-medium hover:text-white/80 transition py-2 px-3 rounded-lg hover:bg-white/10" role="menuitem">How It Works</a>
                    <a href="#pricing" class="text-white font-medium hover:text-white/80 transition py-2 px-3 rounded-lg hover:bg-white/10" role="menuitem">Pricing</a>
                    <a href="blog/" class="text-white font-medium hover:text-white/80 transition py-2 px-3 rounded-lg hover:bg-white/10" role="menuitem">Blog</a>
                    <div class="pt-3 border-t border-white/20 mt-3">
                        <?php if (!$user): ?>
                            <a href="login.php" class="block text-center px-4 py-3 bg-white/20 text-white font-medium rounded-xl hover:bg-white/30 transition mb-2 focus-ring" role="menuitem">
                                Login
                            </a>
                            <a href="register.php" class="block text-center px-4 py-3 bg-white text-purple-600 font-bold rounded-xl hover:bg-white/90 transition focus-ring" role="menuitem">
                                Sign Up Free
                            </a>
                        <?php else: ?>
                            <a href="dashboard.php" class="block text-center px-4 py-3 bg-white text-purple-600 font-bold rounded-xl hover:bg-white/90 transition focus-ring" role="menuitem">
                                Go to Dashboard
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main id="main-content" role="main">
        <?php require_once ROOT_PATH . '/components/ad-header.php'; ?>
        <!-- Hero Section -->
        <section class="hero-gradient pt-28 md:pt-36 pb-20 md:pb-32 px-4 relative overflow-hidden" aria-labelledby="hero-title">
            <div class="absolute inset-0 opacity-10">
                <div class="absolute top-1/4 left-1/4 w-64 h-64 bg-purple-300 rounded-full blur-3xl"></div>
                <div class="absolute bottom-1/4 right-1/4 w-64 h-64 bg-pink-300 rounded-full blur-3xl"></div>
            </div>

            <div class="max-w-6xl mx-auto text-center relative z-10">
                <?php if ($flash): ?>
                    <div class="mb-8 p-4 rounded-xl <?= $flash['type'] === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700' ?> glass-card" role="alert">
                        <?= $flash['message'] ?>
                    </div>
                <?php endif; ?>

                <!-- Badge -->
                <span class="inline-block py-2 px-4 rounded-full bg-white/20 text-white text-sm font-semibold mb-6 backdrop-blur-sm border border-white/20 fade-in-up">
                    <i class="fas fa-star mr-2"></i>Trusted by 50,000+ users worldwide
                </span>

                <!-- Main Heading -->
                <h1 id="hero-title" class="text-4xl md:text-6xl lg:text-7xl font-extrabold text-white mb-6 leading-tight fade-in-up" style="animation-delay: 0.1s">
                    Free URL Shortener with<br>
                    <span class="text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 to-pink-300">Advanced Analytics</span>
                </h1>

                <!-- Subheading -->
                <p class="text-lg md:text-xl text-purple-100 mb-10 max-w-3xl mx-auto leading-relaxed fade-in-up" style="animation-delay: 0.2s">
                    Create branded short links, track detailed analytics, generate QR codes, and manage custom domains.
                    <strong>No credit card required.</strong> Perfect for marketers, businesses, and creators.
                </p>

                <!-- URL Shortener Form -->
                <div class="glass-card rounded-2xl p-2 md:p-3 max-w-4xl mx-auto transform transition hover:scale-[1.01] duration-300 fade-in-up shadow-2xl" style="animation-delay: 0.3s" itemscope itemtype="https://schema.org/Action">
                    <meta itemprop="name" content="Shorten URL">
                    <div class="relative">
                        <form id="shortenForm" class="flex flex-col md:flex-row gap-2" aria-label="URL Shortener Form">
                            <div class="relative flex-grow">
                                <label for="urlInput" class="sr-only">Enter long URL to shorten</label>
                                <div class="absolute inset-y-0 left-0 pl-4 md:pl-6 flex items-center pointer-events-none">
                                    <i class="fas fa-link text-gray-400 text-lg"></i>
                                </div>
                                <input
                                    type="url"
                                    id="urlInput"
                                    class="w-full pl-12 md:pl-14 pr-4 py-4 md:py-5 bg-transparent border-none text-gray-800 placeholder-gray-500 text-base md:text-lg focus:ring-0 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                                    placeholder="Paste your long URL here (https://...)"
                                    required
                                    aria-required="true"
                                    aria-describedby="urlHelp"
                                    autocomplete="url">
                            </div>
                            <button
                                type="button"
                                id="shortenBtn"
                                class="px-6 md:px-8 py-4 bg-gray-900 text-white text-base md:text-lg font-bold rounded-xl hover:bg-black transition flex items-center justify-center gap-2 shadow-xl min-h-[52px] focus-ring"
                                aria-label="Shorten URL">
                                <span>Shorten URL</span>
                                <i class="fas fa-magic" aria-hidden="true"></i>
                            </button>
                        </form>
                        <p id="urlHelp" class="text-xs text-gray-500 mt-2 ml-4">
                            Enter any valid URL starting with http:// or https://
                        </p>
                    </div>
                </div>

                <!-- Result Box -->
                <div id="resultBox" class="hidden mt-6 max-w-4xl mx-auto fade-in-up" role="region" aria-live="polite">
                    <div class="glass-card rounded-2xl p-4 md:p-6 flex flex-col md:flex-row items-center justify-between gap-4">
                        <div class="flex items-center gap-3 md:gap-4 overflow-hidden w-full">
                            <div class="w-10 h-10 md:w-12 md:h-12 bg-green-100 rounded-xl flex items-center justify-center flex-shrink-0" aria-hidden="true">
                                <i class="fas fa-check text-green-600 text-lg md:text-xl"></i>
                            </div>
                            <div class="min-w-0 flex-1">
                                <span class="sr-only">Shortened URL:</span>
                                <a href="#" id="resultLink" target="_blank" rel="noopener noreferrer" class="text-base md:text-xl font-bold text-gray-800 truncate hover:text-purple-600 transition break-all focus-ring rounded">
                                    <span id="resultText"></span>
                                </a>
                                <p class="text-xs text-gray-500 mt-1">Click to open, right-click to copy</p>
                            </div>
                        </div>
                        <div class="flex gap-2 w-full md:w-auto">
                            <button id="heroCopyBtn" class="flex-1 md:flex-none px-4 md:px-6 py-3 bg-purple-100 text-purple-700 font-bold rounded-xl hover:bg-purple-200 transition text-sm md:text-base focus-ring">
                                <i class="fas fa-copy mr-2" aria-hidden="true"></i>
                                <span>Copy</span>
                            </button>
                            <?php if ($user): ?>
                                <a href="dashboard.php" class="flex-1 md:flex-none px-4 md:px-6 py-3 bg-gray-900 text-white font-bold rounded-xl hover:bg-gray-800 transition text-sm md:text-base focus-ring">
                                    <i class="fas fa-chart-bar mr-2" aria-hidden="true"></i>
                                    <span>Analytics</span>
                                </a>
                            <?php else: ?>
                                <a href="register.php" class="flex-1 md:flex-none px-4 md:px-6 py-3 bg-gray-900 text-white font-bold rounded-xl hover:bg-gray-800 transition text-sm md:text-base focus-ring">
                                    <i class="fas fa-chart-line mr-2" aria-hidden="true"></i>
                                    <span>Track Clicks</span>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>

                    <?php if (!$user): ?>
                        <!-- Guest User CTA -->
                        <div class="glass-card rounded-xl p-4 mt-4 bg-gradient-to-r from-purple-50 to-pink-50 border border-purple-200">
                            <div class="flex items-center gap-3">
                                <i class="fas fa-gift text-purple-600 text-xl" aria-hidden="true"></i>
                                <div class="flex-1">
                                    <p class="text-sm md:text-base text-purple-900">
                                        <strong>Free Account Benefits:</strong> Unlimited links, custom aliases, detailed analytics, QR codes, and more! No credit card required.
                                    </p>
                                </div>
                                <a href="register.php" class="px-4 py-2 bg-purple-600 text-white font-bold rounded-lg hover:bg-purple-700 transition text-sm focus-ring whitespace-nowrap">
                                    Sign Up Free
                                </a>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Trust Indicators -->
                <div class="mt-12 flex flex-wrap items-center justify-center gap-4 md:gap-8 text-white/80 text-xs md:text-sm fade-in-up" style="animation-delay: 0.4s" aria-label="Trust indicators">
                    <div class="flex items-center gap-2 bg-white/10 backdrop-blur-sm px-3 py-2 rounded-lg">
                        <i class="fas fa-shield-alt text-sm"></i>
                        <span>256-bit SSL Security</span>
                    </div>
                    <div class="flex items-center gap-2 bg-white/10 backdrop-blur-sm px-3 py-2 rounded-lg">
                        <i class="fas fa-bolt text-sm"></i>
                        <span>99.9% Uptime</span>
                    </div>
                    <div class="flex items-center gap-2 bg-white/10 backdrop-blur-sm px-3 py-2 rounded-lg">
                        <i class="fas fa-chart-line text-sm"></i>
                        <span>Real-time Analytics</span>
                    </div>
                    <div class="flex items-center gap-2 bg-white/10 backdrop-blur-sm px-3 py-2 rounded-lg">
                        <i class="fas fa-users text-sm"></i>
                        <span>50,000+ Users</span>
                    </div>
                </div>
            </div>
        </section>

        <!-- Features Section -->
        <section id="features" class="py-16 md:py-24 bg-gray-50" aria-labelledby="features-heading">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="text-center max-w-3xl mx-auto mb-12 md:mb-16">
                    <span class="inline-block py-2 px-4 bg-purple-100 text-purple-700 rounded-full text-sm font-semibold mb-4">
                        WHY CHOOSE SNAPLINK PRO
                    </span>
                    <h2 id="features-heading" class="text-2xl md:text-3xl font-bold text-gray-900 mb-4">Everything You Need to Grow Your Links</h2>
                    <p class="text-base md:text-lg text-gray-600">SnapLink Pro provides comprehensive tools for link management, tracking, and optimization.</p>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
                    <!-- Feature 1 -->
                    <div class="bg-white p-6 md:p-8 rounded-2xl shadow-sm hover:shadow-lg transition duration-300" itemscope itemtype="https://schema.org/Service">
                        <div class="w-12 h-12 md:w-14 md:h-14 bg-purple-100 text-purple-600 rounded-xl flex items-center justify-center text-xl md:text-2xl mb-4 md:mb-6" aria-hidden="true">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <h3 class="text-lg md:text-xl font-bold text-gray-900 mb-2 md:mb-3" itemprop="name">Advanced Analytics</h3>
                        <p class="text-sm md:text-base text-gray-600 mb-4" itemprop="description">
                            Track clicks, geographical locations, devices, browsers, and referrers with detailed, real-time analytics.
                        </p>
                        <ul class="text-sm text-gray-500 space-y-1">
                            <li class="flex items-center gap-2">
                                <i class="fas fa-check text-green-500 text-xs"></i>
                                <span>Real-time click tracking</span>
                            </li>
                            <li class="flex items-center gap-2">
                                <i class="fas fa-check text-green-500 text-xs"></i>
                                <span>Geographic heatmaps</span>
                            </li>
                            <li class="flex items-center gap-2">
                                <i class="fas fa-check text-green-500 text-xs"></i>
                                <span>Device & browser analytics</span>
                            </li>
                        </ul>
                    </div>

                    <!-- Feature 2 -->
                    <div class="bg-white p-6 md:p-8 rounded-2xl shadow-sm hover:shadow-lg transition duration-300" itemscope itemtype="https://schema.org/Service">
                        <div class="w-12 h-12 md:w-14 md:h-14 bg-pink-100 text-pink-600 rounded-xl flex items-center justify-center text-xl md:text-2xl mb-4 md:mb-6" aria-hidden="true">
                            <i class="fas fa-globe"></i>
                        </div>
                        <h3 class="text-lg md:text-xl font-bold text-gray-900 mb-2 md:mb-3" itemprop="name">Custom Domains</h3>
                        <p class="text-sm md:text-base text-gray-600 mb-4" itemprop="description">
                            Brand your links with custom domains. Increase click-through rates and build trust with branded short URLs.
                        </p>
                        <ul class="text-sm text-gray-500 space-y-1">
                            <li class="flex items-center gap-2">
                                <i class="fas fa-check text-green-500 text-xs"></i>
                                <span>Multiple custom domains</span>
                            </li>
                            <li class="flex items-center gap-2">
                                <i class="fas fa-check text-green-500 text-xs"></i>
                                <span>SSL certification included</span>
                            </li>
                            <li class="flex items-center gap-2">
                                <i class="fas fa-check text-green-500 text-xs"></i>
                                <span>Easy DNS configuration</span>
                            </li>
                        </ul>
                    </div>

                    <!-- Feature 3 -->
                    <div class="bg-white p-6 md:p-8 rounded-2xl shadow-sm hover:shadow-lg transition duration-300" itemscope itemtype="https://schema.org/Service">
                        <div class="w-12 h-12 md:w-14 md:h-14 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center text-xl md:text-2xl mb-4 md:mb-6" aria-hidden="true">
                            <i class="fas fa-layer-group"></i>
                        </div>
                        <h3 class="text-lg md:text-xl font-bold text-gray-900 mb-2 md:mb-3" itemprop="name">Bio Link Pages</h3>
                        <p class="text-sm md:text-base text-gray-600 mb-4" itemprop="description">
                            Create beautiful, customizable bio link pages for your social media profiles with multiple links.
                        </p>
                        <ul class="text-sm text-gray-500 space-y-1">
                            <li class="flex items-center gap-2">
                                <i class="fas fa-check text-green-500 text-xs"></i>
                                <span>Customizable themes</span>
                            </li>
                            <li class="flex items-center gap-2">
                                <i class="fas fa-check text-green-500 text-xs"></i>
                                <span>Social media integration</span>
                            </li>
                            <li class="flex items-center gap-2">
                                <i class="fas fa-check text-green-500 text-xs"></i>
                                <span>Click analytics per link</span>
                            </li>
                        </ul>
                    </div>
                </div>

                <!-- More Features Link -->
                <div class="text-center mt-12">
                    <a href="features.php" class="inline-flex items-center px-6 py-3 bg-purple-600 text-white font-semibold rounded-xl hover:bg-purple-700 transition focus-ring group">
                        <span>Explore All Features</span>
                        <i class="fas fa-arrow-right ml-2 group-hover:translate-x-1 transition-transform"></i>
                    </a>
                </div>
            </div>
        </section>

        <!-- CTA Section -->
        <section class="py-16 md:py-24 bg-gradient-to-r from-purple-600 to-pink-600 text-white" aria-labelledby="cta-heading">
            <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
                <h2 id="cta-heading" class="text-2xl md:text-4xl font-bold mb-6">Ready to Shorten Your First Link?</h2>
                <p class="text-lg md:text-xl text-purple-100 mb-8 max-w-2xl mx-auto">
                    Join 50,000+ marketers, businesses, and creators who trust SnapLink Pro for their link management needs.
                </p>
                <div class="flex flex-col sm:flex-row gap-4 justify-center">
                    <a href="register.php" class="px-8 py-4 bg-white text-purple-600 font-bold rounded-xl hover:bg-white/90 transition shadow-xl focus-ring">
                        <i class="fas fa-rocket mr-2" aria-hidden="true"></i>
                        Get Started Free
                    </a>
                    <a href="how-it-works.php" class="px-8 py-4 bg-transparent border-2 border-white text-white font-bold rounded-xl hover:bg-white/10 transition focus-ring">
                        <i class="fas fa-play-circle mr-2" aria-hidden="true"></i>
                        Watch Demo
                    </a>
                </div>
                <p class="text-sm text-purple-200 mt-6">
                    <i class="fas fa-check-circle mr-1"></i>
                    No credit card required • Free forever plan • 24/7 support
                </p>
            </div>
        </section>

        <!-- Pricing Section -->
        <section id="pricing" class="py-16 md:py-24 bg-white" aria-labelledby="pricing-heading">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="text-center max-w-3xl mx-auto mb-12 md:mb-16">
                    <span class="inline-block py-2 px-4 bg-gray-100 text-gray-700 rounded-full text-sm font-semibold mb-4">
                        SIMPLE PRICING
                    </span>
                    <h2 id="pricing-heading" class="text-2xl md:text-3xl font-bold text-gray-900 mb-4">Choose Your Perfect Plan</h2>
                    <p class="text-base md:text-lg text-gray-600">Start free, upgrade anytime. All plans include core features.</p>
                </div>

                <?php if (!empty($plans)): ?>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8" itemscope itemtype="https://schema.org/ItemList">
                        <?php foreach ($plans as $index => $plan):
                            $features = json_decode($plan['features'], true) ?: [];
                            $isPopular = strtolower($plan['name']) === 'pro';
                        ?>
                            <div class="relative bg-white border <?= $isPopular ? 'border-purple-500 shadow-xl md:scale-105 z-10' : 'border-gray-200 shadow-sm' ?> rounded-2xl p-6 md:p-8 hover:shadow-xl transition duration-300" itemprop="itemListElement" itemscope itemtype="https://schema.org/Offer">
                                <?php if ($isPopular): ?>
                                    <div class="absolute top-0 right-0 bg-purple-600 text-white text-xs font-bold px-3 py-1 rounded-bl-lg rounded-tr-lg">
                                        MOST POPULAR
                                    </div>
                                <?php endif; ?>

                                <h3 class="text-lg md:text-xl font-bold text-gray-900 mb-2" itemprop="name"><?= htmlspecialchars($plan['name']) ?></h3>
                                <p class="text-gray-500 text-xs md:text-sm mb-4 md:mb-6" itemprop="description"><?= htmlspecialchars($plan['description']) ?></p>

                                <div class="flex items-baseline mb-4 md:mb-6">
                                    <span class="text-3xl md:text-4xl font-extrabold text-gray-900" itemprop="price">$<?= number_format($plan['price_monthly'], 2) ?></span>
                                    <span class="text-gray-500 ml-1">/month</span>
                                    <meta itemprop="priceCurrency" content="USD">
                                </div>

                                <ul class="space-y-3 md:space-y-4 mb-6 md:mb-8">
                                    <?php foreach ($features as $feature): ?>
                                        <li class="flex items-start gap-3 text-xs md:text-sm text-gray-600">
                                            <i class="fas fa-check text-green-500 mt-0.5 flex-shrink-0"></i>
                                            <span><?= htmlspecialchars($feature) ?></span>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>

                                <a href="register.php?plan=<?= $plan['id'] ?>" class="block w-full py-3 text-center rounded-xl font-bold transition <?= $isPopular ? 'bg-purple-600 text-white hover:bg-purple-700' : 'bg-gray-100 text-gray-900 hover:bg-gray-200' ?> text-sm md:text-base focus-ring" itemprop="url">
                                    <?= $plan['price_monthly'] == 0 ? 'Start Free' : 'Start Free Trial' ?>
                                </a>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- Pricing Note -->
                    <div class="text-center mt-8 text-sm text-gray-500">
                        <p><i class="fas fa-info-circle mr-1"></i> All plans include 30-day money-back guarantee. Enterprise plans available.</p>
                    </div>
                <?php else: ?>
                    <!-- Fallback Pricing -->
                    <div class="text-center p-8 md:p-12 bg-gray-50 rounded-2xl border border-dashed border-gray-300">
                        <p class="text-gray-500 mb-4">Pricing information is currently being updated.</p>
                        <a href="register.php" class="text-purple-600 underline text-sm md:text-base">Start with Free Plan</a>
                    </div>
                <?php endif; ?>
            </div>
        </section>
    </main>

    <?php require_once ROOT_PATH . '/components/ad-footer.php'; ?>
    <?php require_once ROOT_PATH . '/components/footer.php'; ?>

    <!-- JavaScript -->
    <script>
        // Mobile Menu Toggle
        const mobileMenuButton = document.getElementById('mobileMenuButton');
        const mobileMenu = document.getElementById('mobileMenu');

        mobileMenuButton.addEventListener('click', function() {
            const isExpanded = this.getAttribute('aria-expanded') === 'true';
            this.setAttribute('aria-expanded', !isExpanded);
            mobileMenu.classList.toggle('hidden');

            const icon = this.querySelector('i');
            icon.className = isExpanded ? 'fas fa-bars' : 'fas fa-times';
        });

        // Close mobile menu when clicking outside
        document.addEventListener('click', function(event) {
            if (!mobileMenu.contains(event.target) && !mobileMenuButton.contains(event.target)) {
                mobileMenu.classList.add('hidden');
                mobileMenuButton.setAttribute('aria-expanded', 'false');
                mobileMenuButton.querySelector('i').className = 'fas fa-bars';
            }
        });

        // URL Shortener Functionality
        const shortenBtn = document.getElementById('shortenBtn');
        const urlInput = document.getElementById('urlInput');
        const resultBox = document.getElementById('resultBox');
        const resultLink = document.getElementById('resultLink');
        const resultText = document.getElementById('resultText');
        const heroCopyBtn = document.getElementById('heroCopyBtn');

        // URL validation
        function isValidUrl(url) {
            try {
                const urlObj = new URL(url);
                return urlObj.protocol === 'http:' || urlObj.protocol === 'https:';
            } catch {
                return false;
            }
        }

        // Show success state
        function showSuccess(shortUrl) {
            resultLink.href = shortUrl;
            resultText.textContent = shortUrl;
            resultLink.setAttribute('title', 'Click to open: ' + shortUrl);
            resultBox.classList.remove('hidden');

            // Update page title for better CTR
            const originalTitle = document.title;
            document.title = `✓ Shortened: ${shortUrl} | SnapLink Pro`;

            setTimeout(() => {
                document.title = originalTitle;
            }, 3000);
        }

        // Show error message
        function showError(message) {
            alert(message); // Simple alert for now
        }

        // Copy to clipboard
        async function copyToClipboard(text) {
            try {
                await navigator.clipboard.writeText(text);

                // Visual feedback
                heroCopyBtn.innerHTML = '<i class="fas fa-check mr-2"></i><span>Copied!</span>';
                heroCopyBtn.classList.remove('bg-purple-100', 'text-purple-700');
                heroCopyBtn.classList.add('bg-green-100', 'text-green-700');

                setTimeout(() => {
                    heroCopyBtn.innerHTML = '<i class="fas fa-copy mr-2"></i><span>Copy</span>';
                    heroCopyBtn.classList.remove('bg-green-100', 'text-green-700');
                    heroCopyBtn.classList.add('bg-purple-100', 'text-purple-700');
                }, 2000);
            } catch (err) {
                console.error('Failed to copy:', err);
                alert('Failed to copy to clipboard. Please copy manually.');
            }
        }

        // Handle URL shortening
        shortenBtn.addEventListener('click', async () => {
            const url = urlInput.value.trim();

            if (!url) {
                urlInput.focus();
                showError('Please enter a URL');
                return;
            }

            if (!isValidUrl(url)) {
                urlInput.focus();
                showError('Please enter a valid URL starting with http:// or https://');
                return;
            }

            // Show loading state
            const originalBtnText = shortenBtn.innerHTML;
            shortenBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Shortening...';
            shortenBtn.disabled = true;

            try {
                // Prepare form data
                const formData = new FormData();
                formData.append('long_url', url);

                // Check if user is logged in
                <?php if ($user): ?>
                    // Add user ID for logged-in users
                    formData.append('user_id', '<?= $user['id'] ?>');

                    // Add CSRF token if available
                    <?php if (isset($_SESSION['csrf_token'])): ?>
                        formData.append('csrf_token', '<?= $_SESSION['csrf_token'] ?>');
                    <?php endif; ?>
                <?php endif; ?>

                // Make API request
                const fetchOptions = {
                    method: 'POST',
                    body: formData
                };

                <?php if ($user): ?>
                    // Add headers for logged-in requests
                    fetchOptions.headers = {
                        'X-Requested-With': 'XMLHttpRequest'
                    };
                    <?php if (isset($_SESSION['csrf_token'])): ?>
                        fetchOptions.headers['X-CSRF-Token'] = '<?= $_SESSION['csrf_token'] ?>';
                    <?php endif; ?>
                <?php endif; ?>

                const response = await fetch('api/shorten.php', fetchOptions);

                // Parse response
                const data = await response.json();

                if (data.success) {
                    // Show success
                    showSuccess(data.data.shortUrl);
                    urlInput.value = '';

                    // Scroll to result smoothly
                    resultBox.scrollIntoView({
                        behavior: 'smooth',
                        block: 'center'
                    });

                } else {
                    // Handle different error types
                    if (data.limit_reached) {
                        const shouldSignup = confirm(
                            `${data.error}\n\nWould you like to sign up for free to get unlimited links?`
                        );
                        if (shouldSignup) {
                            window.location.href = data.signup_url || 'register.php';
                        }
                    } else if (data.error && (data.error.includes('sign up') || data.signup_url)) {
                        const shouldSignup = confirm(
                            `${data.error}\n\nSign up now to unlock this feature for free?`
                        );
                        if (shouldSignup) {
                            window.location.href = data.signup_url || 'register.php';
                        }
                    } else {
                        showError(data.error || 'Error shortening URL. Please try again.');
                    }
                }
            } catch (error) {
                console.error('Error:', error);
                showError('Network error. Please check your connection and try again.');
            } finally {
                // Reset button
                shortenBtn.innerHTML = originalBtnText;
                shortenBtn.disabled = false;
            }
        });

        // Enter key support
        urlInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                shortenBtn.click();
            }
        });

        // Copy button click
        heroCopyBtn.addEventListener('click', () => {
            const url = resultLink.href;
            copyToClipboard(url);
        });

        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                const targetId = this.getAttribute('href');
                if (targetId === '#') return;

                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    // Close mobile menu if open
                    if (!mobileMenu.classList.contains('hidden')) {
                        mobileMenu.classList.add('hidden');
                        mobileMenuButton.setAttribute('aria-expanded', 'false');
                        mobileMenuButton.querySelector('i').className = 'fas fa-bars';
                    }

                    // Calculate header offset
                    const headerOffset = 80;
                    const elementPosition = targetElement.getBoundingClientRect().top;
                    const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

                    window.scrollTo({
                        top: offsetPosition,
                        behavior: 'smooth'
                    });
                }
            });
        });
    </script>

</body>

</html>