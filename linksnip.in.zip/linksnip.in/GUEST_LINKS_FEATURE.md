﻿# Guest Links Feature Documentation

## Overview
The URL Shortener now supports **unauthenticated (guest) users** creating short links without signing up. This feature is designed to:
- Lower the barrier to entry for new users
- Provide a "try before you buy" experience
- Encourage conversion to registered users through feature limitations and upsells

---

## Features

### For Guest Users
✅ **Create short links** - Up to 5 links per day per IP address  
✅ **View their links** - Access via `my-guest-links.php` page  
✅ **Track clicks** - Basic click tracking for guest links  
✅ **Copy links** - Easy-to-use copy functionality  

### Restrictions (Premium Features)
❌ **Custom Aliases** - Registered users only  
❌ **Password Protection** - Registered users only  
❌ **Link Expiration** - Registered users only  
❌ **Click Limits** - Registered users only  
❌ **Device-Specific Redirects** - Registered users only  
❌ **A/B Testing** - Registered users only  
❌ **Advanced Analytics** - Registered users only  
❌ **API Access** - Registered users only  

---

## Database Schema Changes

### 1. Modified `urls` Table
```sql
-- Made user_id nullable to allow guest links
ALTER TABLE urls MODIFY COLUMN user_id INT NULL DEFAULT NULL;

-- Added IP tracking column
ALTER TABLE urls ADD COLUMN created_by_ip VARCHAR(45) NULL DEFAULT NULL;
ALTER TABLE urls ADD INDEX idx_created_by_ip (created_by_ip);

-- Added guest flag
ALTER TABLE urls ADD COLUMN is_guest BOOLEAN DEFAULT FALSE;

-- Updated foreign key constraint
ALTER TABLE urls DROP FOREIGN KEY urls_ibfk_1;
ALTER TABLE urls ADD CONSTRAINT fk_urls_user_id 
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL;
```

### 2. New `guest_rate_limits` Table
```sql
CREATE TABLE `guest_rate_limits` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `ip_address` VARCHAR(45) NOT NULL,
    `links_created_today` INT DEFAULT 1,
    `last_reset_date` DATE NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `unique_ip` (`ip_address`),
    INDEX `idx_last_reset` (`last_reset_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

### 3. New `guest_sessions` Table
```sql
CREATE TABLE `guest_sessions` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `session_id` VARCHAR(128) NOT NULL,
    `ip_address` VARCHAR(45) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_session_id` (`session_id`),
    INDEX `idx_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

---

## API Changes

### Modified: `api/shorten.php`

#### Rate Limiting
- Guest users: **5 links per day** (configurable via `$GUEST_DAILY_LIMIT`)
- Rate limit resets daily at midnight
- Tracked by IP address

#### Request Handling
- Accepts both JSON and form data (`$_POST`)
- Supports both authenticated and guest users
- Returns different response formats for errors

#### Response Format
**Success:**
```json
{
    "success": true,
    "data": {
        "id": 123,
        "shortCode": "abc123",
        "shortUrl": "https://snaplink.pro/abc123",
        "longUrl": "https://example.com",
        "isGuest": true
    },
    "message": "Link created! Sign up to unlock advanced features..."
}
```

**Rate Limit Error:**
```json
{
    "error": "Daily limit reached. Guest users can create 5 links per day. Please sign up for unlimited links!",
    "limit_reached": true,
    "signup_url": "https://snaplink.pro/register.php"
}
```

**Feature Restriction Error:**
```json
{
    "error": "Custom aliases are only available for registered users. Sign up for free!",
    "signup_url": "https://snaplink.pro/register.php"
}
```

---

## New Pages

### `my-guest-links.php`
A dedicated page for guest users to:
- View all links created from their IP address
- See rate limit status (links remaining today)
- Copy short links
- Access call-to-action to sign up

**Features:**
- Shows last 20 guest links
- Displays click counts
- Shows creation dates
- Prominent signup CTA
- Responsive design

---

## Helper Functions

### Added to `config/config.php`

#### `get_client_ip()`
```php
/**
 * Get Client IP Address
 * Works with proxies, CloudFlare, etc.
 */
function get_client_ip() {
    // Check for CloudFlare IP
    if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        return $_SERVER['HTTP_CF_CONNECTING_IP'];
    }
    
    // Check for proxies
    if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ipList = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        return trim($ipList[0]);
    }
    
    if (isset($_SERVER['HTTP_X_REAL_IP'])) {
        return $_SERVER['HTTP_X_REAL_IP'];
    }
    
    // Default remote addr
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}
```

---

## Configuration

### Rate Limiting
To change the daily limit for guest users, modify this constant in `api/shorten.php`:
```php
$GUEST_DAILY_LIMIT = 5; // Change to desired limit
```

### IP Tracking
The system tracks guest users by IP address. This works well with:
- CloudFlare proxy
- Standard web servers
- Other reverse proxies

---

## User Experience Flow

### Guest User Journey
1. **Lands on homepage** → sees URL shortener box
2. **Enters long URL** → clicks "Shorten"
3. **Link created** → sees short link with "View My Links" button
4. **Sees upsell message** → encouraged to sign up
5. **Reaches rate limit** → prompted to create account
6. **Signs up** → gains access to all features

### Conversion Triggers
1. **Rate limit reached** - Confirmation dialog with signup CTA
2. **Tries premium feature** - Error message with signup CTA
3. **After creating link** - Inline message below result
4. **On guest links page** - Prominent feature comparison

---

## Security Considerations

### IP-Based Tracking
- Guest links are tied to IP addresses
- Daily limits prevent abuse
- IP address stored for analytics

### Data Privacy
- No personal information collected from guests
- IP addresses anonymized after 30 days (optional)
- Clear GDPR compliance message

### Rate Limiting
- Prevents spam and abuse
- Resets daily to encourage legitimate use
- Higher limits available for registered users

---

## Admin Tools

### Viewing Guest Links
Admins can query guest links:
```sql
SELECT COUNT(*) as guest_links 
FROM urls 
WHERE is_guest = 1;
```

### Monitoring Rate Limits
```sql
SELECT ip_address, links_created_today, last_reset_date 
FROM guest_rate_limits 
WHERE links_created_today >= 5 
ORDER BY updated_at DESC;
```

### Converting Guest Links
When a user signs up, you can optionally claim their guest links:
```sql
UPDATE urls 
SET user_id = ?, is_guest = 0
WHERE created_by_ip = ? AND is_guest = 1;
```

---

## Future Enhancements

### Planned Features
1. **Auto-claim links** - Automatically assign guest links to user after signup
2. **Extended trial** - Give first-time users 10 links instead of 5
3. **Guest analytics** - Show basic analytics on guest links page
4. **QR codes for guests** - Allow QR code download for guest links
5. **Link expiration** - Auto-expire guest links after 30 days

### Configuration Panel
Add admin settings for:
- Guest daily limit
- Guest link expiration days
- Auto-claim on signup
- Rate limit reset time

---

## Testing

### Test Guest Link Creation
1. Open incognito browser
2. Go to homepage
3. Shorten 5 links
4. Try to shorten 6th link → should show rate limit error

### Test Rate Limit Reset
1. Create 5 guest links today
2. Change system date to tomorrow
3. Create another link → should work

### Test Feature Restrictions
Try creating links with:
- Custom alias
- Password
- Expiration date
- All should show appropriate error messages

---

## Deployment

### Run Database Migration
```bash
# Visit in browser
https://yourdomain.com/update_database.php

# Or run as SQL script
mysql -u username -p database_name < guest_links_migration.sql
```

### Verify Installation
1. Check database tables created
2. Test guest link creation
3. Verify rate limiting works
4. Test signup conversion flow

---

## Troubleshooting

### Common Issues

**Issue:** Rate limit not resetting
- **Solution:** Check `last_reset_date` column, ensure date comparison is correct

**Issue:** Guest can't create links
- **Solution:** Verify `user_id` is nullable in `urls` table

**Issue:** IP address shows as 0.0.0.0
- **Solution:** Check `get_client_ip()` function, verify proxy headers

**Issue:** Foreign key constraint error
- **Solution:** Drop old constraint before modifying column

---

## Support

For questions or issues:
- Email: admin@snaplink.pro
- GitHub: Create an issue
- Documentation: See README.md
