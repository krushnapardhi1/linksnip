﻿# Cloudflare Setup Guide for SnapLink Pro

This guide will help you connect Cloudflare to your SnapLink Pro URL shortener for improved performance, security, and SSL.

## Why Use Cloudflare?

- ✅ **Free SSL Certificate** - HTTPS for your site
- ✅ **CDN** - Faster loading worldwide
- ✅ **DDoS Protection** - Block malicious traffic
- ✅ **Analytics** - Traffic insights
- ✅ **Caching** - Reduced server load
- ✅ **Always Online** - Keeps site accessible even if server is down

## Step 1: Create Cloudflare Account

1. Go to [cloudflare.com](https://www.cloudflare.com/)
2. Click **Sign Up** (it's free!)
3. Enter your email and create a password
4. Verify your email

## Step 2: Add Your Website

### If Using Custom Domain

1. Click **Add a Site** in Cloudflare dashboard
2. Enter your domain: `yourdomain.com`
3. Click **Add Site**
4. Select **Free Plan** (or paid if you prefer)
5. Click **Continue**

### If Using InfinityFree Subdomain

InfinityFree subdomains (`.infinityfreeapp.com`) cannot use Cloudflare directly. You need:
- A custom domain (purchase from Namecheap, GoDaddy, etc.)
- Or use InfinityFree's built-in Cloudflare integration

## Step 3: DNS Records Scan

Cloudflare will automatically scan your domain's DNS records.

1. Wait for scan to complete (10-30 seconds)
2. Review detected DNS records
3. Click **Continue**

**Important DNS Records:**

```
Type    Name    Content                 Proxy Status
A       @       your.server.ip.address  Proxied (Orange Cloud)
A       www     your.server.ip.address  Proxied (Orange Cloud)
CNAME   ftp     ftp.infinityfreeapp.com DNS Only (Grey Cloud)
```

> 💡 **Proxied (Orange Cloud)** = Traffic goes through Cloudflare (recommended for web)
> 
> **DNS Only (Grey Cloud)** = Direct to server (use for FTP, email)

## Step 4: Update Nameservers

Cloudflare will give you 2 nameservers. You need to update these at your domain registrar.

### Example Cloudflare Nameservers:
```
aria.ns.cloudflare.com
nash.ns.cloudflare.com
```

### Update at Your Registrar:

**For Namecheap:**
1. Login to Namecheap
2. Go to **Domain List** → Click **Manage** on your domain
3. Find **Nameservers** section
4. Select **Custom DNS**
5. Enter Cloudflare's nameservers:
   - Nameserver 1: `aria.ns.cloudflare.com`
   - Nameserver 2: `nash.ns.cloudflare.com`
6. Click ✅ **Save**

**For GoDaddy:**
1. Login to GoDaddy
2. Go to **My Products** → **Domains**
3. Click on your domain
4. Scroll to **Nameservers** → Click **Change**
5. Select **I'll use my own nameservers**
6. Enter Cloudflare nameservers
7. Click **Save**

**For Other Registrars:**
- Look for "Nameservers" or "DNS Settings"
- Replace with Cloudflare's nameservers

> ⚠️ **Changes can take 24-48 hours** to propagate globally, but usually happen within 1-2 hours.

## Step 5: Cloudflare Configuration

Once nameservers are updated, configure these settings:

### 5.1 SSL/TLS Settings

1. Go to **SSL/TLS** tab
2. Select **Full** or **Full (Strict)** encryption mode
3. Under **Edge Certificates**:
   - ✅ Enable **Always Use HTTPS**
   - ✅ Enable **Automatic HTTPS Rewrites**
   - ✅ Enable **HTTP Strict Transport Security (HSTS)** (after testing)

### 5.2 Speed Settings

1. Go to **Speed** tab → **Optimization**
2. Enable:
   - ✅ **Auto Minify** (HTML, CSS, JavaScript)
   - ✅ **Brotli** compression
   - ✅ **Rocket Loader** (improves JavaScript loading)
   - ✅ **HTTP/2** and **HTTP/3**

### 5.3 Caching Settings

1. Go to **Caching** tab → **Configuration**
2. Set **Caching Level** to **Standard**
3. Set **Browser Cache TTL** to **4 hours** or **1 day**

**Create Cache Rules:**

Go to **Caching** → **Cache Rules** → **Create Rule**

```
Rule Name: Cache Static Assets
When incoming requests match: 
  - URI Path contains ".jpg" OR
  - URI Path contains ".png" OR
  - URI Path contains ".css" OR
  - URI Path contains ".js" OR
  - URI Path contains ".woff" OR
  - URI Path contains ".ico"
Then:
  - Cache Level: Cache Everything
  - Edge TTL: 1 month
```

### 5.4 Page Rules (Optional)

Go to **Rules** → **Page Rules** → **Create Page Rule**

**Rule 1: Don't cache admin/API:**
```
URL: *yourdomain.com/admin/* OR */api/*
Settings:
  - Cache Level: Bypass
```

**Rule 2: Cache everything else:**
```
URL: *yourdomain.com/*
Settings:
  - Cache Level: Cache Everything
  - Edge Cache TTL: 2 hours
```

### 5.5 Firewall Settings

1. Go to **Security** tab → **WAF**
2. Enable **OWASP ModSecurity Core Rule Set**
3. Go to **Security** → **Bots**
4. Enable **Bot Fight Mode** (Free plan)

### 5.6 Rocket Loader (Optional)

1. Go to **Speed** → **Optimization**
2. Enable **Rocket Loader**
3. Test your site - if JavaScript breaks, disable it

## Step 6: Update SnapLink Pro Configuration

### Update `config/config.php`:

```php
// Update APP_URL to use your custom domain with HTTPS
define('APP_URL', 'https://yourdomain.com'); // Change to your domain
define('BASE_URL', APP_URL);

// Cloudflare IP detection (get real visitor IP)
function get_client_ip() {
    // Check for Cloudflare headers first
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        return $_SERVER['HTTP_CF_CONNECTING_IP'];
    }
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        return trim($ips[0]);
    }
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}
```

### Update `.htaccess`:

Add at the top of your `.htaccess` file:

```apache
# Trust Cloudflare IPs
SetEnvIf CF-Connecting-IP "^(.*)$" REMOTE_ADDR=$1

# Force HTTPS (Cloudflare)
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteCond %{HTTP:CF-Visitor} '"scheme":"http"'
    RewriteRule ^(.*)$ https://%{HTTP_HOST}/$1 [R=301,L]
</IfModule>
```

## Step 7: Verify Setup

### Check DNS Propagation:
Visit: https://www.whatsmydns.net/
Enter your domain and check if it points to Cloudflare IPs.

### Check SSL:
Visit: `https://yourdomain.com`
- You should see 🔒 padlock in browser
- Certificate should be issued by Cloudflare

### Check Headers:
Use browser DevTools (F12) → Network tab → Check response headers for:
```
CF-Cache-Status: HIT/MISS
CF-RAY: xxxxx
Server: cloudflare
```

### Test Performance:
- https://www.webpagetest.org/
- https://tools.pingdom.com/
- https://gtmetrix.com/

## Step 8: Cloudflare Analytics

1. Go to **Analytics & Logs** tab
2. View:
   - Traffic (requests, bandwidth)
   - Security threats blocked
   - Performance metrics
   - Top countries/pages

## Advanced Features (Optional)

### Workers (Serverless Functions)

Use Cloudflare Workers for:
- Custom redirect logic
- A/B testing
- API rate limiting
- Edge caching

**Example Worker for API Rate Limiting:**

```javascript
addEventListener('fetch', event => {
  event.respondWith(handleRequest(event.request))
})

async function handleRequest(request) {
  const url = new URL(request.url)
  
  // Only rate limit API endpoints
  if (url.pathname.startsWith('/api/')) {
    const apiKey = request.headers.get('X-API-Key')
    
    // Check rate limit using KV storage
    // ... implement your rate limiting logic
  }
  
  return fetch(request)
}
```

### Load Balancing (Paid)

Distribute traffic across multiple servers for high availability.

### Argo Smart Routing (Paid - $5/month)

Routes traffic through fastest Cloudflare paths for better performance.

## Troubleshooting

### Issue: "Too Many Redirects"
**Solution:** Change SSL mode to **Full** (not Flexible)

### Issue: "Mixed Content Warnings"
**Solution:** 
- Enable **Automatic HTTPS Rewrites**
- Update all `http://` URLs to `https://` in your code

### Issue: "Site Not Loading"
**Solution:**
- Check nameservers are correct
- Wait for DNS propagation (up to 48 hours)
- Clear Cloudflare cache: **Caching** → **Purge Everything**

### Issue: "Admin Panel Not Working"
**Solution:**
- Create Page Rule to bypass cache for `/admin/*`
- Disable Rocket Loader for admin pages

### Issue: "Wrong Visitor IP Addresses"
**Solution:**
- Use `$_SERVER['HTTP_CF_CONNECTING_IP']` to get real IP
- Update IP detection function (shown in Step 6)

## Cloudflare + InfinityFree Specific Tips

1. **Don't use "Flexible" SSL** - InfinityFree supports HTTPS, use "Full"
2. **Bypass cache for dynamic content** - Admin, API, user dashboards
3. **Enable "Always Online"** - Cloudflare serves cached version if InfinityFree is down
4. **Use Cloudflare's "Zaraz"** - Better way to load Google Analytics/AdSense

## Security Best Practices

1. ✅ Enable **Bot Fight Mode**
2. ✅ Enable **Email Obfuscation**
3. ✅ Enable **DNSSEC** (in DNS tab)
4. ✅ Enable **HSTS** (under SSL/TLS → Edge Certificates)
5. ✅ Set **Security Level** to "Medium" or "High"
6. ✅ Enable **Challenge Passage** (under Firewall)

## Performance Optimization

1. ✅ Enable all **Auto Minify** options
2. ✅ Enable **Brotli** compression
3. ✅ Set **Browser Cache TTL** to at least 4 hours
4. ✅ Create **Page Rules** to cache everything except dynamic pages
5. ✅ Use **Cloudflare Images** for image optimization (paid)

## Free vs. Paid Plans

**Free Plan Includes:**
- Unlimited bandwidth
- Basic DDoS protection
- SSL certificate
- Basic caching
- 3 Page Rules
- Basic analytics

**Pro Plan ($20/month):**
- Advanced DDoS protection
- Image optimization
- 20 Page Rules
- Better WAF rules
- Mobile optimization

**Business Plan ($200/month):**
- Everything in Pro
- Custom SSL certificates
- 50 Page Rules
- PCI compliance
- Priority support

> 💡 **For SnapLink Pro, the FREE plan is more than enough!**

## Monitoring & Maintenance

### Weekly Tasks:
- Check analytics for unusual traffic spikes
- Review security threats blocked
- Monitor cache hit ratio (should be >80%)

### Monthly Tasks:
- Review Page Rules effectiveness
- Update firewall rules if needed
- Check SSL certificate expiry (auto-renewed)
- Purge old cached content if updated site

### Cloudflare Cache Purging:

When you update your site:
1. Go to **Caching** → **Configuration**
2. Click **Purge Everything**
3. Or purge specific URLs/files

**API to Purge Cache:**
```bash
curl -X POST "https://api.cloudflare.com/client/v4/zones/{zone_id}/purge_cache" \
  -H "Authorization: Bearer YOUR_API_TOKEN" \
  -H "Content-Type: application/json" \
  --data '{"purge_everything":true}'
```

## Additional Resources

- Cloudflare Documentation: https://developers.cloudflare.com/
- Cloudflare Community: https://community.cloudflare.com/
- Cloudflare Status: https://www.cloudflarestatus.com/
- Cloudflare Speed Test: https://speed.cloudflare.com/

## Summary Checklist

- [ ] Create Cloudflare account
- [ ] Add your domain to Cloudflare
- [ ] Update nameservers at domain registrar
- [ ] Wait for DNS propagation (check status in Cloudflare)
- [ ] Set SSL/TLS mode to **Full**
- [ ] Enable **Always Use HTTPS**
- [ ] Enable **Auto Minify** (HTML, CSS, JS)
- [ ] Create Page Rules for caching
- [ ] Update SnapLink Pro config.php with HTTPS URL
- [ ] Update .htaccess for Cloudflare compatibility
- [ ] Test your site: `https://yourdomain.com`
- [ ] Verify SSL certificate
- [ ] Check Cloudflare analytics

---

**Questions or Issues?**
- Check Cloudflare's extensive documentation
- Visit Cloudflare Community forums
- Contact InfinityFree support for hosting-specific questions

🎉 **Enjoy your faster, more secure SnapLink Pro!**
