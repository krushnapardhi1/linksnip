<?php
/**
 * Database Updater
 * Run this script to create missing tables and columns on your production server.
 * Delete this file after use!
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

echo "<h1>Database Update Status</h1>";
echo "<pre>";

try {
    $db = db()->getConnection();
    
    // 1. Stripe Billing Tables
    echo "Checking Billing Tables...\n";
    
    $sql = "CREATE TABLE IF NOT EXISTS `subscription_plans` (
        `id` INT PRIMARY KEY AUTO_INCREMENT,
        `stripe_price_id` VARCHAR(100) NULL,
        `name` VARCHAR(50) NOT NULL,
        `description` TEXT,
        `price_monthly` DECIMAL(10, 2) NOT NULL,
        `price_yearly` DECIMAL(10, 2) NULL,
        `currency` VARCHAR(3) DEFAULT 'USD',
        `features` JSON,
        `link_limit` INT DEFAULT 1000,
        `custom_domains` INT DEFAULT 0,
        `is_active` BOOLEAN DEFAULT TRUE,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
    $db->exec($sql);
    echo "- subscription_plans: OK\n";

    $sql = "CREATE TABLE IF NOT EXISTS `user_subscriptions` (
        `id` INT PRIMARY KEY AUTO_INCREMENT,
        `user_id` INT NOT NULL,
        `plan_id` INT NOT NULL,
        `stripe_customer_id` VARCHAR(100) NULL,
        `stripe_subscription_id` VARCHAR(100) NULL,
        `status` VARCHAR(20) DEFAULT 'inactive',
        `current_period_start` TIMESTAMP NULL,
        `current_period_end` TIMESTAMP NULL,
        `cancel_at_period_end` BOOLEAN DEFAULT FALSE,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX `idx_user_id` (`user_id`),
        INDEX `idx_stripe_cust` (`stripe_customer_id`),
        FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
    $db->exec($sql);
    echo "- user_subscriptions: OK\n";

    $sql = "CREATE TABLE IF NOT EXISTS `user_invoices` (
        `id` INT PRIMARY KEY AUTO_INCREMENT,
        `user_id` INT NOT NULL,
        `stripe_invoice_id` VARCHAR(100) NOT NULL,
        `amount` DECIMAL(10, 2) NOT NULL,
        `currency` VARCHAR(3) DEFAULT 'USD',
        `status` VARCHAR(20) NOT NULL,
        `invoice_pdf` VARCHAR(500) NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
    $db->exec($sql);
    echo "- user_invoices: OK\n";

    // Seed Plans
    $stmt = $db->query("SELECT COUNT(*) FROM subscription_plans");
    if ($stmt->fetchColumn() == 0) {
        $db->exec("INSERT INTO `subscription_plans` (`name`, `description`, `price_monthly`, `link_limit`, `custom_domains`, `features`) VALUES 
        ('Free', 'For personal use', 0.00, 50, 0, '[\"50 Links\", \"Basic Analytics\", \"Ad-supported\"]'),
        ('Pro', 'For creators & professionals', 9.99, 1000, 5, '[\"1,000 Links\", \"5 Custom Domains\", \"Password Protection\", \"No Ads\", \"API Access\"]'),
        ('Business', 'For agencies & teams', 29.99, 10000, 20, '[\"10,000 Links\", \"20 Custom Domains\", \"Priority Support\", \"Team Features\", \"Advanced Analytics\"]')");
        echo "- Plans seeded: OK\n";
    }

    // 2. Security / 2FA Columns
    echo "\nChecking Security Columns...\n";
    $columns = $db->query("SHOW COLUMNS FROM users LIKE 'two_factor_secret'")->fetchAll();
    if (empty($columns)) {
        $db->exec("ALTER TABLE users ADD COLUMN two_factor_secret VARCHAR(255) NULL DEFAULT NULL");
        echo "- Added two_factor_secret\n";
    }
    $columns = $db->query("SHOW COLUMNS FROM users LIKE 'two_factor_enabled'")->fetchAll();
    if (empty($columns)) {
        $db->exec("ALTER TABLE users ADD COLUMN two_factor_enabled BOOLEAN DEFAULT FALSE");
        echo "- Added two_factor_enabled\n";
    }
    echo "- Security columns: OK\n";

    // 3. Geo Redirects
    echo "\nChecking Geo Redirects...\n";
    $sql = "CREATE TABLE IF NOT EXISTS `geo_redirects` (
        `id` INT PRIMARY KEY AUTO_INCREMENT,
        `url_id` INT NOT NULL,
        `country` VARCHAR(2) NOT NULL,
        `redirect_url` VARCHAR(2000) NOT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX `idx_url_id` (`url_id`),
        INDEX `idx_country` (`country`),
        UNIQUE KEY `unique_url_country` (`url_id`, `country`),
        FOREIGN KEY (`url_id`) REFERENCES `urls`(`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
    $db->exec($sql);
    echo "- geo_redirects: OK\n";

    // 4. Link Rotation
    echo "\nChecking Link Rotation...\n";
    $columns = $db->query("SHOW COLUMNS FROM urls LIKE 'rotation_enabled'")->fetchAll();
    if (empty($columns)) {
        $db->exec("ALTER TABLE urls ADD COLUMN rotation_enabled BOOLEAN DEFAULT FALSE");
        echo "- Added rotation_enabled to urls\n";
    }
    $columns = $db->query("SHOW COLUMNS FROM urls LIKE 'rotation_mode'")->fetchAll();
    if (empty($columns)) {
        $db->exec("ALTER TABLE urls ADD COLUMN rotation_mode VARCHAR(20) DEFAULT 'random'");
        echo "- Added rotation_mode to urls\n";
    }

    $sql = "CREATE TABLE IF NOT EXISTS `link_rotations` (
        `id` INT PRIMARY KEY AUTO_INCREMENT,
        `url_id` INT NOT NULL,
        `name` VARCHAR(200) NULL DEFAULT NULL,
        `destination_url` VARCHAR(2000) NOT NULL,
        `weight` INT DEFAULT 100,
        `clicks` INT DEFAULT 0,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX `idx_url_id` (`url_id`),
        FOREIGN KEY (`url_id`) REFERENCES `urls`(`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
    $db->exec($sql);
    echo "- link_rotations: OK\n";

    // 5. Webhooks & API Keys
    echo "\nChecking Developer Tools...\n";
    $sql = "CREATE TABLE IF NOT EXISTS `api_keys` (
        `id` INT PRIMARY KEY AUTO_INCREMENT,
        `user_id` INT NOT NULL,
        `api_key` VARCHAR(128) UNIQUE NOT NULL,
        `name` VARCHAR(100) DEFAULT 'API Key',
        `last_used_at` TIMESTAMP NULL DEFAULT NULL,
        `is_active` BOOLEAN DEFAULT TRUE,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
    $db->exec($sql);
    echo "- api_keys: OK\n";

    $sql = "CREATE TABLE IF NOT EXISTS `webhooks` (
        `id` INT PRIMARY KEY AUTO_INCREMENT,
        `user_id` INT NOT NULL,
        `url_id` INT NULL DEFAULT NULL,
        `event_type` ENUM('first_click', 'milestone', 'expiry') NOT NULL,
        `webhook_url` VARCHAR(500) NOT NULL,
        `milestone` INT NULL DEFAULT NULL,
        `is_active` BOOLEAN DEFAULT TRUE,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
    $db->exec($sql);
    echo "- webhooks: OK\n";
    
    // 6. Link Folders
    echo "\nChecking Link Folders...\n";
    $sql = "CREATE TABLE IF NOT EXISTS `link_folders` (
        `id` INT PRIMARY KEY AUTO_INCREMENT,
        `user_id` INT NOT NULL,
        `name` VARCHAR(100) NOT NULL,
        `color` VARCHAR(20) DEFAULT 'blue',
        `icon` VARCHAR(50) DEFAULT 'folder',
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
    $db->exec($sql);
    echo "- link_folders: OK\n";
    
    $columns = $db->query("SHOW COLUMNS FROM urls LIKE 'folder_id'")->fetchAll();
    if (empty($columns)) {
        $db->exec("ALTER TABLE urls ADD COLUMN folder_id INT NULL DEFAULT NULL AFTER user_id");
         // Try to add FK but ignore if fails due to existing data issues (safe mode)
        try {
            $db->exec("ALTER TABLE urls ADD CONSTRAINT `fk_url_folder` FOREIGN KEY (`folder_id`) REFERENCES `link_folders`(`id`) ON DELETE SET NULL");
        } catch (Exception $e) {}
        echo "- Added folder_id to urls\n";
    }

    // 7. Bio Pages
    echo "\nChecking Bio Pages...\n";
    
    // Add bio_title to users if missing
    $columns = $db->query("SHOW COLUMNS FROM users LIKE 'bio_title'")->fetchAll();
    if (empty($columns)) {
        $db->exec("ALTER TABLE users ADD COLUMN bio_title VARCHAR(200) NULL DEFAULT NULL AFTER bio");
        echo "- Added bio_title to users\n";
    }

    // Check if bio_pages exists
    $tableExists = $db->query("SHOW TABLES LIKE 'bio_pages'")->fetch();
    
    if ($tableExists) {
        // Table exists - check if user_id column exists
        $columns = $db->query("SHOW COLUMNS FROM bio_pages LIKE 'user_id'")->fetchAll();
        if (empty($columns)) {
            // Table exists but missing user_id - DROP and recreate
            echo "- bio_pages has wrong schema, recreating...\n";
            $db->exec("DROP TABLE IF EXISTS bio_socials"); // Drop dependent table first
            $db->exec("DROP TABLE IF EXISTS bio_pages");
        }
    }

    // Create bio_pages table
    $sql = "CREATE TABLE IF NOT EXISTS `bio_pages` (
        `id` INT PRIMARY KEY AUTO_INCREMENT,
        `user_id` INT NOT NULL,
        `theme` VARCHAR(50) DEFAULT 'gradient',
        `accent_color` VARCHAR(7) DEFAULT '#7F00FF',
        `button_style` VARCHAR(50) DEFAULT 'rounded',
        `background_image` VARCHAR(500) NULL DEFAULT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX `idx_user_id` (`user_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
    $db->exec($sql);
    echo "- bio_pages: OK\n";

    // Check if bio_socials exists with correct schema
    $tableExists = $db->query("SHOW TABLES LIKE 'bio_socials'")->fetch();
    if ($tableExists) {
        $columns = $db->query("SHOW COLUMNS FROM bio_socials LIKE 'user_id'")->fetchAll();
        if (empty($columns)) {
            $db->exec("DROP TABLE IF EXISTS bio_socials");
        }
    }

    $sql = "CREATE TABLE IF NOT EXISTS `bio_socials` (
        `id` INT PRIMARY KEY AUTO_INCREMENT,
        `user_id` INT NOT NULL,
        `platform` VARCHAR(50) NOT NULL,
        `url` VARCHAR(500) NOT NULL,
        `position` INT DEFAULT 0,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX `idx_user_id` (`user_id`),
        INDEX `idx_position` (`position`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
    $db->exec($sql);
    echo "- bio_socials: OK\n";

    // 8. Guest Links Support
    echo "\nChecking Guest Links Support...\n";
    
    // Make user_id nullable in urls table
    $columns = $db->query("SHOW COLUMNS FROM urls LIKE 'user_id'")->fetch();
    if ($columns && strtoupper($columns['Null']) === 'NO') {
        try {
            // Remove the foreign key constraint first
            $db->exec("ALTER TABLE urls DROP FOREIGN KEY urls_ibfk_1");
            echo "- Removed old foreign key constraint\n";
        } catch (Exception $e) {
            // Constraint might have different name or not exist
        }
        
        // Make user_id nullable
        $db->exec("ALTER TABLE urls MODIFY COLUMN user_id INT NULL DEFAULT NULL");
        echo "- Made user_id nullable in urls table\n";
        
        // Add back the foreign key with ON DELETE SET NULL
        try {
            $db->exec("ALTER TABLE urls ADD CONSTRAINT fk_urls_user_id FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL");
            echo "- Added new foreign key constraint with SET NULL\n";
        } catch (Exception $e) {
            echo "- Warning: Could not add foreign key: " . $e->getMessage() . "\n";
        }
    }
    
    // Add created_by_ip column if missing
    $columns = $db->query("SHOW COLUMNS FROM urls LIKE 'created_by_ip'")->fetchAll();
    if (empty($columns)) {
        $db->exec("ALTER TABLE urls ADD COLUMN created_by_ip VARCHAR(45) NULL DEFAULT NULL AFTER user_id");
        $db->exec("ALTER TABLE urls ADD INDEX idx_created_by_ip (created_by_ip)");
        echo "- Added created_by_ip column to urls\n";
    }
    
    // Add is_guest column if missing
    $columns = $db->query("SHOW COLUMNS FROM urls LIKE 'is_guest'")->fetchAll();
    if (empty($columns)) {
        $db->exec("ALTER TABLE urls ADD COLUMN is_guest BOOLEAN DEFAULT FALSE AFTER created_by_ip");
        echo "- Added is_guest column to urls\n";
    }
    
    // Create guest_rate_limits table
    $sql = "CREATE TABLE IF NOT EXISTS `guest_rate_limits` (
        `id` INT PRIMARY KEY AUTO_INCREMENT,
        `ip_address` VARCHAR(45) NOT NULL,
        `links_created_today` INT DEFAULT 1,
        `last_reset_date` DATE NOT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY `unique_ip` (`ip_address`),
        INDEX `idx_last_reset` (`last_reset_date`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
    $db->exec($sql);
    echo "- guest_rate_limits: OK\n";
    
    // Create guest_sessions table for tracking guest links in session
    $sql = "CREATE TABLE IF NOT EXISTS `guest_sessions` (
        `id` INT PRIMARY KEY AUTO_INCREMENT,
        `session_id` VARCHAR(128) NOT NULL,
        `ip_address` VARCHAR(45) NOT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX `idx_session_id` (`session_id`),
        INDEX `idx_created_at` (`created_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
    $db->exec($sql);
    echo "- guest_sessions: OK\n";

    echo "\n\nSUCCESS! Database updated successfully.";

} catch (PDOException $e) {
    echo "Database Error: " . $e->getMessage();
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}

echo "</pre>";
echo "<br><a href='index.php'>Go to Home</a>";
