-- Anti-Fraud & Traffic Protection System
-- Run this migration to add fraud protection tables

-- Click Logs Table (detailed traffic logging)
CREATE TABLE IF NOT EXISTS click_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    url_id INT NULL,
    ip VARCHAR(50),
    country VARCHAR(10),
    city VARCHAR(100),
    user_agent TEXT,
    referrer TEXT,
    org TEXT,
    device_type VARCHAR(20),
    browser VARCHAR(50),
    is_suspicious BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_ip (ip),
    INDEX idx_url_id (url_id),
    INDEX idx_created_at (created_at),
    INDEX idx_suspicious (is_suspicious)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Banned IPs Table (temp + permanent bans)
CREATE TABLE IF NOT EXISTS banned_ips (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ip VARCHAR(50) UNIQUE,
    reason VARCHAR(255),
    expires_at DATETIME NULL,
    banned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_ip (ip),
    INDEX idx_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Banned Users Table (permanent user bans)
CREATE TABLE IF NOT EXISTS banned_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNIQUE,
    reason VARCHAR(255),
    banned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Fraud Rules Table (customizable auto-ban rules)
CREATE TABLE IF NOT EXISTS fraud_rules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    rule_name VARCHAR(100),
    rule_type ENUM('rate_limit', 'bot_detection', 'geo_restriction', 'vpn_block') DEFAULT 'rate_limit',
    threshold INT DEFAULT 50,
    time_window INT DEFAULT 60,
    ban_duration INT DEFAULT 3600,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert default fraud rules
INSERT INTO fraud_rules (rule_name, rule_type, threshold, time_window, ban_duration) VALUES
('Rapid Click Abuse', 'rate_limit', 50, 10, 3600),
('Hourly Click Limit', 'rate_limit', 200, 3600, 86400),
('Headless Browser Block', 'bot_detection', 1, 1, 86400),
('VPN/Datacenter Block', 'vpn_block', 1, 1, 43200);
