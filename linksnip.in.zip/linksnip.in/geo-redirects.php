﻿<?php
/**
 * Geo Redirects Manager
 * Configure country-specific redirects for a URL
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

require_login();
$user = current_user();

$urlId = $_GET['id'] ?? null;

if (!$urlId) {
    redirect(base_url('dashboard.php'));
}

$db = db()->getConnection();

// Get URL info
$url = $db->prepare("SELECT * FROM urls WHERE id = ? AND user_id = ?");
$url->execute([$urlId, $user['id']]);
$url = $url->fetch(PDO::FETCH_ASSOC);

if (!$url) {
    set_flash('error', 'URL not found');
    redirect(base_url('dashboard.php'));
}

// Get existing geo redirects
$stmt = $db->prepare("SELECT * FROM geo_redirects WHERE url_id = ? ORDER BY country");
$stmt->execute([$urlId]);
$geoRedirects = $stmt->fetchAll(PDO::FETCH_ASSOC);

$baseUrl = APP_URL;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Geo Redirects - <?= htmlspecialchars($url['short_code']) ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gray-50">

    <!-- Navbar -->
    <nav class="bg-white shadow-sm border-b sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <a href="index.php" class="flex items-center gap-2">
                    <div class="w-10 h-10 rounded-xl bg-purple-600 flex items-center justify-center text-white">
                        <i class="fas fa-link"></i>
                    </div>
                    <span class="text-xl font-bold">SnapLink Pro</span>
                </a>
                
                <div class="flex items-center gap-4">
                    <a href="analytics.php?id=<?= $url['id'] ?>" class="text-gray-700 hover:text-purple-600">
                        <i class="fas fa-chart-bar mr-2"></i>Analytics
                    </a>
                    <a href="dashboard.php" class="text-gray-700 hover:text-purple-600">
                        <i class="fas fa-arrow-left mr-2"></i>Dashboard
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="max-w-5xl mx-auto px-4 py-8">
        
        <!-- Header -->
        <div class="mb-8">
            <div class="flex items-center gap-3 mb-4">
                <a href="dashboard.php" class="text-gray-400 hover:text-gray-600">
                    <i class="fas fa-arrow-left"></i>
                </a>
                <div>
                    <h1 class="text-3xl font-bold text-gray-900">Geo-Based Redirects</h1>
                    <p class="text-gray-600">Send visitors to different URLs based on their country</p>
                </div>
            </div>
            
            <div class="bg-white rounded-xl p-4 border">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm text-gray-500">Short URL</p>
                        <a href="<?= $baseUrl ?>/<?= $url['short_code'] ?>" target="_blank" 
                           class="text-purple-600 font-semibold hover:underline">
                            <?= $baseUrl ?>/<?= $url['short_code'] ?>
                        </a>
                    </div>
                    <div>
                        <p class="text-sm text-gray-500">Default Destination</p>
                        <p class="text-gray-900 font-medium truncate max-w-md"><?= htmlspecialchars($url['long_url']) ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Info Banner -->
        <div class="bg-blue-50 border border-blue-200 rounded-xl p-6 mb-8">
            <div class="flex gap-4">
                <i class="fas fa-info-circle text-2xl text-blue-600 flex-shrink-0"></i>
                <div>
                    <h3 class="font-bold text-blue-900 mb-2">How Geo-Based Redirects Work</h3>
                    <p class="text-sm text-blue-800 mb-2">
                        When someone clicks your link, we detect their country and redirect them to the appropriate URL.
                        If no country-specific redirect is set, they see the default destination.
                    </p>
                    <p class="text-sm text-blue-700">
                        <strong>Example:</strong> Promote different Amazon stores (.com for USA, .co.uk for UK, .in for India)
                    </p>
                </div>
            </div>
        </div>

        <!-- Geo Redirects List -->
        <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
            <div class="p-6 border-b bg-gradient-to-r from-purple-50 to-pink-50">
                <div class="flex items-center justify-between">
                    <div>
                        <h2 class="text-xl font-bold text-gray-900">Country Redirects</h2>
                        <p class="text-sm text-gray-600">Configure where visitors from each country should go</p>
                    </div>
                    <button onclick="openAddModal()" class="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 font-semibold">
                        <i class="fas fa-plus mr-2"></i>Add Country
                    </button>
                </div>
            </div>

            <div class="p-6">
                <?php if (empty($geoRedirects)): ?>
                    <div class="text-center py-12">
                        <div class="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                            <i class="fas fa-globe text-4xl text-gray-400"></i>
                        </div>
                        <h3 class="text-lg font-semibold text-gray-900 mb-2">No Geo Redirects Yet</h3>
                        <p class="text-gray-500 mb-6">Add your first country-specific redirect</p>
                        <button onclick="openAddModal()" class="px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 font-semibold">
                            <i class="fas fa-plus mr-2"></i>Add First Redirect
                        </button>
                    </div>
                <?php else: ?>
                    <div class="space-y-3">
                        <?php foreach ($geoRedirects as $redirect): ?>
                            <div class="flex items-center gap-4 p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition">
                                <div class="flex-shrink-0">
                                    <span class="text-3xl"><?= getCountryFlag($redirect['country']) ?></span>
                                </div>
                                <div class="flex-1 min-w-0">
                                    <h4 class="font-semibold text-gray-900"><?= getCountryName($redirect['country']) ?></h4>
                                    <p class="text-sm text-gray-600 truncate"><?= htmlspecialchars($redirect['redirect_url']) ?></p>
                                </div>
                                <div class="flex items-center gap-2">
                                    <button onclick="editRedirect(<?= $redirect['id'] ?>, '<?= $redirect['country'] ?>', '<?= htmlspecialchars($redirect['redirect_url'], ENT_QUOTES) ?>')" 
                                            class="px-3 py-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 font-semibold text-sm">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button onclick="deleteRedirect(<?= $redirect['id'] ?>)" 
                                            class="px-3 py-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 font-semibold text-sm">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

    </div>

    <!-- Add/Edit Modal -->
    <div id="redirectModal" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-2xl p-8 max-w-md w-full">
            <div class="flex items-center justify-between mb-6">
                <h3 class="text-2xl font-bold" id="modalTitle">Add Geo Redirect</h3>
                <button onclick="closeModal()" class="text-gray-400 hover:text-gray-600">
                    <i class="fas fa-times text-xl"></i>
                </button>
            </div>
            
            <form id="redirectForm" class="space-y-4">
                <input type="hidden" id="redirectId" name="redirect_id">
                <input type="hidden" name="url_id" value="<?= $url['id'] ?>">
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Country</label>
                    <select id="country" name="country" required
                            class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500">
                        <option value="">Select a country...</option>
                        <?php foreach (getCountriesList() as $code => $name): ?>
                            <option value="<?= $code ?>"><?= getCountryFlag($code) ?> <?= $name ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Redirect URL</label>
                    <input type="url" id="redirectUrl" name="redirect_url" required
                           class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500"
                           placeholder="https://example.com">
                    <p class="text-xs text-gray-500 mt-2">Visitors from this country will go to this URL</p>
                </div>
                
                <button type="submit" class="w-full px-6 py-3 bg-purple-600 text-white rounded-xl font-semibold hover:bg-purple-700">
                    <i class="fas fa-save mr-2"></i><span id="submitText">Save Redirect</span>
                </button>
            </form>
        </div>
    </div>

    <!-- Toast -->
    <div id="toast" class="hidden fixed top-4 right-4 bg-green-600 text-white px-6 py-4 rounded-lg shadow-lg z-50">
        <div class="flex items-center gap-3">
            <i class="fas fa-check-circle text-xl"></i>
            <span id="toast-message">Success!</span>
        </div>
    </div>

    <script>
        let isEditMode = false;

        function showToast(message, type = 'success') {
            const toast = document.getElementById('toast');
            toast.className = `fixed top-4 right-4 px-6 py-4 rounded-lg shadow-lg z-50 ${
                type === 'success' ? 'bg-green-600' : 'bg-red-600'
            } text-white`;
            document.getElementById('toast-message').textContent = message;
            toast.classList.remove('hidden');
            setTimeout(() => toast.classList.add('hidden'), 3000);
        }

        function openAddModal() {
            isEditMode = false;
            document.getElementById('modalTitle').textContent = 'Add Geo Redirect';
            document.getElementById('submitText').textContent = 'Save Redirect';
            document.getElementById('redirectForm').reset();
            document.getElementById('redirectId').value = '';
            document.getElementById('redirectModal').classList.remove('hidden');
        }

        function editRedirect(id, country, url) {
            isEditMode = true;
            document.getElementById('modalTitle').textContent = 'Edit Geo Redirect';
            document.getElementById('submitText').textContent = 'Update Redirect';
            document.getElementById('redirectId').value = id;
            document.getElementById('country').value = country;
            document.getElementById('redirectUrl').value = url;
            document.getElementById('redirectModal').classList.remove('hidden');
        }

        function closeModal() {
            document.getElementById('redirectModal').classList.add('hidden');
        }

        document.getElementById('redirectForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const data = {
                url_id: formData.get('url_id'),
                country: formData.get('country'),
                redirect_url: formData.get('redirect_url')
            };
            
            if (isEditMode) {
                data.id = formData.get('redirect_id');
            }
            
            const url = isEditMode ? 'api/geo-redirects.php?action=update' : 'api/geo-redirects.php?action=create';
            
            try {
                const response = await fetch(url, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showToast(isEditMode ? 'Redirect updated!' : 'Redirect added!');
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showToast(result.error || 'Failed to save redirect', 'error');
                }
            } catch (error) {
                showToast('An error occurred', 'error');
            }
        });

        async function deleteRedirect(id) {
            if (!confirm('Delete this geo redirect?')) return;
            
            try {
                const response = await fetch('api/geo-redirects.php?action=delete', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showToast('Redirect deleted!');
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showToast(result.error || 'Failed to delete redirect', 'error');
                }
            } catch (error) {
                showToast('An error occurred', 'error');
            }
        }
    </script>

</body>
</html>

<?php
function getCountryFlag($code) {
    $flags = [
        'US' => '🇺🇸', 'GB' => '🇬🇧', 'IN' => '🇮🇳', 'CA' => '🇨🇦', 'AU' => '🇦🇺',
        'DE' => '🇩🇪', 'FR' => '🇫🇷', 'ES' => '🇪🇸', 'IT' => '🇮🇹', 'BR' => '🇧🇷',
        'MX' => '🇲🇽', 'JP' => '🇯🇵', 'CN' => '🇨🇳', 'KR' => '🇰🇷', 'RU' => '🇷🇺',
        'NL' => '🇳🇱', 'SE' => '🇸🇪', 'NO' => '🇳🇴', 'DK' => '🇩🇰', 'FI' => '🇫🇮',
        'PL' => '🇵🇱', 'TR' => '🇹🇷', 'SA' => '🇸🇦', 'AE' => '🇦🇪', 'SG' => '🇸🇬'
    ];
    return $flags[$code] ?? '🌍';
}

function getCountryName($code) {
    $countries = getCountriesList();
    return $countries[$code] ?? $code;
}

function getCountriesList() {
    return [
        'US' => 'United States',
        'GB' => 'United Kingdom',
        'IN' => 'India',
        'CA' => 'Canada',
        'AU' => 'Australia',
        'DE' => 'Germany',
        'FR' => 'France',
        'ES' => 'Spain',
        'IT' => 'Italy',
        'BR' => 'Brazil',
        'MX' => 'Mexico',
        'JP' => 'Japan',
        'CN' => 'China',
        'KR' => 'South Korea',
        'RU' => 'Russia',
        'NL' => 'Netherlands',
        'SE' => 'Sweden',
        'NO' => 'Norway',
        'DK' => 'Denmark',
        'FI' => 'Finland',
        'PL' => 'Poland',
        'TR' => 'Turkey',
        'SA' => 'Saudi Arabia',
        'AE' => 'UAE',
        'SG' => 'Singapore'
    ];
}
?>
