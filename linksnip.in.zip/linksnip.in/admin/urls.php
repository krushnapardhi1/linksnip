﻿<?php
/**
 * Admin - URL Management
 */
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

// Must be admin
if (!is_logged_in() || current_user()['role'] !== 'admin') {
    redirect(base_url('dashboard.php'));
}

// Handle delete action
if (isset($_POST['delete_id'])) {
    $deleteId = (int)$_POST['delete_id'];
    db()->execute('DELETE FROM urls WHERE id = ?', [$deleteId]);
    set_flash('success', 'URL deleted successfully');
    redirect(base_url('admin/urls.php'));
}

// Handle toggle active
if (isset($_POST['toggle_id'])) {
    $toggleId = (int)$_POST['toggle_id'];
    db()->execute('UPDATE urls SET is_active = NOT is_active WHERE id = ?', [$toggleId]);
    set_flash('success', 'URL status updated');
    redirect(base_url('admin/urls.php'));
}

// Pagination
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$perPage = 20;
$offset = ($page - 1) * $perPage;

// Search and filters
$search = $_GET['search'] ?? '';
$userFilter = $_GET['user'] ?? '';
$statusFilter = $_GET['status'] ?? '';

// Build query
$whereClauses = [];
$params = [];

if (!empty($search)) {
    $whereClauses[] = '(u.short_code LIKE ? OR u.long_url LIKE ?)';
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if (!empty($userFilter)) {
    $whereClauses[] = 'u.user_id = ?';
    $params[] = (int)$userFilter;
}

if ($statusFilter === 'active') {
    $whereClauses[] = 'u.is_active = 1';
} elseif ($statusFilter === 'inactive') {
    $whereClauses[] = 'u.is_active = 0';
}

$whereSQL = !empty($whereClauses) ? 'WHERE ' . implode(' AND ', $whereClauses) : '';

// Get total count
$totalUrls = db()->fetchOne("SELECT COUNT(*) as count FROM links u $whereSQL", $params)['count'] ?? 0;
$totalPages = ceil($totalUrls / $perPage);

// Get URLs
$urls = db()->fetchAll("
    SELECT 
        u.*,
        usr.name as user_name,
        usr.email as user_email,
        usr.plan as user_plan
    FROM links u
    LEFT JOIN users usr ON u.user_id = usr.id
    $whereSQL
    ORDER BY u.created_at DESC
    LIMIT $perPage OFFSET $offset
", $params) ?? [];

// Get stats
$stats = db()->fetchOne('
    SELECT 
        COUNT(*) as total_urls,
        SUM(clicks) as total_clicks,
        COUNT(CASE WHEN is_active = 1 THEN 1 END) as active_urls,
        COUNT(CASE WHEN is_active = 0 THEN 1 END) as inactive_urls
    FROM links
') ?? [];

$pageTitle = 'Manage URLs';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?> - SnapLink Pro Admin</title>
    <?php 
    if (function_exists('meta_canonical')) {
        meta_canonical('php-version/admin/urls.php');
    }
    ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gray-50">
    <div class="flex min-h-screen">
        <?php require_once ROOT_PATH . '/components/sidebar.php'; ?>

        <div class="flex-1">
            <div class="max-w-7xl mx-auto px-4 py-8">
                <!-- Header -->
                <div class="mb-8">
                    <h1 class="text-3xl font-bold text-gray-900 mb-2">
                        <i class="fas fa-link text-purple-600 mr-2"></i>Manage URLs
                    </h1>
                    <p class="text-gray-600">View and manage all short URLs across the platform</p>
                </div>

                <?php if ($flash = get_flash()): ?>
                    <div class="mb-6 p-4 rounded-lg <?= $flash['type'] === 'success' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200' ?>">
                        <?= htmlspecialchars($flash['message']) ?>
                    </div>
                <?php endif; ?>

                <!-- Stats Cards -->
                <div class="grid grid-cols-1 md:grid-cols-5 gap-4 mb-8">
                    <div class="bg-white rounded-lg shadow-sm p-4 border border-gray-200">
                        <div class="text-gray-600 text-sm mb-1">Total URLs</div>
                        <div class="text-2xl font-bold text-gray-900"><?= number_format($stats['total_urls'] ?? 0) ?></div>
                    </div>
                    <div class="bg-white rounded-lg shadow-sm p-4 border border-gray-200">
                        <div class="text-gray-600 text-sm mb-1">Total Clicks</div>
                        <div class="text-2xl font-bold text-blue-600"><?= number_format($stats['total_clicks'] ?? 0) ?></div>
                    </div>
                    <div class="bg-white rounded-lg shadow-sm p-4 border border-gray-200">
                        <div class="text-gray-600 text-sm mb-1">QR Scans</div>
                        <div class="text-2xl font-bold text-purple-600"><?= number_format($stats['total_scans'] ?? 0) ?></div>
                    </div>
                    <div class="bg-white rounded-lg shadow-sm p-4 border border-green-200 bg-green-50">
                        <div class="text-green-600 text-sm mb-1">Active</div>
                        <div class="text-2xl font-bold text-green-700"><?= number_format($stats['active_urls'] ?? 0) ?></div>
                    </div>
                    <div class="bg-white rounded-lg shadow-sm p-4 border border-gray-300">
                        <div class="text-gray-500 text-sm mb-1">Inactive</div>
                        <div class="text-2xl font-bold text-gray-600"><?= number_format($stats['inactive_urls'] ?? 0) ?></div>
                    </div>
                </div>

                <!-- Filters -->
                <div class="bg-white rounded-xl shadow-sm p-6 mb-6 border border-gray-200">
                    <form method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Search</label>
                            <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" 
                                   placeholder="Short code or URL..." 
                                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Status</label>
                            <select name="status" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                                <option value="">All Status</option>
                                <option value="active" <?= $statusFilter === 'active' ? 'selected' : '' ?>>Active</option>
                                <option value="inactive" <?= $statusFilter === 'inactive' ? 'selected' : '' ?>>Inactive</option>
                            </select>
                        </div>
                        <div class="flex items-end gap-2">
                            <button type="submit" class="px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition">
                                <i class="fas fa-search mr-2"></i>Filter
                            </button>
                            <a href="urls.php" class="px-6 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition">
                                <i class="fas fa-redo mr-2"></i>Reset
                            </a>
                        </div>
                    </form>
                </div>

                <!-- URLs Table -->
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                    <div class="overflow-x-auto">
                        <?php if (empty($urls)): ?>
                            <div class="text-center py-12 text-gray-500">
                                <i class="fas fa-inbox text-5xl mb-4"></i>
                                <p class="text-lg font-medium">No URLs found</p>
                                <?php if ($search): ?>
                                    <p class="text-sm mt-2">Try adjusting your search filters</p>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <table class="w-full">
                                <thead class="bg-gray-50 border-b border-gray-200">
                                    <tr>
                                        <th class="text-left py-3 px-4 font-semibold text-gray-900">Short Code</th>
                                        <th class="text-left py-3 px-4 font-semibold text-gray-900">Long URL</th>
                                        <th class="text-left py-3 px-4 font-semibold text-gray-900">User</th>
                                        <th class="text-left py-3 px-4 font-semibold text-gray-900">Clicks</th>
                                        <th class="text-left py-3 px-4 font-semibold text-gray-900">Status</th>
                                        <th class="text-left py-3 px-4 font-semibold text-gray-900">Created</th>
                                        <th class="text-left py-3 px-4 font-semibold text-gray-900">Actions</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-200">
                                    <?php foreach ($urls as $url): ?>
                                        <tr class="hover:bg-gray-50">
                                            <td class="py-3 px-4">
                                                <div class="flex items-center gap-2">
                                                    <code class="px-2 py-1 bg-purple-100 text-purple-800 rounded font-mono text-sm">
                                                        <?= htmlspecialchars($url['short_code']) ?>
                                                    </code>
                                                    <a href="<?= base_url($url['short_code']) ?>" target="_blank" class="text-gray-400 hover:text-purple-600">
                                                        <i class="fas fa-external-link-alt text-xs"></i>
                                                    </a>
                                                </div>
                                            </td>
                                            <td class="py-3 px-4">
                                                <div class="max-w-xs truncate text-sm text-gray-600" title="<?= htmlspecialchars($url['long_url']) ?>">
                                                    <?= htmlspecialchars($url['long_url']) ?>
                                                </div>
                                            </td>
                                            <td class="py-3 px-4">
                                                <div class="text-sm">
                                                    <?php if ($url['user_id']): ?>
                                                        <div class="font-medium text-gray-900"><?= htmlspecialchars($url['user_name']) ?></div>
                                                        <div class="text-xs text-gray-500"><?= htmlspecialchars($url['user_email']) ?></div>
                                                        <span class="inline-block mt-1 px-2 py-0.5 bg-<?= $url['user_plan'] === 'free' ? 'gray' : ($url['user_plan'] === 'pro' ? 'purple' : 'pink') ?>-100 text-<?= $url['user_plan'] === 'free' ? 'gray' : ($url['user_plan'] === 'pro' ? 'purple' : 'pink') ?>-800 rounded-full text-xs">
                                                            <?= ucfirst($url['user_plan']) ?>
                                                        </span>
                                                    <?php else: ?>
                                                        <div class="font-medium text-purple-600">
                                                            <i class="fas fa-user-secret mr-1"></i> Guest User
                                                        </div>
                                                        <div class="text-xs text-gray-500">
                                                            IP: <?= htmlspecialchars($url['guest_ip'] ?? 'Unknown') ?>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                            <td class="py-3 px-4">
                                                <div class="text-sm">
                                                    <div class="font-medium text-gray-900"><?= number_format($url['clicks'] ?? 0) ?></div>
                                                    <div class="text-xs text-gray-500">Total clicks</div>
                                                </div>
                                            </td>
                                            <td class="py-3 px-4">
                                                <form method="POST" class="inline" onsubmit="return confirm('Toggle URL status?')">
                                                    <input type="hidden" name="toggle_id" value="<?= $url['id'] ?>">
                                                    <button type="submit" class="px-3 py-1 rounded-full text-xs font-medium <?= $url['is_active'] ? 'bg-green-100 text-green-800 hover:bg-green-200' : 'bg-gray-100 text-gray-800 hover:bg-gray-200' ?>">
                                                        <?= $url['is_active'] ? 'Active' : 'Inactive' ?>
                                                    </button>
                                                </form>
                                            </td>
                                            <td class="py-3 px-4 text-sm text-gray-600">
                                                <?= date('M d, Y', strtotime($url['created_at'])) ?>
                                            </td>
                                            <td class="py-3 px-4">
                                                <div class="flex items-center gap-2">
                                                    <a href="<?= base_url('analytics.php?id=' . $url['id']) ?>" 
                                                       class="text-blue-600 hover:text-blue-700" title="View Analytics">
                                                        <i class="fas fa-chart-bar"></i>
                                                    </a>
                                                    <a href="<?= base_url('qr.php?code=' . $url['short_code']) ?>" 
                                                       target="_blank" class="text-purple-600 hover:text-purple-700" title="QR Code">
                                                        <i class="fas fa-qrcode"></i>
                                                    </a>
                                                    <form method="POST" class="inline" onsubmit="return confirm('Are you sure you want to delete this URL?')">
                                                        <input type="hidden" name="delete_id" value="<?= $url['id'] ?>">
                                                        <button type="submit" class="text-red-600 hover:text-red-700" title="Delete">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>

                    <!-- Pagination -->
                    <?php if ($totalPages > 1): ?>
                        <div class="border-t border-gray-200 px-4 py-3 bg-gray-50">
                            <div class="flex items-center justify-between">
                                <div class="text-sm text-gray-600">
                                    Showing <?= $offset + 1 ?> to <?= min($offset + $perPage, $totalUrls) ?> of <?= number_format($totalUrls ?? 0) ?> URLs
                                </div>
                                <div class="flex gap-2">
                                    <?php if ($page > 1): ?>
                                        <a href="?page=<?= $page - 1 ?>&search=<?= urlencode($search) ?>&status=<?= urlencode($statusFilter) ?>" 
                                           class="px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
                                            Previous
                                        </a>
                                    <?php endif; ?>
                                    
                                    <span class="px-4 py-2 bg-purple-600 text-white rounded-lg">
                                        Page <?= $page ?> of <?= $totalPages ?>
                                    </span>
                                    
                                    <?php if ($page < $totalPages): ?>
                                        <a href="?page=<?= $page + 1 ?>&search=<?= urlencode($search) ?>&status=<?= urlencode($statusFilter) ?>" 
                                           class="px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
                                            Next
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
