﻿<?php
/**
 * Admin Fraud Control Panel
 * Monitor suspicious traffic, manage bans, view click logs
 */
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

require_login();
require_admin();

$user = current_user();

// Handle ban/unban actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    switch ($_POST['action']) {
        case 'ban_ip':
            $ip = $_POST['ip'] ?? '';
            $reason = $_POST['reason'] ?? 'Manual ban';
            $hours = $_POST['hours'] ?? null;
            $expires = $hours ? date("Y-m-d H:i:s", strtotime("+$hours hours")) : null;
            
            db()->insert(
                "INSERT INTO banned_ips (ip, reason, expires_at) VALUES (?, ?, ?)
                 ON DUPLICATE KEY UPDATE reason = ?, expires_at = ?",
                [$ip, $reason, $expires, $reason, $expires]
            );
            
            json_response(['success' => true]);
            break;
            
        case 'unban_ip':
            $ip = $_POST['ip'] ?? '';
            db()->execute("DELETE FROM banned_ips WHERE ip = ?", [$ip]);
            json_response(['success' => true]);
            break;
            
        case 'ban_user':
            $userId = $_POST['user_id'] ?? 0;
            $reason = $_POST['reason'] ?? 'Manual ban';
            db()->insert(
                "INSERT INTO banned_users (user_id, reason) VALUES (?, ?)
                 ON DUPLICATE KEY UPDATE reason = ?",
                [$userId, $reason, $reason]
            );
            json_response(['success' => true]);
            break;
            
        case 'unban_user':
            $userId = $_POST['user_id'] ?? 0;
            db()->execute("DELETE FROM banned_users WHERE user_id = ?", [$userId]);
            json_response(['success' => true]);
            break;
    }
    exit;
}

// Check if fraud protection tables exist
$tablesExist = true;
try {
    db()->fetchOne("SELECT 1 FROM click_logs LIMIT 1");
} catch (Exception $e) {
    $tablesExist = false;
}

if (!$tablesExist) {
    // Show setup instructions
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Set Up Fraud Protection - Admin - SnapLink Pro</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
        <style>body { font-family: 'Inter', sans-serif; }</style>
    </head>
    <body class="bg-gray-50 min-h-screen flex items-center justify-center p-4">
        <div class="max-w-2xl w-full bg-white rounded-2xl shadow-xl p-8">
            <div class="text-center mb-6">
                <div class="w-20 h-20 bg-red-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                    <i class="fas fa-database text-3xl text-red-600"></i>
                </div>
                <h1 class="text-2xl font-bold text-gray-900 mb-2">Fraud Protection Not Set Up</h1>
                <p class="text-gray-500">The required database tables are missing</p>
            </div>
            
            <div class="bg-yellow-50 border border-yellow-200 rounded-xl p-6 mb-6">
                <h3 class="font-bold text-gray-900 mb-3 flex items-center gap-2">
                    <i class="fas fa-exclamation-triangle text-yellow-600"></i>
                    Action Required
                </h3>
                <p class="text-gray-700 mb-4">
                    You need to run the database migration to set up fraud protection tables.
                </p>
                <ol class="space-y-2 text-sm text-gray-700">
                    <li class="flex items-start gap-2">
                        <span class="font-bold text-purple-600">1.</span>
                        <span>Open <strong>phpMyAdmin</strong> and select your database (<code class="bg-gray-100 px-2 py-1 rounded">if0_34392250_snaplink</code>)</span>
                    </li>
                    <li class="flex items-start gap-2">
                        <span class="font-bold text-purple-600">2.</span>
                        <span>Click the <strong>SQL</strong> tab</span>
                    </li>
                    <li class="flex items-start gap-2">
                        <span class="font-bold text-purple-600">3.</span>
                        <span>Copy and paste the SQL from <code class="bg-gray-100 px-2 py-1 rounded">migration_fraud_protection.sql</code></span>
                    </li>
                    <li class="flex items-start gap-2">
                        <span class="font-bold text-purple-600">4.</span>
                        <span>Click <strong>Go</strong> to execute</span>
                    </li>
                    <li class="flex items-start gap-2">
                        <span class="font-bold text-purple-600">5.</span>
                        <span>Refresh this page</span>
                    </li>
                </ol>
            </div>

            <div class="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6">
                <h4 class="font-semibold text-sm text-gray-900 mb-2">Quick Copy SQL:</h4>
                <div class="bg-white rounded p-3 border border-blue-300">
                    <code class="text-xs text-gray-700 block" style="white-space: pre-line;">
-- Copy this entire block to phpMyAdmin
CREATE TABLE IF NOT EXISTS click_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    url_id INT NULL,
    ip VARCHAR(50),
    country VARCHAR(10),
    city VARCHAR(100),
    user_agent TEXT,
    referrer TEXT,
    org TEXT,
    device_type VARCHAR(20),
    browser VARCHAR(50),
    is_suspicious BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_ip (ip),
    INDEX idx_url_id (url_id)
);

CREATE TABLE IF NOT EXISTS banned_ips (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ip VARCHAR(50) UNIQUE,
    reason VARCHAR(255),
    expires_at DATETIME NULL,
    banned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS banned_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNIQUE,
    reason VARCHAR(255),
    banned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
                    </code>
                </div>
                <button onclick="navigator.clipboard.writeText(this.previousElementSibling.querySelector('code').textContent)" 
                        class="mt-2 text-sm text-blue-600 hover:text-blue-700 font-medium">
                    <i class="fas fa-copy mr-1"></i>Copy SQL
                </button>
            </div>

            <div class="flex gap-3">
                <a href="<?= base_url('admin/index.php') ?>" class="flex-1 py-3 border border-gray-300 rounded-xl text-center font-semibold text-gray-700 hover:bg-gray-50">
                    <i class="fas fa-arrow-left mr-1"></i>Back to Dashboard
                </a>
                <button onclick="location.reload()" class="flex-1 py-3 bg-purple-600 text-white rounded-xl font-semibold hover:bg-purple-700">
                    <i class="fas fa-sync mr-1"></i>Refresh Page
                </button>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// Get stats
$stats = [
    'total_clicks' => db()->fetchOne("SELECT COUNT(*) as c FROM click_logs")['c'] ?? 0,
    'suspicious_clicks' => db()->fetchOne("SELECT COUNT(*) as c FROM click_logs WHERE is_suspicious = 1")['c'] ?? 0,
    'banned_ips' => db()->fetchOne("SELECT COUNT(*) as c FROM banned_ips")['c'] ?? 0,
    'banned_users' => db()->fetchOne("SELECT COUNT(*) as c FROM banned_users")['c'] ?? 0,
];

// Get suspicious traffic (last 1000 clicks flagged)
$suspiciousTraffic = db()->fetchAll(
    "SELECT * FROM click_logs WHERE is_suspicious = 1 ORDER BY created_at DESC LIMIT 100"
) ?? [];

// Get banned IPs
$bannedIPs = db()->fetchAll(
    "SELECT * FROM banned_ips ORDER BY banned_at DESC LIMIT 50"
) ?? [];

// Get clickaggregation by IP (top abusers)
$topIPs = db()->fetchAll(
    "SELECT ip, COUNT(*) as click_count, MAX(created_at) as last_click
     FROM click_logs 
     GROUP BY ip 
     HAVING click_count > 10
     ORDER BY click_count DESC LIMIT 50"
) ?? [];

// Geo distribution
$geoStats = db()->fetchAll(
    "SELECT country, COUNT(*) as count FROM click_logs 
     GROUP BY country ORDER BY count DESC LIMIT 10"
) ?? [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fraud Control - Admin - SnapLink Pro</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-50">
    <div class="flex">
        <?php require_once ROOT_PATH . '/admin/partials/sidebar.php'; ?>
        
        <div class="flex-1 min-h-screen">
            <!-- Header -->
            <header class="bg-white border-b border-gray-200 px-6 py-4">
                <div class="flex items-center justify-between">
                    <div>
                        <h1 class="text-2xl font-bold text-gray-900">Fraud Control Center</h1>
                        <p class="text-gray-500 text-sm">Monitor & block malicious traffic</p>
                    </div>
                    <div class="flex items-center gap-3">
                        <span class="px-3 py-1 rounded-full text-xs font-medium bg-red-100 text-red-700">
                            <?= $stats['suspicious_clicks'] ?> Suspicious
                        </span>
                        <span class="px-3 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-700">
                            <?= $stats['banned_ips'] ?> IPs Banned
                        </span>
                    </div>
                </div>
            </header>

            <div class="p-6">
                <!-- Stats Overview -->
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
                    <div class="bg-white rounded-xl p-6 border border-gray-100">
                        <div class="flex items-center justify-between">
                            <div>
                            <p class="text-gray-500 text-sm">Total Clicks</p>
                            <p class="text-3xl font-bold text-gray-900 mt-1"><?= number_format($stats['total_clicks']) ?></p>
                        </div>
                        <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-mouse-pointer text-blue-600"></i>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-xl p-6 border border-gray-100">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-500 text-sm">Suspicious Clicks</p>
                            <p class="text-3xl font-bold text-red-600 mt-1"><?= number_format($stats['suspicious_clicks']) ?></p>
                        </div>
                        <div class="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-exclamation-triangle text-red-600"></i>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-xl p-6 border border-gray-100">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-500 text-sm">Banned IPs</p>
                            <p class="text-3xl font-bold text-orange-600 mt-1"><?= $stats['banned_ips'] ?></p>
                        </div>
                        <div class="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-ban text-orange-600"></i>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-xl p-6 border border-gray-100">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-gray-500 text-sm">Banned Users</p>
                            <p class="text-3xl font-bold text-purple-600 mt-1"><?= $stats['banned_users'] ?></p>
                        </div>
                        <div class="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                            <i class="fas fa-user-slash text-purple-600"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Charts Row -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                <div class="bg-white rounded-xl p-6 border border-gray-100">
                    <h3 class="font-bold text-gray-900 mb-4">Traffic by Country</h3>
                    <canvas id="geoChart" height="200"></canvas>
                </div>
                <div class="bg-white rounded-xl p-6 border border-gray-100">
                    <h3 class="font-bold text-gray-900 mb-4">Fraud Detection Rate</h3>
                    <canvas id="fraudChart" height="200"></canvas>
                </div>
            </div>

            <!-- Top Abusers -->
            <div class="bg-white rounded-xl border border-gray-100 mb-6">
                <div class="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
                    <h3 class="font-bold text-gray-900">Top IP Addresses (High Click Count)</h3>
                    <span class="text-xs text-gray-500"><?= count($topIPs) ?> IPs</span>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="bg-gray-50 text-xs text-gray-500 uppercase">
                            <tr>
                                <th class="px-6 py-3 text-left">IP Address</th>
                                <th class="px-6 py-3 text-left">Click Count</th>
                                <th class="px-6 py-3 text-left">Last Click</th>
                                <th class="px-6 py-3 text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            <?php foreach ($topIPs as $ipData): ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4 font-mono text-sm"><?= htmlspecialchars($ipData['ip']) ?></td>
                                    <td class="px-6 py-4">
                                        <span class="px-2 py-1 rounded-full text-xs font-medium <?= $ipData['click_count'] > 100 ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700' ?>">
                                            <?= number_format($ipData['click_count']) ?> clicks
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-600"><?= date('M j, g:i A', strtotime($ipData['last_click'])) ?></td>
                                    <td class="px-6 py-4 text-center">
                                        <button onclick="banIP('<?= htmlspecialchars($ipData['ip']) ?>')" 
                                                class="text-red-600 hover:text-red-700 text-sm font-medium">
                                            <i class="fas fa-ban mr-1"></i>Ban
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Banned IPs -->
            <div class="bg-white rounded-xl border border-gray-100">
                <div class="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
                    <h3 class="font-bold text-gray-900">Banned IP Addresses</h3>
                    <button onclick="showBanIPModal()" class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 text-sm font-medium">
                        <i class="fas fa-plus mr-1"></i>Ban New IP
                    </button>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="bg-gray-50 text-xs text-gray-500 uppercase">
                            <tr>
                                <th class="px-6 py-3 text-left">IP Address</th>
                                <th class="px-6 py-3 text-left">Reason</th>
                                <th class="px-6 py-3 text-left">Banned At</th>
<th class="px-6 py-3 text-left">Expires</th>
                                <th class="px-6 py-3 text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            <?php if (empty($bannedIPs)): ?>
                                <tr>
                                    <td colspan="5" class="px-6 py-8 text-center text-gray-500">No banned IPs yet</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($bannedIPs as $ban): ?>
                                    <tr class="hover:bg-gray-50">
                                        <td class="px-6 py-4 font-mono text-sm font-medium"><?= htmlspecialchars($ban['ip']) ?></td>
                                        <td class="px-6 py-4 text-sm text-gray-600"><?= htmlspecialchars($ban['reason']) ?></td>
                                        <td class="px-6 py-4 text-sm text-gray-600"><?= date('M j, g:i A', strtotime($ban['banned_at'])) ?></td>
                                        <td class="px-6 py-4 text-sm">
                                            <?php if ($ban['expires_at']): ?>
                                                <span class="text-yellow-600"><?= date('M j, g:i A', strtotime($ban['expires_at'])) ?></span>
                                            <?php else: ?>
                                                <span class="text-red-600 font-medium">Permanent</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="px-6 py-4 text-center">
                                            <button onclick="unbanIP('<?= htmlspecialchars($ban['ip']) ?>')" 
                                                    class="text-green-600 hover:text-green-700 text-sm font-medium">
                                                <i class="fas fa-unlock mr-1"></i>Unban
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Geo Chart
        new Chart(document.getElementById('geoChart'), {
            type: 'bar',
            data: {
                labels: <?= json_encode(array_column($geoStats, 'country')) ?>,
                datasets: [{
                    label: 'Clicks',
                    data: <?= json_encode(array_column($geoStats, 'count')) ?>,
                    backgroundColor: '#7F00FF'
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: false } }
            }
        });

        // Fraud Chart
        const totalClicks = <?= $stats['total_clicks'] ?>;
        const suspiciousClicks = <?= $stats['suspicious_clicks'] ?>;
        new Chart(document.getElementById('fraudChart'), {
            type: 'doughnut',
            data: {
                labels: ['Legitimate', 'Suspicious'],
                datasets: [{
                    data: [totalClicks - suspiciousClicks, suspiciousClicks],
                    backgroundColor: ['#10B981', '#EF4444']
                }]
            }
        });

        function banIP(ip) {
            const reason = prompt('Reason for banning IP ' + ip + ':', 'Manual ban');
            if (!reason) return;
            
            const hours = prompt('Ban duration in hours (leave empty for permanent):', '24');
            
            fetch('fraud.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: `action=ban_ip&ip=${encodeURIComponent(ip)}&reason=${encodeURIComponent(reason)}&hours=${hours}`
            })
            .then(r => r.json())
            .then(() => {
                alert('IP banned successfully');
                location.reload();
            });
        }

        function unbanIP(ip) {
            if (!confirm('Unban IP ' + ip + '?')) return;
            
            fetch('fraud.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: `action=unban_ip&ip=${encodeURIComponent(ip)}`
            })
            .then(r => r.json())
            .then(() => {
                alert('IP unbanned successfully');
                location.reload();
            });
        }

        function showBanIPModal() {
            const ip = prompt('Enter IP address to ban:');
            if (!ip) return;
            banIP(ip);
        }
    </script>
        </div>
    </div>
</body>
</html>
