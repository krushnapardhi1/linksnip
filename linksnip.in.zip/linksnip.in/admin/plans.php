﻿<?php
/**
 * Admin - Plan Management
 */
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

require_admin();

$user = current_user();
$flash = get_flash();

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    try {
        if ($action === 'create' || $action === 'update') {
            $name = sanitize($_POST['name']);
            $description = sanitize($_POST['description']);
            $price_monthly = floatval($_POST['price_monthly']);
            $price_yearly = floatval($_POST['price_yearly']); // Optional
            $currency = sanitize($_POST['currency']);
            $stripe_price_id = sanitize($_POST['stripe_price_id']);
            $link_limit = intval($_POST['link_limit']);
            $custom_domains = intval($_POST['custom_domains']);
            $is_active = isset($_POST['is_active']) ? 1 : 0;
            
            // Handle features - simple comma separated for now converted to json
            $featuresList = explode("\n", $_POST['features']);
            $features = array_filter(array_map('trim', $featuresList));
            $featuresJson = json_encode(array_values($features));

            if ($action === 'create') {
                db()->query(
                    "INSERT INTO subscription_plans (name, description, price_monthly, price_yearly, currency, stripe_price_id, link_limit, custom_domains, features, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    [$name, $description, $price_monthly, $price_yearly, $currency, $stripe_price_id, $link_limit, $custom_domains, $featuresJson, $is_active]
                );
                set_flash('success', 'Plan created successfully');
            } else {
                $id = intval($_POST['id']);
                db()->query(
                    "UPDATE subscription_plans SET name=?, description=?, price_monthly=?, price_yearly=?, currency=?, stripe_price_id=?, link_limit=?, custom_domains=?, features=?, is_active=? WHERE id=?",
                    [$name, $description, $price_monthly, $price_yearly, $currency, $stripe_price_id, $link_limit, $custom_domains, $featuresJson, $is_active, $id]
                );
                set_flash('success', 'Plan updated successfully');
            }
        } elseif ($action === 'delete') {
            $id = intval($_POST['id']);
            // Soft delete or hard? Hard delete but check constraints
            try {
                db()->query("DELETE FROM subscription_plans WHERE id = ?", [$id]);
                set_flash('success', 'Plan deleted successfully');
            } catch (Exception $e) {
                // If in use, maybe just deactivate
                db()->query("UPDATE subscription_plans SET is_active = 0 WHERE id = ?", [$id]);
                set_flash('error', 'Plan is in use. Deactivated instead of deleted.');
            }
        }
    } catch (Exception $e) {
        set_flash('error', 'Error: ' . $e->getMessage());
    }
    
    redirect('plans.php');
}

// Fetch Plans
$plans = db()->fetchAll("SELECT * FROM subscription_plans ORDER BY price_monthly ASC");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Plans - Admin - SnapLink Pro</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        brand: { purple: '#7F00FF', pink: '#E100FF', dark: '#0F172A' }
                    },
                    fontFamily: { sans: ['Inter', 'sans-serif'] }
                }
            }
        }
    </script>
</head>
<body class="bg-gray-50 font-sans">

    <div class="flex h-screen overflow-hidden">
        
        <!-- Sidebar -->
        <?php include ROOT_PATH . '/admin/partials/sidebar.php'; ?>

        <!-- Main Content -->
        <main class="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50">
            <!-- Header -->
            <header class="bg-white shadow-sm sticky top-0 z-30">
                <div class="px-6 py-4">
                    <h1 class="text-2xl font-bold text-gray-800">Plan Management</h1>
                </div>
            </header>

            <div class="p-6">
                
                <?php if ($flash): ?>
                    <div class="mb-6 p-4 rounded-xl <?= $flash['type'] === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700' ?>">
                        <?= $flash['message'] ?>
                    </div>
                <?php endif; ?>

                <!-- Actions -->
                <div class="mb-6 flex justify-between items-center">
                    <p class="text-gray-600">Manage subscription plans available to users.</p>
                    <button onclick="openModal('create')" class="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 font-semibold shadow-lg">
                        <i class="fas fa-plus mr-2"></i>Create Plan
                    </button>
                </div>

                <!-- Plans Grid -->
                <div class="grid md:grid-cols-2 xl:grid-cols-3 gap-6">
                    <?php foreach ($plans as $plan): 
                        $features = json_decode($plan['features'], true) ?: [];
                    ?>
                        <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition">
                            <div class="p-6">
                                <div class="flex justify-between items-start mb-4">
                                    <div>
                                        <h3 class="text-xl font-bold text-gray-900"><?= htmlspecialchars($plan['name']) ?></h3>
                                        <p class="text-sm text-purple-600 font-semibold"><?= htmlspecialchars($plan['stripe_price_id'] ?: 'No Stripe ID') ?></p>
                                    </div>
                                    <span class="px-3 py-1 rounded-full text-xs font-bold <?= $plan['is_active'] ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600' ?>">
                                        <?= $plan['is_active'] ? 'ACTIVE' : 'INACTIVE' ?>
                                    </span>
                                </div>
                                
                                <p class="text-gray-500 text-sm mb-4 h-10 overflow-hidden text-ellipsis line-clamp-2"><?= htmlspecialchars($plan['description']) ?></p>
                                
                                <div class="flex items-baseline mb-4">
                                    <span class="text-2xl font-bold text-gray-900">$<?= number_format($plan['price_monthly'], 2) ?></span>
                                    <span class="text-gray-500 text-sm ml-1">/mo</span>
                                </div>

                                <div class="space-y-2 mb-6 text-sm text-gray-600">
                                    <div class="flex justify-between">
                                        <span>Link Limit:</span>
                                        <span class="font-semibold"><?= number_format($plan['link_limit']) ?></span>
                                    </div>
                                    <div class="flex justify-between">
                                        <span>Custom Domains:</span>
                                        <span class="font-semibold"><?= number_format($plan['custom_domains']) ?></span>
                                    </div>
                                    <div class="pt-2 text-xs text-gray-400">
                                        <?= count($features) ?> Features configured
                                    </div>
                                </div>

                                <div class="flex gap-2">
                                    <button onclick='openModal("edit", <?= json_encode($plan) ?>)' class="flex-1 px-3 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 font-medium transition">
                                        Edit
                                    </button>
                                    <?php if ($plan['id'] != 1): // Prevent deleting default/first plan easily ?>
                                    <form method="POST" onsubmit="return confirm('Are you sure? This might affect subscribed users.')" class="flex-1">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?= $plan['id'] ?>">
                                        <button type="submit" class="w-full px-3 py-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 font-medium transition">
                                            Delete
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

            </div>
        </main>
    </div>

    <!-- Edit/Create Modal -->
    <div id="planModal" class="fixed inset-0 bg-black/50 z-50 hidden flex items-center justify-center p-4">
        <div class="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div class="p-6 border-b border-gray-100 flex justify-between items-center">
                <h3 id="modalTitle" class="text-xl font-bold text-gray-900">Create New Plan</h3>
                <button onclick="closeModal()" class="text-gray-400 hover:text-gray-600"><i class="fas fa-times"></i></button>
            </div>
            
            <form method="POST" class="p-6 space-y-4">
                <input type="hidden" name="action" id="formAction" value="create">
                <input type="hidden" name="id" id="planId">

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Plan Name</label>
                        <input type="text" name="name" id="name" required class="w-full rounded-lg border-gray-300 focus:ring-purple-500 focus:border-purple-500 px-4 py-2 border">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Stripe Price ID</label>
                        <input type="text" name="stripe_price_id" id="stripe_price_id" placeholder="price_..." class="w-full rounded-lg border-gray-300 focus:ring-purple-500 focus:border-purple-500 px-4 py-2 border">
                    </div>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Description</label>
                    <input type="text" name="description" id="description" class="w-full rounded-lg border-gray-300 focus:ring-purple-500 focus:border-purple-500 px-4 py-2 border">
                </div>

                <div class="grid grid-cols-3 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Monthly Price</label>
                        <input type="number" step="0.01" name="price_monthly" id="price_monthly" required class="w-full rounded-lg border-gray-300 focus:ring-purple-500 focus:border-purple-500 px-4 py-2 border">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Yearly Price</label>
                        <input type="number" step="0.01" name="price_yearly" id="price_yearly" class="w-full rounded-lg border-gray-300 focus:ring-purple-500 focus:border-purple-500 px-4 py-2 border">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Currency</label>
                        <select name="currency" id="currency" class="w-full rounded-lg border-gray-300 focus:ring-purple-500 focus:border-purple-500 px-4 py-2 border">
                            <option value="USD">USD ($)</option>
                            <option value="EUR">EUR (€)</option>
                            <option value="GBP">GBP (£)</option>
                            <option value="INR">INR (₹)</option>
                        </select>
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Link Limit</label>
                        <input type="number" name="link_limit" id="link_limit" value="1000" class="w-full rounded-lg border-gray-300 focus:ring-purple-500 focus:border-purple-500 px-4 py-2 border">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Custom Domains</label>
                        <input type="number" name="custom_domains" id="custom_domains" value="0" class="w-full rounded-lg border-gray-300 focus:ring-purple-500 focus:border-purple-500 px-4 py-2 border">
                    </div>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Features (One per line)</label>
                    <textarea name="features" id="features" rows="4" class="w-full rounded-lg border-gray-300 focus:ring-purple-500 focus:border-purple-500 px-4 py-2 border" placeholder="Ad-free experience&#10;Priority Support&#10;Advanced Analytics"></textarea>
                </div>

                <div class="flex items-center">
                    <input type="checkbox" name="is_active" id="is_active" value="1" checked class="w-4 h-4 text-purple-600 rounded border-gray-300 focus:ring-purple-500">
                    <label for="is_active" class="ml-2 text-sm text-gray-700">Plan is Active</label>
                </div>

                <div class="pt-4 flex justify-end gap-3">
                    <button type="button" onclick="closeModal()" class="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 font-medium">Cancel</button>
                    <button type="submit" class="px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 font-bold shadow-lg">Save Plan</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        const modal = document.getElementById('planModal');
        const formAction = document.getElementById('formAction');
        const planId = document.getElementById('planId');
        const modalTitle = document.getElementById('modalTitle');
        
        // Fields
        const fields = ['name', 'stripe_price_id', 'description', 'price_monthly', 'price_yearly', 'currency', 'link_limit', 'custom_domains'];

        function openModal(mode, data = null) {
            modal.classList.remove('hidden');
            if (mode === 'edit' && data) {
                formAction.value = 'update';
                planId.value = data.id;
                modalTitle.textContent = 'Edit Plan';
                
                fields.forEach(f => {
                    document.getElementById(f).value = data[f] || '';
                });

                document.getElementById('is_active').checked = data.is_active == 1;
                
                // Parse features
                try {
                    const feats = JSON.parse(data.features);
                    document.getElementById('features').value = feats.join('\n');
                } catch(e) {
                    document.getElementById('features').value = '';
                }

            } else {
                formAction.value = 'create';
                planId.value = '';
                modalTitle.textContent = 'Create New Plan';
                document.querySelector('form').reset();
                document.getElementById('is_active').checked = true;
            }
        }

        function closeModal() {
            modal.classList.add('hidden');
        }
    </script>
</body>
</html>
