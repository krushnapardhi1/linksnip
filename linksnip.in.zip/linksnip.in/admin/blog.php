﻿<?php
/**
 * Admin Blog Management
 */
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

// Must be admin
if (!is_logged_in() || current_user()['role'] !== 'admin') {
    redirect(base_url('dashboard.php'));
}

$action = $_GET['action'] ?? 'list';

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (isset($_POST['create_post']) || isset($_POST['update_post'])) {
            $title = sanitize($_POST['title']);
            $slug = sanitize($_POST['slug']);
            if (empty($slug)) $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title)));
            
            $excerpt = sanitize($_POST['excerpt']);
            $content = $_POST['content']; // Allow HTML for content
            $isPublished = isset($_POST['is_published']) ? 1 : 0;
            $thumbnail = $_POST['thumbnail_url'] ?? null;
            
            if (isset($_POST['create_post'])) {
                // Check slug uniqueness
                $exists = db()->fetchOne("SELECT id FROM blogs WHERE slug = ?", [$slug]);
                if ($exists) throw new Exception("Slug already exists");
                
                db()->insert(
                    "INSERT INTO blogs (title, slug, excerpt, content, thumbnail_url, author_id, is_published) 
                     VALUES (?, ?, ?, ?, ?, ?, ?)",
                    [$title, $slug, $excerpt, $content, $thumbnail, current_user()['id'], $isPublished]
                );
                set_flash('success', 'Post created successfully');
                $action = 'list';
            } else {
                $id = $_POST['id'];
                db()->execute(
                    "UPDATE blogs SET title = ?, slug = ?, excerpt = ?, content = ?, thumbnail_url = ?, is_published = ? WHERE id = ?",
                    [$title, $slug, $excerpt, $content, $thumbnail, $isPublished, $id]
                );
                set_flash('success', 'Post updated successfully');
                $action = 'list';
            }
        }
        
        elseif (isset($_POST['delete_post'])) {
            $id = $_POST['id'];
            db()->execute("DELETE FROM blogs WHERE id = ?", [$id]);
            set_flash('success', 'Post deleted successfully');
        }
    } catch (Exception $e) {
        set_flash('error', $e->getMessage());
    }
}

// Fetch Posts for List View
$posts = db()->fetchAll("SELECT b.*, u.name as author_name FROM blogs b LEFT JOIN users u ON b.author_id = u.id ORDER BY b.created_at DESC") ?? [];

// Fetch Single Post for Edit
$editPost = null;
if ($action === 'edit' && isset($_GET['id'])) {
    $editPost = db()->fetchOne("SELECT * FROM blogs WHERE id = ?", [$_GET['id']]);
}

$flash = get_flash();
$pageTitle = 'Blog Management';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?> - SnapLink Pro Admin</title>
    <?php 
    if (function_exists('meta_canonical')) {
        meta_canonical('php-version/admin/blog.php');
    }
    ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <!-- TinyMCE Editor -->
    <script src="https://cdn.tiny.cloud/1/gh529n4f5wrof732d5k7en1ekb2vtb89c8n77zb2mzpqp5d8/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
    <script>
      tinymce.init({
        selector: '#contentEditor',
        height: 500,
        plugins: [
          // Core editing features
          'anchor', 'autolink', 'charmap', 'codesample', 'emoticons', 'link', 'lists', 'media', 'searchreplace', 'table', 'visualblocks', 'wordcount',
          // Premium features (trial until Feb 7, 2026)
          'checklist', 'mediaembed', 'casechange', 'formatpainter', 'pageembed', 'a11ychecker', 'tinymcespellchecker', 'permanentpen', 'powerpaste', 'advtable', 'advcode', 'advtemplate', 'ai', 'uploadcare', 'mentions', 'tinycomments', 'tableofcontents', 'footnotes', 'mergetags', 'autocorrect', 'typography', 'inlinecss', 'markdown', 'importword', 'exportword', 'exportpdf'
        ],
        toolbar: 'undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link media table mergetags | addcomment showcomments | spellcheckdialog a11ycheck typography uploadcare | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat',
        tinycomments_mode: 'embedded',
        tinycomments_author: 'Author name',
        mergetags_list: [
          { value: 'First.Name', title: 'First Name' },
          { value: 'Email', title: 'Email' },
        ],
        ai_request: (request, respondWith) => respondWith.string(() => Promise.reject('See docs to implement AI Assistant')),
        uploadcare_public_key: '890179c1cd80170a31b0',
      });
    </script>
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gray-50">
    <div class="flex min-h-screen">
        <?php require_once ROOT_PATH . '/components/sidebar.php'; ?>

        <main class="flex-1 p-8">
            <div class="max-w-7xl mx-auto">
                <div class="flex justify-between items-center mb-8">
                    <h1 class="text-3xl font-bold text-gray-900">
                        <i class="fas fa-blog text-purple-600 mr-2"></i>Blog Management
                    </h1>
                    <?php if ($action === 'list'): ?>
                        <a href="?action=create" class="px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition">
                            <i class="fas fa-plus mr-2"></i> New Post
                        </a>
                    <?php else: ?>
                        <a href="blog.php" class="text-gray-600 hover:text-gray-900">
                            <i class="fas fa-arrow-left mr-1"></i> Back to List
                        </a>
                    <?php endif; ?>
                </div>

                <?php if ($flash): ?>
                    <div class="mb-6 p-4 rounded-lg <?= $flash['type'] === 'success' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200' ?>">
                        <?= htmlspecialchars($flash['message']) ?>
                    </div>
                <?php endif; ?>

                <?php if ($action === 'list'): ?>
                    <div class="bg-white rounded-xl shadow-sm overflow-hidden border border-gray-200">
                        <?php if (empty($posts)): ?>
                            <div class="text-center py-12 text-gray-500">
                                <i class="fas fa-blog text-5xl mb-4"></i>
                                <p class="text-lg font-medium mb-2">No blog posts yet</p>
                                <p class="text-sm">Create your first blog post to get started</p>
                            </div>
                        <?php else: ?>
                            <table class="w-full">
                                <thead class="bg-gray-50 border-b border-gray-200">
                                    <tr>
                                        <th class="text-left py-3 px-4 font-semibold text-gray-900">Title</th>
                                        <th class="text-left py-3 px-4 font-semibold text-gray-900">Author</th>
                                        <th class="text-center py-3 px-4 font-semibold text-gray-900">Status</th>
                                        <th class="text-left py-3 px-4 font-semibold text-gray-900">Date</th>
                                        <th class="text-right py-3 px-4 font-semibold text-gray-900">Actions</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-200">
                                    <?php foreach ($posts as $post): ?>
                                        <tr class="hover:bg-gray-50">
                                            <td class="py-3 px-4">
                                                <div class="font-medium text-gray-900"><?= htmlspecialchars($post['title']) ?></div>
                                                <div class="text-xs text-gray-500">/<?= htmlspecialchars($post['slug']) ?></div>
                                            </td>
                                            <td class="py-3 px-4 text-sm text-gray-600"><?= htmlspecialchars($post['author_name'] ?? 'Unknown') ?></td>
                                            <td class="py-3 px-4 text-center">
                                                <span class="px-3 py-1 rounded-full text-xs font-medium <?= $post['is_published'] ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700' ?>">
                                                    <?= $post['is_published'] ? 'Published' : 'Draft' ?>
                                                </span>
                                            </td>
                                            <td class="py-3 px-4 text-sm text-gray-600">
                                                <?= date('M d, Y', strtotime($post['created_at'])) ?>
                                            </td>
                                            <td class="py-3 px-4 text-right">
                                                <div class="flex items-center justify-end gap-3">
                                                    <a href="?action=edit&id=<?= $post['id'] ?>" class="text-blue-600 hover:text-blue-700" title="Edit">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <a href="<?= base_url('blog.php?slug=' . $post['slug']) ?>" target="_blank" class="text-purple-600 hover:text-purple-700" title="View">
                                                        <i class="fas fa-external-link-alt"></i>
                                                    </a>
                                                    <form method="POST" class="inline" onsubmit="return confirm('Delete this post?')">
                                                        <input type="hidden" name="delete_post" value="1">
                                                        <input type="hidden" name="id" value="<?= $post['id'] ?>">
                                                        <button type="submit" class="text-red-600 hover:text-red-700" title="Delete">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>

                <?php elseif ($action === 'create' || $action === 'edit'): ?>
                    <div class="bg-white rounded-xl shadow-sm p-8 border border-gray-200">
                        <form method="POST">
                            <?php if ($action === 'create'): ?>
                                <input type="hidden" name="create_post" value="1">
                            <?php else: ?>
                                <input type="hidden" name="update_post" value="1">
                                <input type="hidden" name="id" value="<?= $editPost['id'] ?>">
                            <?php endif; ?>

                            <div class="space-y-6">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Title *</label>
                                    <input type="text" name="title" value="<?= htmlspecialchars($editPost['title'] ?? '') ?>" 
                                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent" required>
                                </div>
                                
                                <div class="grid grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">Slug (Optional)</label>
                                        <input type="text" name="slug" value="<?= htmlspecialchars($editPost['slug'] ?? '') ?>" 
                                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent" 
                                               placeholder="auto-generated-from-title">
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">Thumbnail URL</label>
                                        <input type="url" name="thumbnail_url" value="<?= htmlspecialchars($editPost['thumbnail_url'] ?? '') ?>" 
                                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                                    </div>
                                </div>

                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Excerpt</label>
                                    <textarea name="excerpt" rows="3" 
                                              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"><?= htmlspecialchars($editPost['excerpt'] ?? '') ?></textarea>
                                </div>

                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Content *</label>
                                    <textarea id="contentEditor" name="content"><?= htmlspecialchars($editPost['content'] ?? '') ?></textarea>
                                </div>

                                <div class="flex items-center gap-2">
                                    <input type="checkbox" name="is_published" id="is_published" 
                                           class="w-4 h-4 rounded text-purple-600 focus:ring-purple-500" 
                                           <?= ($editPost['is_published'] ?? 0) ? 'checked' : '' ?>>
                                    <label for="is_published" class="text-sm text-gray-700">Publish immediately</label>
                                </div>

                                <div class="flex justify-end gap-3 pt-4 border-t border-gray-200">
                                    <a href="blog.php" class="px-6 py-2 text-gray-600 hover:bg-gray-100 rounded-lg transition">Cancel</a>
                                    <button type="submit" class="px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition">
                                        <?= $action === 'create' ? 'Create Post' : 'Save Changes' ?>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>
</html>
