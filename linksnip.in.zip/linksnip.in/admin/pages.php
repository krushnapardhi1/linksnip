﻿<?php
/**
 * Admin Pages Management - CMS
 */
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

// Must be admin
if (!is_logged_in() || current_user()['role'] !== 'admin') {
    redirect(base_url('dashboard.php'));
}

$action = $_GET['action'] ?? 'list';

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (isset($_POST['create_page']) || isset($_POST['update_page'])) {
            $title = sanitize($_POST['title']);
            $slug = sanitize($_POST['slug']);
            if (empty($slug)) $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title)));
            
            $content = $_POST['content']; // Allow HTML
            $metaDescription = sanitize($_POST['meta_description'] ?? '');
            $showInNav = isset($_POST['show_in_nav']) ? 1 : 0;
            $sortOrder = (int)($_POST['sort_order'] ?? 0);
            
            if (isset($_POST['create_page'])) {
                // Check slug uniqueness
                $exists = db()->fetchOne("SELECT id FROM pages WHERE slug = ?", [$slug]);
                if ($exists) throw new Exception("Slug already exists");
                
                db()->insert(
                    "INSERT INTO pages (title, slug, content, meta_description, show_in_nav, sort_order) 
                     VALUES (?, ?, ?, ?, ?, ?)",
                    [$title, $slug, $content, $metaDescription, $showInNav, $sortOrder]
                );
                set_flash('success', 'Page created successfully');
                $action = 'list';
            } else {
                $id = $_POST['id'];
                db()->execute(
                    "UPDATE pages SET title = ?, slug = ?, content = ?, meta_description = ?, show_in_nav = ?, sort_order = ? WHERE id = ?",
                    [$title, $slug, $content, $metaDescription, $showInNav, $sortOrder, $id]
                );
                set_flash('success', 'Page updated successfully');
                $action = 'list';
            }
        }
        
        elseif (isset($_POST['delete_page'])) {
            $id = $_POST['id'];
            db()->execute("DELETE FROM pages WHERE id = ?", [$id]);
            set_flash('success', 'Page deleted successfully');
        }
    } catch (Exception $e) {
        set_flash('error', $e->getMessage());
    }
}

// Fetch Pages for List View
$pages = db()->fetchAll("SELECT * FROM pages ORDER BY sort_order ASC, created_at DESC") ?? [];

// Fetch Single Page for Edit
$editPage = null;
if ($action === 'edit' && isset($_GET['id'])) {
    $editPage = db()->fetchOne("SELECT * FROM pages WHERE id = ?", [$_GET['id']]);
}

$flash = get_flash();
$pageTitle = 'Page Management';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?> - SnapLink Pro Admin</title>
    <?php 
    if (function_exists('meta_canonical')) {
        meta_canonical('php-version/admin/pages.php');
    }
    ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <!-- TinyMCE Editor -->
    <script src="https://cdn.tiny.cloud/1/gh529n4f5wrof732d5k7en1ekb2vtb89c8n77zb2mzpqp5d8/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
    <script>
      tinymce.init({
        selector: '#contentEditor',
        height: 500,
        plugins: [
          // Core editing features
          'anchor', 'autolink', 'charmap', 'codesample', 'emoticons', 'link', 'lists', 'media', 'searchreplace', 'table', 'visualblocks', 'wordcount',
          // Premium features (trial until Feb 7, 2026)
          'checklist', 'mediaembed', 'casechange', 'formatpainter', 'pageembed', 'a11ychecker', 'tinymcespellchecker', 'permanentpen', 'powerpaste', 'advtable', 'advcode', 'advtemplate', 'ai', 'uploadcare', 'mentions', 'tinycomments', 'tableofcontents', 'footnotes', 'mergetags', 'autocorrect', 'typography', 'inlinecss', 'markdown', 'importword', 'exportword', 'exportpdf'
        ],
        toolbar: 'undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link media table mergetags | addcomment showcomments | spellcheckdialog a11ycheck typography uploadcare | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat',
        tinycomments_mode: 'embedded',
        tinycomments_author: 'Author name',
        mergetags_list: [
          { value: 'First.Name', title: 'First Name' },
          { value: 'Email', title: 'Email' },
        ],
        ai_request: (request, respondWith) => respondWith.string(() => Promise.reject('See docs to implement AI Assistant')),
        uploadcare_public_key: '890179c1cd80170a31b0',
      });
    </script>
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gray-50">
    <div class="flex min-h-screen">
        <?php require_once ROOT_PATH . '/components/sidebar.php'; ?>

        <main class="flex-1 p-8">
            <div class="max-w-7xl mx-auto">
                <div class="flex justify-between items-center mb-8">
                    <h1 class="text-3xl font-bold text-gray-900">
                        <i class="fas fa-file-alt text-purple-600 mr-2"></i>Page Management
                    </h1>
                    <?php if ($action === 'list'): ?>
                        <a href="?action=create" class="px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition">
                            <i class="fas fa-plus mr-2"></i> New Page
                        </a>
                    <?php else: ?>
                        <a href="pages.php" class="text-gray-600 hover:text-gray-900">
                            <i class="fas fa-arrow-left mr-1"></i> Back to List
                        </a>
                    <?php endif; ?>
                </div>

                <?php if ($flash): ?>
                    <div class="mb-6 p-4 rounded-lg <?= $flash['type'] === 'success' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200' ?>">
                        <?= htmlspecialchars($flash['message']) ?>
                    </div>
                <?php endif; ?>

                <?php if ($action === 'list'): ?>
                    <div class="bg-white rounded-xl shadow-sm overflow-hidden border border-gray-200">
                        <?php if (empty($pages)): ?>
                            <div class="text-center py-12 text-gray-500">
                                <i class="fas fa-file-alt text-5xl mb-4"></i>
                                <p class="text-lg font-medium mb-2">No custom pages yet</p>
                                <p class="text-sm">Create pages for About, Privacy Policy, Terms, etc.</p>
                            </div>
                        <?php else: ?>
                            <table class="w-full">
                                <thead class="bg-gray-50 border-b border-gray-200">
                                    <tr>
                                        <th class="text-left py-3 px-4 font-semibold text-gray-900">Title</th>
                                        <th class="text-left py-3 px-4 font-semibold text-gray-900">Slug</th>
                                        <th class="text-center py-3 px-4 font-semibold text-gray-900">In Nav</th>
                                        <th class="text-center py-3 px-4 font-semibold text-gray-900">Order</th>
                                        <th class="text-right py-3 px-4 font-semibold text-gray-900">Actions</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-200">
                                    <?php foreach ($pages as $page): ?>
                                        <tr class="hover:bg-gray-50">
                                            <td class="py-3 px-4 font-medium text-gray-900"><?= htmlspecialchars($page['title']) ?></td>
                                            <td class="py-3 px-4 text-gray-500 text-sm">/<?= htmlspecialchars($page['slug']) ?></td>
                                            <td class="py-3 px-4 text-center">
                                                <?php if ($page['show_in_nav']): ?>
                                                    <i class="fas fa-check text-green-500"></i>
                                                <?php else: ?>
                                                    <i class="fas fa-times text-gray-300"></i>
                                                <?php endif; ?>
                                            </td>
                                            <td class="py-3 px-4 text-center text-sm text-gray-600"><?= $page['sort_order'] ?></td>
                                            <td class="py-3 px-4 text-right">
                                                <div class="flex items-center justify-end gap-3">
                                                    <a href="?action=edit&id=<?= $page['id'] ?>" class="text-blue-600 hover:text-blue-700" title="Edit">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <a href="<?= base_url('page.php?slug=' . $page['slug']) ?>" target="_blank" class="text-purple-600 hover:text-purple-700" title="View">
                                                        <i class="fas fa-external-link-alt"></i>
                                                    </a>
                                                    <form method="POST" class="inline" onsubmit="return confirm('Delete this page?')">
                                                        <input type="hidden" name="delete_page" value="1">
                                                        <input type="hidden" name="id" value="<?= $page['id'] ?>">
                                                        <button type="submit" class="text-red-600 hover:text-red-700" title="Delete">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>

                <?php elseif ($action === 'create' || $action === 'edit'): ?>
                    <div class="bg-white rounded-xl shadow-sm p-8 border border-gray-200">
                        <form method="POST">
                            <?php if ($action === 'create'): ?>
                                <input type="hidden" name="create_page" value="1">
                            <?php else: ?>
                                <input type="hidden" name="update_page" value="1">
                                <input type="hidden" name="id" value="<?= $editPage['id'] ?>">
                            <?php endif; ?>

                            <div class="space-y-6">
                                <div class="grid grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">Page Title *</label>
                                        <input type="text" name="title" value="<?= htmlspecialchars($editPage['title'] ?? '') ?>" 
                                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent" required>
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">Slug (URL)</label>
                                        <div class="flex items-center">
                                            <span class="text-gray-400 mr-2">/</span>
                                            <input type="text" name="slug" value="<?= htmlspecialchars($editPage['slug'] ?? '') ?>" 
                                                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent" 
                                                   placeholder="about-us">
                                        </div>
                                    </div>
                                </div>

                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Meta Description (SEO)</label>
                                    <textarea name="meta_description" rows="2" 
                                              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"><?= htmlspecialchars($editPage['meta_description'] ?? '') ?></textarea>
                                </div>

                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Content *</label>
                                    <textarea id="contentEditor" name="content"><?= htmlspecialchars($editPage['content'] ?? '') ?></textarea>
                                </div>

                                <div class="grid grid-cols-3 gap-4">
                                    <div class="flex items-center gap-2">
                                        <input type="checkbox" name="show_in_nav" id="show_in_nav" 
                                               class="w-4 h-4 rounded text-purple-600 focus:ring-purple-500" 
                                               <?= ($editPage['show_in_nav'] ?? 0) ? 'checked' : '' ?>>
                                        <label for="show_in_nav" class="text-sm text-gray-700">Show in Navigation</label>
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">Sort Order</label>
                                        <input type="number" name="sort_order" value="<?= $editPage['sort_order'] ?? 0 ?>" 
                                               class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent" min="0">
                                    </div>
                                </div>

                                <div class="flex justify-end gap-3 pt-4 border-t border-gray-200">
                                    <a href="pages.php" class="px-6 py-2 text-gray-600 hover:bg-gray-100 rounded-lg transition">Cancel</a>
                                    <button type="submit" class="px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition">
                                        <?= $action === 'create' ? 'Create Page' : 'Save Changes' ?>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>
</html>
