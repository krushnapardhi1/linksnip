﻿<?php
/**
 * Admin Dashboard
 */
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

require_admin();

$user = current_user();

// Get stats
$userCount = db()->fetchOne('SELECT COUNT(*) as count FROM users')['count'];
$urlCount = db()->fetchOne('SELECT COUNT(*) as count FROM urls')['count'];
$clickCount = db()->fetchOne('SELECT COALESCE(SUM(clicks), 0) as count FROM urls')['count'];
$paidUsers = db()->fetchOne("SELECT COUNT(*) as count FROM users WHERE plan != 'free'")['count'];

// User Growth (Last 30 days)
$dailyUsers = db()->fetchAll(
    "SELECT DATE(created_at) as date, COUNT(*) as count 
     FROM users 
     WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) 
     GROUP BY DATE(created_at) ORDER BY date"
);

// Recent Users
$recentUsers = db()->fetchAll('SELECT name, email, plan, created_at FROM users ORDER BY created_at DESC LIMIT 5');

// Top Links
$topLinks = db()->fetchAll(
    'SELECT u.short_code, u.long_url, u.clicks, us.name as user_name 
     FROM urls u 
     LEFT JOIN users us ON u.user_id = us.id 
     ORDER BY u.clicks DESC LIMIT 5'
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - SnapLink Pro</title>
    <?php 
    if (function_exists('meta_canonical')) {
        meta_canonical('php-version/admin/index.php');
    }
    ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Inter', 'sans-serif'] },
                    colors: { brand: { purple: '#7F00FF', pink: '#E100FF' } }
                }
            }
        }
    </script>
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-100 min-h-screen">
    <div class="flex">
        <!-- Sidebar -->
        <?php include ROOT_PATH . '/admin/partials/sidebar.php'; ?>

        <!-- Main Content -->
        <main class="flex-1 p-4 lg:p-8">
            <div class="mb-8">
                <h1 class="text-2xl font-bold text-gray-900">Dashboard</h1>
                <p class="text-gray-500">Welcome back, <?= htmlspecialchars($user['name']) ?>!</p>
            </div>

            <!-- Stats Cards -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                    <div class="flex items-center justify-between mb-4">
                        <div class="w-12 h-12 rounded-xl bg-purple-100 text-purple-600 flex items-center justify-center text-xl">
                            <i class="fas fa-users"></i>
                        </div>
                        <span class="text-sm text-green-600 font-medium">Total</span>
                    </div>
                    <p class="text-3xl font-bold text-gray-900"><?= number_format($userCount) ?></p>
                    <p class="text-gray-500 text-sm">Users</p>
                </div>

                <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                    <div class="flex items-center justify-between mb-4">
                        <div class="w-12 h-12 rounded-xl bg-pink-100 text-pink-600 flex items-center justify-center text-xl">
                            <i class="fas fa-link"></i>
                        </div>
                        <span class="text-sm text-green-600 font-medium">Total</span>
                    </div>
                    <p class="text-3xl font-bold text-gray-900"><?= number_format($urlCount) ?></p>
                    <p class="text-gray-500 text-sm">Links</p>
                </div>

                <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                    <div class="flex items-center justify-between mb-4">
                        <div class="w-12 h-12 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center text-xl">
                            <i class="fas fa-mouse-pointer"></i>
                        </div>
                        <span class="text-sm text-green-600 font-medium">Total</span>
                    </div>
                    <p class="text-3xl font-bold text-gray-900"><?= number_format($clickCount) ?></p>
                    <p class="text-gray-500 text-sm">Clicks</p>
                </div>

                <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                    <div class="flex items-center justify-between mb-4">
                        <div class="w-12 h-12 rounded-xl bg-green-100 text-green-600 flex items-center justify-center text-xl">
                            <i class="fas fa-crown"></i>
                        </div>
                        <span class="text-sm text-green-600 font-medium">Paid</span>
                    </div>
                    <p class="text-3xl font-bold text-gray-900"><?= number_format($paidUsers) ?></p>
                    <p class="text-gray-500 text-sm">Pro/Enterprise Users</p>
                </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
                <!-- User Growth Chart -->
                <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                    <h2 class="text-lg font-bold text-gray-900 mb-4">User Growth (Last 30 Days)</h2>
                    <canvas id="userGrowthChart" height="200"></canvas>
                </div>

                <!-- Recent Users -->
                <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                    <div class="flex items-center justify-between mb-4">
                        <h2 class="text-lg font-bold text-gray-900">Recent Users</h2>
                        <a href="users.php" class="text-purple-600 text-sm hover:underline">View All</a>
                    </div>
                    <div class="space-y-4">
                        <?php foreach ($recentUsers as $u): ?>
                            <div class="flex items-center justify-between">
                                <div class="flex items-center gap-3">
                                    <div class="w-10 h-10 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center font-bold">
                                        <?= strtoupper(substr($u['name'], 0, 1)) ?>
                                    </div>
                                    <div>
                                        <p class="font-medium text-gray-900"><?= htmlspecialchars($u['name']) ?></p>
                                        <p class="text-sm text-gray-500"><?= htmlspecialchars($u['email']) ?></p>
                                    </div>
                                </div>
                                <span class="px-2 py-1 rounded-full text-xs font-medium 
                                    <?= $u['plan'] === 'enterprise' ? 'bg-purple-100 text-purple-700' : 
                                       ($u['plan'] === 'pro' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700') ?>">
                                    <?= ucfirst($u['plan']) ?>
                                </span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Top Links -->
            <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                <div class="flex items-center justify-between mb-4">
                    <h2 class="text-lg font-bold text-gray-900">Top Performing Links</h2>
                    <a href="urls.php" class="text-purple-600 text-sm hover:underline">View All</a>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="bg-gray-50 text-left text-sm text-gray-500 uppercase tracking-wider">
                            <tr>
                                <th class="px-4 py-3 rounded-l-lg">Short Code</th>
                                <th class="px-4 py-3">Original URL</th>
                                <th class="px-4 py-3">User</th>
                                <th class="px-4 py-3 text-right rounded-r-lg">Clicks</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            <?php foreach ($topLinks as $link): ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-4 py-3">
                                        <span class="text-purple-600 font-medium"><?= $link['short_code'] ?></span>
                                    </td>
                                    <td class="px-4 py-3">
                                        <span class="text-gray-600 truncate max-w-[200px] block"><?= htmlspecialchars($link['long_url']) ?></span>
                                    </td>
                                    <td class="px-4 py-3 text-gray-600"><?= htmlspecialchars($link['user_name'] ?? 'Anonymous') ?></td>
                                    <td class="px-4 py-3 text-right font-bold text-gray-900"><?= number_format($link['clicks']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <script>
        // User Growth Chart
        const ctx = document.getElementById('userGrowthChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?= json_encode(array_column($dailyUsers, 'date')) ?>,
                datasets: [{
                    label: 'New Users',
                    data: <?= json_encode(array_column($dailyUsers, 'count')) ?>,
                    borderColor: '#7F00FF',
                    backgroundColor: 'rgba(127, 0, 255, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: false } },
                scales: { y: { beginAtZero: true } }
            }
        });
    </script>
</body>
</html>
