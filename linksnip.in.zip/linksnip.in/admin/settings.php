﻿<?php
/**
 * Admin - Settings Page
 */
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

require_admin();

$user = current_user();
$flash = get_flash();

// Get current settings
$settings = [];
$rows = db()->fetchAll('SELECT * FROM site_settings');
foreach ($rows as $row) {
    $settings[$row['key_name']] = $row['value'];
}

// Handle save
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    
    $newSettings = $_POST;
    unset($newSettings['action']);
    
    try {
        foreach ($newSettings as $key => $value) {
            db()->query(
                'INSERT INTO site_settings (key_name, value) VALUES (?, ?) 
                 ON DUPLICATE KEY UPDATE value = ?',
                [$key, $value, $value]
            );
        }
        json_response(['success' => true]);
    } catch (Exception $e) {
        json_response(['error' => 'Failed to save settings'], 500);
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - Admin - SnapLink Pro</title>
    <?php 
    if (function_exists('meta_canonical')) {
        meta_canonical('php-version/admin/settings.php');
    }
    ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Inter', 'sans-serif'] },
                    colors: { brand: { purple: '#7F00FF', pink: '#E100FF' } }
                }
            }
        }
    </script>
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-100 min-h-screen">
    <div class="flex">
        <?php include ROOT_PATH . '/admin/partials/sidebar.php'; ?>

        <main class="flex-1 p-4 lg:p-8">
            <div class="mb-8">
                <h1 class="text-2xl font-bold text-gray-900">Site Settings</h1>
                <p class="text-gray-500">Configure your URL shortener</p>
            </div>

            <form id="settingsForm" class="space-y-6">
                <!-- General Settings -->
                <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                    <h2 class="text-lg font-bold text-gray-900 mb-4">General Settings</h2>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Site Name</label>
                            <input type="text" name="site_name" value="<?= htmlspecialchars($settings['site_name'] ?? 'SnapLink Pro') ?>"
                                class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Contact Email</label>
                            <input type="email" name="contact_email" value="<?= htmlspecialchars($settings['contact_email'] ?? '') ?>"
                                class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500">
                        </div>
                    </div>
                </div>

                <!-- SMTP Email Configuration -->
                <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                    <div class="flex items-center justify-between mb-4">
                        <div>
                            <h2 class="text-lg font-bold text-gray-900">SMTP Email Configuration</h2>
                            <p class="text-sm text-gray-500">Configure custom email server for sending notifications</p>
                        </div>
                        <button type="button" onclick="testSMTP()" 
                                class="px-4 py-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 font-semibold text-sm">
                            <i class="fas fa-envelope mr-2"></i>Test SMTP
                        </button>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">SMTP Host</label>
                            <input type="text" name="smtp_host" 
                                   value="<?= htmlspecialchars($settings['smtp_host'] ?? 'smtp.gmail.com') ?>"
                                   placeholder="smtp.gmail.com"
                                   class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">SMTP Port</label>
                            <input type="number" name="smtp_port" 
                                   value="<?= htmlspecialchars($settings['smtp_port'] ?? '587') ?>"
                                   placeholder="587"
                                   class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">SMTP Username</label>
                            <input type="text" name="smtp_username" 
                                   value="<?= htmlspecialchars($settings['smtp_username'] ?? '') ?>"
                                   placeholder="your@email.com"
                                   class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">SMTP Password</label>
                            <input type="password" name="smtp_password" 
                                   value="<?= htmlspecialchars($settings['smtp_password'] ?? '') ?>"
                                   placeholder="••••••••"
                                   class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Encryption</label>
                            <select name="smtp_encryption"
                                    class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500">
                                <option value="tls" <?= ($settings['smtp_encryption'] ?? 'tls') === 'tls' ? 'selected' : '' ?>>TLS</option>
                                <option value="ssl" <?= ($settings['smtp_encryption'] ?? '') === 'ssl' ? 'selected' : '' ?>>SSL</option>
                                <option value="" <?= empty($settings['smtp_encryption']) ? 'selected' : '' ?>>None</option>
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">From Email</label>
                            <input type="email" name="smtp_from_email" 
                                   value="<?= htmlspecialchars($settings['smtp_from_email'] ?? '') ?>"
                                   placeholder="noreply@snaplink.pro"
                                   class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500">
                        </div>
                        
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-2">From Name</label>
                            <input type="text" name="smtp_from_name" 
                                   value="<?= htmlspecialchars($settings['smtp_from_name'] ?? 'SnapLink Pro') ?>"
                                   placeholder="SnapLink Pro"
                                   class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500">
                        </div>
                    </div>
                    
                    <div class="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
                        <p class="text-sm text-blue-800">
                            <i class="fas fa-info-circle mr-2"></i>
                            <strong>Gmail Users:</strong> Use host: <code class="bg-blue-100 px-2 py-1 rounded">smtp.gmail.com</code>, 
                            port: <code class="bg-blue-100 px-2 py-1 rounded">587</code>, and create an 
                            <a href="https://myaccount.google.com/apppasswords" target="_blank" class="underline">App Password</a>
                        </p>
                    </div>
                </div>

                <!-- Stripe Payment Configuration -->
                <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                    <div class="flex items-center justify-between mb-4">
                        <div>
                            <h2 class="text-lg font-bold text-gray-900">Stripe Payment Gateway</h2>
                            <p class="text-sm text-gray-500">Configure Stripe keys to accept payments</p>
                        </div>
                        <div class="flex items-center gap-2">
                             <span class="px-2 py-1 bg-blue-100 text-blue-700 rounded text-xs">v10+ Support</span>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Stripe Publishable Key</label>
                            <input type="text" name="stripe_publishable_key" 
                                   value="<?= htmlspecialchars($settings['stripe_publishable_key'] ?? '') ?>"
                                   placeholder="pk_test_..."
                                   class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 font-mono text-sm">
                        </div>
                        
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Stripe Secret Key</label>
                            <input type="password" name="stripe_secret_key" 
                                   value="<?= htmlspecialchars($settings['stripe_secret_key'] ?? '') ?>"
                                   placeholder="sk_test_..."
                                   class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 font-mono text-sm">
                        </div>
                        
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Webhook Signing Secret</label>
                            <input type="password" name="stripe_webhook_secret" 
                                   value="<?= htmlspecialchars($settings['stripe_webhook_secret'] ?? '') ?>"
                                   placeholder="whsec_..."
                                   class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 font-mono text-sm">
                            <p class="text-xs text-gray-500 mt-1">
                                Webhook URL: <code class="bg-gray-100 px-1 rounded"><?= APP_URL ?>/api/stripe-webhook.php</code>
                            </p>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Currency Code</label>
                            <input type="text" name="stripe_currency" 
                                   value="<?= htmlspecialchars($settings['stripe_currency'] ?? 'USD') ?>"
                                   placeholder="USD"
                                   class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 uppercase">
                        </div>
                    </div>
                </div>

                <!-- Razorpay Settings -->
                <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                    <div class="flex items-center justify-between mb-4">
                        <div>
                            <h2 class="text-lg font-bold text-gray-900">Razorpay Settings</h2>
                            <p class="text-sm text-gray-500">Accept payments via Razorpay (India)</p>
                        </div>
                        <div class="flex items-center gap-2">
                            <span class="px-2 py-1 bg-blue-100 text-blue-700 rounded text-xs">INR Preferred</span>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Razorpay Key ID</label>
                            <input type="text" name="razorpay_key_id" 
                                   value="<?= htmlspecialchars($settings['razorpay_key_id'] ?? '') ?>"
                                   placeholder="rzp_test_..."
                                   class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 font-mono text-sm">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Razorpay Key Secret</label>
                            <input type="password" name="razorpay_key_secret" 
                                   value="<?= htmlspecialchars($settings['razorpay_key_secret'] ?? '') ?>"
                                   placeholder="Your secret key"
                                   class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 font-mono text-sm">
                        </div>
                        
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Webhook Secret</label>
                            <input type="password" name="razorpay_webhook_secret" 
                                   value="<?= htmlspecialchars($settings['razorpay_webhook_secret'] ?? '') ?>"
                                   placeholder="whsec_..."
                                   class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 font-mono text-sm">
                            <p class="text-xs text-gray-500 mt-1">
                                Webhook URL: <code class="bg-gray-100 px-1 rounded"><?= APP_URL ?>/api/razorpay-webhook.php</code>
                            </p>
                        </div>

                        <div>
                            <label class="flex items-center gap-2">
                                <input type="checkbox" name="razorpay_enabled" value="1" 
                                       <?= ($settings['razorpay_enabled'] ?? '') == '1' ? 'checked' : '' ?>
                                       class="w-4 h-4 text-purple-600 rounded border-gray-300 focus:ring-purple-500">
                                <span class="text-sm text-gray-700">Enable Razorpay Payments</span>
                            </label>
                        </div>
                    </div>
                </div>

                <!-- Security Settings (reCAPTCHA) -->
                <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                    <div class="flex items-center justify-between mb-4">
                        <div>
                            <h2 class="text-lg font-bold text-gray-900">Security Settings</h2>
                            <p class="text-sm text-gray-500">Protect your site from bots and spam</p>
                        </div>
                        <div class="flex items-center gap-2">
                             <span class="px-2 py-1 bg-green-100 text-green-700 rounded text-xs">reCAPTCHA v3</span>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-2">reCAPTCHA Site Key</label>
                            <input type="text" name="recaptcha_site_key" 
                                   value="<?= htmlspecialchars($settings['recaptcha_site_key'] ?? '') ?>"
                                   placeholder="6Lc..."
                                   class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 font-mono text-sm">
                        </div>
                        
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-2">reCAPTCHA Secret Key</label>
                            <input type="password" name="recaptcha_secret_key" 
                                   value="<?= htmlspecialchars($settings['recaptcha_secret_key'] ?? '') ?>"
                                   placeholder="6Lc..."
                                   class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 font-mono text-sm">
                        </div>
                    </div>
                </div>

                <!-- SEO Settings -->
                <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                    <h2 class="text-lg font-bold text-gray-900 mb-4">SEO Settings</h2>
                    <div class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Meta Title</label>
                            <input type="text" name="meta_title" value="<?= htmlspecialchars($settings['meta_title'] ?? '') ?>"
                                class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Meta Description</label>
                            <textarea name="meta_description" rows="3"
                                class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500"><?= htmlspecialchars($settings['meta_description'] ?? '') ?></textarea>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Meta Keywords</label>
                            <input type="text" name="meta_keywords" value="<?= htmlspecialchars($settings['meta_keywords'] ?? '') ?>"
                                class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500"
                                placeholder="url shortener, link shortener, short links">
                        </div>
                    </div>
                </div>

                <!-- Ad Settings -->
                <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                    <h2 class="text-lg font-bold text-gray-900 mb-4">Ad Settings</h2>
                    <div class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Header Ad Code</label>
                            <textarea name="header_ad_code" rows="4"
                                class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 font-mono text-sm"
                                placeholder="Paste your header ad code here..."><?= htmlspecialchars($settings['header_ad_code'] ?? '') ?></textarea>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Interstitial Ad Code (for redirect pages)</label>
                            <textarea name="interstitial_ad_code" rows="4"
                                class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 font-mono text-sm"
                                placeholder="Paste your interstitial ad code here..."><?= htmlspecialchars($settings['interstitial_ad_code'] ?? '') ?></textarea>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Footer Ad Code</label>
                            <textarea name="footer_ad_code" rows="4"
                                class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 font-mono text-sm"
                                placeholder="Paste your footer ad code here..."><?= htmlspecialchars($settings['footer_ad_code'] ?? '') ?></textarea>
                        </div>
                    </div>
                </div>

                <!-- Legal Pages -->
                <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                    <h2 class="text-lg font-bold text-gray-900 mb-4">Legal Pages</h2>
                    <div class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Privacy Policy</label>
                            <textarea name="privacy_policy" rows="6"
                                class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500"><?= htmlspecialchars($settings['privacy_policy'] ?? '') ?></textarea>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Terms of Service</label>
                            <textarea name="terms_of_service" rows="6"
                                class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500"><?= htmlspecialchars($settings['terms_of_service'] ?? '') ?></textarea>
                        </div>
                    </div>
                </div>

                <!-- Save Button -->
                <div class="flex justify-end">
                    <button type="submit" id="saveBtn"
                        class="px-6 py-3 bg-purple-600 text-white font-semibold rounded-xl hover:bg-purple-700 transition flex items-center gap-2">
                        <i class="fas fa-save"></i>
                        <span>Save Settings</span>
                    </button>
                </div>
            </form>
        </main>
    </div>

    <script>
        document.getElementById('settingsForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const btn = document.getElementById('saveBtn');
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
            btn.disabled = true;

            try {
                const formData = new FormData(this);
                const res = await fetch('settings.php', { method: 'POST', body: formData });
                const data = await res.json();

                if (data.success) {
                    alert('Settings saved successfully!');
                } else {
                    alert(data.error || 'Failed to save');
                }
            } catch (err) {
                alert('An error occurred');
            } finally {
                btn.innerHTML = '<i class="fas fa-save"></i><span>Save Settings</span>';
                btn.disabled = false;
            }
        });
        
        async function testSMTP() {
            const btn = event.target;
            const originalHTML = btn.innerHTML;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Sending...';
            btn.disabled = true;
            
            try {
                const response = await fetch('../api/test-smtp.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' }
                });
                
                const data = await response.json();
                
                if (data.success) {
                    alert('✅ Test email sent successfully! Check your inbox.');
                } else {
                    alert('❌ SMTP test failed: ' + (data.error || 'Unknown error'));
                }
            } catch (err) {
                alert('❌ An error occurred while testing SMTP');
            } finally {
                btn.innerHTML = originalHTML;
                btn.disabled = false;
            }
        }
    </script>
</body>
</html>
