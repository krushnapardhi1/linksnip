﻿<?php
/**
 * Admin API Analytics Page
 */
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

// Must be admin
if (!is_logged_in() || current_user()['role'] !== 'admin') {
    redirect(base_url('dashboard.php'));
}

// Get overall stats
$totalRequests = db()->fetchOne('SELECT COUNT(*) as count FROM api_requests')['count'] ?? 0;
$todayRequests = db()->fetchOne('SELECT COUNT(*) as count FROM api_requests WHERE DATE(created_at) = CURDATE()')['count'] ?? 0;
$totalUsers = db()->fetchOne('SELECT COUNT(DISTINCT user_id) as count FROM api_requests')['count'] ?? 0;
$avgResponseTime = db()->fetchOne('SELECT AVG(response_time_ms) as avg_time FROM api_requests')['avg_time'] ?? 0;

// Get top users
$topUsers = db()->fetchAll('
    SELECT 
        u.id,
        u.name,
        u.email,
        u.plan,
        COUNT(ar.id) as request_count,
        MAX(ar.created_at) as last_request
    FROM users u
    INNER JOIN api_requests ar ON u.id = ar.user_id
    GROUP BY u.id
    ORDER BY request_count DESC
    LIMIT 10
') ?? [];

// Get last 7 days data
$dailyStats = db()->fetchAll('
    SELECT 
        DATE(created_at) as date,
        COUNT(*) as count
    FROM api_requests
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    GROUP BY DATE(created_at)
    ORDER BY date ASC
') ?? [];

// Prepare chart data
$chartDates = [];
$chartCounts = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $chartDates[] = date('M d', strtotime($date));
    $found = false;
    foreach ($dailyStats as $stat) {
        if ($stat['date'] === $date) {
            $chartCounts[] = (int)$stat['count'];
            $found = true;
            break;
        }
    }
    if (!$found) {
        $chartCounts[] = 0;
    }
}

// Get endpoint stats
$endpointStats = db()->fetchAll('
    SELECT 
        endpoint,
        COUNT(*) as count,
        AVG(response_time_ms) as avg_response_time
    FROM api_requests 
    GROUP BY endpoint
    ORDER BY count DESC
    LIMIT 10
') ?? [];

// Get recent requests
$recentRequests = db()->fetchAll('
    SELECT 
        ar.*,
        u.name as user_name,
        u.email as user_email
    FROM api_requests ar
    LEFT JOIN users u ON ar.user_id = u.id
    ORDER BY ar.created_at DESC
    LIMIT 30
') ?? [];

$pageTitle = 'API Analytics (Admin)';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?> - SnapLink Pro Admin</title>
    <?php 
    if (function_exists('meta_canonical')) {
        meta_canonical('php-version/admin/api-analytics.php');
    }
    ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gray-50">
    <div class="flex min-h-screen">
        <?php require_once ROOT_PATH . '/components/sidebar.php'; ?>

        <div class="flex-1">
            <div class="max-w-7xl mx-auto px-4 py-8">
                <!-- Header -->
                <div class="mb-8">
                    <h1 class="text-3xl font-bold text-gray-900 mb-2">
                        <i class="fas fa-chart-line text-purple-600 mr-2"></i>API Analytics
                    </h1>
                    <p class="text-gray-600">Monitor all API usage across the platform</p>
                </div>

                <!-- Stats Cards -->
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                    <div class="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl shadow-lg p-6 text-white">
                        <div class="flex items-center justify-between mb-2">
                            <div class="text-sm font-medium opacity-90">Total Requests</div>
                            <i class="fas fa-server text-2xl opacity-75"></i>
                        </div>
                        <div class="text-3xl font-bold"><?= number_format($totalRequests) ?></div>
                        <div class="text-xs opacity-75 mt-1">All time</div>
                    </div>

                    <div class="bg-gradient-to-br from-green-500 to-green-600 rounded-xl shadow-lg p-6 text-white">
                        <div class="flex items-center justify-between mb-2">
                            <div class="text-sm font-medium opacity-90">Today</div>
                            <i class="fas fa-calendar-day text-2xl opacity-75"></i>
                        </div>
                        <div class="text-3xl font-bold"><?= number_format($todayRequests) ?></div>
                        <div class="text-xs opacity-75 mt-1"><?= date('M d, Y') ?></div>
                    </div>

                    <div class="bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl shadow-lg p-6 text-white">
                        <div class="flex items-center justify-between mb-2">
                            <div class="text-sm font-medium opacity-90">Active Users</div>
                            <i class="fas fa-users text-2xl opacity-75"></i>
                        </div>
                        <div class="text-3xl font-bold"><?= number_format($totalUsers) ?></div>
                        <div class="text-xs opacity-75 mt-1">Using API</div>
                    </div>

                    <div class="bg-gradient-to-br from-pink-500 to-pink-600 rounded-xl shadow-lg p-6 text-white">
                        <div class="flex items-center justify-between mb-2">
                            <div class="text-sm font-medium opacity-90">Avg Response</div>
                            <i class="fas fa-tachometer-alt text-2xl opacity-75"></i>
                        </div>
                        <div class="text-3xl font-bold"><?= number_format($avgResponseTime) ?></div>
                        <div class="text-xs opacity-75 mt-1">milliseconds</div>
                    </div>
                </div>

                <!-- Chart -->
                <div class="bg-white rounded-xl shadow-sm p-6 mb-6 border border-gray-200">
                    <h2 class="text-xl font-bold text-gray-900 mb-4">
                        <i class="fas fa-chart-area text-purple-600 mr-2"></i>API Usage Trend (Last 7 Days)
                    </h2>
                    <canvas id="requestsChart" height="80"></canvas>
                </div>

                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                    <!-- Top API Users -->
                    <div class="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
                        <h2 class="text-xl font-bold text-gray-900 mb-4">
                            <i class="fas fa-trophy text-purple-600 mr-2"></i>Top API Users
                        </h2>
                        <?php if (empty($topUsers)): ?>
                            <div class="text-center py-8 text-gray-500">
                                <i class="fas fa-inbox text-4xl mb-3"></i>
                                <p>No API usage yet</p>
                            </div>
                        <?php else: ?>
                            <div class="space-y-3">
                                <?php foreach ($topUsers as $idx => $user): ?>
                                    <div class="flex items-center gap-4 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition">
                                        <div class="w-8 h-8 bg-purple-600 text-white rounded-full flex items-center justify-center font-bold">
                                            <?= $idx + 1 ?>
                                        </div>
                                        <div class="flex-1">
                                            <div class="font-medium text-gray-900"><?= htmlspecialchars($user['name']) ?></div>
                                            <div class="text-sm text-gray-500"><?= htmlspecialchars($user['email']) ?></div>
                                            <div class="text-xs text-gray-400 mt-1">
                                                Last: <?= date('M d, H:i', strtotime($user['last_request'])) ?>
                                            </div>
                                        </div>
                                        <div class="text-right">
                                            <div class="text-2xl font-bold text-purple-600"><?= number_format($user['request_count']) ?></div>
                                            <span class="px-2 py-1 bg-<?= $user['plan'] === 'free' ? 'gray' : ($user['plan'] === 'pro' ? 'purple' : 'pink') ?>-100 text-<?= $user['plan'] === 'free' ? 'gray' : ($user['plan'] === 'pro' ? 'purple' : 'pink') ?>-800 rounded-full text-xs">
                                                <?= ucfirst($user['plan']) ?>
                                            </span>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Endpoint Stats -->
                    <div class="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
                        <h2 class="text-xl font-bold text-gray-900 mb-4">
                            <i class="fas fa-plug text-purple-600 mr-2"></i>Most Used Endpoints
                        </h2>
                        <?php if (empty($endpointStats)): ?>
                            <div class="text-center py-8 text-gray-500">
                                <i class="fas fa-inbox text-4xl mb-3"></i>
                                <p>No endpoint data</p>
                            </div>
                        <?php else: ?>
                            <div class="space-y-3">
                                <?php foreach ($endpointStats as $stat): ?>
                                    <div class="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                                        <div class="flex-1">
                                            <div class="font-medium text-gray-900 font-mono text-sm">
                                                <?= htmlspecialchars($stat['endpoint']) ?>
                                            </div>
                                            <div class="text-sm text-gray-500">
                                                Avg: <?= number_format($stat['avg_response_time']) ?>ms
                                            </div>
                                        </div>
                                        <div class="text-right">
                                            <div class="text-2xl font-bold text-purple-600"><?= number_format($stat['count']) ?></div>
                                            <div class="text-xs text-gray-500">requests</div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Recent Requests -->
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                    <div class="p-6 border-b border-gray-200">
                        <h2 class="text-xl font-bold text-gray-900">
                            <i class="fas fa-history text-purple-600 mr-2"></i>Recent API Requests
                        </h2>
                    </div>
                    <div class="overflow-x-auto">
                        <?php if (empty($recentRequests)): ?>
                            <div class="text-center py-12 text-gray-500">
                                <i class="fas fa-inbox text-5xl mb-4"></i>
                                <p class="text-lg font-medium">No API activity</p>
                            </div>
                        <?php else: ?>
                            <table class="w-full text-sm">
                                <thead class="bg-gray-50 border-b border-gray-200">
                                    <tr>
                                        <th class="text-left py-3 px-4 font-semibold text-gray-900">User</th>
                                        <th class="text-left py-3 px-4 font-semibold text-gray-900">Endpoint</th>
                                        <th class="text-left py-3 px-4 font-semibold text-gray-900">Method</th>
                                        <th class="text-left py-3 px-4 font-semibold text-gray-900">Status</th>
                                        <th class="text-left py-3 px-4 font-semibold text-gray-900">Time</th>
                                        <th class="text-left py-3 px-4 font-semibold text-gray-900">IP</th>
                                        <th class="text-left py-3 px-4 font-semibold text-gray-900">Date</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-200">
                                    <?php foreach ($recentRequests as $req): ?>
                                        <tr class="hover:bg-gray-50">
                                            <td class="py-3 px-4">
                                                <div class="font-medium text-gray-900"><?= htmlspecialchars($req['user_name'] ?? 'Unknown') ?></div>
                                                <div class="text-xs text-gray-500"><?= htmlspecialchars($req['user_email'] ?? '') ?></div>
                                            </td>
                                            <td class="py-3 px-4 font-mono text-xs"><?= htmlspecialchars($req['endpoint']) ?></td>
                                            <td class="py-3 px-4">
                                                <span class="px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs font-medium">
                                                    <?= htmlspecialchars($req['method']) ?>
                                                </span>
                                            </td>
                                            <td class="py-3 px-4">
                                                <?php
                                                $statusClass = 'bg-gray-100 text-gray-800';
                                                if ($req['response_code'] >= 200 && $req['response_code'] < 300) {
                                                    $statusClass = 'bg-green-100 text-green-800';
                                                } elseif ($req['response_code'] >= 400) {
                                                    $statusClass = 'bg-red-100 text-red-800';
                                                }
                                                ?>
                                                <span class="px-2 py-1 <?= $statusClass ?> rounded text-xs font-medium">
                                                    <?= $req['response_code'] ?>
                                                </span>
                                            </td>
                                            <td class="py-3 px-4 text-gray-600"><?= $req['response_time_ms'] ?>ms</td>
                                            <td class="py-3 px-4 font-mono text-xs text-gray-600"><?= htmlspecialchars($req['ip_address']) ?></td>
                                            <td class="py-3 px-4 text-gray-600"><?= date('M d, H:i', strtotime($req['created_at'])) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Chart
        const ctx = document.getElementById('requestsChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?= json_encode($chartDates) ?>,
                datasets: [{
                    label: 'API Requests',
                    data: <?= json_encode($chartCounts) ?>,
                    borderColor: 'rgb(147, 51, 234)',
                    backgroundColor: 'rgba(147, 51, 234, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>
