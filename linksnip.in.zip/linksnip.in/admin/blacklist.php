﻿<?php
/**
 * Admin - Blacklist Management
 */
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

// Must be admin
if (!is_logged_in() || current_user()['role'] !== 'admin') {
    redirect(base_url('dashboard.php'));
}

$user = current_user();
$flash = get_flash();

// Handle Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    try {
        if ($action === 'add') {
            $type = $_POST['type'] ?? 'domain';
            $value = trim($_POST['value'] ?? '');
            $reason = trim($_POST['reason'] ?? '');
            
            if (empty($value)) {
                throw new Exception("Value is required");
            }
            
            // Normalize value based on type
            if ($type === 'domain') {
                $value = strtolower(parse_url($value, PHP_URL_HOST) ?: $value);
            }
            
            // Check if exists
            $exists = db()->fetchOne("SELECT id FROM blacklist WHERE type = ? AND value = ?", [$type, $value]);
            if ($exists) {
                throw new Exception("This $type is already blacklisted");
            }
            
            db()->insert(
                "INSERT INTO blacklist (type, value, reason, created_by) VALUES (?, ?, ?, ?)",
                [$type, $value, $reason, $user['id']]
            );
            
            set_flash('success', ucfirst($type) . ' added to blacklist');
        } elseif ($action === 'delete') {
            $id = $_POST['id'] ?? 0;
            db()->execute("DELETE FROM blacklist WHERE id = ?", [$id]);
            set_flash('success', 'Entry removed from blacklist');
        }
    } catch (Exception $e) {
        set_flash('error', $e->getMessage());
    }
    
    redirect(base_url('admin/blacklist.php'));
}

// Fetch Blacklist
$search = $_GET['search'] ?? '';
$typeFilter = $_GET['type'] ?? '';

$where = [];
$params = [];

if ($search) {
    $where[] = "(value LIKE ? OR reason LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($typeFilter) {
    $where[] = "type = ?";
    $params[] = $typeFilter;
}

$whereSQL = $where ? 'WHERE ' . implode(' AND ', $where) : '';
$blacklist = db()->fetchAll("SELECT * FROM blacklist $whereSQL ORDER BY created_at DESC", $params);

$pageTitle = 'Blacklist Management';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?> - SnapLink Pro Admin</title>
    <?php 
    if (function_exists('meta_canonical')) {
        meta_canonical('php-version/admin/blacklist.php');
    }
    ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Inter', 'sans-serif'] },
                    colors: { brand: { purple: '#7F00FF', pink: '#E100FF' } }
                }
            }
        }
    </script>
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-50 min-h-screen">
    <div class="flex min-h-screen">
        <?php require_once ROOT_PATH . '/admin/partials/sidebar.php'; ?>

        <main class="flex-1 p-8">
            <div class="max-w-6xl mx-auto">
                <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
                    <div>
                        <h1 class="text-3xl font-bold text-gray-900">
                            <i class="fas fa-ban text-red-600 mr-2"></i>Blacklist
                        </h1>
                        <p class="text-gray-500">Block domains, IPs, or User Agents</p>
                    </div>
                    <button onclick="document.getElementById('addModal').classList.remove('hidden')" 
                            class="px-6 py-3 bg-red-600 text-white rounded-xl hover:bg-red-700 transition flex items-center gap-2">
                        <i class="fas fa-plus"></i>
                        <span>Add Block</span>
                    </button>
                </div>

                <?php if ($flash): ?>
                    <div class="mb-6 p-4 rounded-xl <?= $flash['type'] === 'success' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200' ?>">
                        <?= htmlspecialchars($flash['message']) ?>
                    </div>
                <?php endif; ?>

                <!-- Filters -->
                <div class="bg-white rounded-xl p-4 shadow-sm border border-gray-200 mb-6">
                    <form method="GET" class="flex flex-col md:flex-row gap-4">
                        <div class="flex-1 relative">
                            <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" 
                                   placeholder="Search value or reason..." 
                                   class="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                            <i class="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                        </div>
                        <div class="w-full md:w-48">
                            <select name="type" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                                <option value="">All Types</option>
                                <option value="domain" <?= $typeFilter === 'domain' ? 'selected' : '' ?>>Domain</option>
                                <option value="ip" <?= $typeFilter === 'ip' ? 'selected' : '' ?>>IP Address</option>
                                <option value="user_agent" <?= $typeFilter === 'user_agent' ? 'selected' : '' ?>>User Agent</option>
                            </select>
                        </div>
                        <button type="submit" class="px-6 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 font-medium">
                            Filter
                        </button>
                    </form>
                </div>

                <!-- List -->
                <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                    <?php if (empty($blacklist)): ?>
                        <div class="text-center py-12 text-gray-500">
                            <i class="fas fa-shield-alt text-5xl mb-4 text-gray-300"></i>
                            <p class="text-lg font-medium">No blacklisted entries found</p>
                        </div>
                    <?php else: ?>
                        <div class="overflow-x-auto">
                            <table class="w-full">
                                <thead class="bg-gray-50 border-b border-gray-200">
                                    <tr>
                                        <th class="text-left py-3 px-6 font-semibold text-gray-900">Type</th>
                                        <th class="text-left py-3 px-6 font-semibold text-gray-900">Value</th>
                                        <th class="text-left py-3 px-6 font-semibold text-gray-900">Reason</th>
                                        <th class="text-right py-3 px-6 font-semibold text-gray-900">Date</th>
                                        <th class="text-right py-3 px-6 font-semibold text-gray-900">Action</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-200">
                                    <?php foreach ($blacklist as $item): ?>
                                        <tr class="hover:bg-gray-50">
                                            <td class="py-3 px-6">
                                                <span class="px-2 py-1 rounded-md text-xs font-semibold uppercase
                                                    <?= $item['type'] === 'domain' ? 'bg-purple-100 text-purple-700' : 
                                                       ($item['type'] === 'ip' ? 'bg-blue-100 text-blue-700' : 'bg-orange-100 text-orange-700') ?>">
                                                    <?= $item['type'] ?>
                                                </span>
                                            </td>
                                            <td class="py-3 px-6 font-mono text-sm"><?= htmlspecialchars($item['value']) ?></td>
                                            <td class="py-3 px-6 text-sm text-gray-600"><?= htmlspecialchars($item['reason'] ?: '-') ?></td>
                                            <td class="py-3 px-6 text-right text-sm text-gray-500">
                                                <?= date('M d, Y', strtotime($item['created_at'])) ?>
                                            </td>
                                            <td class="py-3 px-6 text-right">
                                                <form method="POST" onsubmit="return confirm('Remove this entry from blacklist?');">
                                                    <input type="hidden" name="action" value="delete">
                                                    <input type="hidden" name="id" value="<?= $item['id'] ?>">
                                                    <button type="submit" class="text-red-500 hover:text-red-700 transition p-2" title="Delete">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>

    <!-- Add Modal -->
    <div id="addModal" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
        <div class="bg-white rounded-2xl shadow-xl max-w-md w-full p-6 transform scale-100 transition-all">
            <h2 class="text-xl font-bold text-gray-900 mb-4">Add Retrieval Block</h2>
            <form method="POST">
                <input type="hidden" name="action" value="add">
                
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Block Type</label>
                        <select name="type" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                            <option value="domain">Domain Name</option>
                            <option value="ip">IP Address</option>
                            <option value="user_agent">User Agent</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Value to Block</label>
                        <input type="text" name="value" required placeholder="e.g. spam-site.com"
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                        <p class="text-xs text-gray-500 mt-1">For domains, exclude http/https.</p>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Reason (Optional)</label>
                        <input type="text" name="reason" placeholder="e.g. Malware distribution"
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500">
                    </div>
                </div>

                <div class="flex justify-end gap-3 mt-6">
                    <button type="button" onclick="document.getElementById('addModal').classList.add('hidden')" 
                            class="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg transition">
                        Cancel
                    </button>
                    <button type="submit" class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition">
                        Add Block
                    </button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
