<?php
/**
 * Admin Sidebar Partial
 */
$currentPage = basename($_SERVER['PHP_SELF'], '.php');
?>
<aside class="w-64 bg-gray-900 text-white min-h-screen flex flex-col">
    <!-- Logo -->
    <div class="p-6 border-b border-gray-800">
        <a href="../index.php" class="flex items-center gap-2">
            <div class="w-10 h-10 rounded-xl bg-brand-purple flex items-center justify-center">
                <i class="fas fa-link"></i>
            </div>
            <span class="text-xl font-bold">Link<span class="text-yellow-300">Snip</span></span>
        </a>
    </div>

    <!-- Navigation -->
    <nav class="flex-1 p-4 space-y-2">
        <p class="px-4 text-xs text-gray-500 uppercase tracking-wider mb-2">Admin Panel</p>
        
        <a href="index.php" class="flex items-center gap-3 px-4 py-3 rounded-xl <?= $currentPage === 'index' ? 'bg-brand-purple text-white' : 'text-gray-400 hover:bg-gray-800 hover:text-white' ?> transition">
            <i class="fas fa-tachometer-alt w-5"></i>
            <span>Dashboard</span>
        </a>
        
        <a href="users.php" class="flex items-center gap-3 px-4 py-3 rounded-xl <?= $currentPage === 'users' ? 'bg-brand-purple text-white' : 'text-gray-400 hover:bg-gray-800 hover:text-white' ?> transition">
            <i class="fas fa-users w-5"></i>
            <span>Users</span>
        </a>
        
        <a href="urls.php" class="flex items-center gap-3 px-4 py-3 rounded-xl <?= $currentPage === 'urls' ? 'bg-brand-purple text-white' : 'text-gray-400 hover:bg-gray-800 hover:text-white' ?> transition">
            <i class="fas fa-link w-5"></i>
            <span>URLs</span>
        </a>
        
        <a href="analytics.php" class="flex items-center gap-3 px-4 py-3 rounded-xl <?= $currentPage === 'analytics' ? 'bg-brand-purple text-white' : 'text-gray-400 hover:bg-gray-800 hover:text-white' ?> transition">
            <i class="fas fa-chart-bar w-5"></i>
            <span>Analytics</span>
        </a>
        
        <a href="blog.php" class="flex items-center gap-3 px-4 py-3 rounded-xl <?= $currentPage === 'blog' ? 'bg-brand-purple text-white' : 'text-gray-400 hover:bg-gray-800 hover:text-white' ?> transition">
            <i class="fas fa-blog w-5"></i>
            <span>Blog</span>
        </a>
        
        <a href="blacklist.php" class="flex items-center gap-3 px-4 py-3 rounded-xl <?= $currentPage === 'blacklist' ? 'bg-brand-purple text-white' : 'text-gray-400 hover:bg-gray-800 hover:text-white' ?> transition">
            <i class="fas fa-ban w-5"></i>
            <span>Blacklist</span>
        </a>
        
        <a href="fraud.php" class="flex items-center gap-3 px-4 py-3 rounded-xl <?= $currentPage === 'fraud' ? 'bg-brand-purple text-white' : 'text-gray-400 hover:bg-gray-800 hover:text-white' ?> transition">
            <i class="fas fa-shield-alt w-5"></i>
            <span>Fraud Control</span>
        </a>
        
        <a href="plans.php" class="flex items-center gap-3 px-4 py-3 rounded-xl <?= $currentPage === 'plans' ? 'bg-brand-purple text-white' : 'text-gray-400 hover:bg-gray-800 hover:text-white' ?> transition">
            <i class="fas fa-money-bill-wave w-5"></i>
            <span>Plans</span>
        </a>

        <a href="settings.php" class="flex items-center gap-3 px-4 py-3 rounded-xl <?= $currentPage === 'settings' ? 'bg-brand-purple text-white' : 'text-gray-400 hover:bg-gray-800 hover:text-white' ?> transition">
            <i class="fas fa-cog w-5"></i>
            <span>Settings</span>
        </a>
        
        <div class="pt-4 mt-4 border-t border-gray-800">
            <a href="../dashboard.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-gray-400 hover:bg-gray-800 hover:text-white transition">
                <i class="fas fa-arrow-left w-5"></i>
                <span>Back to User</span>
            </a>
        </div>
    </nav>

    <!-- User Info -->
    <div class="p-4 border-t border-gray-800">
        <div class="flex items-center gap-3 mb-3">
            <div class="w-10 h-10 rounded-full bg-brand-purple flex items-center justify-center text-white font-bold">
                <?= strtoupper(substr($user['name'], 0, 1)) ?>
            </div>
            <div class="flex-1 min-w-0">
                <p class="font-medium truncate"><?= htmlspecialchars($user['name']) ?></p>
                <p class="text-xs text-gray-400">Administrator</p>
            </div>
        </div>
        <a href="../logout.php" class="flex items-center gap-2 text-gray-400 hover:text-red-400 transition text-sm">
            <i class="fas fa-sign-out-alt"></i>
            <span>Logout</span>
        </a>
    </div>
</aside>
