﻿
<?php
/**
 * Admin - User Management
 */

define('ROOT_PATH', dirname(__DIR__));

require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

require_admin();

$user = current_user();
$flash = get_flash();

// Pagination
$page = max(1, (int)($_GET['page'] ?? 1));
$limit = 10;
$offset = ($page - 1) * $limit;

$search = trim($_GET['search'] ?? '');

$where = '';
$params = [];

if ($search) {
    $where = "WHERE name LIKE ? OR email LIKE ?";
    $params = ["%$search%", "%$search%"];
}

// Get users
$users = db()->fetchAll(
    "SELECT * FROM users $where ORDER BY created_at DESC LIMIT $limit OFFSET $offset",
    $params
);

// Total users
$totalCount = db()->fetchOne(
    "SELECT COUNT(*) as count FROM users $where",
    $params
)['count'];

$totalPages = ceil($totalCount / $limit);

// AJAX Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    header('Content-Type: application/json');

    $action = $_POST['action'] ?? '';
    $userId = (int)($_POST['userId'] ?? 0);

    if (!$userId) {
        echo json_encode(['error' => 'Invalid user']);
        exit;
    }

    try {

        switch ($action) {

            case 'ban':

                $status = $_POST['status'] ?? 'banned';

                db()->execute(
                    "UPDATE users SET status=? WHERE id=?",
                    [$status, $userId]
                );

                echo json_encode(['success' => true]);
                break;

            case 'delete':

                db()->execute(
                    "DELETE FROM users WHERE id=?",
                    [$userId]
                );

                echo json_encode(['success' => true]);
                break;

            case 'role':

                $role = $_POST['role'] ?? 'user';

                db()->execute(
                    "UPDATE users SET role=? WHERE id=?",
                    [$role, $userId]
                );

                echo json_encode(['success' => true]);
                break;

            case 'plan':

                $plan = $_POST['plan'] ?? 'free';

                db()->execute(
                    "UPDATE users SET plan=? WHERE id=?",
                    [$plan, $userId]
                );

                echo json_encode(['success' => true]);
                break;

            default:

                echo json_encode(['error' => 'Invalid action']);
        }

    } catch (Exception $e) {

        echo json_encode([
            'error' => $e->getMessage()
        ]);
    }

    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>User Management - SnapLink Pro</title>

    <!-- Tailwind -->
    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">

    <!-- FontAwesome -->
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap"
          rel="stylesheet">

    <style>

        *{
            font-family: 'Inter', sans-serif;
        }

        body{
            background:#f3f4f6;
        }

        .sidebar{
            width:260px;
            min-height:100vh;
            background:linear-gradient(180deg,#7c3aed,#ec4899);
        }

        .sidebar a{
            transition:0.3s;
        }

        .sidebar a:hover{
            background:rgba(255,255,255,0.15);
        }

        .table-row:hover{
            background:#f9fafb;
        }

    </style>

</head>

<body>

<div class="flex">

    <!-- SIDEBAR -->
    <aside class="sidebar text-white p-6 hidden lg:block">

        <div class="mb-10">

            <h1 class="text-3xl font-bold">
                Link<span class="text-yellow-300">Snip</span>
            </h1>

            <p class="text-purple-100 mt-1">
                Admin Panel
            </p>

        </div>

        <nav class="space-y-2">

            <a href="index.php"
               class="flex items-center gap-3 px-4 py-3 rounded-xl">

                <i class="fas fa-chart-pie"></i>
                Dashboard

            </a>

            <a href="users.php"
               class="flex items-center gap-3 px-4 py-3 rounded-xl bg-white bg-opacity-20">

                <i class="fas fa-users"></i>
                Users

            </a>

            <a href="urls.php"
               class="flex items-center gap-3 px-4 py-3 rounded-xl">

                <i class="fas fa-link"></i>
                URLs

            </a>

            <a href="analytics.php"
               class="flex items-center gap-3 px-4 py-3 rounded-xl">

                <i class="fas fa-chart-line"></i>
                Analytics

            </a>

            <a href="../dashboard.php"
               class="flex items-center gap-3 px-4 py-3 rounded-xl">

                <i class="fas fa-arrow-left"></i>
                Back to User

            </a>

        </nav>

        <div class="absolute bottom-6 left-6">

            <a href="../logout.php"
               class="text-sm text-white">

                <i class="fas fa-sign-out-alt mr-2"></i>
                Logout

            </a>

        </div>

    </aside>

    <!-- MAIN -->
    <main class="flex-1 p-6 lg:p-10">

        <!-- TOP -->
        <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 mb-8">

            <div>

                <h2 class="text-3xl font-bold text-gray-800">
                    User Management
                </h2>

                <p class="text-gray-500 mt-1">
                    <?= number_format($totalCount) ?> total users
                </p>

            </div>

            <!-- SEARCH -->
            <form method="GET" class="relative">

                <input type="text"
                       name="search"
                       value="<?= htmlspecialchars($search) ?>"
                       placeholder="Search users..."

                       class="bg-white border border-gray-300 rounded-xl pl-12 pr-4 py-3 w-72 focus:outline-none focus:ring-2 focus:ring-purple-500">

                <i class="fas fa-search absolute left-4 top-4 text-gray-400"></i>

            </form>

        </div>

        <!-- FLASH -->
        <?php if ($flash): ?>

            <div class="mb-6 p-4 rounded-xl
                <?= $flash['type'] === 'success'
                    ? 'bg-green-100 text-green-700'
                    : 'bg-red-100 text-red-700' ?>">

                <?= $flash['message'] ?>

            </div>

        <?php endif; ?>

        <!-- TABLE -->
        <div class="bg-white rounded-3xl shadow-lg overflow-hidden">

            <div class="overflow-x-auto">

                <table class="w-full">

                    <thead class="bg-gray-100">

                    <tr class="text-left text-gray-600 text-sm uppercase">

                        <th class="px-6 py-4">User</th>
                        <th class="px-6 py-4">Status</th>
                        <th class="px-6 py-4">Role</th>
                        <th class="px-6 py-4">Plan</th>
                        <th class="px-6 py-4">Joined</th>
                        <th class="px-6 py-4 text-center">Actions</th>

                    </tr>

                    </thead>

                    <tbody>

                    <?php foreach ($users as $u): ?>

                        <tr class="table-row border-t">

                            <!-- USER -->
                            <td class="px-6 py-5">

                                <div class="flex items-center gap-4">

                                    <div class="w-12 h-12 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center font-bold text-lg">

                                        <?= strtoupper(substr($u['name'],0,1)) ?>

                                    </div>

                                    <div>

                                        <h4 class="font-semibold text-gray-800">

                                            <?= htmlspecialchars($u['name']) ?>

                                        </h4>

                                        <p class="text-sm text-gray-500">

                                            <?= htmlspecialchars($u['email']) ?>

                                        </p>

                                    </div>

                                </div>

                            </td>

                            <!-- STATUS -->
                            <td class="px-6 py-5">

                                <?php
                                $status = $u['status'] ?? 'active';
                                ?>

                                <span class="px-3 py-1 rounded-full text-xs font-semibold
                                <?= $status === 'active'
                                    ? 'bg-green-100 text-green-700'
                                    : 'bg-red-100 text-red-700' ?>">

                                    <?= ucfirst($status) ?>

                                </span>

                            </td>

                            <!-- ROLE -->
                            <td class="px-6 py-5">

                                <select onchange="changeRole(<?= $u['id'] ?>, this.value)"
                                        class="border rounded-lg px-3 py-2">

                                    <option value="user"
                                        <?= $u['role'] === 'user' ? 'selected' : '' ?>>
                                        User
                                    </option>

                                    <option value="admin"
                                        <?= $u['role'] === 'admin' ? 'selected' : '' ?>>
                                        Admin
                                    </option>

                                </select>

                            </td>

                            <!-- PLAN -->
                            <td class="px-6 py-5">

                                <select onchange="changePlan(<?= $u['id'] ?>, this.value)"
                                        class="border rounded-lg px-3 py-2">

                                    <option value="free"
                                        <?= $u['plan'] === 'free' ? 'selected' : '' ?>>
                                        Free
                                    </option>

                                    <option value="pro"
                                        <?= $u['plan'] === 'pro' ? 'selected' : '' ?>>
                                        Pro
                                    </option>

                                    <option value="enterprise"
                                        <?= $u['plan'] === 'enterprise' ? 'selected' : '' ?>>
                                        Enterprise
                                    </option>

                                </select>

                            </td>

                            <!-- JOIN -->
                            <td class="px-6 py-5 text-gray-500">

                                <?= date('M d, Y', strtotime($u['created_at'])) ?>

                            </td>

                            <!-- ACTION -->
                            <td class="px-6 py-5">

                                <div class="flex justify-center gap-3">

                                    <?php if ($status === 'active'): ?>

                                        <button onclick="banUser(<?= $u['id'] ?>,'banned')"
                                                class="w-10 h-10 rounded-xl bg-yellow-100 text-yellow-600 hover:bg-yellow-200">

                                            <i class="fas fa-ban"></i>

                                        </button>

                                    <?php else: ?>

                                        <button onclick="banUser(<?= $u['id'] ?>,'active')"
                                                class="w-10 h-10 rounded-xl bg-green-100 text-green-600 hover:bg-green-200">

                                            <i class="fas fa-check"></i>

                                        </button>

                                    <?php endif; ?>

                                    <button onclick="deleteUser(<?= $u['id'] ?>)"
                                            class="w-10 h-10 rounded-xl bg-red-100 text-red-600 hover:bg-red-200">

                                        <i class="fas fa-trash"></i>

                                    </button>

                                </div>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                    </tbody>

                </table>

            </div>

        </div>

    </main>

</div>

<script>

async function sendAction(action,userId,extra={}){

    const formData = new FormData();

    formData.append('action',action);
    formData.append('userId',userId);

    for(let key in extra){
        formData.append(key,extra[key]);
    }

    const res = await fetch('users.php',{
        method:'POST',
        body:formData
    });

    const data = await res.json();

    if(data.success){

        location.reload();

    }else{

        alert(data.error || 'Action failed');

    }
}

function banUser(id,status){

    if(!confirm('Are you sure?')) return;

    sendAction('ban',id,{status});

}

function deleteUser(id){

    if(!confirm('Delete this user permanently?')) return;

    sendAction('delete',id);

}

function changeRole(id,role){

    sendAction('role',id,{role});

}

function changePlan(id,plan){

    sendAction('plan',id,{plan});

}

</script>

</body>
</html>
```
