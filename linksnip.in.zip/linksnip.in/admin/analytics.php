<?php
/**
 * Admin Analytics Page - Redirects to API Analytics
 * This serves as a compatibility layer for routing
 */
header('Location: api-analytics.php');
exit;
