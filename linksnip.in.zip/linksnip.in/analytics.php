﻿<?php
/**
 * Analytics Page - View detailed stats for a single URL
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

require_login();

$user = current_user();
$urlId = $_GET['id'] ?? null;

if (!$urlId) {
    redirect(base_url('dashboard.php'));
}

// Get URL info
$url = db()->fetchOne('SELECT * FROM urls WHERE id = ? AND user_id = ?', [$urlId, $user['id']]);

if (!$url) {
    http_response_code(404);
    set_flash('error', 'URL not found');
    redirect(base_url('dashboard.php'));
}

// Get click stats by day (last 30 days)
$dailyClicks = db()->fetchAll(
    "SELECT DATE(clicked_at) as date, COUNT(*) as clicks 
     FROM url_clicks WHERE url_id = ? AND clicked_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
     GROUP BY DATE(clicked_at) ORDER BY date",
    [$urlId]
);

// Get browser stats
$browsers = db()->fetchAll(
    "SELECT browser, COUNT(*) as count 
     FROM url_clicks WHERE url_id = ? 
     GROUP BY browser ORDER BY count DESC LIMIT 10",
    [$urlId]
);

// Get device stats
$devices = db()->fetchAll(
    "SELECT device_type, COUNT(*) as count 
     FROM url_clicks WHERE url_id = ? 
     GROUP BY device_type",
    [$urlId]
);

// Get country stats
$countries = db()->fetchAll(
    "SELECT country, COUNT(*) as count 
     FROM url_clicks WHERE url_id = ? 
     GROUP BY country ORDER BY count DESC LIMIT 10",
    [$urlId]
);

// Get referrer stats
$referrers = db()->fetchAll(
    "SELECT referrer, COUNT(*) as count 
     FROM url_clicks WHERE url_id = ? 
     GROUP BY referrer ORDER BY count DESC LIMIT 10",
    [$urlId]
);

// Get recent clicks
$recentClicks = db()->fetchAll(
    "SELECT * FROM url_clicks WHERE url_id = ? ORDER BY clicked_at DESC LIMIT 50",
    [$urlId]
);

$baseUrl = APP_URL;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analytics - <?= htmlspecialchars($url['short_code']) ?> - SnapLink Pro</title>
    <?php meta_canonical('php-version/analytics.php'); ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Inter', 'sans-serif'] },
                    colors: {
                        brand: { purple: '#7F00FF', pink: '#E100FF' }
                    }
                }
            }
        }
    </script>
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-50 min-h-screen">
    <!-- Top Bar -->
    <header class="bg-white border-b border-gray-200 px-4 lg:px-8 py-4">
        <div class="max-w-7xl mx-auto flex items-center justify-between">
            <div class="flex items-center gap-4">
                <a href="dashboard.php" class="text-gray-500 hover:text-purple-600">
                    <i class="fas fa-arrow-left"></i>
                </a>
                <div>
                    <h1 class="text-xl font-bold text-gray-900">Analytics</h1>
                    <a href="<?= $baseUrl ?>/<?= $url['short_code'] ?>" target="_blank" class="text-purple-600 text-sm hover:underline">
                        <?= $baseUrl ?>/<?= $url['short_code'] ?>
                    </a>
                </div>
            </div>
            <div class="flex items-center gap-3">
                <span class="px-3 py-1 rounded-full text-xs font-medium <?= $url['is_active'] ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700' ?>">
                    <?= $url['is_active'] ? 'Active' : 'Disabled' ?>
                </span>
            </div>
            <div class="flex items-center gap-3">
                <button onclick="exportCSV()" class="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 font-semibold text-sm">
                    <i class="fas fa-download mr-2"></i>Export CSV
                </button>
                <span class="px-3 py-1 rounded-full text-xs font-medium <?= $url['is_active'] ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700' ?>">
                    <?= $url['is_active'] ? 'Active' : 'Disabled' ?>
                </span>
            </div>
        </div>
    </header>

    <div class="max-w-7xl mx-auto p-4 lg:p-8">
        
        <!-- Date Range Filter -->
        <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm mb-8">
            <div class="flex flex-col md:flex-row items-center justify-between gap-4">
                <h3 class="text-lg font-bold text-gray-900">Date Range</h3>
                <div class="flex items-center gap-3">
                    <input type="date" id="startDate" class="px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-purple-500">
                    <span class="text-gray-500">to</span>
                    <input type="date" id="endDate" class="px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-purple-500">
                    <button onclick="applyDateFilter()" class="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 font-semibold">
                        <i class="fas fa-filter mr-2"></i>Filter
                    </button>
                    <button onclick="resetDateFilter()" class="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 font-semibold">
                        Reset
                    </button>
                </div>
            </div>
        </div>
        
        <!-- Stats Overview -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                <div class="flex items-center justify-between mb-2">
                    <span class="text-gray-500 text-sm">Total Clicks</span>
                    <i class="fas fa-mouse-pointer text-purple-500"></i>
                </div>
                <p class="text-3xl font-bold text-gray-900"><?= number_format($url['clicks']) ?></p>
            </div>
            <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                <div class="flex items-center justify-between mb-2">
                    <span class="text-gray-500 text-sm">QR Scans</span>
                    <i class="fas fa-qrcode text-pink-500"></i>
                </div>
                <p class="text-3xl font-bold text-gray-900"><?= number_format($url['qr_scans']) ?></p>
            </div>
            <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                <div class="flex items-center justify-between mb-2">
                    <span class="text-gray-500 text-sm">Countries</span>
                    <i class="fas fa-globe text-blue-500"></i>
                </div>
                <p class="text-3xl font-bold text-gray-900"><?= count($countries) ?></p>
            </div>
            <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                <div class="flex items-center justify-between mb-2">
                    <span class="text-gray-500 text-sm">Created</span>
                    <i class="fas fa-calendar text-green-500"></i>
                </div>
                <p class="text-xl font-bold text-gray-900"><?= date('M j, Y', strtotime($url['created_at'])) ?></p>
            </div>
        </div>

        <!-- URL Info Card -->
        <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm mb-8">
            <h2 class="text-lg font-bold text-gray-900 mb-4">Link Details</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <p class="text-sm text-gray-500 mb-1">Original URL</p>
                    <a href="<?= htmlspecialchars($url['long_url']) ?>" target="_blank" class="text-purple-600 hover:underline break-all">
                        <?= htmlspecialchars($url['long_url']) ?>
                    </a>
                </div>
                <div>
                    <p class="text-sm text-gray-500 mb-1">Short URL</p>
                    <div class="flex items-center gap-2">
                        <span class="text-gray-900 font-medium"><?= $baseUrl ?>/<?= $url['short_code'] ?></span>
                        <button onclick="navigator.clipboard.writeText('<?= $baseUrl ?>/<?= $url['short_code'] ?>')" class="text-gray-400 hover:text-gray-600">
                            <i class="far fa-copy"></i>
                        </button>
                    </div>
                </div>
            </div>
            <?php if ($url['notes']): ?>
                <div class="mt-4 p-3 bg-gray-50 rounded-lg">
                    <p class="text-sm text-gray-500 mb-1">Notes</p>
                    <p class="text-gray-700"><?= htmlspecialchars($url['notes']) ?></p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Charts Row -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <!-- Clicks Over Time -->
            <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                <h3 class="text-lg font-bold text-gray-900 mb-4">Clicks Over Time (Last 30 Days)</h3>
                <canvas id="clicksChart" height="200"></canvas>
            </div>

            <!-- Device Distribution -->
            <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                <h3 class="text-lg font-bold text-gray-900 mb-4">Device Distribution</h3>
                <canvas id="devicesChart" height="200"></canvas>
            </div>
        </div>

        <!-- Stats Tables -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <!-- Top Countries -->
            <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                <h3 class="text-lg font-bold text-gray-900 mb-4">Top Countries</h3>
                <?php if (empty($countries)): ?>
                    <p class="text-gray-500 text-center py-8">No data yet</p>
                <?php else: ?>
                    <div class="space-y-3">
                        <?php foreach ($countries as $country): ?>
                            <div class="flex items-center justify-between">
                                <span class="text-gray-700"><?= htmlspecialchars($country['country']) ?></span>
                                <div class="flex items-center gap-3">
                                    <div class="w-32 h-2 bg-gray-100 rounded-full overflow-hidden">
                                        <div class="h-full bg-purple-500 rounded-full" style="width: <?= min(100, ($country['count'] / ($countries[0]['count'] ?: 1)) * 100) ?>%"></div>
                                    </div>
                                    <span class="text-gray-500 text-sm w-12 text-right"><?= number_format($country['count']) ?></span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Top Referrers -->
            <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                <h3 class="text-lg font-bold text-gray-900 mb-4">Top Referrers</h3>
                <?php if (empty($referrers)): ?>
                    <p class="text-gray-500 text-center py-8">No data yet</p>
                <?php else: ?>
                    <div class="space-y-3">
                        <?php foreach ($referrers as $ref): ?>
                            <div class="flex items-center justify-between">
                                <span class="text-gray-700 truncate max-w-[200px]"><?= htmlspecialchars($ref['referrer']) ?></span>
                                <div class="flex items-center gap-3">
                                    <div class="w-32 h-2 bg-gray-100 rounded-full overflow-hidden">
                                        <div class="h-full bg-pink-500 rounded-full" style="width: <?= min(100, ($ref['count'] / ($referrers[0]['count'] ?: 1)) * 100) ?>%"></div>
                                    </div>
                                    <span class="text-gray-500 text-sm w-12 text-right"><?= number_format($ref['count']) ?></span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Recent Clicks Table -->
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
            <div class="px-6 py-4 border-b border-gray-100">
                <h3 class="text-lg font-bold text-gray-900">Recent Clicks</h3>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-gray-50 text-left text-sm text-gray-500 uppercase tracking-wider">
                        <tr>
                            <th class="px-6 py-3">Time</th>
                            <th class="px-6 py-3">Location</th>
                            <th class="px-6 py-3">Device</th>
                            <th class="px-6 py-3">Browser</th>
                            <th class="px-6 py-3">Referrer</th>
                            <th class="px-6 py-3 text-center">QR</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        <?php if (empty($recentClicks)): ?>
                            <tr>
                                <td colspan="6" class="px-6 py-12 text-center text-gray-500">No clicks yet</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($recentClicks as $click): ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4 text-sm text-gray-600">
                                        <?= date('M j, g:i A', strtotime($click['clicked_at'])) ?>
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-600">
                                        <?= htmlspecialchars($click['city'] ?: 'Unknown') ?>, <?= htmlspecialchars($click['country'] ?: 'Unknown') ?>
                                    </td>
                                    <td class="px-6 py-4 text-sm">
                                        <span class="px-2 py-1 rounded-full text-xs font-medium 
                                            <?= $click['device_type'] === 'mobile' ? 'bg-green-100 text-green-700' : 
                                               ($click['device_type'] === 'tablet' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700') ?>">
                                            <?= ucfirst($click['device_type']) ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-600">
                                        <?= htmlspecialchars($click['browser']) ?> <?= $click['browser_version'] ?>
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-600 truncate max-w-[150px]">
                                        <?= htmlspecialchars($click['referrer']) ?>
                                    </td>
                                    <td class="px-6 py-4 text-center">
                                        <?php if ($click['is_qr_scan']): ?>
                                            <i class="fas fa-qrcode text-purple-500"></i>
                                        <?php else: ?>
                                            <span class="text-gray-300">-</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        // Clicks Over Time Chart
        const clicksCtx = document.getElementById('clicksChart').getContext('2d');
        new Chart(clicksCtx, {
            type: 'line',
            data: {
                labels: <?= json_encode(array_column($dailyClicks, 'date')) ?>,
                datasets: [{
                    label: 'Clicks',
                    data: <?= json_encode(array_column($dailyClicks, 'clicks')) ?>,
                    borderColor: '#7F00FF',
                    backgroundColor: 'rgba(127, 0, 255, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: false } },
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });

        // Devices Chart
        const devicesCtx = document.getElementById('devicesChart').getContext('2d');
        new Chart(devicesCtx, {
            type: 'doughnut',
            data: {
                labels: <?= json_encode(array_map('ucfirst', array_column($devices, 'device_type'))) ?>,
                datasets: [{
                    data: <?= json_encode(array_column($devices, 'count')) ?>,
                    backgroundColor: ['#7F00FF', '#E100FF', '#FFD700'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'bottom' }
                }
            }
        });
        
        // Export CSV
        async function exportCSV() {
            const urlParams = new URLSearchParams(window.location.search);
            const urlId = urlParams.get('id');
            const startDate = document.getElementById('startDate').value;
            const endDate = document.getElementById('endDate').value;
            
            let url = `api/export-analytics.php?id=${urlId}`;
            if (startDate) url += `&start=${startDate}`;
            if (endDate) url += `&end=${endDate}`;
            
            window.location.href = url;
        }
        
        // Apply date filter
        function applyDateFilter() {
            const startDate = document.getElementById('startDate').value;
            const endDate = document.getElementById('endDate').value;
            
            if (!startDate || !endDate) {
                alert('Please select both start and end dates');
                return;
            }
            
            const urlParams = new URLSearchParams(window.location.search);
            const currentUrl = new URL(window.location.href);
            currentUrl.searchParams.set('start', startDate);
            currentUrl.searchParams.set('end', endDate);
            window.location.href = currentUrl.toString();
        }
        
        // Reset date filter
        function resetDateFilter() {
            const urlParams = new URLSearchParams(window.location.search);
            const currentUrl = new URL(window.location.href);
            currentUrl.searchParams.delete('start');
            currentUrl.searchParams.delete('end');
            window.location.href = currentUrl.toString();
        }
        
        // Initialize date inputs
        document.addEventListener('DOMContentLoaded', function() {
            const urlParams = new URLSearchParams(window.location.search);
            const startDate = urlParams.get('start');
            const endDate = urlParams.get('end');
            
            if (startDate) document.getElementById('startDate').value = startDate;
            if (endDate) document.getElementById('endDate').value = endDate;
            
            // Set default dates if none selected (last 30 days)
            if (!startDate && !endDate) {
                const today = new Date();
                const thirtyDaysAgo = new Date(today);
                thirtyDaysAgo.setDate(today.getDate() - 30);
                
                document.getElementById('endDate').value = today.toISOString().split('T')[0];
                document.getElementById('startDate').value = thirtyDaysAgo.toISOString().split('T')[0];
            }
        });
    </script>

    <?php require_once ROOT_PATH . '/components/cookie-consent.php'; ?>
</body>
</html>
