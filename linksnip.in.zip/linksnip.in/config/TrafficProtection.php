<?php
/**
 * Anti-Fraud & Traffic Protection System
 * Detects bots, VPNs, rate abuse, and malicious traffic
 */

class TrafficProtection {
    private $db;
    private $ip;
    
    public function __construct() {
        $this->db = db();
        $this->ip = $this->getIP();
    }
    
    /**
     * Get real IP address (handles proxies/CDN)
     */
    public function getIP() {
        // Check for Cloudflare first
        if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
            return $_SERVER['HTTP_CF_CONNECTING_IP'];
        }
        
        // Check for common proxy headers
        $headers = [
            'HTTP_CLIENT_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_FORWARDED',
            'HTTP_X_CLUSTER_CLIENT_IP',
            'HTTP_FORWARDED_FOR',
            'HTTP_FORWARDED',
            'REMOTE_ADDR'
        ];
        
        foreach ($headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ip = $_SERVER[$header];
                if (strpos($ip, ',') !== false) {
                    $ips = explode(',', $ip);
                    $ip = trim($ips[0]);
                }
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
        
        return '0.0.0.0';
    }
    
    /**
     * Check if IP is banned
     */
    public function isIPBanned() {
        $ban = $this->db->fetchOne(
            "SELECT * FROM banned_ips WHERE ip = ?",
            [$this->ip]
        );
        
        if (!$ban) return false;
        
        // Check if ban expired
        if ($ban['expires_at'] && strtotime($ban['expires_at']) < time()) {
            $this->db->execute("DELETE FROM banned_ips WHERE ip = ?", [$this->ip]);
            return false;
        }
        
        return true;
    }
    
    /**
     * Check if user is banned
     */
    public function isUserBanned($userId) {
        $ban = $this->db->fetchOne(
            "SELECT * FROM banned_users WHERE user_id = ?",
            [$userId]
        );
        return (bool)$ban;
    }
    
    /**
     * Detect headless browsers
     */
    public function isHeadless() {
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $patterns = [
            'HeadlessChrome',
            'Puppeteer',
            'PhantomJS',
            'Selenium',
            'curl',
            'wget',
            'python',
            'node-fetch',
            'go-http',
            'okhttp'
        ];
        
        foreach ($patterns as $pattern) {
            if (stripos($ua, $pattern) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Check for invalid/missing UA
     */
    public function hasInvalidUA() {
        return !isset($_SERVER['HTTP_USER_AGENT']) || 
               trim($_SERVER['HTTP_USER_AGENT']) == '';
    }
    
    /**
     * Detect bot-like referrers
     */
    public function hasInvalidReferrer() {
        $ref = $_SERVER['HTTP_REFERER'] ?? '';
        
        if (empty($ref)) {
            // Empty referrer can be legit (direct access), so we're lenient
            return false;
        }
        
        $patterns = ['bot', 'crawler', 'spider', 'scraper', 'seo-'];
        foreach ($patterns as $pattern) {
            if (stripos($ref, $pattern) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Check if IP belongs to datacenter/VPN
     */
    public function isDatacenterIP() {
        // Use free ipinfo.io API (limited to 50k requests/month)
        $cacheKey = 'ipinfo_' . str_replace('.', '_', $this->ip);
        
        // Check cache first (store in session for this request)
        if (isset($_SESSION[$cacheKey])) {
            return $_SESSION[$cacheKey];
        }
        
        try {
            $response = @file_get_contents("https://ipinfo.io/{$this->ip}/json", false, stream_context_create([
                'http' => ['timeout' => 2]
            ]));
            
            if ($response === false) {
                return false; // API failed, don't block
            }
            
            $data = json_decode($response, true);
            $org = $data['org'] ?? '';
            
            $datacenterPatterns = [
                'Google',
                'Amazon',
                'AWS',
                'DigitalOcean',
                'OVH',
                'Hetzner',
                'Linode',
                'Vultr',
                'Microsoft',
                'Cloud',
                'Hosting',
                'Data Center',
                'VPN',
                'Proxy'
            ];
            
            foreach ($datacenterPatterns as $pattern) {
                if (stripos($org, $pattern) !== false) {
                    $_SESSION[$cacheKey] = true;
                    return true;
                }
            }
            
            $_SESSION[$cacheKey] = false;
            return false;
            
        } catch (Exception $e) {
            return false; // Don't block on API error
        }
    }
    
    /**
     * Check rate limit
     */
    public function checkRateLimit($limit = 50, $seconds = 10) {
        $since = date("Y-m-d H:i:s", time() - $seconds);
        
        $count = $this->db->fetchOne(
            "SELECT COUNT(*) as c FROM click_logs 
             WHERE ip = ? AND created_at > ?",
            [$this->ip, $since]
        );
        
        return ($count['c'] ?? 0) <= $limit;
    }
    
    /**
     * Ban IP (temp or permanent)
     */
    public function banIP($reason, $hours = null) {
        $expires = $hours ? date("Y-m-d H:i:s", strtotime("+$hours hours")) : null;
        
        try {
            $this->db->insert(
                "INSERT INTO banned_ips (ip, reason, expires_at) 
                 VALUES (?, ?, ?) 
                 ON DUPLICATE KEY UPDATE reason = ?, expires_at = ?",
                [$this->ip, $reason, $expires, $reason, $expires]
            );
        } catch (Exception $e) {
            error_log("Ban IP failed: " . $e->getMessage());
        }
    }
    
    /**
     * Ban user permanently
     */
    public function banUser($userId, $reason) {
        try {
            $this->db->insert(
                "INSERT INTO banned_users (user_id, reason) VALUES (?, ?)
                 ON DUPLICATE KEY UPDATE reason = ?",
                [$userId, $reason, $reason]
            );
        } catch (Exception $e) {
            error_log("Ban user failed: " . $e->getMessage());
        }
    }
    
    /**
     * Log click with fraud detection
     */
    public function logClick($urlId, $userId = null) {
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $ref = $_SERVER['HTTP_REFERER'] ?? '';
        
        // Parse UA for device/browser
        $device = $this->detectDevice($ua);
        $browser = $this->detectBrowser($ua);
        
        // Get geo data (simplified - you can enhance)
        $country = $_SERVER['HTTP_CF_IPCOUNTRY'] ?? 'Unknown';
        
        // Suspicious if: headless, no UA, datacenter, etc.
        $isSuspicious = $this->isHeadless() || 
                       $this->hasInvalidUA() || 
                       $this->isDatacenterIP();
        
        $this->db->insert(
            "INSERT INTO click_logs (user_id, url_id, ip, country, user_agent, referrer, device_type, browser, is_suspicious)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            [$userId, $urlId, $this->ip, $country, $ua, $ref, $device, $browser, $isSuspicious]
        );
    }
    
    /**
     * Simple device detection
     */
    private function detectDevice($ua) {
        if (preg_match('/(tablet|ipad|playbook)|(android(?!.*(mobi|opera mini)))/i', $ua)) {
            return 'tablet';
        }
        if (preg_match('/(up.browser|up.link|mmp|symbian|smartphone|midp|wap|phone|android|iemobile)/i', $ua)) {
            return 'mobile';
        }
        return 'desktop';
    }
    
    /**
     * Simple browser detection
     */
    private function detectBrowser($ua) {
        if (stripos($ua, 'Edge') !== false) return 'Edge';
        if (stripos($ua, 'Chrome') !== false) return 'Chrome';
        if (stripos($ua, 'Safari') !== false) return 'Safari';
        if (stripos($ua, 'Firefox') !== false) return 'Firefox';
        if (stripos($ua, 'MSIE') !== false || stripos($ua, 'Trident') !== false) return 'IE';
        return 'Other';
    }
    
    /**
     * Comprehensive fraud check
     * Returns array: ['allowed' => bool, 'reason' => string]
     */
    public function checkTraffic() {
        // 1. IP Ban check
        if ($this->isIPBanned()) {
            return ['allowed' => false, 'reason' => 'IP banned'];
        }
        
        // 2. Headless browser
        if ($this->isHeadless()) {
            $this->banIP("Headless browser detected", 24);
            return ['allowed' => false, 'reason' => 'Bot detected'];
        }
        
        // 3. Invalid UA
        if ($this->hasInvalidUA()) {
            $this->banIP("Invalid User-Agent", 24);
            return ['allowed' => false, 'reason' => 'Invalid request'];
        }
        
        // 4. Rate limit (50 clicks in 10 seconds)
        if (!$this->checkRateLimit(50, 10)) {
            $this->banIP("Rate limit exceeded", 1);
            return ['allowed' => false, 'reason' => 'Too many requests'];
        }
        
        // 5. Datacenter/VPN (softer check - log but allow for now)
        if ($this->isDatacenterIP()) {
            // You can choose to block or just flag
            // $this->banIP("Datacenter/VPN", 12);
            // For now, we'll just log it as suspicious
        }
        
        return ['allowed' => true, 'reason' => ''];
    }
}
