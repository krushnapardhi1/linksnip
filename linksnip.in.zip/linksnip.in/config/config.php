<?php
/**
 * SnapLink Pro - URL Shortener Configuration
 * InfinityFree Compatible
 */

// Prevent direct access
if (!defined('ROOT_PATH')) {
    define('ROOT_PATH', dirname(__DIR__));
}

// Error Reporting (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Session Configuration
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);

// Fix for InfinityFree - Custom session path
$sessionPath = ROOT_PATH . '/sessions';
if (!file_exists($sessionPath)) {
    @mkdir($sessionPath, 0755, true);
}
if (is_writable($sessionPath)) {
    session_save_path($sessionPath);
}

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database Configuration - InfinityFree Production
define('DB_HOST', 'sql205.infinityfree.com');
define('DB_NAME', 'if0_34392250_linksnip');  
define('DB_USER', 'if0_34392250');   
define('DB_PASS', '2FNbOe0JDsw5');

// Application Settings
define('APP_NAME', 'SnapLink Pro');
define('APP_URL', 'https://snaplink.pro'); // Production domain
define('APP_VERSION', '1.0.0');

// Security Settings
define('HASH_COST', 10); // bcrypt cost factor
define('TOKEN_EXPIRY', 7 * 24 * 60 * 60); // 7 days in seconds
define('GOOGLE_CLIENT_ID', '430789512328-841g1e00n0v7gtechh78204jtjefjn3p.apps.googleusercontent.com');

// Upload Settings (InfinityFree has limited space)
define('MAX_FILE_SIZE', 2 * 1024 * 1024); // 2MB
define('UPLOAD_PATH', ROOT_PATH . '/uploads/');

// Timezone
date_default_timezone_set('Asia/Kolkata');

// GeoIP API
define('GEOIP_API', 'http://ip-api.com/json');

// Short Code Settings
define('SHORT_CODE_LENGTH', 6);
define('SHORT_CODE_CHARS', 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789');

// Reserved routes (cannot be used as short codes)
define('RESERVED_ROUTES', [
    'login', 'register', 'logout', 'dashboard', 'settings', 
    'domains', 'api', 'admin', 'blog', 'billing', 'bio',
    'install', 'config', 'includes', 'assets', 'uploads'
]);

/**
 * Helper function to get base URL
 */
function base_url($path = '') {
    return rtrim(APP_URL, '/') . '/' . ltrim($path, '/');
}

/**
 * Helper function to redirect
 */
function redirect($url) {
    header("Location: " . $url);
    exit;
}

/**
 * Helper function to check if user is logged in
 */
function is_logged_in() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Helper function to require login
 */
function require_login() {
    if (!is_logged_in()) {
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
        redirect(base_url('login.php'));
    }
}

/**
 * Helper function to require admin
 */
function require_admin() {
    require_login();
    if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
        http_response_code(403);
        include ROOT_PATH . '/error.php';
        exit;
    }
}

/**
 * Get current user
 */
function current_user() {
    if (!is_logged_in()) return null;
    return [
        'id' => $_SESSION['user_id'],
        'name' => $_SESSION['user_name'] ?? '',
        'email' => $_SESSION['user_email'] ?? '',
        'role' => $_SESSION['user_role'] ?? 'user',
        'plan' => $_SESSION['user_plan'] ?? 'free',
        'theme' => $_SESSION['user_theme'] ?? 'light'
    ];
}

/**
 * CSRF Token Generation
 */
function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * CSRF Token Validation
 */
function validate_csrf($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * JSON Response Helper
 */
function json_response($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

/**
 * Sanitize Input
 */
function sanitize($input) {
    if (is_array($input)) {
        return array_map('sanitize', $input);
    }
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

/**
 * Validate URL
 */
function validate_url($url) {
    return filter_var($url, FILTER_VALIDATE_URL) !== false;
}

/**
 * Generate canonical URL for current page
 */
function canonical_url($path = null) {
    if ($path === null) {
        // Get current script name
        $path = basename($_SERVER['PHP_SELF']);
    }
    return base_url($path);
}

/**
 * Output canonical meta tag
 */
function meta_canonical($url = null) {
    $canonical = $url ?: canonical_url();
    echo '<link rel="canonical" href="' . htmlspecialchars($canonical, ENT_QUOTES, 'UTF-8') . '">' . "\n";
}

/**
 * Flash Message Helpers
 */
function set_flash($type, $message) {
    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message
    ];
}

function get_flash() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/**
 * Get Client IP Address
 * Works with proxies, CloudFlare, etc.
 */
function get_client_ip() {
    // Check for CloudFlare IP
    if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        return $_SERVER['HTTP_CF_CONNECTING_IP'];
    }
    
    // Check for proxies
    if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ipList = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        return trim($ipList[0]);
    }
    
    if (isset($_SERVER['HTTP_X_REAL_IP'])) {
        return $_SERVER['HTTP_X_REAL_IP'];
    }
    
    // Default remote addr
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

/**
 * Get Site Setting
 * Fetches a setting from the site_settings table and caches it for the request
 */
function get_site_setting($key, $default = '') {
    static $settings_cache = null;
    
    if ($settings_cache === null) {
        $settings_cache = [];
        try {
            // Check if db() is available before trying to fetch
            if (function_exists('db')) {
                $rows = db()->fetchAll("SELECT key_name, value FROM site_settings");
                foreach ($rows as $row) {
                    $settings_cache[$row['key_name']] = $row['value'];
                }
            }
        } catch (Exception $e) {
            // Table might not exist yet, ignore
        }
    }
    
    return $settings_cache[$key] ?? $default;
}

