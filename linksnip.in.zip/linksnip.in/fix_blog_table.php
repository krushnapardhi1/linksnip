﻿<?php
/**
 * Fix Blog Posts Table
 * Creates the 'blog_posts' table and seeds it with demo content
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';

echo "<h1>Fixing Blog Posts Table...</h1>";

try {
    $db = db();
    
    // Create Table
    echo "Creating 'blog_posts' table...<br>";
    $sql = "CREATE TABLE IF NOT EXISTS blog_posts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        slug VARCHAR(255) NOT NULL UNIQUE,
        excerpt TEXT NULL,
        content LONGTEXT NOT NULL,
        featured_image VARCHAR(255) NULL,
        author VARCHAR(100) DEFAULT 'Admin',
        status ENUM('published', 'draft') DEFAULT 'published',
        meta_description VARCHAR(160) NULL,
        views INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_slug (slug),
        INDEX idx_status (status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
    
    $db->execute($sql);
    echo "<span style='color:green'>✅ Table 'blog_posts' checked/created.</span><br>";

    // Seed Data
    $posts = [
        [
            'title' => 'How to Shorten URLs for Free in India',
            'slug' => 'how-to-shorten-urls-free-india',
            'excerpt' => 'Learn how to create short links for free using SnapLink Pro. Perfect for social media marketing, email campaigns, and WhatsApp sharing in India.',
            'content' => '
                <p>In today\'s digital world, sharing long, messy URLs is a thing of the past. Whether you are a marketer, a student, or a business owner, using a URL shortener can significantly improve your click-through rates and brand visibility.</p>
                <h2>Why Use a URL Shortener?</h2>
                <ul>
                    <li><strong>Better Aesthetics:</strong> Short links look cleaner and more professional.</li>
                    <li><strong>Tracking & Analytics:</strong> Know exactly who is clicking your links and from where.</li>
                    <li><strong>Space Saving:</strong> Critical for platforms with character limits like Twitter/X.</li>
                </ul>
                <h2>How to Get Started with SnapLink Pro</h2>
                <p>SnapLink Pro is designed to be the easiest and most powerful URL shortener available for free. Here is how to use it:</p>
                <ol>
                    <li>Copy your long link.</li>
                    <li>Paste it into the box on the SnapLink Pro homepage.</li>
                    <li>Click "Shorten".</li>
                    <li>Copy your new short link and share it anywhere!</li>
                </ol>
                <p>Start shortening your links today for free!</p>
            '
        ],
        [
            'title' => 'Best Free URL Shortener in 2026',
            'slug' => 'best-free-url-shortener-2026',
            'excerpt' => 'Discover why SnapLink Pro is the best free URL shortener in 2026. Compare features, pricing, and analytics with Bitly and other alternatives.',
            'content' => '
                <p>Choosing the right URL shortener can be tough with so many options out there. In 2026, you need a tool that is not just a redirector, but a complete link management platform.</p>
                <h2>Top Contenders</h2>
                <p>While Bitly and TinyURL have been around for years, they often hide their best features behind expensive paywalls. SnapLink Pro changes the game by offering premium features for free.</p>
                <h2>SnapLink Pro Features vs Others</h2>
                <ul>
                    <li><strong>Custom Bios:</strong> Create a "Link in Bio" page for your social media profiles.</li>
                    <li><strong>QR Codes:</strong> Generate instant QR codes for offline marketing.</li>
                    <li><strong>Detailed Analytics:</strong> Get real-time data on clicks, devices, and locations.</li>
                </ul>
                <p>Join the revolution and switch to SnapLink Pro today.</p>
            '
        ]
    ];

    echo "Seeding blog posts...<br>";
    foreach ($posts as $post) {
        // Check if exists
        $exists = $db->fetchOne("SELECT id FROM blog_posts WHERE slug = ?", [$post['slug']]);
        
        if (!$exists) {
            $db->insert(
                "INSERT INTO blog_posts (title, slug, excerpt, content, meta_description) VALUES (?, ?, ?, ?, ?)", 
                [$post['title'], $post['slug'], $post['excerpt'], $post['content'], $post['excerpt']]
            );
            echo "Created post: <strong>{$post['slug']}</strong><br>";
        } else {
            echo "Post <strong>{$post['slug']}</strong> already exists.<br>";
        }
    }

    echo "<h3>Success! Blog works now.</h3>";
    echo "<a href='blog.php' target='_blank'>View Blog</a>";

} catch (Exception $e) {
    echo "<h1>❌ Error</h1>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
}
?>
