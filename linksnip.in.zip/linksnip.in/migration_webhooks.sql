-- Webhooks Table Migration
-- Run this SQL in your MySQL database

CREATE TABLE IF NOT EXISTS `webhooks` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `user_id` INT NOT NULL,
    `url_id` INT NULL DEFAULT NULL,
    `event_type` ENUM('first_click', 'milestone', 'expiry') NOT NULL,
    `webhook_url` VARCHAR(500) NOT NULL,
    `milestone` INT NULL DEFAULT NULL,
    `is_active` BOOLEAN DEFAULT TRUE,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_user_id` (`user_id`),
    INDEX `idx_url_id` (`url_id`),
    INDEX `idx_event_type` (`event_type`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`url_id`) REFERENCES `urls`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
