<?php
// Check what's actually on the server
error_reporting(E_ALL);
ini_set('display_errors', 1);

$file = __DIR__ . '/analytics.php';

if (!file_exists($file)) {
    die("analytics.php not found at: " . $file);
}

$lines = file($file);

echo "<h2>analytics.php Line 165 Contents:</h2>";
echo "<pre>";
echo "Line 163: " . htmlspecialchars($lines[162] ?? 'N/A') . "\n";
echo "Line 164: " . htmlspecialchars($lines[163] ?? 'N/A') . "\n";
echo "<strong>Line 165: " . htmlspecialchars($lines[164] ?? 'N/A') . "</strong>\n";
echo "Line 166: " . htmlspecialchars($lines[165] ?? 'N/A') . "\n";
echo "Line 167: " . htmlspecialchars($lines[166] ?? 'N/A') . "\n";
echo "</pre>";

echo "<h3>Search for display_ad:</h3>";
$content = file_get_contents($file);
if (strpos($content, 'display_ad') !== false) {
    echo "<pre style='color:red'>FOUND display_ad in file!</pre>";
    
    // Show all lines containing display_ad
    foreach ($lines as $num => $line) {
        if (stripos($line, 'display_ad') !== false) {
            echo "Line " . ($num + 1) . ": " . htmlspecialchars($line) . "<br>";
        }
    }
} else {
    echo "<pre style='color:green'>display_ad NOT found in current server file</pre>";
}

echo "<h3>File Info:</h3>";
echo "Total lines: " . count($lines) . "<br>";
echo "Last modified: " . date("Y-m-d H:i:s", filemtime($file)) . "<br>";
