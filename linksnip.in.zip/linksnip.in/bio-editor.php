﻿<?php
/**
 * Bio Page Editor
 * Customize your bio page appearance and content
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

require_login();
$user = current_user();

$db = db()->getConnection();

// Safe database initialization
try {
    // Fetch user's bio page settings
    $stmt = $db->prepare("SELECT * FROM bio_pages WHERE user_id = ?");
    $stmt->execute([$user['id']]);
    $bioPage = $stmt->fetch(PDO::FETCH_ASSOC);

    // Fetch social links
    $stmt = $db->prepare("SELECT * FROM bio_socials WHERE user_id = ? ORDER BY position");
    $stmt->execute([$user['id']]);
    $socials = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    // If table doesn't exist (1146) or column missing (1054), create tables
    if ($e->getCode() == '42S02' || $e->getCode() == '42S22' || strpos($e->getMessage(), '1146') !== false || strpos($e->getMessage(), '1054') !== false) {
        
        // Create bio_pages table
        $db->exec("CREATE TABLE IF NOT EXISTS bio_pages (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            theme VARCHAR(50) DEFAULT 'gradient',
            accent_color VARCHAR(7) DEFAULT '#7F00FF',
            button_style VARCHAR(20) DEFAULT 'rounded',
            background_image VARCHAR(255) NULL,
            bio_title VARCHAR(255) NULL,
            bio_description TEXT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_user_id (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Create bio_socials table
        $db->exec("CREATE TABLE IF NOT EXISTS bio_socials (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            platform VARCHAR(50) NOT NULL,
            url TEXT NOT NULL,
            position INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_user_id (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        
        // Retry fetch (now tables exist empty)
        $bioPage = false;
        $socials = [];
    } else {
        throw $e; // Re-throw other errors
    }
}

// If no bio page exists (or was just created), insert default
if (!$bioPage) {
    try {
        $stmt = $db->prepare("
            INSERT INTO bio_pages (user_id, theme, accent_color, button_style) 
            VALUES (?, 'gradient', '#7F00FF', 'rounded')
        ");
        $stmt->execute([$user['id']]);
        
        // Set default values for the view
        $bioPage = [
            'theme' => 'gradient',
            'accent_color' => '#7F00FF',
            'button_style' => 'rounded',
            'background_image' => null,
            'bio_title' => null,
            'bio_description' => null
        ];
    } catch (Exception $e) {
        // Fallback for view to avoid crash
        $bioPage = [
            'theme' => 'gradient',
            'accent_color' => '#7F00FF',
            'button_style' => 'rounded',
            'background_image' => null
        ];
    }
}

$pageTitle = "Bio Page Editor - SnapLink Pro";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        .color-picker-btn { position: relative; cursor: pointer; }
        .color-picker-btn input[type="color"] { 
            position: absolute; 
            opacity: 0; 
            width: 100%; 
            height: 100%; 
            cursor: pointer; 
        }
    </style>
</head>
<body class="bg-gray-50">

    <!-- Navbar -->
    <nav class="bg-white shadow-sm border-b sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <a href="index.php" class="flex items-center gap-2">
                    <div class="w-10 h-10 rounded-xl bg-purple-600 flex items-center justify-center text-white">
                        <i class="fas fa-link"></i>
                    </div>
                    <span class="text-xl font-bold">SnapLink Pro</span>
                </a>
                
                <div class="flex items-center gap-4">
                    <a href="bio.php?u=<?= urlencode($user['name']) ?>" target="_blank"
                       class="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 font-semibold">
                        <i class="fas fa-eye mr-2"></i>Preview
                    </a>
                    <a href="dashboard.php" class="text-gray-700 hover:text-purple-600">
                        <i class="fas fa-arrow-left mr-2"></i>Dashboard
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="max-w-7xl mx-auto px-4 py-8">
        <div class="grid lg:grid-cols-2 gap-8">
            
            <!-- Editor Panel -->
            <div class="space-y-6">
                <div class="bg-white rounded-2xl shadow-lg p-6">
                    <h2 class="text-2xl font-bold mb-6">Customize Your Bio Page</h2>
                    
                    <!-- Profile Settings -->
                    <div class="mb-6">
                        <h3 class="text-lg font-semibold mb-4">Profile Information</h3>
                        <div class="space-y-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Display Name</label>
                                <input type="text" id="displayName" value="<?= htmlspecialchars($user['name']) ?>"
                                       class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Bio Title</label>
                                <input type="text" id="bioTitle" value="<?= htmlspecialchars($user['bio_title'] ?? '') ?>"
                                       placeholder="e.g., Digital Creator"
                                       class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Bio Description</label>
                                <textarea id="bioDescription" rows="3"
                                          class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500"
                                          placeholder="Tell your story..."><?= htmlspecialchars($user['bio'] ?? '') ?></textarea>
                            </div>
                        </div>
                    </div>

                    <!-- Theme Selection -->
                    <div class="mb-6">
                        <h3 class="text-lg font-semibold mb-4">Theme</h3>
                        <div class="grid grid-cols-3 gap-4">
                            <button onclick="selectTheme('gradient')" data-theme="gradient"
                                    class="theme-btn p-4 rounded-xl border-2 hover:border-purple-500 transition <?= $bioPage['theme'] === 'gradient' ? 'border-purple-500 bg-purple-50' : 'border-gray-200' ?>">
                                <div class="h-16 rounded-lg bg-gradient-to-br from-purple-600 to-pink-600 mb-2"></div>
                                <span class="text-sm font-medium">Gradient</span>
                            </button>
                            <button onclick="selectTheme('solid')" data-theme="solid"
                                    class="theme-btn p-4 rounded-xl border-2 hover:border-purple-500 transition <?= $bioPage['theme'] === 'solid' ? 'border-purple-500 bg-purple-50' : 'border-gray-200' ?>">
                                <div class="h-16 rounded-lg bg-purple-600 mb-2"></div>
                                <span class="text-sm font-medium">Solid</span>
                            </button>
                            <button onclick="selectTheme('minimal')" data-theme="minimal"
                                    class="theme-btn p-4 rounded-xl border-2 hover:border-purple-500 transition <?= $bioPage['theme'] === 'minimal' ? 'border-purple-500 bg-purple-50' : 'border-gray-200' ?>">
                                <div class="h-16 rounded-lg bg-white border-2 border-gray-200 mb-2"></div>
                                <span class="text-sm font-medium">Minimal</span>
                            </button>
                        </div>
                    </div>

                    <!-- Accent Color -->
                    <div class="mb-6">
                        <h3 class="text-lg font-semibold mb-4">Accent Color</h3>
                        <div class="flex items-center gap-3">
                            <div class="color-picker-btn w-16 h-16 rounded-xl border-2 border-gray-200" 
                                 style="background-color: <?= htmlspecialchars($bioPage['accent_color']) ?>">
                                <input type="color" id="accentColor" value="<?= htmlspecialchars($bioPage['accent_color']) ?>" onchange="updatePreview()">
                            </div>
                            <div class="flex-1">
                                <p class="text-sm text-gray-600">Choose your brand color</p>
                                <p class="text-xs text-gray-400" id="colorValue"><?= htmlspecialchars($bioPage['accent_color']) ?></p>
                            </div>
                        </div>
                    </div>

                    <!-- Button Style -->
                    <div class="mb-6">
                        <h3 class="text-lg font-semibold mb-4">Button Style</h3>
                        <div class="grid grid-cols-3 gap-4">
                            <button onclick="selectButtonStyle('rounded')" data-style="rounded"
                                    class="button-style-btn p-4 border-2 rounded-xl hover:border-purple-500 transition <?= $bioPage['button_style'] === 'rounded' ? 'border-purple-500 bg-purple-50' : 'border-gray-200' ?>">
                                <div class="h-10 bg-purple-600 rounded-lg mb-2"></div>
                                <span class="text-sm font-medium">Rounded</span>
                            </button>
                            <button onclick="selectButtonStyle('pill')" data-style="pill"
                                    class="button-style-btn p-4 border-2 rounded-xl hover:border-purple-500 transition <?= $bioPage['button_style'] === 'pill' ? 'border-purple-500 bg-purple-50' : 'border-gray-200' ?>">
                                <div class="h-10 bg-purple-600 rounded-full mb-2"></div>
                                <span class="text-sm font-medium">Pill</span>
                            </button>
                            <button onclick="selectButtonStyle('square')" data-style="square"
                                    class="button-style-btn p-4 border-2 rounded-xl hover:border-purple-500 transition <?= $bioPage['button_style'] === 'square' ? 'border-purple-500 bg-purple-50' : 'border-gray-200' ?>">
                                <div class="h-10 bg-purple-600 mb-2"></div>
                                <span class="text-sm font-medium">Square</span>
                            </button>
                        </div>
                    </div>

                    <!-- Social Links -->
                    <div class="mb-6">
                        <div class="flex items-center justify-between mb-4">
                            <h3 class="text-lg font-semibold">Social Links</h3>
                            <button onclick="addSocialLink()" class="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 text-sm">
                                <i class="fas fa-plus mr-2"></i>Add Link
                            </button>
                        </div>
                        <div id="socialLinks" class="space-y-3">
                            <?php foreach ($socials as $social): ?>
                                <div class="flex items-center gap-3 p-3 bg-gray-50 rounded-lg social-link-item" data-id="<?= $social['id'] ?>">
                                    <select class="social-platform px-3 py-2 border border-gray-200 rounded-lg">
                                        <option value="twitter" <?= $social['platform'] === 'twitter' ? 'selected' : '' ?>>𝕏 Twitter</option>
                                        <option value="instagram" <?= $social['platform'] === 'instagram' ? 'selected' : '' ?>>📷 Instagram</option>
                                        <option value="facebook" <?= $social['platform'] === 'facebook' ? 'selected' : '' ?>>👤 Facebook</option>
                                        <option value="linkedin" <?= $social['platform'] === 'linkedin' ? 'selected' : '' ?>>💼 LinkedIn</option>
                                        <option value="youtube" <?= $social['platform'] === 'youtube' ? 'selected' : '' ?>>▶️ YouTube</option>
                                        <option value="github" <?= $social['platform'] === 'github' ? 'selected' : '' ?>>💻 GitHub</option>
                                        <option value="tiktok" <?= $social['platform'] === 'tiktok' ? 'selected' : '' ?>>🎵 TikTok</option>
                                    </select>
                                    <input type="url" class="social-url flex-1 px-3 py-2 border border-gray-200 rounded-lg" 
                                           value="<?= htmlspecialchars($social['url']) ?>" placeholder="https://">
                                    <button onclick="removeSocialLink(this)" class="text-red-500 hover:text-red-700">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Save Button -->
                    <button onclick="saveBioPage()" class="w-full px-6 py-4 bg-purple-600 text-white rounded-xl font-bold hover:bg-purple-700 text-lg">
                        <i class="fas fa-save mr-2"></i>Save Changes
                    </button>
                </div>
            </div>

            <!-- Preview Panel -->
            <div class="lg:sticky lg:top-24">
                <div class="bg-white rounded-2xl shadow-lg p-6">
                    <h3 class="text-lg font-semibold mb-4">Live Preview</h3>
                    <div class="border-4 border-gray-200 rounded-2xl overflow-hidden">
                        <iframe id="preview" src="bio.php?u=<?= urlencode($user['name']) ?>" 
                                class="w-full h-[600px]"></iframe>
                    </div>
                    <p class="text-sm text-gray-500 mt-4 text-center">
                        <i class="fas fa-info-circle mr-2"></i>Your bio page URL: 
                        <a href="bio.php?u=<?= urlencode($user['name']) ?>" target="_blank" 
                           class="text-purple-600 hover:underline">
                            <?= APP_URL ?>/bio.php?u=<?= urlencode($user['name']) ?>
                        </a>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- Toast -->
    <div id="toast" class="hidden fixed top-4 right-4 bg-green-600 text-white px-6 py-4 rounded-lg shadow-lg z-50">
        <div class="flex items-center gap-3">
            <i class="fas fa-check-circle text-xl"></i>
            <span id="toast-message">Saved successfully!</span>
        </div>
    </div>

    <script>
        let selectedTheme = '<?= $bioPage['theme'] ?>';
        let selectedButtonStyle = '<?= $bioPage['button_style'] ?>';

        function showToast(message, type = 'success') {
            const toast = document.getElementById('toast');
            toast.className = `fixed top-4 right-4 px-6 py-4 rounded-lg shadow-lg z-50 ${
                type === 'success' ? 'bg-green-600' : 'bg-red-600'
            } text-white`;
            document.getElementById('toast-message').textContent = message;
            toast.classList.remove('hidden');
            setTimeout(() => toast.classList.add('hidden'), 3000);
        }

        function selectTheme(theme) {
            selectedTheme = theme;
            document.querySelectorAll('.theme-btn').forEach(btn => {
                if (btn.dataset.theme === theme) {
                    btn.classList.add('border-purple-500', 'bg-purple-50');
                    btn.classList.remove('border-gray-200');
                } else {
                    btn.classList.remove('border-purple-500', 'bg-purple-50');
                    btn.classList.add('border-gray-200');
                }
            });
            updatePreview();
        }

        function selectButtonStyle(style) {
            selectedButtonStyle = style;
            document.querySelectorAll('.button-style-btn').forEach(btn => {
                if (btn.dataset.style === style) {
                    btn.classList.add('border-purple-500', 'bg-purple-50');
                    btn.classList.remove('border-gray-200');
                } else {
                    btn.classList.remove('border-purple-500', 'bg-purple-50');
                    btn.classList.add('border-gray-200');
                }
            });
            updatePreview();
        }

        function updatePreview() {
            const color = document.getElementById('accentColor').value;
            document.getElementById('colorValue').textContent = color;
            document.querySelector('.color-picker-btn').style.backgroundColor = color;
            // Refresh preview iframe
            setTimeout(() => {
                document.getElementById('preview').contentWindow.location.reload();
            }, 500);
        }

        function addSocialLink() {
            const container = document.getElementById('socialLinks');
            const html = `
                <div class="flex items-center gap-3 p-3 bg-gray-50 rounded-lg social-link-item">
                    <select class="social-platform px-3 py-2 border border-gray-200 rounded-lg">
                        <option value="twitter">𝕏 Twitter</option>
                        <option value="instagram">📷 Instagram</option>
                        <option value="facebook">👤 Facebook</option>
                        <option value="linkedin">💼 LinkedIn</option>
                        <option value="youtube">▶️ YouTube</option>
                        <option value="github">💻 GitHub</option>
                        <option value="tiktok">🎵 TikTok</option>
                    </select>
                    <input type="url" class="social-url flex-1 px-3 py-2 border border-gray-200 rounded-lg" placeholder="https://">
                    <button onclick="removeSocialLink(this)" class="text-red-500 hover:text-red-700">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            `;
            container.insertAdjacentHTML('beforeend', html);
        }

        function removeSocialLink(btn) {
            btn.closest('.social-link-item').remove();
        }

        async function saveBioPage() {
            const data = {
                display_name: document.getElementById('displayName').value,
                bio_title: document.getElementById('bioTitle').value,
                bio_description: document.getElementById('bioDescription').value,
                theme: selectedTheme,
                accent_color: document.getElementById('accentColor').value,
                button_style: selectedButtonStyle,
                socials: []
            };

            // Collect social links
            document.querySelectorAll('.social-link-item').forEach(item => {
                const platform = item.querySelector('.social-platform').value;
                const url = item.querySelector('.social-url').value;
                if (url) {
                    data.socials.push({ platform, url });
                }
            });

            try {
                const response = await fetch('api/bio-page.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });

                const result = await response.json();

                if (result.success) {
                    showToast('Bio page saved successfully!');
                    setTimeout(() => {
                        document.getElementById('preview').contentWindow.location.reload();
                    }, 1000);
                } else {
                    showToast(result.error || 'Failed to save', 'error');
                }
            } catch (error) {
                showToast('An error occurred', 'error');
            }
        }

        // Update color value display
        document.getElementById('accentColor').addEventListener('change', updatePreview);
    </script>

</body>
</html>
