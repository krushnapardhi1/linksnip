﻿<?php
/**
 * Support / FAQ Page
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';
$user = current_user();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Help Center - SnapLink Pro</title>
    <?php meta_canonical('php-version/support.php'); ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-50 min-h-screen flex flex-col">
    <!-- Navbar -->
    <nav class="bg-white border-b border-gray-200">
        <div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
            <a href="index.php" class="flex items-center gap-2">
                <div class="w-10 h-10 rounded-xl bg-purple-600 flex items-center justify-center text-white">
                    <i class="fas fa-link"></i>
                </div>
                <span class="text-xl font-bold text-gray-900">Link<span class="text-purple-600">Snip</span></span>
            </a>
            <?php if ($user): ?>
                <a href="dashboard.php" class="text-purple-600 font-medium hover:text-purple-700">Dashboard</a>
            <?php else: ?>
                <a href="login.php" class="text-purple-600 font-medium hover:text-purple-700">Login</a>
            <?php endif; ?>
        </div>
    </nav>

    <!-- Header -->
    <div class="bg-purple-700 text-white py-16">
        <div class="max-w-4xl mx-auto px-4 text-center">
            <h1 class="text-3xl md:text-4xl font-bold mb-4">How can we help you?</h1>
            <div class="max-w-xl mx-auto relative">
                <input type="text" placeholder="Search for answers..." class="w-full px-6 py-4 rounded-full text-gray-900 focus:outline-none shadow-lg">
                <button class="absolute right-2 top-2 w-10 h-10 bg-purple-600 rounded-full flex items-center justify-center hover:bg-purple-500 transition">
                    <i class="fas fa-search"></i>
                </button>
            </div>
        </div>
    </div>

    <main class="flex-1 max-w-6xl mx-auto w-full px-4 py-12 -mt-8">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition text-center">
                <div class="w-12 h-12 bg-purple-100 text-purple-600 rounded-xl flex items-center justify-center mx-auto mb-4 text-xl">
                    <i class="fas fa-rocket"></i>
                </div>
                <h3 class="font-bold text-gray-900 mb-2">Getting Started</h3>
                <p class="text-gray-500 text-sm">Everything you need to know about getting started with SnapLink Pro.</p>
            </div>
            <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition text-center">
                <div class="w-12 h-12 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center mx-auto mb-4 text-xl">
                    <i class="fas fa-user-cog"></i>
                </div>
                <h3 class="font-bold text-gray-900 mb-2">Account Management</h3>
                <p class="text-gray-500 text-sm">Managing your profile, plan settings and billing information.</p>
            </div>
            <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition text-center">
                <div class="w-12 h-12 bg-green-100 text-green-600 rounded-xl flex items-center justify-center mx-auto mb-4 text-xl">
                    <i class="fas fa-chart-line"></i>
                </div>
                <h3 class="font-bold text-gray-900 mb-2">Analytics & API</h3>
                <p class="text-gray-500 text-sm">Understanding your link stats and developer API integration.</p>
            </div>
        </div>

        <div class="bg-white rounded-2xl padding-8 border border-gray-200 p-8">
            <h2 class="text-2xl font-bold text-gray-900 mb-6">Frequently Asked Questions</h2>
            
            <div class="space-y-4">
                <details class="group bg-gray-50 rounded-xl p-4">
                    <summary class="flex justify-between items-center font-medium cursor-pointer list-none text-gray-900">
                        <span>Is SnapLink Pro free to use?</span>
                        <span class="transition group-open:rotate-180">
                            <i class="fas fa-chevron-down text-gray-400"></i>
                        </span>
                    </summary>
                    <p class="text-gray-600 mt-3 group-open:animate-fadeIn">
                        Yes! SnapLink Pro offers a generous free plan that allows you to shorten links, track clicks, and generate QR codes. We also offer Pro and Enterprise plans for advanced features.
                    </p>
                </details>

                <details class="group bg-gray-50 rounded-xl p-4">
                    <summary class="flex justify-between items-center font-medium cursor-pointer list-none text-gray-900">
                        <span>Can I customize my short links?</span>
                        <span class="transition group-open:rotate-180">
                            <i class="fas fa-chevron-down text-gray-400"></i>
                        </span>
                    </summary>
                    <p class="text-gray-600 mt-3 group-open:animate-fadeIn">
                        Yes, you can create custom aliases (e.g., snaplink.pro/my-brand) on all plans. Custom domains (e.g., link.mybrand.com) are available on Pro and Enterprise plans.
                    </p>
                </details>

                <details class="group bg-gray-50 rounded-xl p-4">
                    <summary class="flex justify-between items-center font-medium cursor-pointer list-none text-gray-900">
                        <span>How long do my links last?</span>
                        <span class="transition group-open:rotate-180">
                            <i class="fas fa-chevron-down text-gray-400"></i>
                        </span>
                    </summary>
                    <p class="text-gray-600 mt-3 group-open:animate-fadeIn">
                        Links on the Free plan are active for 30 days. Pro and Enterprise plans offer extended or permanent link retention.
                    </p>
                </details>
            </div>
        </div>

        <div class="text-center mt-12 pb-8">
            <p class="text-gray-500 mb-4">Still need help?</p>
            <a href="contact.php" class="inline-flex items-center gap-2 px-6 py-3 bg-gray-900 text-white rounded-xl hover:bg-gray-800 transition shadow-lg">
                <i class="fas fa-envelope"></i>
                Contact Support
            </a>
        </div>
    </main>

    <?php require_once ROOT_PATH . '/components/cookie-consent.php'; ?>
</body>
</html>
