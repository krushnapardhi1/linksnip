﻿# Google Search Console Setup Guide for SnapLink Pro

## Step 1: Add Your Property to Google Search Console

### Option A: HTML File Upload Verification (Recommended)

1. **Go to**: [Google Search Console](https://search.google.com/search-console/)
2. **Click**: "Add Property"
3. **Select**: "URL prefix" method
4. **Enter**: `https://snaplink.pro`
5. **Choose**: HTML File Upload verification method
6. **Download**: the verification HTML file (e.g., `google1234567890abcdef.html`)
7. **Upload**: the file to `/public_html/` (root directory) on InfinityFree
8. **Verify**: the file is accessible at `https://snaplink.pro/google1234567890abcdef.html`
9. **Click**: "Verify" in Google Search Console

### Option B: DNS Verification (Alternative)

1. **Choose**: DNS TXT record verification
2. **Copy**: the TXT record value provided by Google
3. **Login**: to your domain registrar or Cloudflare (if using Cloudflare)
4. **Add**: a new TXT record:
   - **Type**: TXT
   - **Name**: @ (or leave blank for root domain)
   - **Value**: (paste the Google verification code)
5. **Wait**: up to 24 hours for DNS propagation
6. **Click**: "Verify" in Google Search Console

---

## Step 2: Submit Your Sitemap

Once your site is verified:

1. **Navigate** to: Sitemaps (in left sidebar)
2. **Enter** sitemap URL: `sitemap.xml`
3. **Click**: "Submit"
4. **Confirm**: Google shows "Success" status

**Your sitemap URL will be:**
```
https://snaplink.pro/sitemap.xml
```

---

## Step 3: Request Indexing for Key Pages

To get indexed faster:

1. **Go to**: URL Inspection tool (top bar)
2. **Enter** each important page URL:
   - `https://snaplink.pro/`
   - `https://snaplink.pro/features.php`
   - `https://snaplink.pro/how-it-works.php`
   - `https://snaplink.pro/faq.php`
   - `https://snaplink.pro/blog.php`
3. **Click**: "Request Indexing"
4. **Wait**: 1-2 minutes for each page
5. **Note**: You can request indexing for up to 10 URLs per day

---

## Step 4: Fix "Duplicate without user-selected canonical" Issues

✅ **Already Implemented!**

All pages now have proper canonical URLs:

- **Homepage**: `<link rel="canonical" href="https://snaplink.pro/">`
- **Features**: `<link rel="canonical" href="https://snaplink.pro/features.php">`
- **FAQ**: `<link rel="canonical" href="https://snaplink.pro/faq.php">`
- And so on...

### For Dynamic Short URLs:

The `r.php` file should include:

```php
<link rel="canonical" href="https://snaplink.pro/<?php echo htmlspecialchars($shortCode); ?>">
```

---

## Step 5: Monitor Performance

After 2-3 weeks, check these metrics in Search Console:

### Performance Report
- **Clicks**: How many users clicked your links in search results
- **Impressions**: How many times your pages appeared in search
- **CTR** (Click-Through Rate): Clicks ÷ Impressions
- **Average Position**: Your ranking position for keywords

### Coverage Report
- **Valid pages**: Pages indexed successfully
- **Errors**: Pages with indexing issues
- **Excluded pages**: Pages intentionally not indexed

### Key Metrics to Track:
- **Total indexed pages**: Should be 15-20 pages within 1 month
- **Search queries**: Keywords people use to find you
- **Top pages**: Which pages get the most traffic

---

## Step 6: Check for Issues Weekly

Every week, review:

1. **Coverage errors**: Fix any indexing problems
2. **Mobile usability**: Ensure all pages are mobile-friendly
3. **Core Web Vitals**: Check page speed metrics
4. **Security issues**: Address any malware or hacking warnings

---

## Expected Timeline

| Timeline | Expected Results |
|----------|------------------|
| **Week 1** | Sitemap submitted, verification complete |
| **Week 2-3** | First pages start appearing in search (homepage, features) |
| **Month 1-2** | 10-20 pages indexed, ranking for long-tail keywords |
| **Month 3-6** | Traffic growth, ranking improvements for competitive keywords |

---

## Troubleshooting Common Issues

### Issue: "Submitted URL not found (404)"
**Solution**: Check that the page exists and .htaccess routing is correct

### Issue: "Duplicate content"
**Solution**: Ensure all pages have unique canonical URLs (already done!)

### Issue: "Page not indexed"
**Solution**: 
1. Check robots.txt allows crawling
2. Ensure page has valuable content
3. Request indexing manually
4. Add internal links to the page

### Issue: "Crawl errors"
**Solution**:
1. Check server logs for 500 errors
2. Fix broken links
3. Ensure HTTPS is working via Cloudflare

---

## Bonus: Accelerate Indexing

### 1. Build Backlinks
- Add your site to directories
- Write guest posts with links
- Share on social media
- Add to your GitHub README

### 2. Create Fresh Content
- Publish blog posts weekly
- Update existing pages monthly
- Add new features and announce them

### 3. Social Signals
- Share each blog post on Twitter, LinkedIn
- Encourage users to share your tool
- Engage with communities (Reddit, Quora)

---

## Quick Commands

### Check if Google can access your site:
```bash
curl -A "Googlebot" https://snaplink.pro
```

### Test sitemap validity:
Visit: `https://www.xml-sitemaps.com/validate-xml-sitemap.html`
Enter: `https://snaplink.pro/sitemap.xml`

### Check robots.txt:
Visit: `https://snaplink.pro/robots.txt`

---

## Support

If you encounter any issues:
- Check [Google Search Console Help](https://support.google.com/webmasters/)
- Review [Indexing documentation](https://developers.google.com/search/docs/crawling-indexing)

---

**Last Updated**: January 29, 2026
**Status**: ✅ SEO Foundation Complete
