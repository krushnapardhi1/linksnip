-- API Keys Table Migration
-- Run this SQL in your MySQL database

CREATE TABLE IF NOT EXISTS `api_keys` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `user_id` INT NOT NULL,
    `api_key` VARCHAR(128) UNIQUE NOT NULL,
    `name` VARCHAR(100) DEFAULT 'API Key',
    `last_used_at` TIMESTAMP NULL DEFAULT NULL,
    `is_active` BOOLEAN DEFAULT TRUE,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_user_id` (`user_id`),
    INDEX `idx_api_key` (`api_key`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
