﻿<?php
/**
 * Export Analytics to CSV
 * Download click data for a specific URL
 */
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

require_login();
$user = current_user();

$urlId = $_GET['id'] ?? null;
$startDate = $_GET['start'] ?? null;
$endDate = $_GET['end'] ?? null;

if (!$urlId) {
    die('URL ID is required');
}

try {
    $db = db()->getConnection();
    
    // Verify URL belongs to user
    $stmt = $db->prepare("SELECT * FROM urls WHERE id = ? AND user_id = ?");
    $stmt->execute([$urlId, $user['id']]);
    $url = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$url) {
        die('URL not found');
    }
    
    // Build query with date filter
    $query = "SELECT 
        clicked_at,
        country,
        city,
        region_name as region,
        device_type,
        os,
        browser,
        browser_version,
        referrer,
        ip_address,
        is_qr_scan
    FROM url_clicks 
    WHERE url_id = ?";
    
    $params = [$urlId];
    
    if ($startDate && $endDate) {
        $query .= " AND DATE(clicked_at) BETWEEN ? AND ?";
        $params[] = $startDate;
        $params[] = $endDate;
    }
    
    $query .= " ORDER BY clicked_at DESC";
    
    // Fetch clicks
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $clicks = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Set headers for CSV download
    $filename = 'analytics_' . $url['short_code'] . '_' . date('Y-m-d') . '.csv';
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Pragma: no-cache');
    header('Expires: 0');
    
    // Open output stream
    $output = fopen('php://output', 'w');
    
    // Add CSV metadata
    fputcsv($output, ['SnapLink Pro Analytics Export']);
    fputcsv($output, ['Short URL', $url['short_code']]);
    fputcsv($output, ['Long URL', $url['long_url']]);
    fputcsv($output, ['Total Clicks', $url['clicks']]);
    fputcsv($output, ['Export Date', date('Y-m-d H:i:s')]);
    if ($startDate && $endDate) {
        fputcsv($output, ['Date Range', $startDate . ' to ' . $endDate]);
    }
    fputcsv($output, []); // Empty row
    
    // Add headers
    if (!empty($clicks)) {
        fputcsv($output, [
            'Date/Time',
            'Country',
            'City',
            'Region',
            'Device Type',
            'OS',
            'Browser',
            'Browser Version',
            'Referrer',
            'IP Address',
            'QR Scan'
        ]);
        
        // Add data rows
        foreach ($clicks as $click) {
            fputcsv($output, [
                $click['clicked_at'],
                $click['country'] ?: 'Unknown',
                $click['city'] ?: 'Unknown',
                $click['region'] ?: '',
                ucfirst($click['device_type']),
                $click['os'] ?: 'Unknown',
                $click['browser'] ?: 'Unknown',
                $click['browser_version'] ?: '',
                $click['referrer'] ?: 'Direct',
                $click['ip_address'],
                $click['is_qr_scan'] ? 'Yes' : 'No'
            ]);
        }
    } else {
        fputcsv($output, ['No clicks recorded for this URL']);
    }
    
    fclose($output);
    exit;
    
} catch (Exception $e) {
    error_log("CSV Export Error: " . $e->getMessage());
    die('Failed to export analytics');
}
