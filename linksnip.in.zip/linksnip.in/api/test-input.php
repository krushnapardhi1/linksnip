<?php
/**
 * API Debug Test
 * Test if the API is receiving data correctly
 */
header('Content-Type: application/json');

// Simulate the API input handling
if (!empty($_POST)) {
    $input = $_POST;
    $source = 'POST (FormData)';
} else {
    $input = json_decode(file_get_contents('php://input'), true) ?: [];
    $source = 'JSON Body';
}

$url = trim($input['url'] ?? $input['long_url'] ?? '');

$response = [
    'test' => 'API Input Debug',
    'data_source' => $source,
    'received_input' => $input,
    'extracted_url' => $url,
    'url_empty' => empty($url),
    'post_data' => $_POST,
    'get_data' => $_GET,
    'content_type' => $_SERVER['CONTENT_TYPE'] ?? 'not set',
    'request_method' => $_SERVER['REQUEST_METHOD'] ?? 'unknown'
];

echo json_encode($response, JSON_PRETTY_PRINT);
?>
