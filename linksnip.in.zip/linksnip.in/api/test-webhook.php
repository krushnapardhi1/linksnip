<?php
/**
 * Test Webhook Endpoint
 * Send a test webhook to verify endpoint is working
 */
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

header('Content-Type: application/json');

$user = current_user();
if (!$user) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    $webhook_id = $input['id'] ?? null;
    
    if (!$webhook_id) {
        echo json_encode(['success' => false, 'error' => 'Webhook ID is required']);
        exit;
    }
    
    $db = db()->getConnection();
    
    // Get webhook
    $stmt = $db->prepare("SELECT * FROM webhooks WHERE id = ? AND user_id = ?");
    $stmt->execute([$webhook_id, $user['id']]);
    $webhook = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$webhook) {
        echo json_encode(['success' => false, 'error' => 'Webhook not found']);
        exit;
    }
    
    // Prepare test payload
    $payload = [
        'event' => $webhook['event_type'],
        'test' => true,
        'link' => [
            'short_code' => 'test123',
            'long_url' => 'https://example.com',
            'clicks' => $webhook['milestone'] ?? 1
        ],
        'timestamp' => date('c')
    ];
    
    // Send webhook
    $ch = curl_init($webhook['webhook_url']);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode >= 200 && $httpCode < 300) {
        echo json_encode([
            'success' => true,
            'message' => 'Test webhook sent successfully',
            'http_code' => $httpCode
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'error' => 'Webhook endpoint returned HTTP ' . $httpCode
        ]);
    }
    
} catch (Exception $e) {
    error_log("Test Webhook Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Failed to send test webhook']);
}
