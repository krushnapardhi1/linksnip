<?php

/**
 * Stripe Webhook Handler
 * Process events from Stripe (payments, subscriptions)
 */
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';
require_once ROOT_PATH . '/utils/stripe-client.php';

// Disable default error reporting to avoid breaking webhook output
error_reporting(0);
header('Content-Type: application/json');

try {
    $db = db()->getConnection();

    // Get Stripe settings
    $settings = (new StripeClient())->getSettings();
    $endpoint_secret = $settings['stripe_webhook_secret'] ?? '';

    $payload = @file_get_contents('php://input');
    $sig_header = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';
    $event = null;

    if (empty($endpoint_secret)) {
        http_response_code(400);
        exit(json_encode(['error' => 'Webhook signing secret not configured']));
    }

    try {
        if (class_exists('Stripe\Webhook')) {
            $event = call_user_func(
                ['\Stripe\Webhook', 'constructEvent'],
                $payload,
                $sig_header,
                $endpoint_secret
            );
        } else {
            // Fallback for environment without Stripe library (Not recommended for prod)
            $event = json_decode($payload);
        }
    } catch (\UnexpectedValueException $e) {
        http_response_code(400);
        exit(json_encode(['error' => 'Invalid payload']));
    } catch (\Exception $e) {
        if (get_class($e) === 'Stripe\Exception\SignatureVerificationException') {
            http_response_code(400);
            exit(json_encode(['error' => 'Invalid signature']));
        }
        throw $e; // Re-throw if it's not the signature exception
    }

    // Handle the event
    switch ($event->type) {
        case 'checkout.session.completed':
            handleCheckoutCompleted($event->data->object, $db);
            break;

        case 'invoice.payment_succeeded':
            handleInvoicePaid($event->data->object, $db);
            break;

        case 'customer.subscription.updated':
            handleSubscriptionUpdated($event->data->object, $db);
            break;

        case 'customer.subscription.deleted':
            handleSubscriptionDeleted($event->data->object, $db);
            break;
    }

    http_response_code(200);
    echo json_encode(['status' => 'success']);
} catch (Exception $e) {
    error_log("Stripe Webhook Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}

// --- Event Handler Functions ---

function handleCheckoutCompleted($session, $db)
{
    if ($session->mode == 'subscription') {
        $userId = $session->metadata->user_id ?? null;
        $customerId = $session->customer;
        $subscriptionId = $session->subscription;

        if ($userId) {
            // Check if user has a record. If so, link the Stripe Customer ID
            // If not, create a placeholder record linking User <-> Stripe Customer
            // The actual Plan content will be filled by 'customer.subscription.updated'

            $stmt = $db->prepare("SELECT id FROM user_subscriptions WHERE user_id = ?");
            $stmt->execute([$userId]);
            $existing = $stmt->fetch();

            if ($existing) {
                $stmt = $db->prepare("
                    UPDATE user_subscriptions 
                    SET stripe_customer_id = ?, stripe_subscription_id = ? 
                    WHERE user_id = ?
                ");
                $stmt->execute([$customerId, $subscriptionId, $userId]);
            } else {
                // Insert new placeholder
                $stmt = $db->prepare("
                    INSERT INTO user_subscriptions (user_id, plan_id, stripe_customer_id, stripe_subscription_id, status) 
                    VALUES (?, 1, ?, ?, 'incomplete')
                ");
                $stmt->execute([$userId, $customerId, $subscriptionId]);
            }
        }
    }
}

function handleInvoicePaid($invoice, $db)
{
    $customerId = $invoice->customer;
    $amount = $invoice->total / 100;
    $currency = strtoupper($invoice->currency);
    $status = 'paid';
    $invoicePdf = $invoice->hosted_invoice_url ?? null;
    $stripeInvoiceId = $invoice->id;

    // Find User by Stripe Customer ID
    $stmt = $db->prepare("SELECT user_id FROM user_subscriptions WHERE stripe_customer_id = ? LIMIT 1");
    $stmt->execute([$customerId]);
    $sub = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($sub) {
        // Check if invoice already exists
        $stmt = $db->prepare("SELECT id FROM user_invoices WHERE stripe_invoice_id = ?");
        $stmt->execute([$stripeInvoiceId]);

        if (!$stmt->fetch()) {
            $stmt = $db->prepare("
                INSERT INTO user_invoices (user_id, stripe_invoice_id, amount, currency, status, invoice_pdf, created_at)
                VALUES (?, ?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([$sub['user_id'], $stripeInvoiceId, $amount, $currency, $status, $invoicePdf]);
        }
    }
}

function handleSubscriptionUpdated($subscription, $db)
{
    $customerId = $subscription->customer;
    $status = $subscription->status;
    $planIdStripe = $subscription->items->data[0]->price->id;
    $currentPeriodStart = date('Y-m-d H:i:s', $subscription->current_period_start);
    $currentPeriodEnd = date('Y-m-d H:i:s', $subscription->current_period_end);
    $cancelAtPeriodEnd = $subscription->cancel_at_period_end ? 1 : 0;

    // 1. Identify the Plan
    $stmt = $db->prepare("SELECT id FROM subscription_plans WHERE stripe_price_id = ?");
    $stmt->execute([$planIdStripe]);
    $localPlan = $stmt->fetch(PDO::FETCH_ASSOC);
    $localPlanId = $localPlan['id'] ?? null;

    if ($localPlanId) {
        // 2. Identify the User Subscription
        $stmt = $db->prepare("SELECT id FROM user_subscriptions WHERE stripe_customer_id = ?");
        $stmt->execute([$customerId]);
        $existingSub = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($existingSub) {
            $stmt = $db->prepare("
                UPDATE user_subscriptions 
                SET plan_id = ?, status = ?, current_period_start = ?, current_period_end = ?, cancel_at_period_end = ?, updated_at = NOW()
                WHERE id = ?
            ");
            $stmt->execute([$localPlanId, $status, $currentPeriodStart, $currentPeriodEnd, $cancelAtPeriodEnd, $existingSub['id']]);
        }
    }
}

function handleSubscriptionDeleted($subscription, $db)
{
    $customerId = $subscription->customer;

    // Find subscription
    $stmt = $db->prepare("SELECT id, user_id FROM user_subscriptions WHERE stripe_customer_id = ?");
    $stmt->execute([$customerId]);
    $sub = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($sub) {
        // Mark as canceled
        $stmt = $db->prepare("
            UPDATE user_subscriptions 
            SET status = 'canceled', cancel_at_period_end = 0, updated_at = NOW()
            WHERE id = ?
        ");
        $stmt->execute([$sub['id']]);

        // Optionally revert to a "Free" tier entry if your logic requires active sub row 
        // OR rely on 'canceled' status to fallback to free limits in your app logic.
        // We leave it as 'canceled', application logic should treat non-active as Free.
    }
}
