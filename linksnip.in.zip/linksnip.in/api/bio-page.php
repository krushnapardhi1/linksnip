<?php
/**
 * Bio Page API
 * Save bio page settings and social links
 */
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

header('Content-Type: application/json');

$user = current_user();
if (!$user) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    $db = db()->getConnection();
    
    // Update user profile
    if (isset($input['display_name']) || isset($input['bio_title']) || isset($input['bio_description'])) {
        $stmt = $db->prepare("
            UPDATE users 
            SET bio_title = ?, bio = ? 
            WHERE id = ?
        ");
        $stmt->execute([
            $input['bio_title'] ?? '',
            $input['bio_description'] ?? '',
            $user['id']
        ]);
    }
    
    // Update or insert bio page settings
    $stmt = $db->prepare("
        INSERT INTO bio_pages (user_id, theme, accent_color, button_style) 
        VALUES (?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE 
            theme = VALUES(theme),
            accent_color = VALUES(accent_color),
            button_style = VALUES(button_style)
    ");
    
    $stmt->execute([
        $user['id'],
        $input['theme'] ?? 'gradient',
        $input['accent_color'] ?? '#7F00FF',
        $input['button_style'] ?? 'rounded'
    ]);
    
    // Delete existing social links
    $stmt = $db->prepare("DELETE FROM bio_socials WHERE user_id = ?");
    $stmt->execute([$user['id']]);
    
    // Insert new social links
    if (!empty($input['socials'])) {
        $stmt = $db->prepare("
            INSERT INTO bio_socials (user_id, platform, url, position) 
            VALUES (?, ?, ?, ?)
        ");
        
        foreach ($input['socials'] as $index => $social) {
            $stmt->execute([
                $user['id'],
                $social['platform'],
                $social['url'],
                $index
            ]);
        }
    }
    
    echo json_encode(['success' => true, 'message' => 'Bio page updated successfully']);
    
} catch (Exception $e) {
    error_log("Bio Page API Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Failed to save bio page']);
}
