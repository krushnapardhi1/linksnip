<?php
/**
 * Folders API Endpoint
 * CRUD operations for link folders
 */
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

header('Content-Type: application/json');

$user = current_user();
if (!$user) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

$db = db()->getConnection();
$action = $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'create':
            $input = json_decode(file_get_contents('php://input'), true);
            
            $name = $input['name'] ?? null;
            $color = $input['color'] ?? '#3B82F6';
            $icon = $input['icon'] ?? 'folder';
            
            if (!$name) {
                echo json_encode(['success' => false, 'error' => 'Folder name is required']);
                exit;
            }
            
            $stmt = $db->prepare("
                INSERT INTO link_folders (user_id, name, color, icon, created_at) 
                VALUES (?, ?, ?, ?, NOW())
            ");
            
            $stmt->execute([$user['id'], $name, $color, $icon]);
            
            echo json_encode([
                'success' => true,
                'message' => 'Folder created successfully',
                'folder_id' => $db->lastInsertId()
            ]);
            break;
            
        case 'update':
            $input = json_decode(file_get_contents('php://input'), true);
            
            $id = $input['id'] ?? null;
            $name = $input['name'] ?? null;
            $color = $input['color'] ?? null;
            $icon = $input['icon'] ?? null;
            
            if (!$id || !$name) {
                echo json_encode(['success' => false, 'error' => 'Folder ID and name are required']);
                exit;
            }
            
            $stmt = $db->prepare("
                UPDATE link_folders 
                SET name = ?, color = ?, icon = ? 
                WHERE id = ? AND user_id = ?
            ");
            
            $stmt->execute([$name, $color, $icon, $id, $user['id']]);
            
            if ($stmt->rowCount() > 0) {
                echo json_encode(['success' => true, 'message' => 'Folder updated successfully']);
            } else {
                echo json_encode(['success' => false, 'error' => 'Folder not found']);
            }
            break;
            
        case 'delete':
            $input = json_decode(file_get_contents('php://input'), true);
            
            $id = $input['id'] ?? null;
            
            if (!$id) {
                echo json_encode(['success' => false, 'error' => 'Folder ID is required']);
                exit;
            }
            
            // Unassign links from this folder
            $stmt = $db->prepare("UPDATE urls SET folder_id = NULL WHERE folder_id = ? AND user_id = ?");
            $stmt->execute([$id, $user['id']]);
            
            // Delete folder
            $stmt = $db->prepare("DELETE FROM link_folders WHERE id = ? AND user_id = ?");
            $stmt->execute([$id, $user['id']]);
            
            if ($stmt->rowCount() > 0) {
                echo json_encode(['success' => true, 'message' => 'Folder deleted successfully']);
            } else {
                echo json_encode(['success' => false, 'error' => 'Folder not found']);
            }
            break;
            
        case 'list':
            $stmt = $db->prepare("
                SELECT 
                    f.*,
                    COUNT(u.id) as link_count
                FROM link_folders f
                LEFT JOIN urls u ON f.id = u.folder_id
                WHERE f.user_id = ?
                GROUP BY f.id
                ORDER BY f.name
            ");
            $stmt->execute([$user['id']]);
            $folders = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo json_encode(['success' => true, 'folders' => $folders]);
            break;
            
        default:
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
    
} catch (Exception $e) {
    error_log("Folders API Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'An error occurred']);
}
