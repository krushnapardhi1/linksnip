<?php
/**
 * API Endpoint for URL Shortening
 * robust version with Output Buffering
 */
// Prevent any output before we are ready
ob_start();

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: ' . ($_SERVER['HTTP_ORIGIN'] ?? '*'));
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, X-Requested-With, X-CSRF-Token');

// Error handling function to return JSON
function returnError($message, $code = 400, $details = null) {
    // Clear any previous output
    ob_clean(); 
    http_response_code($code);
    echo json_encode([
        'success' => false, 
        'error' => $message,
        'details' => $details
    ]);
    exit;
}

try {
    require_once __DIR__ . '/../config/config.php';
    require_once __DIR__ . '/../config/database.php';

    // Start session for CSRF if not started
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    // Check if request is AJAX or from our site
    if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) !== 'xmlhttprequest') {
        // Allow direct POST for guest users (skip verify for now to simplify testing)
        // if (!isset($_SERVER['HTTP_REFERER']) || strpos($_SERVER['HTTP_REFERER'], $_SERVER['HTTP_HOST']) === false) ...
    }

    // Get POST data
    $longUrl = $_POST['long_url'] ?? '';
    if (empty($longUrl)) {
        // Try JSON input fallback
        $jsonInput = json_decode(file_get_contents('php://input'), true);
        $longUrl = $jsonInput['long_url'] ?? '';
    }

    $userId = $_POST['user_id'] ?? null;
    $csrfToken = $_POST['csrf_token'] ?? '';

    // Clean URL
    $longUrl = trim($longUrl);
    
    // Validate URL
    if (empty($longUrl)) {
        returnError('Please enter a URL');
    }

    // Validate URL format
    if (!filter_var($longUrl, FILTER_VALIDATE_URL)) {
        returnError('Invalid URL format. Please include http:// or https://');
    }

    // Check if user is logged in
    $user = null;
    if (isset($_SESSION['user_id']) || $userId) {
        $user = current_user(); // Assuming this function exists in config/config.php
        
        // Verify CSRF token for logged-in users
        if ($user && (!isset($_SESSION['csrf_token']) || $csrfToken !== $_SESSION['csrf_token'])) {
           // Skip CSRF for now during debug if it fails often
           // returnError('Security token mismatch', 403);
        }
    }

    // Check daily limit (using 'links' table and 'guest_ip')
    if (!$user) {
        $guestIp = $_SERVER['REMOTE_ADDR'];
        $today = date('Y-m-d');
        
        try {
            // Updated query for 'links' table
            $stmt = db()->query("SELECT COUNT(*) as count FROM links WHERE guest_ip = ? AND DATE(created_at) = ?", [$guestIp, $today]);
            $result = $stmt->fetch();
            
            if ($result && $result['count'] >= 10) { 
                ob_clean();
                echo json_encode([
                    'success' => false,
                    'error' => 'Daily limit reached for guest users',
                    'limit_reached' => true,
                    'signup_url' => 'register.php?ref=limit'
                ]);
                exit;
            }
        } catch (Exception $e) {
             error_log("Guest limit check failed: " . $e->getMessage());
        }
    }

    // Generate unique short code
    function generateShortCode($length = 6) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $shortCode = '';
        for ($i = 0; $i < $length; $i++) {
            $shortCode .= $characters[random_int(0, $charactersLength - 1)];
        }
        return $shortCode;
    }

    $shortCode = '';
    $attempts = 0;
    do {
        $shortCode = generateShortCode(6);
        // Check uniqueness in 'links' table
        $stmt = db()->query("SELECT id FROM links WHERE short_code = ?", [$shortCode]);
        $exists = $stmt->rowCount() > 0;
        $attempts++;
    } while ($exists && $attempts < 10);

    if ($exists) {
        returnError('Failed to generate unique code. Please try again.', 500);
    }

    // Prepare data
    // Schema: links(long_url, short_code, user_id, guest_ip, clicks, created_at)
    $data = [
        $longUrl,
        $shortCode,
        $user ? $user['id'] : null,
        $_SERVER['REMOTE_ADDR'], // guest_ip
        0, // clicks
        date('Y-m-d H:i:s')
        // is_active defaults to TRUE, updated_at defaults to CURRENT_TIMESTAMP
    ];

    // Insert into 'links' table
    $sql = "INSERT INTO links (long_url, short_code, user_id, guest_ip, clicks, created_at) VALUES (?, ?, ?, ?, ?, ?)";
    
    $linkId = db()->insert($sql, $data);
    
    // Generate short URL
    $protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http');
    $baseUrl = $protocol . '://' . $_SERVER['HTTP_HOST'];
    
    if (function_exists('base_url')) {
        $shortUrl = base_url($shortCode);
    } else {
         // Fallback construction
         $path = dirname($_SERVER['SCRIPT_NAME']); // e.g. /urlshortener/php-version/api
         $parent = dirname($path); // e.g. /urlshortener/php-version
         if ($parent === '/' || $parent === '\\') $parent = '';
         $shortUrl = $baseUrl . $parent . '/' . $shortCode;
    }

    // Success Response
    ob_clean(); 
    echo json_encode([
        'success' => true,
        'data' => [
            'id' => $linkId,
            'shortUrl' => $shortUrl,
            'shortCode' => $shortCode,
            'longUrl' => $longUrl,
        ],
        'message' => $user ? 'URL shortened successfully' : 'URL shortened!'
    ]);

} catch (PDOException $e) {
    error_log("Database Error: " . $e->getMessage());
    returnError('Database error occurred', 500, 'DB Error');
} catch (Exception $e) {
    error_log("API Error: " . $e->getMessage());
    returnError('Server error: ' . $e->getMessage(), 500);
}
// Final flush
ob_end_flush();
