﻿<?php
/**
 * Test SMTP Configuration
 * Sends a test email to verify SMTP settings
 */
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

header('Content-Type: application/json');

// Check if user is admin
$user = current_user();
if (!$user || $user['role'] !== 'admin') {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

try {
    $db = db()->getConnection();
    
    // Get SMTP settings from database
    $stmt = $db->prepare("SELECT key_name, value FROM site_settings WHERE key_name LIKE 'smtp_%'");
    $stmt->execute();
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $smtp = [];
    foreach ($rows as $row) {
        $smtp[$row['key_name']] = $row['value'];
    }
    
    // Validate SMTP settings
    if (empty($smtp['smtp_host']) || empty($smtp['smtp_username']) || empty($smtp['smtp_password'])) {
        echo json_encode(['success' => false, 'error' => 'SMTP settings are incomplete. Please configure all required fields.']);
        exit;
    }
    
    // Use PHPMailer if available, otherwise use mail()
    if (class_exists('PHPMailer\PHPMailer\PHPMailer')) {
        require_once ROOT_PATH . '/vendor/autoload.php';
        
        $mail = new PHPMailer\PHPMailer\PHPMailer(true);
        
        // Server settings
        $mail->isSMTP();
        $mail->Host       = $smtp['smtp_host'];
        $mail->SMTPAuth   = true;
        $mail->Username   = $smtp['smtp_username'];
        $mail->Password   = $smtp['smtp_password'];
        $mail->SMTPSecure = $smtp['smtp_encryption'] ?? 'tls';
        $mail->Port       = $smtp['smtp_port'] ?? 587;
        
        // Recipients
        $mail->setFrom($smtp['smtp_from_email'] ?? $smtp['smtp_username'], $smtp['smtp_from_name'] ?? 'SnapLink Pro');
        $mail->addAddress($user['email'], $user['name']);
        
        // Content
        $mail->isHTML(true);
        $mail->Subject = 'SMTP Test - SnapLink Pro';
        $mail->Body    = '
            <h2>SMTP Test Successful!</h2>
            <p>Your SMTP configuration is working correctly.</p>
            <p><strong>SMTP Host:</strong> ' . htmlspecialchars($smtp['smtp_host']) . '</p>
            <p><strong>Port:</strong> ' . htmlspecialchars($smtp['smtp_port'] ?? '587') . '</p>
            <p><strong>Encryption:</strong> ' . htmlspecialchars($smtp['smtp_encryption'] ?? 'TLS') . '</p>
            <p>This is a test email sent from SnapLink Pro admin panel.</p>
        ';
        $mail->AltBody = 'SMTP Test Successful! Your SMTP configuration is working correctly.';
        
        $mail->send();
        
        echo json_encode([
            'success' => true,
            'message' => 'Test email sent successfully to ' . $user['email']
        ]);
        
    } else {
        // Fallback to basic mail() function
        $to = $user['email'];
        $subject = 'SMTP Test - SnapLink Pro';
        $message = 'Your SMTP configuration is working correctly. This is a test email from SnapLink Pro.';
        $headers = 'From: ' . ($smtp['smtp_from_email'] ?? 'noreply@snaplink.pro') . "\r\n" .
                   'Reply-To: ' . ($smtp['smtp_from_email'] ?? 'noreply@snaplink.pro') . "\r\n" .
                   'X-Mailer: PHP/' . phpversion();
        
        if (mail($to, $subject, $message, $headers)) {
            echo json_encode([
                'success' => true,
                'message' => 'Test email sent successfully to ' . $user['email'] . ' (using PHP mail function)'
            ]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Failed to send email using PHP mail() function']);
        }
    }
    
} catch (Exception $e) {
    error_log("SMTP Test Error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => 'Failed to send test email: ' . $e->getMessage()
    ]);
}
