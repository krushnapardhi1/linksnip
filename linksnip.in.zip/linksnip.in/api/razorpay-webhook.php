<?php
/**
 * Razorpay Webhook Handler
 * Handles payment events from Razorpay (payment.captured, subscription events, etc.)
 */
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

// Log webhook for debugging
$payload = file_get_contents('php://input');
error_log("Razorpay Webhook Received: " . substr($payload, 0, 500));

// Get settings
$settings = [];
$rows = db()->fetchAll("SELECT * FROM site_settings WHERE key_name LIKE 'razorpay%'");
foreach ($rows as $row) {
    $settings[$row['key_name']] = $row['value'];
}

$webhookSecret = $settings['razorpay_webhook_secret'] ?? '';

// Verify webhook signature (if secret is set)
if (!empty($webhookSecret)) {
    $signature = $_SERVER['HTTP_X_RAZORPAY_SIGNATURE'] ?? '';
    $expectedSignature = hash_hmac('sha256', $payload, $webhookSecret);
    
    if (!hash_equals($expectedSignature, $signature)) {
        http_response_code(401);
        error_log("Razorpay Webhook: Invalid signature");
        exit('Invalid signature');
    }
}

$event = json_decode($payload, true);

if (!$event || !isset($event['event'])) {
    http_response_code(400);
    exit('Invalid payload');
}

$eventType = $event['event'];
$paymentEntity = $event['payload']['payment']['entity'] ?? null;

try {
    switch ($eventType) {
        case 'payment.captured':
            // Payment was successful
            if ($paymentEntity) {
                $paymentId = $paymentEntity['id'];
                $orderId = $paymentEntity['order_id'] ?? '';
                $notes = $paymentEntity['notes'] ?? [];
                
                $userId = $notes['user_id'] ?? null;
                $planId = $notes['plan_id'] ?? null;
                
                if ($userId && $planId) {
                    // Get plan
                    $plan = db()->fetchOne("SELECT * FROM subscription_plans WHERE id = ?", [$planId]);
                    
                    if ($plan) {
                        $periodStart = date('Y-m-d H:i:s');
                        $periodEnd = date('Y-m-d H:i:s', strtotime('+1 month'));
                        
                        // Check existing subscription
                        $existingSub = db()->fetchOne("SELECT * FROM user_subscriptions WHERE user_id = ?", [$userId]);
                        
                        if ($existingSub) {
                            db()->query(
                                "UPDATE user_subscriptions SET 
                                    plan_id = ?, 
                                    status = 'active', 
                                    stripe_subscription_id = ?,
                                    current_period_start = ?,
                                    current_period_end = ?,
                                    cancel_at_period_end = 0,
                                    updated_at = NOW()
                                WHERE user_id = ?",
                                [$planId, 'razorpay_' . $paymentId, $periodStart, $periodEnd, $userId]
                            );
                        } else {
                            db()->query(
                                "INSERT INTO user_subscriptions (user_id, plan_id, stripe_subscription_id, status, current_period_start, current_period_end) 
                                 VALUES (?, ?, ?, 'active', ?, ?)",
                                [$userId, $planId, 'razorpay_' . $paymentId, $periodStart, $periodEnd]
                            );
                        }
                        
                        // Update user plan
                        db()->query("UPDATE users SET plan = ? WHERE id = ?", [strtolower($plan['name']), $userId]);
                        
                        // Log invoice (prevent duplicates)
                        $existingInvoice = db()->fetchOne("SELECT id FROM user_invoices WHERE stripe_invoice_id = ?", ['razorpay_' . $paymentId]);
                        if (!$existingInvoice) {
                            $amount = ($paymentEntity['amount'] ?? 0) / 100; // Convert back from paise
                            db()->query(
                                "INSERT INTO user_invoices (user_id, stripe_invoice_id, amount, currency, status) VALUES (?, ?, ?, 'INR', 'paid')",
                                [$userId, 'razorpay_' . $paymentId, $amount]
                            );
                        }
                        
                        error_log("Razorpay Webhook: Subscription activated for user $userId, plan $planId");
                    }
                }
            }
            break;
            
        case 'payment.failed':
            // Payment failed
            if ($paymentEntity) {
                $paymentId = $paymentEntity['id'];
                $notes = $paymentEntity['notes'] ?? [];
                $userId = $notes['user_id'] ?? null;
                
                error_log("Razorpay Webhook: Payment failed for user $userId, payment $paymentId");
            }
            break;
            
        case 'subscription.cancelled':
        case 'subscription.halted':
            // Handle subscription cancellation
            $subscriptionEntity = $event['payload']['subscription']['entity'] ?? null;
            if ($subscriptionEntity) {
                $notes = $subscriptionEntity['notes'] ?? [];
                $userId = $notes['user_id'] ?? null;
                
                if ($userId) {
                    db()->query("UPDATE user_subscriptions SET status = 'cancelled', cancel_at_period_end = 1 WHERE user_id = ?", [$userId]);
                    db()->query("UPDATE users SET plan = 'free' WHERE id = ?", [$userId]);
                    error_log("Razorpay Webhook: Subscription cancelled for user $userId");
                }
            }
            break;
            
        default:
            // Log unhandled events
            error_log("Razorpay Webhook: Unhandled event type: $eventType");
    }

    http_response_code(200);
    echo json_encode(['status' => 'ok']);

} catch (Exception $e) {
    error_log("Razorpay Webhook Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Internal error']);
}
