<?php
/**
 * Get URL Stats API Endpoint
 */
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

header('Content-Type: application/json');

$shortCode = $_GET['code'] ?? '';

if (empty($shortCode)) {
    http_response_code(400);
    echo json_encode(['error' => 'Short code is required']);
    exit;
}

try {
    // Get URL data
    $url = db()->fetchOne('
        SELECT short_code, long_url, clicks, qr_scans, created_at, user_id
        FROM urls 
        WHERE short_code = ?
    ', [$shortCode]);
    
    if (!$url) {
        http_response_code(404);
        echo json_encode(['error' => 'Short URL not found']);
        exit;
    }
    
    // Check if API key is provided (for private stats)
    $apiKey = $_SERVER['HTTP_X_API_KEY'] ?? '';
    
    if ($apiKey) {
        // Verify API key and ownership
        $key = db()->fetchOne('SELECT user_id FROM api_keys WHERE api_key = ?', [$apiKey]);
        
        if ($key && $key['user_id'] == $url['user_id']) {
            // Authorized - return full stats
            echo json_encode([
                'success' => true,
                'data' => [
                    'short_code' => $url['short_code'],
                    'long_url' => $url['long_url'],
                    'clicks' => (int)$url['clicks'],
                    'qr_scans' => (int)$url['qr_scans'],
                    'created_at' => $url['created_at']
                ]
            ]);
        } else {
            http_response_code(403);
            echo json_encode(['error' => 'Unauthorized']);
        }
    } else {
        // Public stats - limited info
        echo json_encode([
            'success' => true,
            'data' => [
                'short_code' => $url['short_code'],
                'clicks' => (int)$url['clicks'],
                'created_at' => $url['created_at']
            ]
        ]);
    }
    
} catch (Exception $e) {
    error_log("Stats API error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Internal server error']);
}
