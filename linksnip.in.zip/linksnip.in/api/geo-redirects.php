<?php
/**
 * Geo Redirects API
 * CRUD operations for geo-based redirects
 */
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

header('Content-Type: application/json');

$user = current_user();
if (!$user) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

$db = db()->getConnection();
$action = $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'create':
            $input = json_decode(file_get_contents('php://input'), true);
            
            $urlId = $input['url_id'] ?? null;
            $country = $input['country'] ?? null;
            $redirectUrl = $input['redirect_url'] ?? null;
            
            if (!$urlId || !$country || !$redirectUrl) {
                echo json_encode(['success' => false, 'error' => 'All fields are required']);
                exit;
            }
            
            // Verify URL belongs to user
            $stmt = $db->prepare("SELECT id FROM urls WHERE id = ? AND user_id = ?");
            $stmt->execute([$urlId, $user['id']]);
            if (!$stmt->fetch()) {
                echo json_encode(['success' => false, 'error' => 'URL not found']);
                exit;
            }
            
            // Check if redirect for this country already exists
            $stmt = $db->prepare("SELECT id FROM geo_redirects WHERE url_id = ? AND country = ?");
            $stmt->execute([$urlId, $country]);
            if ($stmt->fetch()) {
                echo json_encode(['success' => false, 'error' => 'Redirect for this country already exists']);
                exit;
            }
            
            // Insert redirect
            $stmt = $db->prepare("
                INSERT INTO geo_redirects (url_id, country, redirect_url, created_at) 
                VALUES (?, ?, ?, NOW())
            ");
            $stmt->execute([$urlId, $country, $redirectUrl]);
            
            echo json_encode(['success' => true, 'message' => 'Geo redirect created successfully']);
            break;
            
        case 'update':
            $input = json_decode(file_get_contents('php://input'), true);
            
            $id = $input['id'] ?? null;
            $country = $input['country'] ?? null;
            $redirectUrl = $input['redirect_url'] ?? null;
            
            if (!$id || !$country || !$redirectUrl) {
                echo json_encode(['success' => false, 'error' => 'All fields are required']);
                exit;
            }
            
            // Verify redirect belongs to user's URL
            $stmt = $db->prepare("
                SELECT gr.id FROM geo_redirects gr
                JOIN urls u ON gr.url_id = u.id
                WHERE gr.id = ? AND u.user_id = ?
            ");
            $stmt->execute([$id, $user['id']]);
            if (!$stmt->fetch()) {
                echo json_encode(['success' => false, 'error' => 'Redirect not found']);
                exit;
            }
            
            // Update redirect
            $stmt = $db->prepare("
                UPDATE geo_redirects 
                SET country = ?, redirect_url = ? 
                WHERE id = ?
            ");
            $stmt->execute([$country, $redirectUrl, $id]);
            
            echo json_encode(['success' => true, 'message' => 'Geo redirect updated successfully']);
            break;
            
        case 'delete':
            $input = json_decode(file_get_contents('php://input'), true);
            
            $id = $input['id'] ?? null;
            
            if (!$id) {
                echo json_encode(['success' => false, 'error' => 'Redirect ID is required']);
                exit;
            }
            
            // Verify redirect belongs to user's URL
            $stmt = $db->prepare("
                SELECT gr.id FROM geo_redirects gr
                JOIN urls u ON gr.url_id = u.id
                WHERE gr.id = ? AND u.user_id = ?
            ");
            $stmt->execute([$id, $user['id']]);
            if (!$stmt->fetch()) {
                echo json_encode(['success' => false, 'error' => 'Redirect not found']);
                exit;
            }
            
            // Delete redirect
            $stmt = $db->prepare("DELETE FROM geo_redirects WHERE id = ?");
            $stmt->execute([$id]);
            
            echo json_encode(['success' => true, 'message' => 'Geo redirect deleted successfully']);
            break;
            
        default:
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
    
} catch (Exception $e) {
    error_log("Geo Redirects API Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'An error occurred']);
}
