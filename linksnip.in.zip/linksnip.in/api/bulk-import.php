<?php
/**
 * Bulk Import CSV Endpoint
 * Process CSV file and create multiple shortened URLs
 */
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

header('Content-Type: application/json');

$user = current_user();
if (!$user) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

try {
    // Check if file was uploaded
    if (!isset($_FILES['csv_file']) || $_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
        echo json_encode(['success' => false, 'error' => 'No file uploaded or upload error']);
        exit;
    }
    
    $file = $_FILES['csv_file'];
    
    // Validate file type
    $fileExt = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if ($fileExt !== 'csv') {
        echo json_encode(['success' => false, 'error' => 'File must be a CSV']);
        exit;
    }
    
    // Read CSV file
    $handle = fopen($file['tmp_name'], 'r');
    if (!$handle) {
        echo json_encode(['success' => false, 'error' => 'Failed to open CSV file']);
        exit;
    }
    
    $db = db()->getConnection();
    $created = 0;
    $failed = 0;
    $errors = [];
    $rowNum = 0;
    
    // Read header row
    $headers = fgetcsv($handle);
    if (!$headers || !in_array('url', $headers)) {
        fclose($handle);
        echo json_encode(['success' => false, 'error' => 'CSV must have "url" column']);
        exit;
    }
    
    // Map headers to indices
    $urlIndex = array_search('url', $headers);
    $aliasIndex = array_search('custom_alias', $headers);
    $passwordIndex = array_search('password', $headers);
    $expiresIndex = array_search('expires_at', $headers);
    $maxClicksIndex = array_search('max_clicks', $headers);
    $notesIndex = array_search('notes', $headers);
    
    // Process each row
    while (($row = fgetcsv($handle)) !== false) {
        $rowNum++;
        
        // Skip empty rows
        if (empty($row) || empty($row[$urlIndex])) {
            continue;
        }
        
        $longUrl = trim($row[$urlIndex]);
        $customAlias = ($aliasIndex !== false && !empty($row[$aliasIndex])) ? trim($row[$aliasIndex]) : null;
        $password = ($passwordIndex !== false && !empty($row[$passwordIndex])) ? trim($row[$passwordIndex]) : null;
        $expiresAt = ($expiresIndex !== false && !empty($row[$expiresIndex])) ? trim($row[$expiresIndex]) : null;
        $maxClicks = ($maxClicksIndex !== false && !empty($row[$maxClicksIndex])) ? intval($row[$maxClicksIndex]) : null;
        $notes = ($notesIndex !== false && !empty($row[$notesIndex])) ? trim($row[$notesIndex]) : null;
        
        // Validate URL
        if (!filter_var($longUrl, FILTER_VALIDATE_URL)) {
            $errors[] = "Row $rowNum: Invalid URL - $longUrl";
            $failed++;
            continue;
        }
        
        // Generate short code if not provided
        if (!$customAlias) {
            $customAlias = substr(md5(uniqid($longUrl, true)), 0, 6);
        }
        
        // Check if alias already exists
        $stmt = $db->prepare("SELECT id FROM urls WHERE short_code = ?");
        $stmt->execute([$customAlias]);
        if ($stmt->fetch()) {
            $errors[] = "Row $rowNum: Alias '$customAlias' already exists";
            $failed++;
            continue;
        }
        
        // Hash password if provided
        $hashedPassword = $password ? password_hash($password, PASSWORD_BCRYPT) : null;
        
        // Insert URL
        try {
            $stmt = $db->prepare("
                INSERT INTO urls (
                    user_id, short_code, long_url, password, 
                    expires_at, max_clicks, notes, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            
            $stmt->execute([
                $user['id'],
                $customAlias,
                $longUrl,
                $hashedPassword,
                $expiresAt,
                $maxClicks,
                $notes
            ]);
            
            $created++;
            
        } catch (PDOException $e) {
            $errors[] = "Row $rowNum: Database error - " . $e->getMessage();
            $failed++;
        }
    }
    
    fclose($handle);
    
    echo json_encode([
        'success' => true,
        'created' => $created,
        'failed' => $failed,
        'errors' => $errors
    ]);
    
} catch (Exception $e) {
    error_log("Bulk Import Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'An error occurred during import']);
}
