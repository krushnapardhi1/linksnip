<?php
/**
 * Webhooks API Endpoint
 * CRUD operations for webhooks
 */
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

header('Content-Type: application/json');

$user = current_user();
if (!$user) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

$db = db()->getConnection();
$method = $_SERVER['REQUEST_METHOD'];

try {
    switch ($method) {
        case 'POST': // Create webhook
            $input = json_decode(file_get_contents('php://input'), true);
            
            $event_type = $input['event_type'] ?? null;
            $webhook_url = $input['webhook_url'] ?? null;
            $url_id = $input['url_id'] ?? null;
            $milestone = $input['milestone'] ?? null;
            
            if (!$event_type || !$webhook_url) {
                echo json_encode(['success' => false, 'error' => 'Event type and webhook URL are required']);
                exit;
            }
            
            // Validate event type
            $validEvents = ['first_click', 'milestone', 'expiry'];
            if (!in_array($event_type, $validEvents)) {
                echo json_encode(['success' => false, 'error' => 'Invalid event type']);
                exit;
            }
            
            // Validate milestone if event type is milestone
            if ($event_type === 'milestone' && !$milestone) {
                echo json_encode(['success' => false, 'error' => 'Milestone value is required for milestone events']);
                exit;
            }
            
            // Verify URL belongs to user if specified
            if ($url_id) {
                $stmt = $db->prepare("SELECT id FROM urls WHERE id = ? AND user_id = ?");
                $stmt->execute([$url_id, $user['id']]);
                if (!$stmt->fetch()) {
                    echo json_encode(['success' => false, 'error' => 'URL not found']);
                    exit;
                }
            }
            
            // Insert webhook
            $stmt = $db->prepare("
                INSERT INTO webhooks (user_id, url_id, event_type, webhook_url, milestone, is_active, created_at) 
                VALUES (?, ?, ?, ?, ?, 1, NOW())
            ");
            
            $stmt->execute([
                $user['id'],
                $url_id,
                $event_type,
                $webhook_url,
                $milestone
            ]);
            
            echo json_encode(['success' => true, 'message' => 'Webhook created successfully']);
            break;
            
        case 'PUT': // Update webhook (toggle active/inactive)
            $input = json_decode(file_get_contents('php://input'), true);
            
            $id = $input['id'] ?? null;
            $is_active = $input['is_active'] ?? null;
            
            if (!$id || $is_active === null) {
                echo json_encode(['success' => false, 'error' => 'Webhook ID and status are required']);
                exit;
            }
            
            $stmt = $db->prepare("UPDATE webhooks SET is_active = ? WHERE id = ? AND user_id = ?");
            $stmt->execute([$is_active ? 1 : 0, $id, $user['id']]);
            
            if ($stmt->rowCount() > 0) {
                echo json_encode(['success' => true, 'message' => 'Webhook updated successfully']);
            } else {
                echo json_encode(['success' => false, 'error' => 'Webhook not found']);
            }
            break;
            
        case 'DELETE': // Delete webhook
            $input = json_decode(file_get_contents('php://input'), true);
            
            $id = $input['id'] ?? null;
            
            if (!$id) {
                echo json_encode(['success' => false, 'error' => 'Webhook ID is required']);
                exit;
            }
            
            $stmt = $db->prepare("DELETE FROM webhooks WHERE id = ? AND user_id = ?");
            $stmt->execute([$id, $user['id']]);
            
            if ($stmt->rowCount() > 0) {
                echo json_encode(['success' => true, 'message' => 'Webhook deleted successfully']);
            } else {
                echo json_encode(['success' => false, 'error' => 'Webhook not found']);
            }
            break;
            
        default:
            echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    }
    
} catch (Exception $e) {
    error_log("Webhooks API Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'An error occurred']);
}
