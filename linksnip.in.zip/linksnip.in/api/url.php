<?php
/**
 * API - URL Management Endpoint (Update, Delete)
 */
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

header('Content-Type: application/json');

// Check authentication
if (!is_logged_in()) {
    json_response(['error' => 'Authentication required'], 401);
}

$userId = $_SESSION['user_id'];
$input = json_decode(file_get_contents('php://input'), true);
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'PUT':
        // Update URL
        $id = $input['id'] ?? null;
        $longUrl = $input['longUrl'] ?? null;
        $isActive = $input['isActive'] ?? null;
        $notes = $input['notes'] ?? null;
        
        if (!$id) {
            json_response(['error' => 'URL ID is required'], 400);
        }
        
        // Verify ownership
        $url = db()->fetchOne('SELECT id FROM urls WHERE id = ? AND user_id = ?', [$id, $userId]);
        if (!$url) {
            json_response(['error' => 'URL not found'], 404);
        }
        
        // Build update query
        $updates = [];
        $params = [];
        
        if ($longUrl !== null) {
            if (!validate_url($longUrl)) {
                json_response(['error' => 'Invalid URL format'], 400);
            }
            $updates[] = 'long_url = ?';
            $params[] = $longUrl;
        }
        
        if ($isActive !== null) {
            $updates[] = 'is_active = ?';
            $params[] = $isActive ? 1 : 0;
        }
        
        if ($notes !== null) {
            $updates[] = 'notes = ?';
            $params[] = $notes;
        }
        
        if (empty($updates)) {
            json_response(['error' => 'No updates provided'], 400);
        }
        
        $params[] = $id;
        $params[] = $userId;
        
        try {
            $sql = "UPDATE urls SET " . implode(', ', $updates) . " WHERE id = ? AND user_id = ?";
            db()->execute($sql, $params);
            json_response(['success' => true]);
        } catch (Exception $e) {
            json_response(['error' => 'Failed to update'], 500);
        }
        break;
        
    case 'DELETE':
        // Delete URL
        $id = $input['id'] ?? null;
        
        if (!$id) {
            json_response(['error' => 'URL ID is required'], 400);
        }
        
        try {
            $affected = db()->execute('DELETE FROM urls WHERE id = ? AND user_id = ?', [$id, $userId]);
            
            if ($affected === 0) {
                json_response(['error' => 'URL not found'], 404);
            }
            
            json_response(['success' => true]);
        } catch (Exception $e) {
            json_response(['error' => 'Failed to delete'], 500);
        }
        break;
        
    case 'GET':
        // Get URL details
        $id = $_GET['id'] ?? null;
        
        if (!$id) {
            json_response(['error' => 'URL ID is required'], 400);
        }
        
        $url = db()->fetchOne(
            'SELECT * FROM urls WHERE id = ? AND user_id = ?',
            [$id, $userId]
        );
        
        if (!$url) {
            json_response(['error' => 'URL not found'], 404);
        }
        
        // Don't return password hash
        unset($url['password']);
        
        json_response(['success' => true, 'data' => $url]);
        break;
        
    default:
        json_response(['error' => 'Method not allowed'], 405);
}
