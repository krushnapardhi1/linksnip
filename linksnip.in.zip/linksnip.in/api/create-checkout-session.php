<?php
/**
 * Create Stripe Checkout Session API
 */
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';
require_once ROOT_PATH . '/utils/stripe-client.php';

header('Content-Type: application/json');

// Check login
$user = current_user();
if (!$user) {
    echo json_encode(['error' => 'Please login first']);
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    $planId = $input['plan_id'] ?? null;

    if (!$planId) {
        throw new Exception('Plan ID required');
    }

    $db = db()->getConnection();
    $stmt = $db->prepare("SELECT * FROM subscription_plans WHERE id = ?");
    $stmt->execute([$planId]);
    $plan = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$plan) {
        throw new Exception('Invalid plan');
    }

    if (empty($plan['stripe_price_id'])) {
        throw new Exception('This plan is not fully configured for payments yet. Please contact support.');
    }

    $stripe = new StripeClient();
    if (!$stripe->isConfigured()) {
        throw new Exception('Payment gateway not configured');
    }

    $successUrl = APP_URL . '/billing.php?session_id={CHECKOUT_SESSION_ID}';
    $cancelUrl = APP_URL . '/pricing.php';

    $result = $stripe->createCheckoutSession(
        $user['id'],
        $user['email'],
        $plan['stripe_price_id'],
        $successUrl,
        $cancelUrl
    );

    if (isset($result['error'])) {
        throw new Exception($result['error']);
    }

    echo json_encode(['url' => $result['url']]);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['error' => $e->getMessage()]);
}
