<?php
/**
 * Link Rotation API
 * CRUD operations and toggle for link rotation
 */
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

header('Content-Type: application/json');

$user = current_user();
if (!$user) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

$db = db()->getConnection();
$action = $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'toggle':
            $input = json_decode(file_get_contents('php://input'), true);
            
            $urlId = $input['url_id'] ?? null;
            $enabled = $input['enabled'] ?? false;
            $mode = $input['mode'] ?? 'random';
            
            // Verify URL ownership
            $stmt = $db->prepare("SELECT id FROM urls WHERE id = ? AND user_id = ?");
            $stmt->execute([$urlId, $user['id']]);
            if (!$stmt->fetch()) {
                echo json_encode(['success' => false, 'error' => 'URL not found']);
                exit;
            }
            
            // Update rotation settings
            $stmt = $db->prepare("
                UPDATE urls 
                SET rotation_enabled = ?, rotation_mode = ? 
                WHERE id = ?
            ");
            $stmt->execute([$enabled ? 1 : 0, $mode, $urlId]);
            
            echo json_encode(['success' => true]);
            break;
            
        case 'create':
            $input = json_decode(file_get_contents('php://input'), true);
            
            $urlId = $input['url_id'] ?? null;
            $name = $input['name'] ?? null;
            $destinationUrl = $input['destination_url'] ?? null;
            $weight = $input['weight'] ?? 100;
            
            if (!$urlId || !$destinationUrl) {
                echo json_encode(['success' => false, 'error' => 'URL ID and destination URL are required']);
                exit;
            }
            
            // Verify URL ownership
            $stmt = $db->prepare("SELECT id FROM urls WHERE id = ? AND user_id = ?");
            $stmt->execute([$urlId, $user['id']]);
            if (!$stmt->fetch()) {
                echo json_encode(['success' => false, 'error' => 'URL not found']);
                exit;
            }
            
            // Insert rotation
            $stmt = $db->prepare("
                INSERT INTO link_rotations (url_id, name, destination_url, weight) 
                VALUES (?, ?, ?, ?)
            ");
            $stmt->execute([$urlId, $name, $destinationUrl, $weight]);
            
            echo json_encode(['success' => true, 'message' => 'Rotation URL added successfully']);
            break;
            
        case 'update':
            $input = json_decode(file_get_contents('php://input'), true);
            
            $id = $input['id'] ?? null;
            $name = $input['name'] ?? null;
            $destinationUrl = $input['destination_url'] ?? null;
            $weight = $input['weight'] ?? 100;
            
            if (!$id || !$destinationUrl) {
                echo json_encode(['success' => false, 'error' => 'ID and destination URL are required']);
                exit;
            }
            
            // Verify ownership
            $stmt = $db->prepare("
                SELECT lr.id FROM link_rotations lr
                JOIN urls u ON lr.url_id = u.id
                WHERE lr.id = ? AND u.user_id = ?
            ");
            $stmt->execute([$id, $user['id']]);
            if (!$stmt->fetch()) {
                echo json_encode(['success' => false, 'error' => 'Rotation not found']);
                exit;
            }
            
            // Update rotation
            $stmt = $db->prepare("
                UPDATE link_rotations 
                SET name = ?, destination_url = ?, weight = ? 
                WHERE id = ?
            ");
            $stmt->execute([$name, $destinationUrl, $weight, $id]);
            
            echo json_encode(['success' => true, 'message' => 'Rotation URL updated successfully']);
            break;
            
        case 'delete':
            $input = json_decode(file_get_contents('php://input'), true);
            
            $id = $input['id'] ?? null;
            
            if (!$id) {
                echo json_encode(['success' => false, 'error' => 'ID is required']);
                exit;
            }
            
            // Verify ownership
            $stmt = $db->prepare("
                SELECT lr.id FROM link_rotations lr
                JOIN urls u ON lr.url_id = u.id
                WHERE lr.id = ? AND u.user_id = ?
            ");
            $stmt->execute([$id, $user['id']]);
            if (!$stmt->fetch()) {
                echo json_encode(['success' => false, 'error' => 'Rotation not found']);
                exit;
            }
            
            // Delete rotation
            $stmt = $db->prepare("DELETE FROM link_rotations WHERE id = ?");
            $stmt->execute([$id]);
            
            echo json_encode(['success' => true, 'message' => 'Rotation URL deleted successfully']);
            break;
            
        default:
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
    
} catch (Exception $e) {
    error_log("Link Rotation API Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'An error occurred']);
}
