﻿<?php
/**
 * Bulk Export All Links to CSV
 * Download all user's shortened URLs as CSV
 */
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

require_login();
$user = current_user();

try {
    $db = db()->getConnection();
    
    // Fetch all user's URLs
    $stmt = $db->prepare("
        SELECT 
            short_code,
            long_url,
            clicks,
            qr_scans,
            is_active,
            notes,
            created_at,
            expires_at,
            max_clicks,
            CASE WHEN password IS NOT NULL THEN 'Yes' ELSE 'No' END as has_password
        FROM urls 
        WHERE user_id = ? 
        ORDER BY created_at DESC
    ");
    $stmt->execute([$user['id']]);
    $urls = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Set headers for CSV download
    $filename = 'snaplink_links_' . date('Y-m-d_His') . '.csv';
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Pragma: no-cache');
    header('Expires: 0');
    
    // Open output stream
    $output = fopen('php://output', 'w');
    
    // Add CSV metadata
    fputcsv($output, ['SnapLink Pro - All Links Export']);
    fputcsv($output, ['User', $user['name']]);
    fputcsv($output, ['Email', $user['email']]);
    fputcsv($output, ['Export Date', date('Y-m-d H:i:s')]);
    fputcsv($output, ['Total Links', count($urls)]);
    fputcsv($output, []); // Empty row
    
    // Add headers
    fputcsv($output, [
        'Short Code',
        'Short URL',
        'Long URL',
        'Clicks',
        'QR Scans',
        'Status',
        'Password Protected',
        'Created At',
        'Expires At',
        'Max Clicks',
        'Notes'
    ]);
    
    // Add data rows
    $baseUrl = APP_URL;
    foreach ($urls as $url) {
        fputcsv($output, [
            $url['short_code'],
            $baseUrl . '/' . $url['short_code'],
            $url['long_url'],
            $url['clicks'],
            $url['qr_scans'],
            $url['is_active'] ? 'Active' : 'Disabled',
            $url['has_password'],
            $url['created_at'],
            $url['expires_at'] ?: '',
            $url['max_clicks'] ?: '',
            $url['notes'] ?: ''
        ]);
    }
    
    fclose($output);
    exit;
    
} catch (Exception $e) {
    error_log("Bulk Export Error: " . $e->getMessage());
    die('Failed to export links');
}
