<?php
/**
 * Razorpay Payment Verification API
 * Verifies payment signature and activates subscription
 */
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

header('Content-Type: application/json');

// Require login
if (!is_logged_in()) {
    json_response(['error' => 'Login required'], 401);
}

$user = current_user();

// Get settings
$settings = [];
$rows = db()->fetchAll("SELECT * FROM site_settings WHERE key_name LIKE 'razorpay%'");
foreach ($rows as $row) {
    $settings[$row['key_name']] = $row['value'];
}

$keySecret = $settings['razorpay_key_secret'] ?? '';

if (empty($keySecret)) {
    json_response(['error' => 'Razorpay is not configured'], 500);
}

// Get payment data from frontend
$input = json_decode(file_get_contents('php://input'), true);

$razorpayPaymentId = $input['razorpay_payment_id'] ?? '';
$razorpayOrderId = $input['razorpay_order_id'] ?? '';
$razorpaySignature = $input['razorpay_signature'] ?? '';

if (empty($razorpayPaymentId) || empty($razorpayOrderId) || empty($razorpaySignature)) {
    json_response(['error' => 'Missing payment details'], 400);
}

// Verify signature
$expectedSignature = hash_hmac('sha256', $razorpayOrderId . '|' . $razorpayPaymentId, $keySecret);

if (!hash_equals($expectedSignature, $razorpaySignature)) {
    error_log("Razorpay signature mismatch for order: $razorpayOrderId");
    json_response(['error' => 'Payment verification failed'], 400);
}

// Retrieve order from session
$orderData = $_SESSION['razorpay_order'] ?? null;

if (!$orderData || $orderData['order_id'] !== $razorpayOrderId) {
    // Fallback: Try to get plan from notes by fetching payment from Razorpay
    // For security, we'll reject if session doesn't match
    json_response(['error' => 'Order mismatch. Please try again.'], 400);
}

$planId = $orderData['plan_id'];
$userId = $user['id'];

// Get plan details
$plan = db()->fetchOne("SELECT * FROM subscription_plans WHERE id = ?", [$planId]);
if (!$plan) {
    json_response(['error' => 'Plan not found'], 404);
}

try {
    // Check if user already has a subscription
    $existingSub = db()->fetchOne("SELECT * FROM user_subscriptions WHERE user_id = ?", [$userId]);
    
    $periodStart = date('Y-m-d H:i:s');
    $periodEnd = date('Y-m-d H:i:s', strtotime('+1 month'));
    
    if ($existingSub) {
        // Update existing subscription
        db()->query(
            "UPDATE user_subscriptions SET 
                plan_id = ?, 
                status = 'active', 
                stripe_subscription_id = ?,
                current_period_start = ?,
                current_period_end = ?,
                cancel_at_period_end = 0,
                updated_at = NOW()
            WHERE user_id = ?",
            [$planId, 'razorpay_' . $razorpayPaymentId, $periodStart, $periodEnd, $userId]
        );
    } else {
        // Create new subscription
        db()->query(
            "INSERT INTO user_subscriptions (user_id, plan_id, stripe_subscription_id, status, current_period_start, current_period_end) 
             VALUES (?, ?, ?, 'active', ?, ?)",
            [$userId, $planId, 'razorpay_' . $razorpayPaymentId, $periodStart, $periodEnd]
        );
    }
    
    // Update user's plan
    db()->query("UPDATE users SET plan = ? WHERE id = ?", [strtolower($plan['name']), $userId]);
    $_SESSION['user_plan'] = strtolower($plan['name']);
    
    // Log the invoice
    db()->query(
        "INSERT INTO user_invoices (user_id, stripe_invoice_id, amount, currency, status) VALUES (?, ?, ?, 'INR', 'paid')",
        [$userId, 'razorpay_' . $razorpayPaymentId, $plan['price_monthly']]
    );
    
    // Clear session order
    unset($_SESSION['razorpay_order']);
    
    json_response([
        'success' => true,
        'message' => 'Payment successful! Your plan has been upgraded.',
        'redirect' => 'billing.php'
    ]);

} catch (Exception $e) {
    error_log("Razorpay subscription error: " . $e->getMessage());
    json_response(['error' => 'Failed to activate subscription. Please contact support.'], 500);
}
