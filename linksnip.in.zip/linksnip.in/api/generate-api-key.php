<?php
/**
 * Generate API Key Endpoint
 */
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

header('Content-Type: application/json');

// Check if user is logged in
$user = current_user();
if (!$user) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    $name = $input['name'] ?? 'API Key';
    
    // Generate a secure API key
    $apiKey = 'lnk_' . bin2hex(random_bytes(32)); // lnk_<64 characters>
    
    $db = db()->getConnection();
    
    // Insert new API key
    $stmt = $db->prepare("
        INSERT INTO api_keys (user_id, api_key, name, is_active, created_at) 
        VALUES (?, ?, ?, 1, NOW())
    ");
    
    $stmt->execute([$user['id'], $apiKey, $name]);
    
    echo json_encode([
        'success' => true,
        'message' => 'API key generated successfully',
        'api_key' => $apiKey
    ]);
    
} catch (Exception $e) {
    error_log("Generate API Key Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Failed to generate API key']);
}
