<?php
/**
 * Create Stripe Customer Portal Session
 */
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';
require_once ROOT_PATH . '/utils/stripe-client.php';

header('Content-Type: application/json');

// Check login
$user = current_user();
if (!$user) {
    echo json_encode(['error' => 'Please login first']);
    exit;
}

try {
    $db = db()->getConnection();
    
    // Get user's active subscription to find stripe_customer_id
    $stmt = $db->prepare("SELECT stripe_customer_id FROM user_subscriptions WHERE user_id = ? AND stripe_customer_id IS NOT NULL LIMIT 1");
    $stmt->execute([$user['id']]);
    $sub = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$sub || empty($sub['stripe_customer_id'])) {
        throw new Exception('No billing account found');
    }
    
    $stripe = new StripeClient();
    $returnUrl = APP_URL . '/billing.php';
    
    $result = $stripe->createCustomerPortalSession($sub['stripe_customer_id'], $returnUrl);
    
    if (isset($result['error'])) {
        throw new Exception($result['error']);
    }
    
    echo json_encode(['url' => $result['url']]);

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['error' => $e->getMessage()]);
}
