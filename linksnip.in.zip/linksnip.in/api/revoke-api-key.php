<?php
/**
 * Revoke API Key Endpoint
 */
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

header('Content-Type: application/json');

// Check if user is logged in
$user = current_user();
if (!$user) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    $keyId = $input['key_id'] ?? null;
    
    if (!$keyId) {
        echo json_encode(['success' => false, 'error' => 'Key ID is required']);
        exit;
    }
    
    $db = db()->getConnection();
    
    // Verify the key belongs to this user and revoke it
    $stmt = $db->prepare("
        UPDATE api_keys 
        SET is_active = 0 
        WHERE id = ? AND user_id = ?
    ");
    
    $stmt->execute([$keyId, $user['id']]);
    
    if ($stmt->rowCount() > 0) {
        echo json_encode([
            'success' => true,
            'message' => 'API key revoked successfully'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'error' => 'API key not found or already revoked'
        ]);
    }
    
} catch (Exception $e) {
    error_log("Revoke API Key Error: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Failed to revoke API key']);
}
