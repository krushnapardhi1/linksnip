<?php
/**
 * Generate API Key Endpoint
 */
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

header('Content-Type: application/json');

// Must be logged in
if (!is_logged_in()) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$userId = current_user()['id'];

try {
    // Check if user already has an API key
    $existing = db()->fetchOne('SELECT id FROM api_keys WHERE user_id = ?', [$userId]);
    
    if ($existing) {
        http_response_code(400);
        echo json_encode(['error' => 'API key already exists. Manage it in settings.']);
        exit;
    }
    
    // Generate unique API key
    $apiKey = bin2hex(random_bytes(32));
    
    // Insert API key
    db()->insert(
        'INSERT INTO api_keys (user_id, api_key, name, created_at) VALUES (?, ?, ?, NOW())',
        [$userId, $apiKey, 'Default API Key']
    );
    
    echo json_encode([
        'success' => true,
        'api_key' => $apiKey,
        'message' => 'API key generated successfully'
    ]);
    
} catch (Exception $e) {
    error_log("API key generation error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Failed to generate API key']);
}
