<?php
/**
 * Razorpay Order Creation API
 * Creates an order and returns order_id for frontend checkout
 */
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

header('Content-Type: application/json');

// Require login
if (!is_logged_in()) {
    json_response(['error' => 'Login required'], 401);
}

$user = current_user();

// Get settings
$settings = [];
$rows = db()->fetchAll("SELECT * FROM site_settings WHERE key_name LIKE 'razorpay%'");
foreach ($rows as $row) {
    $settings[$row['key_name']] = $row['value'];
}

// Check if Razorpay is enabled
if (empty($settings['razorpay_enabled']) || $settings['razorpay_enabled'] != '1') {
    json_response(['error' => 'Razorpay payments are not enabled'], 400);
}

$keyId = $settings['razorpay_key_id'] ?? '';
$keySecret = $settings['razorpay_key_secret'] ?? '';

if (empty($keyId) || empty($keySecret)) {
    json_response(['error' => 'Razorpay is not configured'], 500);
}

// Get request data
$input = json_decode(file_get_contents('php://input'), true);
$planId = intval($input['plan_id'] ?? 0);

if (!$planId) {
    json_response(['error' => 'Plan ID is required'], 400);
}

// Get plan details
$plan = db()->fetchOne("SELECT * FROM subscription_plans WHERE id = ? AND is_active = 1", [$planId]);
if (!$plan) {
    json_response(['error' => 'Plan not found'], 404);
}

if ($plan['price_monthly'] <= 0) {
    json_response(['error' => 'This plan is free'], 400);
}

// Calculate amount (Razorpay expects amount in paise for INR)
$currency = 'INR';
$amount = $plan['price_monthly'] * 100; // Convert to paise

// Create Razorpay Order via API
$orderData = [
    'amount' => $amount,
    'currency' => $currency,
    'receipt' => 'rcpt_' . time() . '_' . $user['id'],
    'notes' => [
        'user_id' => $user['id'],
        'plan_id' => $planId,
        'plan_name' => $plan['name']
    ]
];

$ch = curl_init('https://api.razorpay.com/v1/orders');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_USERPWD, $keyId . ':' . $keySecret);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($orderData));
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$order = json_decode($response, true);

if ($httpCode !== 200 || empty($order['id'])) {
    error_log('Razorpay Order Creation Failed: ' . $response);
    json_response(['error' => 'Failed to create order. Please try again.'], 500);
}

// Store order in session for verification later
$_SESSION['razorpay_order'] = [
    'order_id' => $order['id'],
    'plan_id' => $planId,
    'amount' => $amount,
    'user_id' => $user['id']
];

// Return order details to frontend
json_response([
    'success' => true,
    'order_id' => $order['id'],
    'amount' => $amount,
    'currency' => $currency,
    'key_id' => $keyId,
    'name' => APP_NAME,
    'description' => $plan['name'] . ' Subscription',
    'prefill' => [
        'name' => $user['name'],
        'email' => $user['email']
    ]
]);
