<?php
/**
 * Force Reset Bio Tables
 * Completely drops and recreates bio_pages and bio_socials tables
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';

echo "<h1>Force Resetting Bio Tables...</h1>";

try {
    $db = db();
    
    // Drop existing tables
    echo "Dropping old tables...<br>";
    $db->execute("DROP TABLE IF EXISTS bio_socials");
    $db->execute("DROP TABLE IF EXISTS bio_pages");
    
    // Create bio_pages with correct schema
    echo "Creating 'bio_pages' table...<br>";
    $sqlPages = "CREATE TABLE bio_pages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        theme VARCHAR(50) DEFAULT 'gradient',
        accent_color VARCHAR(7) DEFAULT '#7F00FF',
        button_style VARCHAR(20) DEFAULT 'rounded',
        background_image VARCHAR(255) NULL,
        bio_title VARCHAR(255) NULL,
        bio_description TEXT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_user_id (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
    $db->execute($sqlPages);
    echo "<span style='color:green'>✅ Created bio_pages</span><br>";

    // Create bio_socials
    echo "Creating 'bio_socials' table...<br>";
    $sqlSocials = "CREATE TABLE bio_socials (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        platform VARCHAR(50) NOT NULL,
        url TEXT NOT NULL,
        position INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_user_id (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
    $db->execute($sqlSocials);
    echo "<span style='color:green'>✅ Created bio_socials</span><br>";

    echo "<h3>Success! Tables have been reset.</h3>";
    echo "<a href='bio-editor.php'>Try Bio Editor Again</a>";

} catch (Exception $e) {
    echo "<h1>❌ Error</h1>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
}
?>
