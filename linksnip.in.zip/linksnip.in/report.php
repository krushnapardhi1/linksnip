﻿<?php
/**
 * Report Abuse Page
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

$user = current_user();
$error = null;
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $url = sanitize($_POST['url'] ?? '');
    $type = sanitize($_POST['type'] ?? '');
    $details = sanitize($_POST['details'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        $error = "Invalid session. Please refresh.";
    } elseif (empty($url) || empty($type)) {
        $error = "URL and Abuse Type are required.";
    } else {
        // In real apps, save to 'abuse_reports' table
        $success = "Report submitted successfully. Our team will review the link shortly.";
    }
}

$csrf = csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report Abuse - SnapLink Pro</title>
    <?php meta_canonical('php-version/report.php'); ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-50 min-h-screen flex flex-col">
    <!-- Navbar -->
    <nav class="bg-white border-b border-gray-200">
        <div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
            <a href="index.php" class="flex items-center gap-2">
                <div class="w-10 h-10 rounded-xl bg-purple-600 flex items-center justify-center text-white">
                    <i class="fas fa-link"></i>
                </div>
                <span class="text-xl font-bold text-gray-900">Link<span class="text-purple-600">Snip</span></span>
            </a>
            <?php if ($user): ?>
                <a href="dashboard.php" class="text-purple-600 font-medium hover:text-purple-700">Dashboard</a>
            <?php else: ?>
                <a href="login.php" class="text-purple-600 font-medium hover:text-purple-700">Login</a>
            <?php endif; ?>
        </div>
    </nav>

    <main class="flex-1 max-w-3xl mx-auto w-full px-4 py-12">
        <div class="text-center mb-10">
            <h1 class="text-3xl font-bold text-gray-900 mb-4">Report Abuse</h1>
            <p class="text-gray-500">Found a link violating our terms? Let us know.</p>
        </div>

        <div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-8">
            <?php if ($success): ?>
                <div class="bg-green-50 text-green-700 p-6 rounded-xl text-center">
                    <i class="fas fa-shield-alt text-3xl mb-4 text-green-600"></i>
                    <h3 class="text-xl font-bold mb-2">Report Received</h3>
                    <p><?= $success ?></p>
                    <a href="index.php" class="inline-block mt-6 text-purple-600 hover:text-purple-700 font-medium">Back to Home</a>
                </div>
            <?php else: ?>
                <?php if ($error): ?>
                    <div class="bg-red-50 text-red-700 p-4 rounded-xl mb-6">
                        <?= $error ?>
                    </div>
                <?php endif; ?>

                <form method="POST" class="space-y-6">
                    <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Short URL *</label>
                        <input type="url" name="url" placeholder="https://snaplink.pro/..." required 
                               class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-red-500">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Violation Type *</label>
                        <select name="type" required class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-red-500">
                            <option value="">Select a reason...</option>
                            <option value="spam">Spam / Scam</option>
                            <option value="malware">Malware / Virus</option>
                            <option value="phishing">Phishing</option>
                            <option value="inappropriate">Inappropriate Content</option>
                            <option value="copyright">Copyright Infringement</option>
                            <option value="other">Other</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Additional Details</label>
                        <textarea name="details" rows="4" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-red-500"></textarea>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Your Email (Optional)</label>
                        <input type="email" name="email" placeholder="For updates on this report"
                               class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-red-500">
                    </div>

                    <div class="pt-4">
                        <button type="submit" class="w-full py-4 bg-red-600 text-white font-bold rounded-xl hover:bg-red-700 transition shadow-lg shadow-red-200">
                            Submit Report
                        </button>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </main>
    
    <?php require_once ROOT_PATH . '/components/cookie-consent.php'; ?>
</body>
</html>
