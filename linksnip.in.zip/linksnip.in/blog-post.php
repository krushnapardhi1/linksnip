﻿<?php
/**
 * Single Blog Post Page
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

$slug = $_GET['slug'] ?? '';
$slug = preg_replace('/[^a-z0-9-]/', '', strtolower($slug));

$post = null;
if ($slug) {
    try {
        $db = db()->getConnection();
        $stmt = $db->prepare("SELECT * FROM blog_posts WHERE slug = ? AND status = 'published'");
        $stmt->execute([$slug]);
        $post = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        $post = null;
    }
}

if (!$post) {
    http_response_code(404);
    $notFoundPage = ROOT_PATH . '/404.php';
    if (file_exists($notFoundPage)) {
        include $notFoundPage;
    } else {
        include ROOT_PATH . '/error.php';
    }
    exit;
}

$user = current_user();
$pageTitle = htmlspecialchars($post['title']) . " - SnapLink Pro Blog";
$pageDescription = htmlspecialchars($post['meta_description'] ?? substr(strip_tags($post['content']), 0, 160));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?></title>
    
    <meta name="description" content="<?= $pageDescription ?>">
    <link rel="canonical" href="<?= APP_URL ?>/blog/<?= htmlspecialchars($post['slug']) ?>">
    
    <!-- Open Graph -->
    <meta property="og:title" content="<?= $pageTitle ?>">
    <meta property="og:description" content="<?= $pageDescription ?>">
    <meta property="og:type" content="article">
    <?php if (!empty($post['featured_image'])): ?>
        <meta property="og:image" content="<?= htmlspecialchars($post['featured_image']) ?>">
    <?php endif; ?>
    
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <style>
        body { font-family: 'Inter', sans-serif; }
        .prose h1 { font-size: 2.5rem; font-weight: 800; margin-bottom: 1.5rem; line-height: 1.2; }
        .prose h2 { font-size: 1.8rem; font-weight: 700; margin-top: 2.5rem; margin-bottom: 1rem; }
        .prose h3 { font-size: 1.4rem; font-weight: 600; margin-top: 2rem; margin-bottom: 1rem; }
        .prose p { margin-bottom: 1.5rem; font-size: 1.125rem; line-height: 1.8; color: #374151; }
        .prose ul, .prose ol { margin-bottom: 1.5rem; padding-left: 1.5rem; }
        .prose ul { list-style-type: disc; }
        .prose ol { list-style-type: decimal; }
        .prose li { margin-bottom: 0.5rem; font-size: 1.125rem; color: #374151; }
        .prose blockquote { border-left: 4px solid #7c3aed; padding-left: 1rem; margin: 2rem 0; font-style: italic; color: #4b5563; }
        .prose img { border-radius: 1rem; margin: 2rem 0; width: 100%; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1); }
        .prose a { color: #7c3aed; text-decoration: underline; font-weight: 500; }
        .prose pre { background: #1f2937; color: white; padding: 1.5rem; border-radius: 0.75rem; overflow-x: auto; margin-bottom: 1.5rem; }
    </style>
</head>
<body class="bg-gray-50 flex flex-col min-h-screen">

    <!-- Navbar -->
    <nav class="bg-white shadow-sm border-b sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <a href="index.php" class="flex items-center gap-2">
                    <div class="w-10 h-10 rounded-xl bg-purple-600 flex items-center justify-center text-white">
                        <i class="fas fa-link"></i>
                    </div>
                    <span class="text-xl font-bold">SnapLink Pro</span>
                </a>
                
                <div class="hidden md:flex items-center space-x-6">
                    <a href="index.php" class="text-gray-700 hover:text-purple-600">Home</a>
                    <a href="blog.php" class="text-gray-700 hover:text-purple-600">Back to Blog</a>
                </div>
                
                <div class="flex items-center gap-4">
                    <?php if ($user): ?>
                        <a href="dashboard.php" class="px-4 py-2 bg-purple-600 text-white rounded-lg font-semibold">Dashboard</a>
                    <?php else: ?>
                        <a href="login.php" class="text-gray-700">Login</a>
                        <a href="register.php" class="px-4 py-2 bg-purple-600 text-white rounded-lg font-semibold">Get Started</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <!-- Content -->
    <main class="flex-grow py-12 px-4">
        <article class="max-w-3xl mx-auto bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
            
            <?php if (!empty($post['featured_image'])): ?>
                <div class="aspect-video w-full overflow-hidden">
                    <img src="<?= htmlspecialchars($post['featured_image']) ?>" alt="<?= htmlspecialchars($post['title']) ?>" class="w-full h-full object-cover">
                </div>
            <?php else: ?>
                <div class="h-64 bg-gradient-to-r from-purple-600 to-pink-600"></div>
            <?php endif; ?>
            
            <div class="p-8 md:p-12">
                <header class="mb-8">
                    <div class="flex items-center gap-3 text-sm text-gray-500 mb-4">
                        <span class="px-3 py-1 bg-purple-100 text-purple-700 rounded-full font-medium">Article</span>
                        <span>&bull;</span>
                        <span><?= date('F d, Y', strtotime($post['created_at'])) ?></span>
                    </div>
                    <h1 class="text-3xl md:text-5xl font-extrabold text-gray-900 leading-tight mb-6">
                        <?= htmlspecialchars($post['title']) ?>
                    </h1>
                    <div class="flex items-center gap-3 border-t border-b border-gray-100 py-4">
                        <div class="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center">
                            <i class="fas fa-user text-gray-500"></i>
                        </div>
                        <div>
                            <p class="text-sm font-bold text-gray-900"><?= htmlspecialchars($post['author'] ?? 'SnapLink Pro Team') ?></p>
                            <p class="text-xs text-gray-500">Author</p>
                        </div>
                    </div>
                </header>
                
                <div class="prose max-w-none">
                    <?= $post['content'] ?>
                </div>
            </div>
            
        </article>
        
        <!-- CTA -->
        <div class="max-w-3xl mx-auto mt-12 mb-8 bg-purple-900 rounded-2xl p-8 md:p-12 text-center text-white relative overflow-hidden">
            <div class="absolute inset-0 opacity-10 pattern-dots"></div>
            <h2 class="text-2xl md:text-3xl font-bold mb-4">Start creating your own short links today</h2>
            <p class="text-purple-200 mb-8 max-w-xl mx-auto">Join thousands of creators and businesses using SnapLink Pro to manage their links.</p>
            <a href="register.php" class="inline-block px-8 py-4 bg-white text-purple-900 rounded-xl font-bold hover:bg-gray-100 transition shadow-lg">
                Get Started for Free
            </a>
        </div>
    </main>

    <!-- Footer -->
    <?php include ROOT_PATH . '/components/footer.php'; ?>

</body>
</html>
