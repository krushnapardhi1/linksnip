﻿<?php
/**
 * API Key Management Page
 * Allows users to create, view, and revoke API keys
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

// Check if user is logged in
$user = current_user();
if (!$user) {
    redirect('login.php');
}

$db = db()->getConnection();

// Fetch user's API keys
$stmt = $db->prepare("SELECT * FROM api_keys WHERE user_id = ? ORDER BY created_at DESC");
$stmt->execute([$user['id']]);
$apiKeys = $stmt->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = "API Keys - SnapLink Pro";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        .brand-purple { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
    </style>
</head>
<body class="bg-gray-50">

    <!-- Navbar -->
    <nav class="bg-white shadow-sm border-b sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <a href="index.php" class="flex items-center gap-2">
                    <div class="w-10 h-10 rounded-xl bg-purple-600 flex items-center justify-center text-white">
                        <i class="fas fa-link"></i>
                    </div>
                    <span class="text-xl font-bold">SnapLink Pro</span>
                </a>
                
                <div class="flex items-center gap-4">
                    <a href="dashboard.php" class="text-gray-700 hover:text-purple-600">
                        <i class="fas fa-arrow-left mr-2"></i>Back to Dashboard
                    </a>
                    <a href="logout.php" class="text-gray-500 hover:text-red-600">
                        <i class="fas fa-sign-out-alt"></i>
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="max-w-5xl mx-auto px-4 py-8">
        
        <!-- Header -->
        <div class="mb-8">
            <h1 class="text-3xl font-bold text-gray-900 mb-2">API Keys</h1>
            <p class="text-gray-600">Manage your API keys for programmatic access to SnapLink Pro</p>
        </div>

        <!-- Generate New Key Button -->
        <div class="bg-gradient-to-r from-purple-600 to-pink-600 rounded-2xl p-8 mb-8 text-white">
            <div class="flex items-center justify-between">
                <div>
                    <h2 class="text-2xl font-bold mb-2">Generate New API Key</h2>
                    <p class="opacity-90">Use API keys to integrate SnapLink Pro with your applications</p>
                </div>
                <button onclick="generateAPIKey()" class="px-6 py-3 bg-white text-purple-600 rounded-lg font-semibold hover:bg-gray-100 transition">
                    <i class="fas fa-plus mr-2"></i>Generate Key
                </button>
            </div>
        </div>

        <!-- API Keys List -->
        <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
            <div class="p-6 border-b">
                <h3 class="text-xl font-bold text-gray-900">Your API Keys</h3>
                <p class="text-sm text-gray-500 mt-1"><?= count($apiKeys) ?> active key(s)</p>
            </div>
            
            <?php if (empty($apiKeys)): ?>
                <div class="p-12 text-center">
                    <div class="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-key text-3xl text-gray-400"></i>
                    </div>
                    <h3 class="text-lg font-semibold text-gray-900 mb-2">No API Keys Yet</h3>
                    <p class="text-gray-500 mb-6">Generate your first API key to start using the SnapLink Pro API</p>
                    <button onclick="generateAPIKey()" class="px-6 py-3 bg-purple-600 text-white rounded-lg font-semibold hover:bg-purple-700">
                        Generate Your First Key
                    </button>
                </div>
            <?php else: ?>
                <div class="divide-y">
                    <?php foreach ($apiKeys as $key): ?>
                        <div class="p-6 hover:bg-gray-50 transition">
                            <div class="flex items-start justify-between">
                                <div class="flex-1">
                                    <div class="flex items-center gap-3 mb-3">
                                        <h4 class="text-lg font-bold text-gray-900">
                                            <?= htmlspecialchars($key['name'] ?: 'API Key') ?>
                                        </h4>
                                        <?php if ($key['is_active']): ?>
                                            <span class="px-3 py-1 bg-green-100 text-green-700 text-xs font-semibold rounded-full">
                                                Active
                                            </span>
                                        <?php else: ?>
                                            <span class="px-3 py-1 bg-red-100 text-red-700 text-xs font-semibold rounded-full">
                                                Revoked
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="bg-gray-100 p-4 rounded-lg mb-3 font-mono text-sm flex items-center justify-between">
                                        <code class="text-gray-700" id="key-<?= $key['id'] ?>">
                                            <?= htmlspecialchars($key['api_key']) ?>
                                        </code>
                                        <button onclick="copyKey('<?= htmlspecialchars($key['api_key']) ?>', <?= $key['id'] ?>)" 
                                                class="ml-4 px-3 py-1 bg-purple-600 text-white rounded hover:bg-purple-700 text-xs">
                                            <i class="fas fa-copy mr-1"></i>
                                            <span id="copy-btn-<?= $key['id'] ?>">Copy</span>
                                        </button>
                                    </div>
                                    
                                    <div class="flex items-center gap-6 text-sm text-gray-500">
                                        <span>
                                            <i class="far fa-calendar mr-2"></i>
                                            Created: <?= date('M d, Y', strtotime($key['created_at'])) ?>
                                        </span>
                                        <?php if ($key['last_used_at']): ?>
                                            <span>
                                                <i class="far fa-clock mr-2"></i>
                                                Last used: <?= time_ago($key['last_used_at']) ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="text-gray-400">
                                                <i class="far fa-clock mr-2"></i>
                                                Never used
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <?php if ($key['is_active']): ?>
                                    <button onclick="revokeKey(<?= $key['id'] ?>)" 
                                            class="ml-4 px-4 py-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 font-semibold">
                                        <i class="fas fa-ban mr-2"></i>Revoke
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- API Documentation Link -->
        <div class="mt-8 bg-blue-50 border border-blue-200 rounded-xl p-6">
            <div class="flex items-start gap-4">
                <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <i class="fas fa-book text-blue-600 text-xl"></i>
                </div>
                <div>
                    <h3 class="text-lg font-bold text-gray-900 mb-2">Need Help?</h3>
                    <p class="text-gray-600 mb-4">Check out our API documentation to learn how to use your API keys</p>
                    <a href="api-docs.php" class="inline-flex items-center gap-2 text-blue-600 font-semibold hover:text-blue-700">
                        View API Documentation
                        <i class="fas fa-arrow-right"></i>
                    </a>
                </div>
            </div>
        </div>

    </div>

    <!-- Toast Notification -->
    <div id="toast" class="hidden fixed top-4 right-4 bg-green-600 text-white px-6 py-4 rounded-lg shadow-lg z-50 transform transition-all">
        <div class="flex items-center gap-3">
            <i class="fas fa-check-circle text-xl"></i>
            <span id="toast-message">Success!</span>
        </div>
    </div>

    <script>
        function showToast(message, type = 'success') {
            const toast = document.getElementById('toast');
            const toastMessage = document.getElementById('toast-message');
            
            toast.className = `fixed top-4 right-4 px-6 py-4 rounded-lg shadow-lg z-50 transform transition-all ${
                type === 'success' ? 'bg-green-600' : 'bg-red-600'
            } text-white`;
            
            toastMessage.textContent = message;
            toast.classList.remove('hidden');
            
            setTimeout(() => {
                toast.classList.add('hidden');
            }, 3000);
        }

        async function generateAPIKey() {
            const name = prompt('Enter a name for this API key (optional):');
            if (name === null) return; // User cancelled
            
            try {
                const response = await fetch('api/generate-api-key.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ name: name || 'API Key' })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    showToast('API key generated successfully!');
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showToast(data.error || 'Failed to generate API key', 'error');
                }
            } catch (error) {
                showToast('An error occurred', 'error');
            }
        }

        async function revokeKey(keyId) {
            if (!confirm('Are you sure you want to revoke this API key? This action cannot be undone.')) {
                return;
            }
            
            try {
                const response = await fetch('api/revoke-api-key.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ key_id: keyId })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    showToast('API key revoked successfully!');
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showToast(data.error || 'Failed to revoke API key', 'error');
                }
            } catch (error) {
                showToast('An error occurred', 'error');
            }
        }

        function copyKey(key, keyId) {
            navigator.clipboard.writeText(key).then(() => {
                const btn = document.getElementById(`copy-btn-${keyId}`);
                btn.innerHTML = '<i class="fas fa-check mr-1"></i>Copied!';
                setTimeout(() => {
                    btn.innerHTML = '<i class="fas fa-copy mr-1"></i>Copy';
                }, 2000);
            });
        }
    </script>

</body>
</html>
