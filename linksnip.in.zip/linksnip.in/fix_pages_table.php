﻿<?php
/**
 * Fix Pages Table
 * Creates the 'pages' table and seeds it with default content
 */
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';

echo "<h1>Fixing Pages Table...</h1>";

try {
    $db = db();
    
    // Create Pages Table
    echo "Creating 'pages' table...<br>";
    $sql = "CREATE TABLE IF NOT EXISTS pages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        slug VARCHAR(100) NOT NULL UNIQUE,
        title VARCHAR(255) NOT NULL,
        content LONGTEXT NULL,
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_slug (slug)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
    
    $db->execute($sql);
    echo "<span style='color:green'>✅ Table 'pages' checked/created.</span><br>";

    // Seed Data
    $pages = [
        'about-us' => [
            'title' => 'About Us',
            'content' => '<p>Welcome to SnapLink Pro! We are a passionate team dedicated to making URL sharing easier, cleaner, and more powerful.</p><p>Our mission is to provide the best URL shortening service with advanced analytics, custom domains, and bio pages for creators and businesses.</p><h2>Our Story</h2><p>Founded in 2024, SnapLink Pro started as a simple tool and grew into a comprehensive platform trusted by thousands of users worldwide.</p>'
        ],
        'terms-of-service' => [
            'title' => 'Terms of Service',
            'content' => '<p>By using SnapLink Pro, you agree to these terms. Please read them carefully.</p><h2>1. Acceptance of Terms</h2><p>By accessing and using our services, you accept and agree to be bound by the terms and provision of this agreement.</p><h2>2. Use License</h2><p>Permission is granted to temporarily download one copy of the materials (information or software) on SnapLink Pro\'s website for personal, non-commercial transitory viewing only.</p>'
        ],
        'privacy-policy' => [
            'title' => 'Privacy Policy',
            'content' => '<p>Your privacy is important to us. It is SnapLink Pro\'s policy to respect your privacy regarding any information we may collect from you across our website.</p><h2>Information We Collect</h2><p>We only ask for personal information when we truly need it to provide a service to you. We collect it by fair and lawful means, with your knowledge and consent.</p>'
        ],
        'contact' => [
            'title' => 'Contact Us',
            'content' => '<p>Have questions? We\'d love to hear from you.</p><p>Email us at: <a href="mailto:support@snaplink.pro">support@snaplink.pro</a></p>'
        ]
    ];

    echo "Seeding default pages...<br>";
    foreach ($pages as $slug => $data) {
        // Check if exists
        $exists = $db->fetchOne("SELECT id FROM pages WHERE slug = ?", [$slug]);
        
        if (!$exists) {
            $db->insert(
                "INSERT INTO pages (slug, title, content) VALUES (?, ?, ?)", 
                [$slug, $data['title'], $data['content']]
            );
            echo "Created page: <strong>$slug</strong><br>";
        } else {
            echo "Page <strong>$slug</strong> already exists.<br>";
        }
    }

    echo "<h3>Success! Pages are ready.</h3>";
    echo "<a href='page.php?slug=about-us' target='_blank'>View About Us Page</a>";

} catch (Exception $e) {
    echo "<h1>❌ Error</h1>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
}
?>
