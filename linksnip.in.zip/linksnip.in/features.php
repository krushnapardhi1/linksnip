﻿<?php
/**
 * Features Page - SEO Optimized
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

$user = current_user();
$pageTitle = "Features - Free URL Shortener with Analytics | SnapLink Pro";
$pageDescription = "Explore SnapLink Pro's powerful features: custom domains, QR codes, detailed analytics, password protection, link expiration, API access, and more.";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?></title>
    
    <!-- SEO Meta Tags -->
    <meta name="description" content="<?= $pageDescription ?>">
    <meta name="keywords" content="url shortener features, custom domain url shortener, qr code generator, link analytics, password protected links">
    <meta name="author" content="SnapLink Pro">
    <link rel="canonical" href="https://snaplink.pro/features.php">
    
    <!-- Open Graph -->
    <meta property="og:title" content="<?= $pageTitle ?>">
    <meta property="og:description" content="<?= $pageDescription ?>">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://snaplink.pro/features.php">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            background-attachment: fixed;
        }
    </style>
</head>
<body class="text-gray-900">

    <!-- Navbar -->
    <nav class="bg-white shadow-sm border-b sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <a href="index.php" class="flex items-center gap-2">
                    <div class="w-10 h-10 rounded-xl bg-purple-600 flex items-center justify-center text-white">
                        <i class="fas fa-link"></i>
                    </div>
                    <span class="text-xl font-bold">SnapLink Pro</span>
                </a>
                
                <div class="hidden md:flex items-center space-x-6">
                    <a href="index.php" class="text-gray-700 hover:text-purple-600">Home</a>
                    <a href="features.php" class="text-purple-600 font-semibold">Features</a>
                    <a href="how-it-works.php" class="text-gray-700 hover:text-purple-600">How It Works</a>
                    <a href="faq.php" class="text-gray-700 hover:text-purple-600">FAQ</a>
                    <a href="blog.php" class="text-gray-700 hover:text-purple-600">Blog</a>
                </div>
                
                <div class="flex items-center gap-4">
                    <?php if ($user): ?>
                        <a href="dashboard.php" class="px-4 py-2 bg-purple-600 text-white rounded-lg font-semibold hover:bg-purple-700">Dashboard</a>
                    <?php else: ?>
                        <a href="login.php" class="text-gray-700 hover:text-purple-600">Login</a>
                        <a href="register.php" class="px-4 py-2 bg-purple-600 text-white rounded-lg font-semibold hover:bg-purple-700">Get Started</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="py-16 bg-gradient-to-r from-purple-600 to-pink-600">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 class="text-5xl font-extrabold text-white mb-6">Powerful Features for Modern Link Management</h1>
            <p class="text-xl text-white/90 max-w-3xl mx-auto">Everything you need to create, manage, and track your short links effectively</p>
        </div>
    </section>

    <!-- Features Grid -->
    <section class="py-20">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            
            <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                
                <!-- Feature 1: Detailed Analytics -->
                <div class="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all">
                    <div class="w-16 h-16 rounded-xl bg-purple-100 text-purple-600 flex items-center justify-center text-3xl mb-6">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <h2 class="text-2xl font-bold text-gray-900 mb-4">Detailed Analytics</h2>
                    <p class="text-gray-600 mb-4">Track every click with comprehensive analytics including geographic location, device type, browser, operating system, and referrer sources.</p>
                    <ul class="space-y-2 text-gray-600">
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> Real-time click tracking</li>
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> Geographic distribution</li>
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> Device & browser stats</li>
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> Referrer analysis</li>
                    </ul>
                </div>

                <!-- Feature 2: Custom Domains -->
                <div class="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all">
                    <div class="w-16 h-16 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center text-3xl mb-6">
                        <i class="fas fa-globe"></i>
                    </div>
                    <h2 class="text-2xl font-bold text-gray-900 mb-4">Custom Domain URL Shortener</h2>
                    <p class="text-gray-600 mb-4">Brand your links with your own custom domain to increase trust and click-through rates.</p>
                    <ul class="space-y-2 text-gray-600">
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> Add unlimited domains</li>
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> SSL certificates</li>
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> Domain verification</li>
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> Seamless integration</li>
                    </ul>
                </div>

                <!-- Feature 3: QR Codes -->
                <div class="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all">
                    <div class="w-16 h-16 rounded-xl bg-pink-100 text-pink-600 flex items-center justify-center text-3xl mb-6">
                        <i class="fas fa-qrcode"></i>
                    </div>
                    <h2 class="text-2xl font-bold text-gray-900 mb-4">Free QR Code Generator</h2>
                    <p class="text-gray-600 mb-4">Automatically generate QR codes for all your short links for use in print materials and offline campaigns.</p>
                    <ul class="space-y-2 text-gray-600">
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> Auto-generated QR codes</li>
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> High-resolution downloads</li>
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> QR scan tracking</li>
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> Print-ready formats</li>
                    </ul>
                </div>

                <!-- Feature 4: Password Protection -->
                <div class="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all">
                    <div class="w-16 h-16 rounded-xl bg-green-100 text-green-600 flex items-center justify-center text-3xl mb-6">
                        <i class="fas fa-lock"></i>
                    </div>
                    <h2 class="text-2xl font-bold text-gray-900 mb-4">Password Protection</h2>
                    <p class="text-gray-600 mb-4">Secure your links with password protection for private or sensitive content sharing.</p>
                    <ul class="space-y-2 text-gray-600">
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> Encrypted passwords</li>
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> Easy sharing</li>
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> Access control</li>
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> Track attempts</li>
                    </ul>
                </div>

                <!-- Feature 5: Link Expiration -->
                <div class="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all">
                    <div class="w-16 h-16 rounded-xl bg-orange-100 text-orange-600 flex items-center justify-center text-3xl mb-6">
                        <i class="fas fa-clock"></i>
                    </div>
                    <h2 class="text-2xl font-bold text-gray-900 mb-4">Link Expiration & Scheduling</h2>
                    <p class="text-gray-600 mb-4">Set expiration dates or click limits for temporary campaigns and time-sensitive content.</p>
                    <ul class="space-y-2 text-gray-600">
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> Date-based expiration</li>
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> Click limit control</li>
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> Scheduled publishing</li>
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> Auto-deactivation</li>
                    </ul>
                </div>

                <!-- Feature 6: API Access -->
                <div class="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all">
                    <div class="w-16 h-16 rounded-xl bg-indigo-100 text-indigo-600 flex items-center justify-center text-3xl mb-6">
                        <i class="fas fa-code"></i>
                    </div>
                    <h2 class="text-2xl font-bold text-gray-900 mb-4">REST API Access</h2>
                    <p class="text-gray-600 mb-4">Integrate SnapLink Pro into your applications with our powerful and easy-to-use REST API.</p>
                    <ul class="space-y-2 text-gray-600">
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> RESTful endpoints</li>
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> Authentication tokens</li>
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> Complete documentation</li>
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> Rate limiting</li>
                    </ul>
                </div>

                <!-- Feature 7: Bio Pages -->
                <div class="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all">
                    <div class="w-16 h-16 rounded-xl bg-yellow-100 text-yellow-600 flex items-center justify-center text-3xl mb-6">
                        <i class="fas fa-id-card"></i>
                    </div>
                    <h2 class="text-2xl font-bold text-gray-900 mb-4">Bio Link Pages</h2>
                    <p class="text-gray-600 mb-4">Create beautiful bio pages with multiple links for your social media profiles.</p>
                    <ul class="space-y-2 text-gray-600">
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> Customizable themes</li>
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> Social media links</li>
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> Analytics tracking</li>
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> Mobile optimized</li>
                    </ul>
                </div>

                <!-- Feature 8: Spam Protection -->
                <div class="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all">
                    <div class="w-16 h-16 rounded-xl bg-red-100 text-red-600 flex items-center justify-center text-3xl mb-6">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <h2 class="text-2xl font-bold text-gray-900 mb-4">Spam & Fraud Protection</h2>
                    <p class="text-gray-600 mb-4">Advanced spam detection and fraud prevention to keep your links safe and trusted.</p>
                    <ul class="space-y-2 text-gray-600">
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> Malware detection</li>
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> Blacklist checking</li>
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> Abuse reporting</li>
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> Safe browsing</li>
                    </ul>
                </div>

                <!-- Feature 9: Device Targeting -->
                <div class="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all">
                    <div class="w-16 h-16 rounded-xl bg-teal-100 text-teal-600 flex items-center justify-center text-3xl mb-6">
                        <i class="fas fa-mobile-alt"></i>
                    </div>
                    <h2 class="text-2xl font-bold text-gray-900 mb-4">Device-Specific Redirects</h2>
                    <p class="text-gray-600 mb-4">Send users to different destinations based on their device type for optimized experiences.</p>
                    <ul class="space-y-2 text-gray-600">
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> Mobile redirects</li>
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> iOS targeting</li>
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> Android targeting</li>
                        <li class="flex items-center gap-2"><i class="fas fa-check text-green-500"></i> Desktop fallback</li>
                    </ul>
                </div>

            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="py-16 bg-gradient-to-r from-purple-600 to-pink-600">
        <div class="max-w-4xl mx-auto px-4 text-center">
            <h2 class="text-4xl font-bold text-white mb-6">Ready to Get Started?</h2>
            <p class="text-xl text-white/90 mb-8">Join thousands of users who trust SnapLink Pro for their URL shortening needs</p>
            <a href="register.php" class="inline-block px-8 py-4 bg-white text-purple-600 rounded-lg font-bold text-lg hover:bg-gray-100 transition shadow-xl">
                Create Free Account
            </a>
        </div>
    </section>

    <!-- Footer -->
    <?php include ROOT_PATH . '/components/footer.php'; ?>

</body>
</html>
