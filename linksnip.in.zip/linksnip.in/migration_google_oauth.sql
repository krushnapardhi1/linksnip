﻿-- Migration Script for Google OAuth
-- Run this if you've already installed SnapLink Pro before this update
-- This adds the necessary columns for Google OAuth authentication

USE your_database_name; -- Replace with your actual database name

-- Add google_id and avatar columns to users table if they don't exist
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS google_id VARCHAR(255) DEFAULT NULL AFTER name,
ADD COLUMN IF NOT EXISTS avatar TEXT DEFAULT NULL AFTER google_id,
ADD INDEX IF NOT EXISTS idx_google_id (google_id);

-- Add pages table for CMS if it doesn't exist
CREATE TABLE IF NOT EXISTS pages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    content TEXT NOT NULL,
    meta_description TEXT,
    show_in_nav BOOLEAN DEFAULT FALSE,
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_slug (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
