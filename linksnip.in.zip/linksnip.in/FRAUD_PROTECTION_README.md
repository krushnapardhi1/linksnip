﻿# Anti-Fraud & Traffic Protection System
## Complete Implementation Guide

## 📦 What's Included

### 1. Database Tables
- **click_logs** - Detailed traffic logging with fraud detection
- **banned_ips** - IP ban management (temp & permanent)
- **banned_users** - User ban management
- **fraud_rules** - Customizable auto-ban rules

### 2. TrafficProtection Class
Location: `config/TrafficProtection.php`

**Features:**
- ✅ IP Ban checking (temp & permanent)
- ✅ User Ban checking
- ✅ Headless browser detection
-  Invalid User-Agent detection
- ✅ Bot referrer detection
- ✅ Datacenter/VPN/Proxy detection (using ipinfo.io)
- ✅ Rate limiting (configurable thresholds)
- ✅ Comprehensive click logging
- ✅ Device & browser detection

### 3. Redirect Integration
Location: `r.php` (updated)

**Protection Flow:**
1. Check if IP is banned → Block
2. Detect headless browsers → Ban 24h
3. Check for invalid UA → Ban 24h
4. Rate limit check (50 clicks/10s) → Ban 1h
5. Optional: VPN/Datacenter detection
6. Log click with fraud flag
7. Allow redirect

### 4. Admin Fraud Control Panel
Location: `admin/fraud.php`

**Dashboard Features:**
- 📊 Real-time fraud statistics
- 📈 Geo distribution charts
- 🚨 Suspicious traffic alerts
- 📋 Top IP abusers list
- 🛡️ Manual IP ban/unban
- 👤 Manual user ban/unban
- 📊 Fraud detection rate visualization

---

## 🚀 Installation Steps

### Step 1: Run Database Migration
```sql
-- Execute this in phpMyAdmin or MySQL:
SOURCE migration_fraud_protection.sql;
```

Or import via phpMyAdmin:
1. Login to phpMyAdmin
2. Select your `snaplink` database
3. Click "Import"
4. Choose `migration_fraud_protection.sql`
5. Execute

### Step 2: Upload Files

Upload these files to your server:
```
php-version/
├── config/
│   └── TrafficProtection.php        (NEW)
├── admin/
│   └── fraud.php                     (NEW)
├── r.php                              (UPDATED)
└── migration_fraud_protection.sql    (RUN ONCE)
```

### Step 3: Add Admin Menu Link

Edit `admin/partials/sidebar.php` and add:
```php
<a href="fraud.php" class="flex items-center gap-3 px-4 py-3 text-gray-700 hover:bg-purple-50 hover:text-purple-600 rounded-lg transition">
    <i class="fas fa-shield-alt w-5"></i>
    <span>Fraud Control</span>
</a>
```

### Step 4: Test

1. Visit a short link normally → Should work
2. Try rapid clicking (>50 in 10s) → Should block
3. Check `admin/fraud.php` → See statistics
4. Ban an IP manually → Test blocked access

---

## 🛡️ Protection Rules

### Default Ban Triggers

| Trigger | Action | Duration |
|---------|--------|----------|
| Headless Browser | Auto-ban | 24 hours |
| No User-Agent | Auto-ban | 24 hours |
| >50 clicks in 10s | Auto-ban | 1 hour |
| Datacenter IP | Flag only | (configurable) |
| Bot referrer | Flag only | (optional) |

### Customization

Edit thresholds in `config/TrafficProtection.php`:

```php
// Line 174: Rate limit
if (!$this->checkRateLimit(50, 10)) {  // 50 clicks, 10 seconds
    $this->banIP("Rate limit exceeded", 1); // 1 hour ban
}
```

Change values as needed:
- `(20, 5)` = 20 clicks in 5 seconds
- `(100, 60)` = 100 clicks in 60 seconds

---

## 📊 Admin Panel Usage

### View Dashboard
Visit: `https://snaplink.pro/php-version/admin/fraud.php`

### Ban an IP Manually
1. Click "Ban New IP" button
2. Enter IP address
3. Enter reason
4. Set duration (hours or blank for permanent)

### Unban an IP
1. Find IP in "Banned IP Addresses" table
2. Click "Unban" button

### Monitor Suspicious Traffic
- Check "Top IP Addresses" table
- IPs with >100 clicks are flagged red
- Click "Ban" to block abusers instantly

---

## 🔧 Advanced Configuration

### Disable VPN Detection
If you want to allow VPN/datacenter traffic:

In `TrafficProtection.php`, comment out:
```php
// Line 183-188
if ($this->isDatacenterIP()) {
    // $this->banIP("Datacenter/VPN", 12);  // Commented = Allow
}
```

### Add Custom Bot Patterns
In `TrafficProtection.php`, line 78:
```php
$patterns = [
    'HeadlessChrome',
    'Puppeteer',
    'YourCustomBot',  // Add here
    // ... more patterns
];
```

### Change IP Info API
Default: ipinfo.io (50k requests/month free)

To use different service, edit line 146:
```php
$response = @file_get_contents("YOUR_API_URL/$ip");
```

---

## 📈 What Gets Logged

Every click logs:
- ✅ IP address
- ✅ Country/City
- ✅ User Agent
- ✅ Referrer
- ✅ Device type
- ✅ Browser
- ✅ ISP/Organization
- ✅ Fraud flag (suspicious yes/no)

View in database: `click_logs` table

---

## 🧪 Testing

### Test Bot Block
```bash
curl https://snaplink.pro/yourlink
# Should be blocked (headless detected)
```

### Test Rate Limit
Use a tool to send rapid requests:
```bash
for i in {1..60}; do curl https://snaplink.pro/yourlink & done
# Should ban after 50 clicks
```

### Test Admin Panel
1. Visit `admin/fraud.php`
2. Should see all stats
3. Charts should render
4. Ban/unban buttons should work

---

## 🚨 Troubleshooting

### "Table doesn't exist" error
- Run `migration_fraud_protection.sql` again
- Check database name in config

### Admin panel shows 0 stats
- Generate some clicks first
- Check click_logs table has data

### Legitimate users getting banned
- Increase rate limits in TrafficProtection.php
- Disable VPN detection if needed
- Check banned_ips table and unban

### IP info not working
- Check ipinfo.io API limit (50k/month)
- Add error logging to debug
- API might be slow/down

---

## 📝 Future Enhancements

You can add:
- [ ] Whitelist IPs (trusted sources)
- [ ] Custom fraud rules UI (no code editing needed)
- [ ] Email alerts for high fraud activity
- [ ] Export ban logs to CSV
- [ ] Integration with Cloudflare Bot Management
- [ ] Machine learning fraud scoring

---

## 🎯 Summary

**What you now have:**
✅ Automatic bot detection & blocking
✅ VPN/Proxy detection
✅ Rate limit protection
✅ Manual ban system
✅ Comprehensive traffic logs
✅ Admin fraud dashboard
✅ Real-time fraud monitoring

**Protection activated on:**
- All short link redirects (`r.php`)
- All click tracking
- All QR scans

**Result:**
Your SnapLink Pro installation is now protected against:
- Bot traffic
- Click fraud
- Scraping
- DDoS/rate abuse
- Headless browsers
- Datacenter attacks

---

## 💡 Need Help?

1. Check click_logs table for fraud patterns
2. Review banned_ips table for bans
3. Test with curl/wget to simulate bots
4. Check admin/fraud.php for statistics

**Remember:** Ban duration is in HOURS
- Temp: 1, 24, 72 hours
- Permanent: NULL (no expires_at value)

Enjoy your fraud-protected URL shortener! 🎉
