﻿<?php
/**
 * URL Redirect Handler
 * Updated to use 'links' table schema
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once __DIR__ . '/config/database.php';

// Get the short code from the URL
$requestUri = $_SERVER['REQUEST_URI'];

// Clean up the path
$basePath = str_replace('/index.php', '', $_SERVER['SCRIPT_NAME']);
$path = parse_url($requestUri, PHP_URL_PATH);

// Remove base path if valid (fixes subdirectory issues)
if (strlen($basePath) > 1 && strpos($path, $basePath) === 0) {
    $path = substr($path, strlen($basePath));
}
$path = trim($path, '/');

// Skip if accessing a PHP file or known directory
if (empty($path) || 
    preg_match('/\.(php|html|css|js|ico|png|jpg|gif|svg|woff|woff2|ttf|eot)$/i', $path) ||
    in_array(strtolower(explode('/', $path)[0]), ['api', 'admin', 'assets', 'config', 'components'])) {
    
    // If it's a real file, let server handle it
    if (file_exists(__DIR__ . '/' . $path)) {
        return false;
    }
    // Otherwise it's just not a short code (e.g. users going to /admin but file missing)
    http_response_code(404);
    echo "File not found"; 
    exit;
}

$code = $path;

// Handle QR scan tracking check (if you use /qr/CODE)
$isQrScan = strpos($requestUri, '/qr/') !== false;
if ($isQrScan) {
    $code = str_replace('qr/', '', $code);
    $code = trim($code, '/');
}

try {
    // Look up the URL in 'links' table
    // Only selecting columns that ACTUALLY exist in your schema:
    // id, long_url, short_code, user_id, guest_ip, title, description, clicks, is_active, created_at, updated_at
    $url = db()->fetchOne(
        "SELECT id, long_url, is_active, clicks FROM links WHERE short_code = ?",
        [$code]
    );

    if (!$url) {
        http_response_code(404);
        showError('Short URL not found');
        exit;
    }

    // Check if active
    if (!$url['is_active']) {
        http_response_code(410);
        showError('This link has been disabled');
        exit;
    }

    // Update click count
    db()->execute('UPDATE links SET clicks = clicks + 1 WHERE id = ?', [$url['id']]);

    // Check for Interstitial Ad
    $interstitialAd = get_site_setting('interstitial_ad_code');
    if (!empty(trim($interstitialAd))) {
        showInterstitialAd($url['long_url'], $interstitialAd);
        exit;
    }

    // Redirect
    header("Location: " . $url['long_url'], true, 302);
    exit;

} catch (Exception $e) {
    error_log("Redirect Error: " . $e->getMessage());
    showError('System error occurred');
}

/**
 * Show error page
 */
function showError($message) {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Error - SnapLink Pro</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    </head>
    <body class="bg-gradient-to-br from-purple-600 to-pink-500 min-h-screen flex items-center justify-center p-4 font-[Inter]">
        <div class="bg-white rounded-2xl shadow-2xl p-8 max-w-sm w-full text-center">
            <div class="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <i class="fas fa-exclamation-triangle text-2xl text-red-600"></i>
            </div>
            <h1 class="text-2xl font-bold text-gray-900 mb-2">Oops!</h1>
            <p class="text-gray-500 mb-6"><?= htmlspecialchars($message) ?></p>
            <a href="index.php" class="inline-block px-6 py-3 bg-purple-600 text-white rounded-xl font-semibold hover:bg-purple-700 transition">
                <i class="fas fa-home mr-2"></i> Go Home
            </a>
        </div>
    </body>
    </html>
    <?php
}

/**
 * Show Interstitial Ad Page
 */
function showInterstitialAd($longUrl, $adCode) {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Redirecting... - SnapLink Pro</title>
        <meta http-equiv="refresh" content="6;url=<?= htmlspecialchars($longUrl, ENT_QUOTES, 'UTF-8') ?>">
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
        <style>
            body { font-family: 'Inter', sans-serif; }
            .ad-container { min-height: 250px; display: flex; align-items: center; justify-content: center; }
        </style>
    </head>
    <body class="bg-gray-50 min-h-screen flex flex-col items-center justify-center p-4">
        <div class="bg-white rounded-2xl shadow-xl p-8 max-w-2xl w-full text-center">
            <h1 class="text-2xl font-bold text-gray-900 mb-2">You are being redirected...</h1>
            <p class="text-gray-500 mb-6">Please wait <span id="countdown" class="font-bold text-purple-600">5</span> seconds.</p>
            
            <div class="w-full bg-gray-100 rounded-xl mb-6 overflow-hidden ad-container border border-gray-200 relative">
                <span class="absolute top-2 left-2 text-xs text-gray-400 bg-white/80 px-2 py-1 rounded">Advertisement</span>
                <?= $adCode ?>
            </div>
            
            <a href="<?= htmlspecialchars($longUrl, ENT_QUOTES, 'UTF-8') ?>" id="skipBtn" class="inline-block px-6 py-3 bg-purple-600 text-white rounded-xl font-semibold hover:bg-purple-700 transition opacity-50 cursor-not-allowed pointer-events-none">
                Skip Ad & Continue <i class="fas fa-arrow-right ml-2"></i>
            </a>
        </div>
        <script>
            let timeLeft = 5;
            const countdownEl = document.getElementById('countdown');
            const skipBtn = document.getElementById('skipBtn');
            
            const timer = setInterval(() => {
                timeLeft--;
                countdownEl.textContent = timeLeft;
                
                if (timeLeft <= 0) {
                    clearInterval(timer);
                    skipBtn.classList.remove('opacity-50', 'cursor-not-allowed', 'pointer-events-none');
                    skipBtn.textContent = 'Continue to Destination';
                    window.location.href = "<?= addslashes($longUrl) ?>";
                }
            }, 1000);
        </script>
    </body>
    </html>
    <?php
}
?>
