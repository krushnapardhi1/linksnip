-- Stripe Billing Migration
-- Tables for plans, subscriptions, and payments

-- 1. Subscription Plans Table
CREATE TABLE IF NOT EXISTS `subscription_plans` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `stripe_price_id` VARCHAR(100) NULL, -- Stripe Price ID (e.g., price_H5ggY...)
    `name` VARCHAR(50) NOT NULL,         -- Basic, Pro, Business
    `description` TEXT,
    `price_monthly` DECIMAL(10, 2) NOT NULL,
    `price_yearly` DECIMAL(10, 2) NULL,
    `currency` VARCHAR(3) DEFAULT 'USD',
    `features` JSON,                     -- JSON array of features
    `link_limit` INT DEFAULT 1000,       -- -1 for unlimited
    `custom_domains` INT DEFAULT 0,
    `is_active` BOOLEAN DEFAULT TRUE,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. User Subscriptions Table
CREATE TABLE IF NOT EXISTS `user_subscriptions` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `user_id` INT NOT NULL,
    `plan_id` INT NOT NULL,
    `stripe_customer_id` VARCHAR(100) NULL,
    `stripe_subscription_id` VARCHAR(100) NULL,
    `status` VARCHAR(20) DEFAULT 'inactive', -- active, past_due, canceled, incomplete
    `current_period_start` TIMESTAMP NULL,
    `current_period_end` TIMESTAMP NULL,
    `cancel_at_period_end` BOOLEAN DEFAULT FALSE,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX `idx_user_id` (`user_id`),
    INDEX `idx_stripe_cust` (`stripe_customer_id`),
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Invoices/Payments Table
CREATE TABLE IF NOT EXISTS `user_invoices` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `user_id` INT NOT NULL,
    `stripe_invoice_id` VARCHAR(100) NOT NULL,
    `amount` DECIMAL(10, 2) NOT NULL,
    `currency` VARCHAR(3) DEFAULT 'USD',
    `status` VARCHAR(20) NOT NULL, -- paid, open, void, uncollectible
    `invoice_pdf` VARCHAR(500) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Seed Default Plans if not exists
INSERT INTO `subscription_plans` (`name`, `description`, `price_monthly`, `link_limit`, `custom_domains`, `features`) 
SELECT 'Free', 'For personal use', 0.00, 50, 0, '["50 Links", "Basic Analytics", "Ad-supported"]'
WHERE NOT EXISTS (SELECT * FROM subscription_plans WHERE name = 'Free');

INSERT INTO `subscription_plans` (`name`, `description`, `price_monthly`, `link_limit`, `custom_domains`, `features`) 
SELECT 'Pro', 'For creators & professionals', 9.99, 1000, 5, '["1,000 Links", "5 Custom Domains", "Password Protection", "No Ads", "API Access"]'
WHERE NOT EXISTS (SELECT * FROM subscription_plans WHERE name = 'Pro');

INSERT INTO `subscription_plans` (`name`, `description`, `price_monthly`, `link_limit`, `custom_domains`, `features`) 
SELECT 'Business', 'For agencies & teams', 29.99, 10000, 20, '["10,000 Links", "20 Custom Domains", "Priority Support", "Team Features", "Advanced Analytics"]'
WHERE NOT EXISTS (SELECT * FROM subscription_plans WHERE name = 'Business');
