﻿<?php
/**
 * Two-Factor Authentication Setup
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';
require_once ROOT_PATH . '/utils/GoogleAuthenticator.php';

require_login();
$user = current_user();
$db = db()->getConnection();
$ga = new PHPGangsta_GoogleAuthenticator();

$message = '';
$error = '';

// Form Handling
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['enable_2fa'])) {
        // First step: Verify code matches the secret being set up
        $secret = $_POST['secret'];
        $code = $_POST['code'];
        
        if ($ga->verifyCode($secret, $code)) {
            // Save secret and enable
            $stmt = $db->prepare("UPDATE users SET two_factor_secret = ?, two_factor_enabled = 1 WHERE id = ?");
            $stmt->execute([$secret, $user['id']]);
            $message = 'Two-factor authentication enabled successfully!';
            
            // Refresh user session data if stored in session
            $_SESSION['user']['two_factor_enabled'] = 1;
            $user['two_factor_enabled'] = 1;
        } else {
            $error = 'Invalid verification code. Please try again.';
        }
    } elseif (isset($_POST['disable_2fa'])) {
        $stmt = $db->prepare("UPDATE users SET two_factor_secret = NULL, two_factor_enabled = 0 WHERE id = ?");
        $stmt->execute([$user['id']]);
        $message = 'Two-factor authentication disabled.';
        
        $_SESSION['user']['two_factor_enabled'] = 0;
        $user['two_factor_enabled'] = 0;
    }
}

// Prepare View Data
$is2FAEnabled = $user['two_factor_enabled'] ?? false;
$newSecret = null;
$qrCodeUrl = null;

if (!$is2FAEnabled) {
    // Generate new secret for setup
    $newSecret = $ga->createSecret();
    
    // Construct OTP Auth URL manually
    $otpAuthUrl = "otpauth://totp/SnapLink Pro:" . $user['email'] . "?secret=" . $newSecret . "&issuer=SnapLink Pro";
    
    // Use a reliable QR code API (GoQR.me or QRServer)
    $qrCodeUrl = "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=" . urlencode($otpAuthUrl);
}

$pageTitle = "Two-Factor Authentication - SnapLink Pro";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style> body { font-family: 'Inter', sans-serif; } </style>
</head>
<body class="bg-gray-50">

    <!-- Navbar -->
    <nav class="bg-white shadow-sm border-b sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <a href="index.php" class="flex items-center gap-2">
                    <div class="w-10 h-10 rounded-xl bg-purple-600 flex items-center justify-center text-white">
                        <i class="fas fa-link"></i>
                    </div>
                    <span class="text-xl font-bold">SnapLink Pro</span>
                </a>
                
                <div class="flex items-center gap-4">
                    <a href="dashboard.php" class="text-gray-700 hover:text-purple-600">
                        <i class="fas fa-arrow-left mr-2"></i>Dashboard
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="max-w-xl mx-auto px-4 py-8">
        
        <h1 class="text-3xl font-bold text-gray-900 mb-8">Two-Factor Authentication</h1>

        <?php if ($message): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <div class="bg-white rounded-2xl shadow-lg p-8">
            <?php if ($is2FAEnabled): ?>
                
                <div class="text-center mb-6">
                    <div class="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-shield-alt text-4xl text-green-600"></i>
                    </div>
                    <h2 class="text-2xl font-bold text-gray-900 mb-2">2FA is Enabled</h2>
                    <p class="text-gray-600">Your account is protected with two-factor authentication.</p>
                </div>

                <form method="POST" onsubmit="return confirm('Are you sure you want to disable 2FA? This will make your account less secure.');">
                    <button type="submit" name="disable_2fa" class="w-full py-3 bg-red-600 text-white font-bold rounded-xl hover:bg-red-700 transition">
                        Disable 2FA
                    </button>
                </form>

            <?php else: ?>

                <div class="text-center mb-6">
                    <h2 class="text-xl font-bold text-gray-900 mb-2">Enable 2FA</h2>
                    <p class="text-gray-600 text-sm mb-6">
                        Use an authenticator app like Google Authenticator or Authy to scan the QR code below.
                    </p>
                    
                    <div class="border-4 border-gray-100 rounded-xl inline-block p-2 mb-4">
                        <img src="<?= $qrCodeUrl ?>" alt="QR Code" class="mx-auto">
                    </div>

                    <p class="text-sm text-gray-500 mb-2">Can't scan the QR code?</p>
                    <code class="bg-gray-100 px-3 py-1 rounded text-sm font-mono select-all"><?= $newSecret ?></code>
                </div>

                <form method="POST" class="space-y-4">
                    <input type="hidden" name="secret" value="<?= $newSecret ?>">
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Verification Code</label>
                        <input type="text" name="code" required autocomplete="off"
                               class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 text-center tracking-widest text-lg"
                               placeholder="123456">
                    </div>

                    <button type="submit" name="enable_2fa" class="w-full py-3 bg-purple-600 text-white font-bold rounded-xl hover:bg-purple-700 transition">
                        Verify & Enable
                    </button>
                </form>

            <?php endif; ?>
        </div>
    </div>

</body>
</html>
