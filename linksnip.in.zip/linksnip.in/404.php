﻿<?php
/**
 * Custom 404 page
 */
if (!defined('ROOT_PATH')) {
    define('ROOT_PATH', __DIR__);
}
require_once ROOT_PATH . '/config/config.php';

http_response_code(404);
$code = 404;
$message = 'The page you requested could not be found.';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - Page Not Found - SnapLink Pro</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gradient-to-br from-purple-600 to-pink-500 min-h-screen flex items-center justify-center p-4">
    <div class="text-center">
        <div class="text-9xl font-bold text-white/20 mb-4">404</div>
        <div class="bg-white rounded-2xl shadow-2xl p-8 max-w-md mx-auto -mt-20 relative z-10">
            <div class="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <i class="fas fa-exclamation-triangle text-2xl text-red-600"></i>
            </div>
            <h1 class="text-2xl font-bold text-gray-900 mb-2">Page Not Found</h1>
            <p class="text-gray-500 mb-6"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></p>
            <div class="flex flex-col sm:flex-row gap-3 justify-center">
                <a href="index.php" class="px-6 py-3 bg-purple-600 text-white rounded-xl font-semibold hover:bg-purple-700 transition">
                    <i class="fas fa-home mr-2"></i> Go Home
                </a>
                <button onclick="history.back()" class="px-6 py-3 bg-gray-100 text-gray-700 rounded-xl font-semibold hover:bg-gray-200 transition">
                    <i class="fas fa-arrow-left mr-2"></i> Go Back
                </button>
            </div>
        </div>
    </div>
</body>
</html>
