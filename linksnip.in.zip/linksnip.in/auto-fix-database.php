﻿<?php
/**
 * Auto-Fix Guest Links Database Setup
 * This script will automatically fix missing columns and tables
 */
define('ROOT_PATH', dirname(__DIR__));
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Auto-Fix Database - SnapLink Pro</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body class="bg-gray-50">
    <div class="max-w-4xl mx-auto p-8">
        <div class="bg-white rounded-xl shadow-lg p-8">
            <h1 class="text-3xl font-bold text-purple-600 mb-6">
                <i class="fas fa-tools mr-3"></i>Database Auto-Fix
            </h1>
            
            <?php
            $pdo = db();
            $errors = [];
            $fixes = [];
            $warnings = [];
            
            echo "<div class='space-y-4'>";
            
            // Check and fix urls table columns
            echo "<h2 class='text-xl font-bold text-gray-800 mt-6 mb-4'>1. Checking URLs Table...</h2>";
            
            try {
                $stmt = $pdo->query("SHOW COLUMNS FROM urls");
                $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
                
                // Check user_id nullable
                $stmt = $pdo->query("SHOW COLUMNS FROM urls LIKE 'user_id'");
                $userIdCol = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($userIdCol && strtoupper($userIdCol['Null']) === 'NO') {
                    echo "<p class='text-yellow-600'><i class='fas fa-wrench mr-2'></i>Making user_id nullable...</p>";
                    
                    // Drop foreign key if exists
                    $pdo->exec("ALTER TABLE urls DROP FOREIGN KEY IF EXISTS urls_ibfk_1");
                    $pdo->exec("ALTER TABLE urls DROP FOREIGN KEY IF EXISTS fk_urls_user_id");
                    
                    // Make nullable
                    $pdo->exec("ALTER TABLE urls MODIFY COLUMN user_id INT NULL DEFAULT NULL");
                    
                    // Re-add foreign key
                    $pdo->exec("ALTER TABLE urls ADD CONSTRAINT fk_urls_user_id 
                               FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL");
                    
                    echo "<p class='text-green-600'><i class='fas fa-check mr-2'></i>✅ user_id is now nullable</p>";
                    $fixes[] = "Made user_id nullable";
                } else {
                    echo "<p class='text-green-600'><i class='fas fa-check mr-2'></i>user_id is already nullable</p>";
                }
                
                // Check created_by_ip column
                if (!in_array('created_by_ip', $columns)) {
                    echo "<p class='text-yellow-600'><i class='fas fa-wrench mr-2'></i>Adding created_by_ip column...</p>";
                    $pdo->exec("ALTER TABLE urls ADD COLUMN created_by_ip VARCHAR(45) NULL DEFAULT NULL AFTER user_id");
                    $pdo->exec("ALTER TABLE urls ADD INDEX idx_created_by_ip (created_by_ip)");
                    echo "<p class='text-green-600'><i class='fas fa-check mr-2'></i>✅ created_by_ip column added</p>";
                    $fixes[] = "Added created_by_ip column";
                } else {
                    echo "<p class='text-green-600'><i class='fas fa-check mr-2'></i>created_by_ip column exists</p>";
                }
                
                // Check is_guest column
                if (!in_array('is_guest', $columns)) {
                    echo "<p class='text-yellow-600'><i class='fas fa-wrench mr-2'></i>Adding is_guest column...</p>";
                    $pdo->exec("ALTER TABLE urls ADD COLUMN is_guest TINYINT(1) DEFAULT 0 AFTER created_by_ip");
                    $pdo->exec("ALTER TABLE urls ADD INDEX idx_is_guest (is_guest)");
                    echo "<p class='text-green-600'><i class='fas fa-check mr-2'></i>✅ is_guest column added</p>";
                    $fixes[] = "Added is_guest column";
                } else {
                    echo "<p class='text-green-600'><i class='fas fa-check mr-2'></i>is_guest column exists</p>";
                }
                
            } catch (Exception $e) {
                $errors[] = "URLs table error: " . $e->getMessage();
                echo "<p class='text-red-600'><i class='fas fa-times mr-2'></i>Error: " . htmlspecialchars($e->getMessage()) . "</p>";
            }
            
            // Check and create guest_rate_limits table
            echo "<h2 class='text-xl font-bold text-gray-800 mt-6 mb-4'>2. Checking Guest Rate Limits Table...</h2>";
            
            try {
                $stmt = $pdo->query("SHOW TABLES LIKE 'guest_rate_limits'");
                if ($stmt->rowCount() === 0) {
                    echo "<p class='text-yellow-600'><i class='fas fa-wrench mr-2'></i>Creating guest_rate_limits table...</p>";
                    
                    $sql = "CREATE TABLE `guest_rate_limits` (
                        `id` INT PRIMARY KEY AUTO_INCREMENT,
                        `ip_address` VARCHAR(45) NOT NULL,
                        `links_created_today` INT DEFAULT 1,
                        `last_reset_date` DATE NOT NULL,
                        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                        UNIQUE KEY `unique_ip` (`ip_address`),
                        INDEX `idx_last_reset` (`last_reset_date`)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                    
                    $pdo->exec($sql);
                    echo "<p class='text-green-600'><i class='fas fa-check mr-2'></i>✅ guest_rate_limits table created</p>";
                    $fixes[] = "Created guest_rate_limits table";
                } else {
                    echo "<p class='text-green-600'><i class='fas fa-check mr-2'></i>guest_rate_limits table exists</p>";
                }
            } catch (Exception $e) {
                $errors[] = "guest_rate_limits table error: " . $e->getMessage();
                echo "<p class='text-red-600'><i class='fas fa-times mr-2'></i>Error: " . htmlspecialchars($e->getMessage()) . "</p>";
            }
            
            // Check and create guest_sessions table
            echo "<h2 class='text-xl font-bold text-gray-800 mt-6 mb-4'>3. Checking Guest Sessions Table...</h2>";
            
            try {
                $stmt = $pdo->query("SHOW TABLES LIKE 'guest_sessions'");
                if ($stmt->rowCount() === 0) {
                    echo "<p class='text-yellow-600'><i class='fas fa-wrench mr-2'></i>Creating guest_sessions table...</p>";
                    
                    $sql = "CREATE TABLE `guest_sessions` (
                        `id` INT PRIMARY KEY AUTO_INCREMENT,
                        `session_id` VARCHAR(128) NOT NULL,
                        `ip_address` VARCHAR(45) NOT NULL,
                        `user_agent` VARCHAR(255) DEFAULT NULL,
                        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        `expires_at` TIMESTAMP NULL DEFAULT NULL,
                        UNIQUE KEY `unique_session` (`session_id`),
                        INDEX `idx_ip_address` (`ip_address`),
                        INDEX `idx_expires_at` (`expires_at`)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                    
                    $pdo->exec($sql);
                    echo "<p class='text-green-600'><i class='fas fa-check mr-2'></i>✅ guest_sessions table created</p>";
                    $fixes[] = "Created guest_sessions table";
                } else {
                    echo "<p class='text-green-600'><i class='fas fa-check mr-2'></i>guest_sessions table exists</p>";
                }
            } catch (Exception $e) {
                $errors[] = "guest_sessions table error: " . $e->getMessage();
                echo "<p class='text-red-600'><i class='fas fa-times mr-2'></i>Error: " . htmlspecialchars($e->getMessage()) . "</p>";
            }
            
            // Check get_client_ip function
            echo "<h2 class='text-xl font-bold text-gray-800 mt-6 mb-4'>4. Checking Helper Functions...</h2>";
            
            if (function_exists('get_client_ip')) {
                $testIp = get_client_ip();
                echo "<p class='text-green-600'><i class='fas fa-check mr-2'></i>get_client_ip() function exists (detected: $testIp)</p>";
            } else {
                echo "<p class='text-red-600'><i class='fas fa-times mr-2'></i>get_client_ip() function missing</p>";
                $errors[] = "get_client_ip() function not found in config.php";
            }
            
            echo "</div>";
            
            // Summary
            echo "<div class='mt-8 p-6 rounded-lg " . (empty($errors) ? "bg-green-50 border-2 border-green-500" : "bg-yellow-50 border-2 border-yellow-500") . "'>";
            echo "<h2 class='text-2xl font-bold mb-4 " . (empty($errors) ? "text-green-700" : "text-yellow-700") . "'>";
            
            if (empty($errors)) {
                echo "<i class='fas fa-check-circle mr-2'></i>✅ All Fixed!";
            } else {
                echo "<i class='fas fa-exclamation-triangle mr-2'></i>⚠️ Some Issues Remain";
            }
            
            echo "</h2>";
            
            if (!empty($fixes)) {
                echo "<div class='mb-4'>";
                echo "<h3 class='font-bold text-green-700 mb-2'>Applied Fixes:</h3>";
                echo "<ul class='list-disc list-inside space-y-1'>";
                foreach ($fixes as $fix) {
                    echo "<li class='text-green-600'>$fix</li>";
                }
                echo "</ul>";
                echo "</div>";
            }
            
            if (!empty($errors)) {
                echo "<div class='mb-4'>";
                echo "<h3 class='font-bold text-red-700 mb-2'>Remaining Issues:</h3>";
                echo "<ul class='list-disc list-inside space-y-1'>";
                foreach ($errors as $error) {
                    echo "<li class='text-red-600'>$error</li>";
                }
                echo "</ul>";
                echo "</div>";
            }
            
            echo "<div class='mt-6 space-x-4'>";
            if (empty($errors)) {
                echo "<a href='index.php' class='inline-block px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 font-bold'>";
                echo "<i class='fas fa-home mr-2'></i>Go to Homepage";
                echo "</a>";
                echo "<a href='test-shortener.php' class='inline-block px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 font-bold'>";
                echo "<i class='fas fa-flask mr-2'></i>Test Shortener";
                echo "</a>";
            } else {
                echo "<a href='auto-fix-database.php' class='inline-block px-6 py-3 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700 font-bold'>";
                echo "<i class='fas fa-redo mr-2'></i>Run Again";
                echo "</a>";
            }
            echo "</div>";
            
            echo "</div>";
            ?>
            
        </div>
        
        <div class="mt-6 text-center text-sm text-gray-600">
            <p>
                <i class="fas fa-info-circle mr-1"></i>
                This script automatically fixes common database issues for the guest links feature.
            </p>
        </div>
    </div>
</body>
</html>
