﻿<?php
/**
 * Contact Us Page
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

$user = current_user();
$flash = get_flash();
$error = null;
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $subject = sanitize($_POST['subject'] ?? '');
    $message = sanitize($_POST['message'] ?? '');
    $csrf = $_POST['csrf_token'] ?? '';

    if (!verify_csrf_token($csrf)) {
        $error = "Invalid session. Please refresh the page.";
    } elseif (empty($name) || empty($email) || empty($message)) {
        $error = "Please fill in all required fields.";
    } else {
        // Send email (mockup for now, or use mail() / PHPMailer)
        // For now, we'll log it or just show success
        // In a real app, you'd insert into a 'messages' table or send SMTP email
        $success = "Thanks for contacting us! We'll get back to you shortly.";
    }
}

$csrf = csrf_token();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - SnapLink Pro</title>
    <?php meta_canonical('php-version/contact.php'); ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-50 min-h-screen flex flex-col">
    <!-- Navbar -->
    <nav class="bg-white border-b border-gray-200">
        <div class="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
            <a href="index.php" class="flex items-center gap-2">
                <div class="w-10 h-10 rounded-xl bg-purple-600 flex items-center justify-center text-white">
                    <i class="fas fa-link"></i>
                </div>
                <span class="text-xl font-bold text-gray-900">Link<span class="text-purple-600">Snip</span></span>
            </a>
            <?php if ($user): ?>
                <a href="dashboard.php" class="text-purple-600 font-medium hover:text-purple-700">Dashboard</a>
            <?php else: ?>
                <a href="login.php" class="text-purple-600 font-medium hover:text-purple-700">Login</a>
            <?php endif; ?>
        </div>
    </nav>

    <main class="flex-1 max-w-4xl mx-auto w-full px-4 py-12">
        <div class="text-center mb-12">
            <h1 class="text-3xl font-bold text-gray-900 mb-4">Contact Us</h1>
            <p class="text-gray-500">Have questions? We'd love to hear from you.</p>
        </div>

        <div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-8 md:p-12">
            <?php if ($success): ?>
                <div class="bg-green-50 text-green-700 p-4 rounded-xl mb-6 text-center">
                    <i class="fas fa-check-circle text-2xl mb-2 block"></i>
                    <?= $success ?>
                </div>
            <?php else: ?>
                <?php if ($error): ?>
                    <div class="bg-red-50 text-red-700 p-4 rounded-xl mb-6 flex items-center gap-2">
                        <i class="fas fa-exclamation-circle"></i>
                        <?= $error ?>
                    </div>
                <?php endif; ?>

                <form method="POST" class="space-y-6">
                    <input type="hidden" name="csrf_token" value="<?= $csrf ?>">
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Name *</label>
                            <input type="text" name="name" required class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500" value="<?= htmlspecialchars($_POST['name'] ?? $user['name'] ?? '') ?>">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Email *</label>
                            <input type="email" name="email" required class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500" value="<?= htmlspecialchars($_POST['email'] ?? $user['email'] ?? '') ?>">
                        </div>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Subject</label>
                        <select name="subject" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500">
                            <option>General Inquiry</option>
                            <option>Support Request</option>
                            <option>Billing Question</option>
                            <option>Feature Request</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Message *</label>
                        <textarea name="message" required rows="5" class="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500"><?= htmlspecialchars($_POST['message'] ?? '') ?></textarea>
                    </div>

                    <button type="submit" class="w-full py-4 bg-purple-600 text-white font-bold rounded-xl hover:bg-purple-700 transition shadow-lg shadow-purple-200">
                        Send Message
                    </button>
                </form>
            <?php endif; ?>
        </div>
    </main>

    <?php require_once ROOT_PATH . '/components/cookie-consent.php'; ?>
</body>
</html>
