﻿# InfinityFree Hosting Deployment Guide

This guide will help you deploy SnapLink Pro to InfinityFree hosting.

## File Structure for InfinityFree

InfinityFree uses `htdocs` as the web root. Here's how to organize your files:

```
htdocs/                          (Your InfinityFree web root)
├── .htaccess                    (URL rewriting rules)
├── index.php                    (Homepage)
├── login.php
├── register.php
├── dashboard.php
├── analytics.php
├── settings.php
├── bio.php
├── blog.php
├── pricing.php
├── webhooks.php
├── page.php
├── r.php                        (Redirect handler)
├── qr.php
├── privacy.php
├── terms.php
├── error.php
├── forgot-password.php
├── reset-password.php
├── install.php                  (Run once, then delete)
├── migration_google_oauth.sql
├── api/
│   ├── shorten.php
│   ├── delete.php
│   ├── toggle.php
│   ├── update.php
│   ├── qr.php
│   └── stripe_webhook.php
├── admin/
│   ├── index.php
│   ├── users.php
│   ├── settings.php
│   ├── blog.php
│   └── pages.php
├── auth/
│   └── google/
│       └── callback.php
├── assets/
│   ├── css/
│   ├── js/
│   └── images/
├── components/
│   ├── header.php
│   ├── footer.php
│   ├── sidebar.php
│   └── cookie-consent.php
├── config/
│   ├── config.php              (Update this!)
│   └── database.php            (Update this!)
├── manifest.json
├── sw.js
└── uploads/                     (Make writable - 755)
```

## Step-by-Step Deployment

### 1. Create InfinityFree Account

1. Go to [InfinityFree](https://www.infinityfree.net/)
2. Sign up for a free account
3. Create a new website/subdomain
4. Note your:
   - FTP hostname
   - FTP username
   - FTP password
   - MySQL hostname
   - MySQL database name
   - MySQL username

### 2. Upload Files

**Option A: Using FileZilla (Recommended)**

1. Download [FileZilla](https://filezilla-project.org/)
2. Connect using your FTP credentials:
   - Host: `ftpupload.net` (or your specific FTP host)
   - Username: Your FTP username
   - Password: Your FTP password
   - Port: 21
3. Navigate to `htdocs` folder on the remote side
4. Upload ALL files from your `php-version` folder to `htdocs`

**Option B: Using InfinityFree File Manager**

1. Login to your InfinityFree control panel
2. Go to "File Manager"
3. Navigate to `htdocs`
4. Upload files (may need to upload in batches)

### 3. Configure Database

**Create MySQL Database:**

1. In InfinityFree control panel, go to "MySQL Databases"
2. Note your database details:
   ```
   Database Name: epiz_XXXXXXXX_snaplink
   Username: epiz_XXXXXXXX
   Password: [your password]
   Hostname: sqlXXX.infinityfreeapp.com
   ```

**Update `config/database.php`:**

```php
<?php
// InfinityFree Database Configuration
define('DB_HOST', 'sqlXXX.infinityfreeapp.com'); // Replace XXX
define('DB_NAME', 'epiz_XXXXXXXX_snaplink');     // Your DB name
define('DB_USER', 'epiz_XXXXXXXX');              // Your DB user
define('DB_PASS', 'your_database_password');     // Your DB password
define('DB_CHARSET', 'utf8mb4');

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>
```

### 4. Configure Application Settings

**Update `config/config.php`:**

```php
<?php
// Application Configuration for InfinityFree

// Your InfinityFree domain
define('APP_URL', 'https://yoursite.infinityfreeapp.com'); // Change this!
define('BASE_URL', APP_URL);

// Or if using custom domain:
// define('APP_URL', 'https://yourdomain.com');

// Security
define('APP_KEY', 'your-random-32-char-secret-key-here'); // Generate random key
define('HASH_COST', 10); // Lower for InfinityFree (saves resources)

// Session
define('SESSION_LIFETIME', 86400); // 24 hours

// File uploads (if needed)
define('UPLOAD_PATH', __DIR__ . '/../uploads/');
define('MAX_UPLOAD_SIZE', 2097152); // 2MB (InfinityFree limit)

// Timezone
date_default_timezone_set('Asia/Kolkata'); // Or your timezone

// Helper functions
function base_url($path = '') {
    return rtrim(BASE_URL, '/') . '/' . ltrim($path, '/');
}

function is_logged_in() {
    return isset($_SESSION['user_id']);
}

function current_user() {
    if (!is_logged_in()) return null;
    return [
        'id' => $_SESSION['user_id'] ?? null,
        'name' => $_SESSION['user_name'] ?? null,
        'email' => $_SESSION['user_email'] ?? null,
        'role' => $_SESSION['user_role'] ?? 'user',
        'plan' => $_SESSION['user_plan'] ?? 'free'
    ];
}

function redirect($url) {
    header("Location: " . $url);
    exit;
}

function json_response($data, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function sanitize($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function get_flash() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}
?>
```

### 5. Create .htaccess File

Create `.htaccess` in your `htdocs` folder:

```apache
# Enable Rewrite Engine
RewriteEngine On

# Force HTTPS (recommended)
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

# Remove www (optional)
RewriteCond %{HTTP_HOST} ^www\.(.+)$ [NC]
RewriteRule ^(.*)$ https://%1/$1 [R=301,L]

# Handle short URLs
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^([a-zA-Z0-9]+)$ r.php?code=$1 [L,QSA]

# Protect sensitive files
<FilesMatch "^(config\.php|database\.php|\.env)$">
    Order allow,deny
    Deny from all
</FilesMatch>

# Disable directory browsing
Options -Indexes

# Set default document
DirectoryIndex index.php index.html

# PHP settings (if allowed by InfinityFree)
php_value upload_max_filesize 2M
php_value post_max_size 2M
php_value max_execution_time 30
php_value max_input_time 30
```

### 6. Run Installation

1. Visit: `https://yoursite.infinityfreeapp.com/install.php`
2. Click "Install Database Tables"
3. Wait for confirmation
4. **IMPORTANT:** Delete `install.php` after successful installation
5. Login with default credentials:
   - Email: `admin@snaplink.com`
   - Password: `admin123`
6. Change admin password immediately!

### 7. Set File Permissions

If you have SSH access (premium) or via FTP:

```
htdocs/              - 755
htdocs/uploads/      - 755 (writable)
htdocs/config/       - 755
All .php files       - 644
.htaccess           - 644
```

## InfinityFree Limitations & Workarounds

### 1. **cURL Restrictions**
InfinityFree may block outgoing HTTP requests (for webhooks, OAuth, etc.)

**Workaround:**
- Use their premium hosting for full cURL support
- Or use CloudFlare Workers as a proxy

### 2. **Email Sending**
InfinityFree blocks `mail()` function

**Workaround:**
```php
// Use SMTP instead (PHPMailer)
// In config/config.php
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'your-email@gmail.com');
define('SMTP_PASS', 'your-app-password');
```

### 3. **Performance**
Free hosting has resource limits

**Optimizations:**
- Enable caching in `config.php`
- Reduce `HASH_COST` to 10
- Optimize images before upload
- Use CDN for assets (like Tailwind CSS)

### 4. **Database Size**
Limited to 400MB

**Optimization:**
- Regularly clean old analytics data
- Set retention period in settings

## Google OAuth Configuration for InfinityFree

Update OAuth redirect URIs to:

```
https://yoursite.infinityfreeapp.com/auth/google/callback.php
```

Or if using custom domain:
```
https://yourdomain.com/auth/google/callback.php
```

## Stripe Webhook Configuration

Update Stripe webhook endpoint to:

```
https://yoursite.infinityfreeapp.com/api/stripe_webhook.php
```

## Testing Checklist

After deployment, test:

- [ ] Homepage loads correctly
- [ ] User registration works
- [ ] User login works
- [ ] URL shortening works
- [ ] Short URL redirect works (yourdomain.com/abc123)
- [ ] Analytics tracking works
- [ ] Admin panel accessible
- [ ] Database connections stable
- [ ] Google OAuth (after configuration)
- [ ] Bio pages work
- [ ] Blog posts display
- [ ] QR code generation works

## Common Issues & Solutions

### Issue: "Database connection failed"
**Solution:** Double-check database credentials in `config/database.php`

### Issue: "404 Not Found" for short URLs
**Solution:** Ensure `.htaccess` is uploaded and mod_rewrite is enabled

### Issue: "500 Internal Server Error"
**Solution:** 
- Check file permissions
- Enable error logging in `config.php`
- View error logs in cPanel

### Issue: "Session not persisting"
**Solution:**
```php
// In config/config.php, adjust session path
session_save_path(__DIR__ . '/../sessions/');
// Create 'sessions' folder with 755 permissions
```

### Issue: "Google OAuth not working"
**Solution:**
- Verify redirect URI matches exactly
- Check if cURL is allowed (may need premium)
- Test locally first

## Custom Domain Setup (Optional)

1. Purchase domain from registrar (Namecheap, GoDaddy, etc.)
2. In InfinityFree, go to "Addon Domains"
3. Add your custom domain
4. Update nameservers at your registrar:
   ```
   ns1.byet.org
   ns2.byet.org
   ```
5. Update `APP_URL` in `config/config.php`
6. Update all OAuth redirect URIs

## Backup Strategy

Since InfinityFree is free hosting, always maintain backups:

1. **Weekly Database Export:**
   - Login to phpMyAdmin
   - Export database as `.sql` file

2. **Weekly File Backup:**
   - Download entire `htdocs` via FTP

3. **Store backups:**
   - Google Drive
   - Dropbox
   - Local machine

## Support & Resources

- InfinityFree Forum: https://forum.infinityfree.net/
- InfinityFree Wiki: https://infinityfree.net/support/
- Your Control Panel: https://cpanel.infinityfreeapp.com/

## Upgrade Path

When ready to upgrade from free hosting:

1. **InfinityFree Premium** - More resources, no ads
2. **Shared Hosting** - Hostinger, SiteGround ($2-5/month)
3. **VPS Hosting** - DigitalOcean, Vultr ($5-10/month)

All configurations remain the same, just update database credentials!

---

**Need Help?** If you encounter issues during deployment, check:
1. InfinityFree error logs (in cPanel)
2. Browser console for JavaScript errors
3. Network tab for failed requests
