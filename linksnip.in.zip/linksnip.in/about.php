﻿<?php
/**
 * About Us Page - SEO Optimized
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

$user = current_user();
$pageTitle = "About Us - SnapLink Pro URL Shortener | Our Story";
$pageDescription = "Learn about SnapLink Pro, a trusted URL shortener platform providing free link shortening, analytics, and custom domains since 2024. Safe, spam-free, and reliable.";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?></title>
    
    <!-- SEO Meta Tags -->
    <meta name="description" content="<?= $pageDescription ?>">
    <meta name="keywords" content="about snaplink, url shortener company, trusted link shortener, safe url shortener">
    <link rel="canonical" href="https://snaplink.pro/about.php">
    
    <!-- Open Graph -->
    <meta property="og:title" content="<?= $pageTitle ?>">
    <meta property="og:description" content="<?= $pageDescription ?>">
    <meta property="og:type" content="website">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gray-50">

    <!-- Navbar -->
    <nav class="bg-white shadow-sm border-b sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <a href="index.php" class="flex items-center gap-2">
                    <div class="w-10 h-10 rounded-xl bg-purple-600 flex items-center justify-center text-white">
                        <i class="fas fa-link"></i>
                    </div>
                    <span class="text-xl font-bold">SnapLink Pro</span>
                </a>
                
                <div class="hidden md:flex items-center space-x-6">
                    <a href="index.php" class="text-gray-700 hover:text-purple-600">Home</a>
                    <a href="features.php" class="text-gray-700 hover:text-purple-600">Features</a>
                    <a href="how-it-works.php" class="text-gray-700 hover:text-purple-600">How It Works</a>
                    <a href="faq.php" class="text-gray-700 hover:text-purple-600">FAQ</a>
                    <a href="blog.php" class="text-gray-700 hover:text-purple-600">Blog</a>
                </div>
                
                <div class="flex items-center gap-4">
                    <?php if ($user): ?>
                        <a href="dashboard.php" class="px-4 py-2 bg-purple-600 text-white rounded-lg font-semibold">Dashboard</a>
                    <?php else: ?>
                        <a href="login.php" class="text-gray-700">Login</a>
                        <a href="register.php" class="px-4 py-2 bg-purple-600 text-white rounded-lg font-semibold">Get Started</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero -->
    <section class="py-20 bg-gradient-to-r from-purple-600 to-pink-600">
        <div class="max-w-5xl mx-auto px-4 text-center text-white">
            <h1 class="text-5xl font-extrabold mb-6">About SnapLink Pro</h1>
            <p class="text-xl opacity-90">Building the future of link management</p>
        </div>
    </section>

    <!-- About Content -->
    <section class="py-20">
        <div class="max-w-4xl mx-auto px-4">
            
            <div class="prose prose-lg max-w-none">
                <h2 class="text-3xl font-bold text-gray-900 mb-6">Our Mission</h2>
                <p class="text-lg text-gray-700 mb-6">
                    SnapLink Pro was created with a simple mission: to provide the best free URL shortener service with powerful features that are accessible to everyone. We believe that every business, creator, and individual deserves access to professional link management tools without breaking the bank.
                </p>

                <h2 class="text-3xl font-bold text-gray-900 mb-6 mt-12">What We Do</h2>
                <p class="text-lg text-gray-700 mb-6">
                    We provide a comprehensive URL shortening platform that includes:
                </p>
                <ul class="space-y-3 text-gray-700 mb-6">
                    <li class="flex items-start gap-3">
                        <i class="fas fa-check-circle text-green-500 mt-1"></i>
                        <span><strong>Free URL Shortening:</strong> Create short, memorable links for your content</span>
                    </li>
                    <li class="flex items-start gap-3">
                        <i class="fas fa-check-circle text-green-500 mt-1"></i>
                        <span><strong>Detailed Analytics:</strong> Track every click with comprehensive insights</span>
                    </li>
                    <li class="flex items-start gap-3">
                        <i class="fas fa-check-circle text-green-500 mt-1"></i>
                        <span><strong>Custom Domains:</strong> Brand your links with your own domain</span>
                    </li>
                    <li class="flex items-start gap-3">
                        <i class="fas fa-check-circle text-green-500 mt-1"></i>
                        <span><strong>QR Code Generation:</strong> Auto-generated QR codes for offline campaigns</span>
                    </li>
                    <li class="flex items-start gap-3">
                        <i class="fas fa-check-circle text-green-500 mt-1"></i>
                        <span><strong>Security Features:</strong> Password protection and spam detection</span>
                    </li>
                </ul>

                <h2 class="text-3xl font-bold text-gray-900 mb-6 mt-12">Why Choose SnapLink Pro?</h2>
                <div class="grid md:grid-cols-2 gap-6 mb-8">
                    <div class="bg-white p-6 rounded-xl shadow-sm border">
                        <h3 class="font-bold text-xl text-purple-600 mb-3">
                            <i class="fas fa-shield-alt mr-2"></i>Safe & Spam-Free
                        </h3>
                        <p class="text-gray-600">Advanced fraud protection and malware detection keep your links safe and trusted.</p>
                    </div>
                    
                    <div class="bg-white p-6 rounded-xl shadow-sm border">
                        <h3 class="font-bold text-xl text-blue-600 mb-3">
                            <i class="fas fa-chart-line mr-2"></i>Powerful Analytics
                        </h3>
                        <p class="text-gray-600">Real-time insights into clicks, locations, devices, and more.</p>
                    </div>
                    
                    <div class="bg-white p-6 rounded-xl shadow-sm border">
                        <h3 class="font-bold text-xl text-green-600 mb-3">
                            <i class="fas fa-bolt mr-2"></i>Lightning Fast
                        </h3>
                        <p class="text-gray-600">Optimized infrastructure ensures your links redirect instantly.</p>
                    </div>
                    
                    <div class="bg-white p-6 rounded-xl shadow-sm border">
                        <h3 class="font-bold text-xl text-pink-600 mb-3">
                            <i class="fas fa-heart mr-2"></i>Always Free
                        </h3>
                        <p class="text-gray-600">Essential features available for free, with premium options for power users.</p>
                    </div>
                </div>

                <h2 class="text-3xl font-bold text-gray-900 mb-6 mt-12">Our Commitment</h2>
                <p class="text-lg text-gray-700 mb-6">
                    We are committed to maintaining a safe, reliable, and spam-free environment for all users. Every link is scanned for malicious content, and we have a robust abuse reporting system to protect our community.
                </p>
                <p class="text-lg text-gray-700 mb-6">
                    Privacy and security are our top priorities. We use industry-standard encryption (HTTPS/SSL) to protect all data, and we never share your information with third parties without your consent.
                </p>

                <h2 class="text-3xl font-bold text-gray-900 mb-6 mt-12">Contact Us</h2>
                <p class="text-lg text-gray-700 mb-6">
                    Have questions or feedback? We'd love to hear from you! Reach out to our support team anytime.
                </p>
                <div class="flex gap-4">
                    <a href="contact.php" class="px-6 py-3 bg-purple-600 text-white rounded-lg font-semibold hover:bg-purple-700 transition">
                        Contact Support
                    </a>
                    <a href="report.php" class="px-6 py-3 bg-gray-200 text-gray-700 rounded-lg font-semibold hover:bg-gray-300 transition">
                        Report Abuse
                    </a>
                </div>
            </div>

        </div>
    </section>

    <!-- Stats -->
    <section class="py-16 bg-gray-100">
        <div class="max-w-7xl mx-auto px-4">
            <div class="grid md:grid-cols-4 gap-8 text-center">
                <div>
                    <div class="text-4xl font-bold text-purple-600 mb-2">10,000+</div>
                    <div class="text-gray-600">Active Users</div>
                </div>
                <div>
                    <div class="text-4xl font-bold text-pink-600 mb-2">100,000+</div>
                    <div class="text-gray-600">Links Created</div>
                </div>
                <div>
                    <div class="text-4xl font-bold text-blue-600 mb-2">1M+</div>
                    <div class="text-gray-600">Clicks Tracked</div>
                </div>
                <div>
                    <div class="text-4xl font-bold text-green-600 mb-2">99.9%</div>
                    <div class="text-gray-600">Uptime</div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA -->
    <section class="py-16 bg-gradient-to-r from-purple-600 to-pink-600">
        <div class="max-w-4xl mx-auto px-4 text-center">
            <h2 class="text-4xl font-bold text-white mb-6">Join the SnapLink Pro Community</h2>
            <p class="text-xl text-white/90 mb-8">Start shortening and tracking your links today — completely free!</p>
            <a href="register.php" class="inline-block px-8 py-4 bg-white text-purple-600 rounded-lg font-bold text-lg hover:bg-gray-100 transition">
                Create Free Account
            </a>
        </div>
    </section>

    <!-- Footer -->
    <?php include ROOT_PATH . '/components/footer.php'; ?>

</body>
</html>
