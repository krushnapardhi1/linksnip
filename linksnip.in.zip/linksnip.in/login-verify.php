﻿<?php
/**
 * 2FA Verification Page
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';
require_once ROOT_PATH . '/utils/GoogleAuthenticator.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Ensure user is in "partial login" state
if (!isset($_SESSION['partial_user_id'])) {
    redirect('login.php');
}

$error = null;
$userId = $_SESSION['partial_user_id'];
$db = db()->getConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $code = $_POST['code'] ?? '';
    
    // Get user secret
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $ga = new PHPGangsta_GoogleAuthenticator();
    
    if ($ga->verifyCode($user['two_factor_secret'], $code, 1)) { // 1 = 30s drift tolerance
        // Complete Login
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['user_plan'] = $user['plan'];
        
        unset($_SESSION['partial_user_id']);
        
        // Handle redirect
        $defaultRedirect = $user['role'] === 'admin' ? 'admin/index.php' : 'dashboard.php';
        $redirectUrl = $_SESSION['redirect_after_login'] ?? $defaultRedirect;
        unset($_SESSION['redirect_after_login']);
        
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH'])) {
            json_response(['success' => true, 'redirect' => $redirectUrl]);
        }
        
        redirect($redirectUrl);
    } else {
        $error = 'Invalid authentication code';
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH'])) {
            json_response(['success' => false, 'error' => $error], 400);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify 2FA - SnapLink Pro</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style> body { font-family: 'Inter', sans-serif; } </style>
</head>
<body class="bg-gray-50 flex items-center justify-center min-h-screen p-4">
    <div class="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
        <div class="w-20 h-20 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <i class="fas fa-lock text-4xl text-purple-600"></i>
        </div>
        
        <h1 class="text-2xl font-bold text-gray-900 mb-2">Two-Factor Authentication</h1>
        <p class="text-gray-500 mb-8">Enter the code from your authenticator app</p>
        
        <?php if ($error): ?>
            <div class="mb-6 p-4 rounded-lg bg-red-50 text-red-700 border border-red-200 text-sm">
                <?= $error ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" id="verifyForm" class="space-y-6">
            <input type="text" name="code" required autocomplete="one-time-code" autofocus
                   class="w-full px-4 py-4 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 text-center text-2xl tracking-[0.5em] font-bold"
                   placeholder="000000" maxlength="6" inputmode="numeric">
            
            <button type="submit" class="w-full py-3 bg-purple-600 text-white font-bold rounded-xl hover:bg-purple-700 transition">
                Verify
            </button>
        </form>
        
        <div class="mt-6 text-sm text-gray-500">
            <a href="login.php" class="hover:text-purple-600">Back to Login</a>
        </div>
    </div>
    
    <script>
        document.getElementById('verifyForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            const btn = this.querySelector('button');
            const originalText = btn.innerText;
            btn.innerText = 'Verifying...';
            btn.disabled = true;
            
            try {
                const formData = new FormData(this);
                const res = await fetch('login-verify.php', {
                    method: 'POST',
                    headers: { 'X-Requested-With': 'XMLHttpRequest' },
                    body: formData
                });
                const data = await res.json();
                
                if (data.success) {
                    window.location.href = data.redirect;
                } else {
                    alert(data.error || 'Verification failed');
                    btn.innerText = originalText;
                    btn.disabled = false;
                }
            } catch (err) {
                this.submit();
            }
        });
    </script>
</body>
</html>
