﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Link Shortener Test - SnapLink Pro</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        .toast {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #10b981;
            color: white;
            padding: 16px 24px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            transform: translateX(400px);
            transition: transform 0.3s ease;
            z-index: 9999;
        }
        .toast.show {
            transform: translateX(0);
        }
    </style>
</head>
<body class="bg-gradient-to-br from-purple-50 to-pink-50 min-h-screen flex items-center justify-center p-4">
    
    <!-- Toast Notification -->
    <div id="toast" class="toast">
        <i class="fas fa-check-circle mr-2"></i>
        <span id="toastMessage">Copied!</span>
    </div>

    <div class="max-w-2xl w-full">
        <!-- Header -->
        <div class="text-center mb-8">
            <div class="w-16 h-16 bg-gradient-to-r from-purple-600 to-pink-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <i class="fas fa-link text-white text-2xl"></i>
            </div>
            <h1 class="text-4xl font-bold text-gray-900 mb-2">Link Shortener Test</h1>
            <p class="text-gray-600">Quick test for guest link creation with copy functionality</p>
        </div>

        <!-- Main Card -->
        <div class="bg-white rounded-2xl shadow-xl p-8 mb-6">
            <!-- Input Section -->
            <div class="mb-6">
                <label class="block text-sm font-semibold text-gray-700 mb-2">
                    <i class="fas fa-link text-purple-600 mr-2"></i>
                    Enter Long URL
                </label>
                <div class="flex gap-3">
                    <input 
                        type="url" 
                        id="urlInput" 
                        class="flex-1 px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-purple-500 focus:outline-none transition"
                        placeholder="https://example.com/very/long/url..."
                        value="https://www.google.com/search?q=url+shortener+example"
                    >
                    <button 
                        id="shortenBtn"
                        class="px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-semibold rounded-xl hover:shadow-lg transition flex items-center gap-2"
                    >
                        <i class="fas fa-cut"></i>
                        <span>Shorten</span>
                    </button>
                </div>
            </div>

            <!-- Result Section (Hidden by default) -->
            <div id="resultSection" class="hidden mt-6">
                <div class="bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-200 rounded-xl p-6">
                    <div class="flex items-start gap-4">
                        <div class="w-12 h-12 bg-green-500 rounded-xl flex items-center justify-center flex-shrink-0">
                            <i class="fas fa-check text-white text-xl"></i>
                        </div>
                        <div class="flex-1 min-w-0">
                            <h3 class="text-lg font-bold text-gray-900 mb-2">✨ Link Created Successfully!</h3>
                            
                            <!-- Short URL Display -->
                            <div class="flex items-center gap-2 mb-3">
                                <div class="flex-1 bg-white rounded-lg px-4 py-3 border border-green-300">
                                    <a href="#" id="shortLink" target="_blank" class="text-purple-600 font-semibold text-lg hover:text-purple-700 break-all"></a>
                                </div>
                                <button 
                                    id="copyBtn"
                                    class="px-4 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition flex items-center gap-2 font-semibold"
                                    title="Copy to clipboard"
                                >
                                    <i class="fas fa-copy"></i>
                                    <span>Copy</span>
                                </button>
                            </div>

                            <!-- Stats -->
                            <div class="flex gap-4 text-sm text-gray-600 mb-3">
                                <span><i class="fas fa-link mr-1"></i> Short Code: <strong id="shortCode"></strong></span>
                                <span><i class="fas fa-clock mr-1"></i> Just now</span>
                            </div>

                            <!-- Original URL -->
                            <div class="text-xs text-gray-500 mb-3">
                                <i class="fas fa-arrow-right mr-1"></i>
                                Redirects to: <span id="originalUrl" class="break-all"></span>
                            </div>

                            <!-- Action Buttons -->
                            <div class="flex gap-2">
                                <a href="my-guest-links.php" class="px-4 py-2 bg-gray-900 text-white rounded-lg hover:bg-gray-800 transition text-sm font-semibold">
                                    <i class="fas fa-list mr-2"></i>View All My Links
                                </a>
                                <button id="testLinkBtn" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition text-sm font-semibold">
                                    <i class="fas fa-external-link-alt mr-2"></i>Test Link
                                </button>
                                <button id="createAnotherBtn" class="px-4 py-2 bg-purple-100 text-purple-700 rounded-lg hover:bg-purple-200 transition text-sm font-semibold">
                                    <i class="fas fa-plus mr-2"></i>Create Another
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Guest Message -->
                <div class="mt-4 p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <p class="text-sm text-purple-900">
                        <i class="fas fa-info-circle mr-2"></i>
                        <strong>Guest User:</strong> You can create up to 5 links per day. 
                        <a href="register.php" class="underline font-semibold hover:text-purple-700">Sign up free</a> 
                        for unlimited links!
                    </p>
                </div>
            </div>

            <!-- Loading State -->
            <div id="loadingState" class="hidden text-center py-8">
                <i class="fas fa-spinner fa-spin text-4xl text-purple-600 mb-3"></i>
                <p class="text-gray-600">Creating your short link...</p>
            </div>

            <!-- Error State -->
            <div id="errorState" class="hidden mt-6">
                <div class="bg-red-50 border-2 border-red-200 rounded-xl p-4">
                    <div class="flex items-start gap-3">
                        <i class="fas fa-exclamation-circle text-red-500 text-xl mt-1"></i>
                        <div>
                            <h4 class="font-bold text-red-900 mb-1">Error</h4>
                            <p id="errorMessage" class="text-sm text-red-700"></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Instructions Card -->
        <div class="bg-white rounded-xl shadow-lg p-6">
            <h3 class="text-lg font-bold text-gray-900 mb-3">
                <i class="fas fa-clipboard-list text-purple-600 mr-2"></i>
                How to Test
            </h3>
            <ol class="space-y-2 text-sm text-gray-700">
                <li class="flex gap-3">
                    <span class="w-6 h-6 bg-purple-100 text-purple-700 rounded-full flex items-center justify-center font-bold flex-shrink-0">1</span>
                    <span>Click the <strong>"Shorten"</strong> button to create a short link</span>
                </li>
                <li class="flex gap-3">
                    <span class="w-6 h-6 bg-purple-100 text-purple-700 rounded-full flex items-center justify-center font-bold flex-shrink-0">2</span>
                    <span>Click the <strong>"Copy"</strong> button to copy the link to clipboard</span>
                </li>
                <li class="flex gap-3">
                    <span class="w-6 h-6 bg-purple-100 text-purple-700 rounded-full flex items-center justify-center font-bold flex-shrink-0">3</span>
                    <span>Click <strong>"Test Link"</strong> to verify the redirect works</span>
                </li>
                <li class="flex gap-3">
                    <span class="w-6 h-6 bg-purple-100 text-purple-700 rounded-full flex items-center justify-center font-bold flex-shrink-0">4</span>
                    <span>Try creating 6 links to test the rate limiting</span>
                </li>
            </ol>
        </div>

        <!-- Quick Links -->
        <div class="mt-6 text-center space-x-4">
            <a href="index.php" class="text-purple-600 hover:text-purple-700 font-semibold">
                <i class="fas fa-home mr-1"></i>Homepage
            </a>
            <a href="my-guest-links.php" class="text-purple-600 hover:text-purple-700 font-semibold">
                <i class="fas fa-list mr-1"></i>My Guest Links
            </a>
            <a href="register.php" class="text-purple-600 hover:text-purple-700 font-semibold">
                <i class="fas fa-user-plus mr-1"></i>Sign Up
            </a>
        </div>
    </div>

    <script>
        const urlInput = document.getElementById('urlInput');
        const shortenBtn = document.getElementById('shortenBtn');
        const resultSection = document.getElementById('resultSection');
        const loadingState = document.getElementById('loadingState');
        const errorState = document.getElementById('errorState');
        const shortLink = document.getElementById('shortLink');
        const shortCode = document.getElementById('shortCode');
        const originalUrl = document.getElementById('originalUrl');
        const copyBtn = document.getElementById('copyBtn');
        const testLinkBtn = document.getElementById('testLinkBtn');
        const createAnotherBtn = document.getElementById('createAnotherBtn');
        const errorMessage = document.getElementById('errorMessage');
        const toast = document.getElementById('toast');
        const toastMessage = document.getElementById('toastMessage');

        // Show toast notification
        function showToast(message, type = 'success') {
            toastMessage.textContent = message;
            toast.style.background = type === 'success' ? '#10b981' : '#ef4444';
            toast.classList.add('show');
            setTimeout(() => {
                toast.classList.remove('show');
            }, 3000);
        }

        // Shorten URL
        shortenBtn.addEventListener('click', async () => {
            const url = urlInput.value.trim();
            if (!url) {
                showToast('Please enter a URL', 'error');
                return;
            }

            // Hide previous results
            resultSection.classList.add('hidden');
            errorState.classList.add('hidden');
            loadingState.classList.remove('hidden');

            try {
                const formData = new FormData();
                formData.append('long_url', url);

                const res = await fetch('api/shorten.php', {
                    method: 'POST',
                    body: formData
                });

                const data = await res.json();
                loadingState.classList.add('hidden');

                if (data.success) {
                    // Show result
                    shortLink.href = data.data.shortUrl;
                    shortLink.textContent = data.data.shortUrl;
                    shortCode.textContent = data.data.shortCode;
                    originalUrl.textContent = url;
                    resultSection.classList.remove('hidden');
                    showToast('Link created successfully!');
                } else {
                    // Show error
                    errorMessage.textContent = data.error || 'An error occurred';
                    errorState.classList.remove('hidden');
                    
                    // Check for rate limit
                    if (data.limit_reached) {
                        if (confirm(data.error + '\n\nWould you like to sign up for free?')) {
                            window.location.href = data.signup_url || 'register.php';
                        }
                    }
                }
            } catch (err) {
                console.error(err);
                loadingState.classList.add('hidden');
                errorMessage.textContent = 'Network error: ' + err.message;
                errorState.classList.remove('hidden');
                showToast('Error creating link', 'error');
            }
        });

        // Copy to clipboard
        copyBtn.addEventListener('click', async () => {
            const url = shortLink.textContent;
            try {
                await navigator.clipboard.writeText(url);
                showToast('Copied to clipboard!');
                copyBtn.innerHTML = '<i class="fas fa-check"></i><span>Copied!</span>';
                setTimeout(() => {
                    copyBtn.innerHTML = '<i class="fas fa-copy"></i><span>Copy</span>';
                }, 2000);
            } catch (err) {
                // Fallback for older browsers
                const textarea = document.createElement('textarea');
                textarea.value = url;
                document.body.appendChild(textarea);
                textarea.select();
                document.execCommand('copy');
                document.body.removeChild(textarea);
                showToast('Copied to clipboard!');
            }
        });

        // Test link
        testLinkBtn.addEventListener('click', () => {
            const url = shortLink.href;
            window.open(url, '_blank');
            showToast('Opening link in new tab...');
        });

        // Create another
        createAnotherBtn.addEventListener('click', () => {
            resultSection.classList.add('hidden');
            errorState.classList.add('hidden');
            urlInput.value = '';
            urlInput.focus();
        });

        // Enter key to submit
        urlInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                shortenBtn.click();
            }
        });
    </script>
</body>
</html>
