-- Link Rotation Migration
-- Create table for link rotation / A/B testing

-- Add rotation columns to urls table if they don't exist
SET @dbname = DATABASE();
SET @tablename = 'urls';

SET @columnname = 'rotation_enabled';
SET @preparedStatement = (SELECT IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
   WHERE table_name = @tablename AND table_schema = @dbname AND column_name = @columnname) > 0,
  'SELECT 1',
  CONCAT('ALTER TABLE ', @tablename, ' ADD COLUMN ', @columnname, ' BOOLEAN DEFAULT FALSE')
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

SET @columnname = 'rotation_mode';
SET @preparedStatement = (SELECT IF(
  (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
   WHERE table_name = @tablename AND table_schema = @dbname AND column_name = @columnname) > 0,
  'SELECT 1',
  CONCAT('ALTER TABLE ', @tablename, ' ADD COLUMN ', @columnname, ' VARCHAR(20) DEFAULT \'random\'')
));
PREPARE alterIfNotExists FROM @preparedStatement;
EXECUTE alterIfNotExists;
DEALLOCATE PREPARE alterIfNotExists;

-- Create link_rotations table
CREATE TABLE IF NOT EXISTS `link_rotations` (
    `id` INT PRIMARY KEY AUTO_INCREMENT,
    `url_id` INT NOT NULL,
    `name` VARCHAR(200) NULL DEFAULT NULL,
    `destination_url` VARCHAR(2000) NOT NULL,
    `weight` INT DEFAULT 100,
    `clicks` INT DEFAULT 0,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_url_id` (`url_id`),
    FOREIGN KEY (`url_id`) REFERENCES `urls`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
