﻿<?php
/**
 * Installation Script
 * Creates all necessary database tables
 * DELETE THIS FILE AFTER INSTALLATION!
 */

define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

$errors = [];
$success = [];

// Check if already installed
$installLock = ROOT_PATH . '/install.lock';
if (file_exists($installLock)) {
    die('Application already installed. Delete install.lock to reinstall.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $pdo = db()->getConnection();

        // Users table
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                email VARCHAR(255) UNIQUE NOT NULL,
                password VARCHAR(255) NOT NULL,
                name VARCHAR(100),
                google_id VARCHAR(255) DEFAULT NULL,
                avatar TEXT DEFAULT NULL,
                role ENUM('user', 'admin') DEFAULT 'user',
                plan ENUM('free', 'pro', 'enterprise') DEFAULT 'free',
                status ENUM('active', 'banned', 'pending') DEFAULT 'active',
                theme VARCHAR(10) DEFAULT 'light',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_email (email),
                INDEX idx_status (status),
                INDEX idx_google_id (google_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $success[] = "✅ Users table created";

        // URLs table
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS urls (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                long_url TEXT NOT NULL,
                short_code VARCHAR(20) UNIQUE NOT NULL,
                custom_domain VARCHAR(255) DEFAULT NULL,
                password VARCHAR(255) DEFAULT NULL,
                expires_at DATETIME DEFAULT NULL,
                max_clicks INT DEFAULT NULL,
                clicks INT DEFAULT 0,
                qr_scans INT DEFAULT 0,
                is_active BOOLEAN DEFAULT TRUE,
                notes TEXT DEFAULT NULL,
                mobile_url TEXT DEFAULT NULL,
                ios_url TEXT DEFAULT NULL,
                android_url TEXT DEFAULT NULL,
                ab_enabled BOOLEAN DEFAULT FALSE,
                ab_url TEXT DEFAULT NULL,
                ab_split INT DEFAULT 50,
                show_ad BOOLEAN DEFAULT FALSE,
                ad_duration INT DEFAULT 5,
                folder_id INT DEFAULT NULL,
                rotation_enabled BOOLEAN DEFAULT FALSE,
                scheduled_start TIMESTAMP NULL,
                scheduled_end TIMESTAMP NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                INDEX idx_short_code (short_code),
                INDEX idx_user_id (user_id),
                INDEX idx_active (is_active)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $success[] = "✅ URLs table created";

        // URL clicks/analytics table
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS url_clicks (
                id INT AUTO_INCREMENT PRIMARY KEY,
                url_id INT NOT NULL,
                ip_address VARCHAR(45),
                country VARCHAR(100),
                city VARCHAR(100),
                browser VARCHAR(100),
                browser_version VARCHAR(50),
                os VARCHAR(100),
                device_type ENUM('desktop', 'mobile', 'tablet') DEFAULT 'desktop',
                referrer TEXT,
                is_qr_scan BOOLEAN DEFAULT FALSE,
                clicked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (url_id) REFERENCES urls(id) ON DELETE CASCADE,
                INDEX idx_url_id (url_id),
                INDEX idx_clicked_at (clicked_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $success[] = "✅ URL clicks table created";

        // Custom domains table
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS domains (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                domain VARCHAR(255) UNIQUE NOT NULL,
                is_verified BOOLEAN DEFAULT FALSE,
                verification_code VARCHAR(64),
                verified_at TIMESTAMP NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                INDEX idx_domain (domain)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $success[] = "✅ Domains table created";

        // Blogs table
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS blogs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                title VARCHAR(255) NOT NULL,
                slug VARCHAR(255) NOT NULL UNIQUE,
                excerpt TEXT,
                content TEXT NOT NULL,
                thumbnail_url VARCHAR(255),
                author_id INT,
                is_published BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE SET NULL,
                INDEX idx_slug (slug),
                INDEX idx_published (is_published)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $success[] = "✅ Blogs table created";

        // Site settings table
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS site_settings (
                id INT AUTO_INCREMENT PRIMARY KEY,
                key_name VARCHAR(100) UNIQUE NOT NULL,
                value TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_key (key_name)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $success[] = "✅ Site settings table created";

        // API Keys table
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS api_keys (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                api_key VARCHAR(64) UNIQUE NOT NULL,
                name VARCHAR(100),
                requests_today INT DEFAULT 0,
                last_used_at TIMESTAMP NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                INDEX idx_api_key (api_key)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $success[] = "✅ API keys table created";

        // Blacklist table
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS blacklist (
                id INT AUTO_INCREMENT PRIMARY KEY,
                type ENUM('domain', 'ip', 'user_agent') NOT NULL,
                value VARCHAR(255) NOT NULL,
                reason VARCHAR(255),
                created_by INT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY unique_blacklist (type, value)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $success[] = "✅ Blacklist table created";

        // Webhooks table
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS webhooks (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                url_id INT,
                webhook_url VARCHAR(500) NOT NULL,
                event_type ENUM('first_click', 'milestone', 'expiry') NOT NULL,
                milestone_count INT DEFAULT NULL,
                is_active BOOLEAN DEFAULT TRUE,
                last_triggered_at TIMESTAMP NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                FOREIGN KEY (url_id) REFERENCES urls(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $success[] = "✅ Webhooks table created";

        // A/B Test results table
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS ab_results (
                id INT AUTO_INCREMENT PRIMARY KEY,
                url_id INT NOT NULL,
                variant ENUM('A', 'B') NOT NULL,
                clicks INT DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (url_id) REFERENCES urls(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $success[] = "✅ A/B results table created";

        // Link folders table
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS link_folders (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                name VARCHAR(100) NOT NULL,
                color VARCHAR(7) DEFAULT '#ec4899',
                icon VARCHAR(50) DEFAULT 'folder',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $success[] = "✅ Link folders table created";

        // Geo redirects table
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS geo_redirects (
                id INT AUTO_INCREMENT PRIMARY KEY,
                url_id INT NOT NULL,
                country_code VARCHAR(2) NOT NULL,
                destination_url TEXT NOT NULL,
                clicks INT DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (url_id) REFERENCES urls(id) ON DELETE CASCADE,
                UNIQUE KEY unique_geo (url_id, country_code)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $success[] = "✅ Geo redirects table created";

        // Bio pages table
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS bio_pages (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL UNIQUE,
                username VARCHAR(50) UNIQUE NOT NULL,
                title VARCHAR(100),
                bio TEXT,
                avatar_url TEXT,
                theme VARCHAR(50) DEFAULT 'default',
                background_color VARCHAR(7) DEFAULT '#1f2937',
                text_color VARCHAR(7) DEFAULT '#ffffff',
                button_style VARCHAR(20) DEFAULT 'rounded',
                show_avatar BOOLEAN DEFAULT TRUE,
                show_social BOOLEAN DEFAULT TRUE,
                is_published BOOLEAN DEFAULT TRUE,
                views INT DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $success[] = "✅ Bio pages table created";

        // Bio page links
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS bio_links (
                id INT AUTO_INCREMENT PRIMARY KEY,
                bio_page_id INT NOT NULL,
                title VARCHAR(100) NOT NULL,
                url TEXT NOT NULL,
                icon VARCHAR(50),
                thumbnail_url TEXT,
                clicks INT DEFAULT 0,
                sort_order INT DEFAULT 0,
                is_active BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (bio_page_id) REFERENCES bio_pages(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $success[] = "✅ Bio links table created";

        // Bio page social links
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS bio_socials (
                id INT AUTO_INCREMENT PRIMARY KEY,
                bio_page_id INT NOT NULL,
                platform VARCHAR(50) NOT NULL,
                url TEXT NOT NULL,
                sort_order INT DEFAULT 0,
                FOREIGN KEY (bio_page_id) REFERENCES bio_pages(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $success[] = "✅ Bio socials table created";

        // Plans table
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS plans (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(50) NOT NULL,
                slug VARCHAR(50) UNIQUE NOT NULL,
                price_monthly DECIMAL(10,2) DEFAULT 0,
                price_yearly DECIMAL(10,2) DEFAULT 0,
                link_limit INT DEFAULT 25,
                custom_domains INT DEFAULT 0,
                retention_days INT DEFAULT 30,
                features TEXT,
                is_active BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $success[] = "✅ Plans table created";

        // Insert default plans
        $pdo->exec("
            INSERT IGNORE INTO plans (name, slug, price_monthly, price_yearly, link_limit, custom_domains, retention_days, features) VALUES
            ('Free', 'free', 0, 0, 25, 0, 30, '[\"25 Links/month\",\"Basic Analytics\",\"QR Codes\"]'),
            ('Pro', 'pro', 9.99, 99, 1000, 3, 365, '[\"1000 Links/month\",\"Advanced Analytics\",\"Custom Domains\",\"Password Protection\",\"API Access\"]'),
            ('Enterprise', 'enterprise', 29.99, 299, -1, 10, -1, '[\"Unlimited Links\",\"Full Analytics\",\"10 Custom Domains\",\"Team Access\",\"Priority Support\"]')
        ");
        $success[] = "✅ Default plans inserted";

        // Pages table for CMS
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS pages (
                id INT AUTO_INCREMENT PRIMARY KEY,
                title VARCHAR(255) NOT NULL,
                slug VARCHAR(255) UNIQUE NOT NULL,
                content TEXT NOT NULL,
                meta_description TEXT,
                show_in_nav BOOLEAN DEFAULT FALSE,
                sort_order INT DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_slug (slug)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $success[] = "✅ Pages table created";

        // API Requests tracking table
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS api_requests (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                api_key_id INT NOT NULL,
                endpoint VARCHAR(255) NOT NULL,
                method VARCHAR(10) NOT NULL,
                ip_address VARCHAR(45),
                user_agent TEXT,
                request_data TEXT,
                response_code INT,
                response_time_ms INT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                FOREIGN KEY (api_key_id) REFERENCES api_keys(id) ON DELETE CASCADE,
                INDEX idx_user_id (user_id),
                INDEX idx_created_at (created_at),
                INDEX idx_endpoint (endpoint)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        ");
        $success[] = "✅ API requests table created";


        // Create default admin user
        $adminEmail = 'admin@snaplink.com';
        $adminPass = password_hash('admin123', PASSWORD_BCRYPT, ['cost' => HASH_COST]);
        
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$adminEmail]);
        
        if (!$stmt->fetch()) {
            $pdo->prepare("
                INSERT INTO users (name, email, password, role, plan, status) 
                VALUES (?, ?, ?, 'admin', 'enterprise', 'active')
            ")->execute(['Admin', $adminEmail, $adminPass]);
            $success[] = "✅ Default admin created (admin@snaplink.com / admin123)";
        }

        // Create install lock file
        file_put_contents($installLock, date('Y-m-d H:i:s'));
        $success[] = "✅ Installation complete!";
        $success[] = "⚠️ IMPORTANT: Delete install.php for security!";

    } catch (PDOException $e) {
        $errors[] = "❌ Database error: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Install SnapLink Pro</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body class="bg-gradient-to-br from-purple-600 to-pink-500 min-h-screen font-[Inter] flex items-center justify-center p-4">
    <div class="bg-white rounded-2xl shadow-2xl p-8 max-w-lg w-full">
        <div class="text-center mb-8">
            <div class="w-16 h-16 bg-purple-600 rounded-xl flex items-center justify-center mx-auto mb-4">
                <svg class="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M12.586 4.586a2 2 0 112.828 2.828l-3 3a2 2 0 01-2.828 0 1 1 0 00-1.414 1.414 4 4 0 005.656 0l3-3a4 4 0 00-5.656-5.656l-1.5 1.5a1 1 0 101.414 1.414l1.5-1.5zm-5 5a2 2 0 012.828 0 1 1 0 101.414-1.414 4 4 0 00-5.656 0l-3 3a4 4 0 105.656 5.656l1.5-1.5a1 1 0 10-1.414-1.414l-1.5 1.5a2 2 0 11-2.828-2.828l3-3z"/>
                </svg>
            </div>
            <h1 class="text-2xl font-bold text-gray-900">Install SnapLink Pro</h1>
            <p class="text-gray-500 mt-2">URL Shortener for InfinityFree</p>
        </div>

        <?php if (!empty($errors)): ?>
            <div class="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
                <?php foreach ($errors as $error): ?>
                    <p class="text-red-700 text-sm"><?= $error ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($success)): ?>
            <div class="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
                <?php foreach ($success as $msg): ?>
                    <p class="text-green-700 text-sm mb-1"><?= $msg ?></p>
                <?php endforeach; ?>
            </div>
            <a href="login.php" class="block w-full py-3 bg-purple-600 text-white text-center rounded-lg font-semibold hover:bg-purple-700 transition">
                Go to Login
            </a>
        <?php else: ?>
            <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
                <p class="text-yellow-800 text-sm font-medium">Before Installing:</p>
                <ul class="text-yellow-700 text-sm mt-2 list-disc list-inside">
                    <li>Edit <code class="bg-yellow-100 px-1 rounded">config/config.php</code></li>
                    <li>Set your database credentials</li>
                    <li>Set your APP_URL</li>
                </ul>
            </div>
            
            <form method="POST">
                <button type="submit" class="w-full py-3 bg-purple-600 text-white rounded-lg font-semibold hover:bg-purple-700 transition">
                    Install Database Tables
                </button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
