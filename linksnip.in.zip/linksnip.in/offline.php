﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Offline - SnapLink Pro</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gray-50 flex items-center justify-center min-h-screen p-4">

    <div class="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full text-center">
        <div class="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <i class="fas fa-wifi text-4xl text-gray-400"></i>
        </div>
        
        <h1 class="text-2xl font-bold text-gray-900 mb-2">You are Offline</h1>
        <p class="text-gray-500 mb-8">
            It looks like you've lost your internet connection. 
            Check your network settings and try again.
        </p>
        
        <button onclick="window.location.reload()" class="w-full py-3 bg-purple-600 text-white font-bold rounded-xl hover:bg-purple-700 transition shadow-lg shadow-purple-200">
            <i class="fas fa-redo-alt mr-2"></i>Retry Connection
        </button>
        
        <div class="mt-6 pt-6 border-t font-medium text-purple-600">
            SnapLink Pro PWA
        </div>
    </div>

</body>
</html>
