﻿<?php
/**
 * Dashboard - Main URL Management Page
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

require_login();

$user = current_user();
$flash = get_flash();

// Get user's URLs
$urls = db()->fetchAll(
    'SELECT id, short_code, long_url, clicks, qr_scans, created_at, is_active, notes, password 
     FROM urls WHERE user_id = ? ORDER BY created_at DESC',
    [$user['id']]
);

// Get summary stats
$stats = db()->fetchOne(
    'SELECT COUNT(*) as totalLinks, 
            COALESCE(SUM(clicks), 0) as totalClicks, 
            COALESCE(SUM(qr_scans), 0) as totalQrScans 
     FROM urls WHERE user_id = ?',
    [$user['id']]
);

// Get user folders
$folders = db()->fetchAll(
    'SELECT * FROM link_folders WHERE user_id = ? ORDER BY name',
    [$user['id']]
);

$baseUrl = APP_URL;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="manifest" href="manifest.json">
    <meta name="theme-color" content="#7e22ce">
    <title>Dashboard - SnapLink Pro</title>
    <?php meta_canonical('php-version/dashboard.php'); ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Inter', 'sans-serif'] },
                    colors: {
                        brand: { purple: '#7F00FF', pink: '#E100FF', dark: '#0F172A' }
                    }
                }
            }
        }
    </script>
    <style>
        body { font-family: 'Inter', sans-serif; }
        .sidebar { transition: transform 0.3s ease; }
        @media (max-width: 1024px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
        }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <div class="flex">
        <!-- Sidebar -->
        <aside id="sidebar" class="sidebar fixed lg:static inset-y-0 left-0 z-40 w-64 bg-gray-900 text-white flex flex-col">
            <!-- Logo -->
            <div class="p-6 border-b border-gray-800">
                <a href="index.php" class="flex items-center gap-2">
                    <div class="w-10 h-10 rounded-xl bg-brand-purple flex items-center justify-center">
                        <i class="fas fa-link"></i>
                    </div>
                    <span class="text-xl font-bold">Link<span class="text-yellow-300">Snip</span></span>
                </a>
            </div>

            <!-- Navigation -->
            <nav class="flex-1 p-4 space-y-2">
                <a href="dashboard.php" class="flex items-center gap-3 px-4 py-3 rounded-xl bg-brand-purple text-white">
                    <i class="fas fa-home w-5"></i>
                    <span>Dashboard</span>
                </a>
                <a href="analytics.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-gray-400 hover:bg-gray-800 hover:text-white transition">
                    <i class="fas fa-chart-bar w-5"></i>
                    <span>Analytics</span>
                </a>
                <a href="bio-editor.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-gray-400 hover:bg-gray-800 hover:text-white transition">
                    <i class="fas fa-id-card w-5"></i>
                    <span>Bio Page</span>
                </a>
                <a href="domains.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-gray-400 hover:bg-gray-800 hover:text-white transition">
                    <i class="fas fa-globe w-5"></i>
                    <span>Domains</span>
                </a>
                <a href="folders.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-gray-400 hover:bg-gray-800 hover:text-white transition">
                    <i class="fas fa-folder w-5"></i>
                    <span>Folders</span>
                </a>
                <a href="api-keys.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-gray-400 hover:bg-gray-800 hover:text-white transition">
                    <i class="fas fa-key w-5"></i>
                    <span>API Keys</span>
                </a>
                <a href="webhooks.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-gray-400 hover:bg-gray-800 hover:text-white transition">
                    <i class="fas fa-bell w-5"></i>
                    <span>Webhooks</span>
                </a>
                <a href="bulk-upload.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-gray-400 hover:bg-gray-800 hover:text-white transition">
                    <i class="fas fa-file-csv w-5"></i>
                    <span>Bulk Upload</span>
                </a>
                <a href="billing.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-gray-400 hover:bg-gray-800 hover:text-white transition">
                    <i class="fas fa-credit-card w-5"></i>
                    <span>Billing</span>
                </a>
                <a href="settings.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-gray-400 hover:bg-gray-800 hover:text-white transition">
                    <i class="fas fa-cog w-5"></i>
                    <span>Settings</span>
                </a>
                <a href="2fa-setup.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-gray-400 hover:bg-gray-800 hover:text-white transition">
                    <i class="fas fa-shield-alt w-5"></i>
                    <span>Security (2FA)</span>
                </a>
                
                <?php if ($user['role'] === 'admin'): ?>
                    <div class="pt-4 mt-4 border-t border-gray-800">
                        <p class="px-4 text-xs text-gray-500 uppercase tracking-wider mb-2">Admin</p>
                        <a href="admin/index.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-gray-400 hover:bg-gray-800 hover:text-white transition">
                            <i class="fas fa-shield-alt w-5"></i>
                            <span>Admin Panel</span>
                        </a>
                    </div>
                <?php endif; ?>
            </nav>

            <!-- User Info -->
            <div class="p-4 border-t border-gray-800">
                <div class="flex items-center gap-3 mb-3">
                    <div class="w-10 h-10 rounded-full bg-brand-purple flex items-center justify-center text-white font-bold">
                        <?= strtoupper(substr($user['name'], 0, 1)) ?>
                    </div>
                    <div class="flex-1 min-w-0">
                        <p class="font-medium truncate"><?= htmlspecialchars($user['name']) ?></p>
                        <p class="text-xs text-gray-400 truncate"><?= htmlspecialchars($user['email']) ?></p>
                    </div>
                </div>
                <a href="logout.php" class="flex items-center gap-2 text-gray-400 hover:text-red-400 transition text-sm">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </div>
        </aside>

        <!-- Sidebar Overlay -->
        <div id="sidebarOverlay" class="hidden fixed inset-0 bg-black/50 z-30 lg:hidden" onclick="toggleSidebar()"></div>

        <!-- Main Content -->
        <main class="flex-1 min-h-screen">
            <!-- Top Bar -->
            <header class="bg-white border-b border-gray-200 px-4 lg:px-8 py-4 flex items-center justify-between">
                <div class="flex items-center gap-4">
                    <button onclick="toggleSidebar()" class="lg:hidden text-gray-600 text-xl">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h1 class="text-xl font-bold text-gray-900">Dashboard</h1>
                </div>
                <div class="flex items-center gap-3">
                    <span class="px-3 py-1 rounded-full bg-purple-100 text-purple-700 text-sm font-medium capitalize">
                        <?= $user['plan'] ?> Plan
                    </span>
                </div>
            </header>

            <div class="p-4 lg:p-8">
                <?php require_once ROOT_PATH . '/components/ad-header.php'; ?>
                <!-- Stats Cards -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                        <div class="flex items-center justify-between mb-4">
                            <div class="w-12 h-12 rounded-xl bg-purple-100 text-purple-600 flex items-center justify-center text-xl">
                                <i class="fas fa-link"></i>
                            </div>
                            <span class="text-sm text-gray-500">Total</span>
                        </div>
                        <p class="text-3xl font-bold text-gray-900"><?= number_format($stats['totalLinks']) ?></p>
                        <p class="text-gray-500 text-sm">Links Created</p>
                    </div>

                    <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                        <div class="flex items-center justify-between mb-4">
                            <div class="w-12 h-12 rounded-xl bg-pink-100 text-pink-600 flex items-center justify-center text-xl">
                                <i class="fas fa-mouse-pointer"></i>
                            </div>
                            <span class="text-sm text-gray-500">Total</span>
                        </div>
                        <p class="text-3xl font-bold text-gray-900"><?= number_format($stats['totalClicks']) ?></p>
                        <p class="text-gray-500 text-sm">Link Clicks</p>
                    </div>

                    <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm">
                        <div class="flex items-center justify-between mb-4">
                            <div class="w-12 h-12 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center text-xl">
                                <i class="fas fa-qrcode"></i>
                            </div>
                            <span class="text-sm text-gray-500">Total</span>
                        </div>
                        <p class="text-3xl font-bold text-gray-900"><?= number_format($stats['totalQrScans']) ?></p>
                        <p class="text-gray-500 text-sm">QR Scans</p>
                    </div>
                </div>

                <!-- Create New Link -->
                <div class="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm mb-8">
                    <h2 class="text-lg font-bold text-gray-900 mb-4">Create New Short Link</h2>
                    <form id="shortenForm" class="space-y-4">
                        <div class="flex flex-col lg:flex-row gap-4">
                            <div class="flex-1">
                                <div class="relative">
                                    <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-gray-400">
                                        <i class="fas fa-link"></i>
                                    </div>
                                    <input type="url" name="url" id="longUrl" required
                                        class="w-full pl-11 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                                        placeholder="Paste your long URL here...">
                                </div>
                            </div>
                            <div class="lg:w-48">
                                <div class="relative">
                                    <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-gray-400">
                                        <i class="fas fa-edit"></i>
                                    </div>
                                    <input type="text" name="customAlias" id="customAlias"
                                        class="w-full pl-11 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                                        placeholder="Custom alias">
                                </div>
                            </div>
                            <button type="submit" id="shortenBtn"
                                class="px-6 py-3 bg-brand-purple text-white font-semibold rounded-xl hover:bg-purple-700 transition flex items-center justify-center gap-2">
                                <i class="fas fa-magic"></i>
                                <span>Shorten</span>
                            </button>
                        </div>

                        <!-- Advanced Options Toggle -->
                        <button type="button" onclick="toggleAdvanced()" class="text-sm text-purple-600 hover:text-purple-700 flex items-center gap-1">
                            <i class="fas fa-cog" id="advancedIcon"></i>
                            <span>Advanced Options</span>
                        </button>

                        <!-- Advanced Options -->
                        <div id="advancedOptions" class="hidden grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 p-4 bg-gray-50 rounded-xl">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Password Protection</label>
                                <input type="password" name="password" placeholder="Optional password"
                                    class="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-purple-500 text-sm">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Expires At</label>
                                <input type="datetime-local" name="expiresAt"
                                    class="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-purple-500 text-sm">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Max Clicks</label>
                                <input type="number" name="maxClicks" min="1" placeholder="Unlimited"
                                    class="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-purple-500 text-sm">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Notes</label>
                                <input type="text" name="notes" placeholder="Internal notes"
                                    class="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-purple-500 text-sm">
                            </div>
                        </div>
                    </form>

                    <!-- Result Area -->
                    <div id="shortenResult" class="hidden mt-4 p-4 bg-green-50 border border-green-200 rounded-xl">
                        <div class="flex items-center justify-between gap-4">
                            <div class="flex-1 min-w-0">
                                <p class="text-sm text-green-700 mb-1">Your short link is ready!</p>
                                <a id="resultUrl" href="#" target="_blank" class="text-lg font-bold text-green-700 hover:underline truncate block"></a>
                            </div>
                            <div class="flex gap-2">
                                <button onclick="copyResult()" class="p-2 text-green-600 hover:text-green-700 transition" title="Copy">
                                    <i class="far fa-copy text-xl"></i>
                                </button>
                                <button onclick="showQR()" class="p-2 text-green-600 hover:text-green-700 transition" title="QR Code">
                                    <i class="fas fa-qrcode text-xl"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Links Table -->
                <div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
                        <h2 class="text-lg font-bold text-gray-900">Your Links</h2>
                        <div class="relative">
                            <input type="text" id="searchLinks" placeholder="Search links..."
                                class="pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-purple-500">
                            <i class="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                        </div>
                    </div>

                    <div class="overflow-x-auto">
                        <table class="w-full">
                            <thead class="bg-gray-50 text-left text-sm text-gray-500 uppercase tracking-wider">
                                <tr>
                                    <th class="px-6 py-3">Short Link</th>
                                    <th class="px-6 py-3">Original URL</th>
                                    <th class="px-6 py-3 text-center">Clicks</th>
                                    <th class="px-6 py-3 text-center">QR Scans</th>
                                    <th class="px-6 py-3 text-center">Status</th>
                                    <th class="px-6 py-3 text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-100" id="linksTable">
                                <?php if (empty($urls)): ?>
                                    <tr>
                                        <td colspan="6" class="px-6 py-12 text-center text-gray-500">
                                            <i class="fas fa-link text-4xl text-gray-300 mb-4"></i>
                                            <p>No links yet. Create your first short link above!</p>
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($urls as $url): ?>
                                        <tr class="link-row hover:bg-gray-50" data-id="<?= $url['id'] ?>">
                                            <td class="px-6 py-4">
                                                <div class="flex items-center gap-2">
                                                    <?php if ($url['password']): ?>
                                                        <i class="fas fa-lock text-gray-400 text-xs" title="Password Protected"></i>
                                                    <?php endif; ?>
                                                    <a href="<?= $baseUrl ?>/<?= $url['short_code'] ?>" target="_blank" class="text-purple-600 font-medium hover:underline">
                                                        <?= $url['short_code'] ?>
                                                    </a>
                                                    <button onclick="copyLink('<?= $baseUrl ?>/<?= $url['short_code'] ?>')" class="text-gray-400 hover:text-gray-600">
                                                        <i class="far fa-copy"></i>
                                                    </button>
                                                </div>
                                            </td>
                                            <td class="px-6 py-4">
                                                <div class="max-w-xs truncate text-gray-600 text-sm" title="<?= htmlspecialchars($url['long_url']) ?>">
                                                    <?= htmlspecialchars($url['long_url']) ?>
                                                </div>
                                            </td>
                                            <td class="px-6 py-4 text-center font-medium"><?= number_format($url['clicks']) ?></td>
                                            <td class="px-6 py-4 text-center font-medium"><?= number_format($url['qr_scans']) ?></td>
                                            <td class="px-6 py-4 text-center">
                                                <span class="px-2 py-1 rounded-full text-xs font-medium <?= $url['is_active'] ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700' ?>">
                                                    <?= $url['is_active'] ? 'Active' : 'Disabled' ?>
                                                </span>
                                            </td>
                                            <td class="px-6 py-4 text-center">
                                                <div class="flex items-center justify-center gap-2">
                                                    <a href="analytics.php?id=<?= $url['id'] ?>" class="p-2 text-gray-400 hover:text-purple-600 transition" title="Analytics">
                                                        <i class="fas fa-chart-bar"></i>
                                                    </a>
                                                    <button onclick="toggleLink(<?= $url['id'] ?>, <?= $url['is_active'] ? 'false' : 'true' ?>)" 
                                                            class="p-2 text-gray-400 hover:text-yellow-600 transition" 
                                                            title="<?= $url['is_active'] ? 'Disable' : 'Enable' ?>">
                                                        <i class="fas <?= $url['is_active'] ? 'fa-pause' : 'fa-play' ?>"></i>
                                                    </button>
                                                    <button onclick="deleteLink(<?= $url['id'] ?>)" class="p-2 text-gray-400 hover:text-red-600 transition" title="Delete">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php require_once ROOT_PATH . '/components/ad-footer.php'; ?>
            </div>
        </main>
    </div>

    <!-- QR Modal -->
    <div id="qrModal" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-2xl p-6 max-w-sm w-full">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-lg font-bold">QR Code</h3>
                <button onclick="closeQR()" class="text-gray-400 hover:text-gray-600">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div id="qrCode" class="flex justify-center p-4 bg-white rounded-xl">
                <!-- QR code will be generated here -->
            </div>
            <p class="text-center text-gray-500 text-sm mt-4">Scan to visit your short link</p>
        </div>
    </div>

    <!-- QR Code Library -->
    <script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.3/build/qrcode.min.js"></script>

    <script>
        const baseUrl = '<?= $baseUrl ?>';
        let currentShortUrl = '';

        function toggleSidebar() {
            document.getElementById('sidebar').classList.toggle('open');
            document.getElementById('sidebarOverlay').classList.toggle('hidden');
        }

        function toggleAdvanced() {
            const options = document.getElementById('advancedOptions');
            const icon = document.getElementById('advancedIcon');
            options.classList.toggle('hidden');
            icon.classList.toggle('fa-cog');
            icon.classList.toggle('fa-times');
        }

        // Shorten Form
        document.getElementById('shortenForm').addEventListener('submit', async function(e) {
            e.preventDefault();

            const url = document.getElementById('longUrl').value.trim();
            if (!url) return alert('Please enter a URL');

            const btn = document.getElementById('shortenBtn');
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
            btn.disabled = true;

            const formData = new FormData(this);
            const data = {
                url: formData.get('url'),
                customAlias: formData.get('customAlias'),
                password: formData.get('password'),
                expiresAt: formData.get('expiresAt'),
                maxClicks: formData.get('maxClicks'),
                notes: formData.get('notes')
            };

            try {
                const res = await fetch('api/shorten.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                const result = await res.json();

                if (result.success) {
                    currentShortUrl = result.data.shortUrl;
                    document.getElementById('resultUrl').href = result.data.shortUrl;
                    document.getElementById('resultUrl').textContent = result.data.shortUrl;
                    document.getElementById('shortenResult').classList.remove('hidden');
                    document.getElementById('longUrl').value = '';
                    document.getElementById('customAlias').value = '';
                    
                    // Reload page to show new link
                    setTimeout(() => location.reload(), 1500);
                } else {
                    alert(result.error || 'Failed to shorten URL');
                }
            } catch (err) {
                console.error(err);
                alert('An error occurred');
            } finally {
                btn.innerHTML = '<i class="fas fa-magic"></i><span>Shorten</span>';
                btn.disabled = false;
            }
        });

        function copyResult() {
            navigator.clipboard.writeText(currentShortUrl).then(() => {
                alert('Copied to clipboard!');
            });
        }

        function copyLink(url) {
            navigator.clipboard.writeText(url).then(() => {
                // Brief visual feedback could be added here
            });
        }

        function showQR() {
            const modal = document.getElementById('qrModal');
            const container = document.getElementById('qrCode');
            container.innerHTML = '';
            
            QRCode.toCanvas(currentShortUrl, { width: 200, margin: 2 }, function(error, canvas) {
                if (error) console.error(error);
                container.appendChild(canvas);
            });
            
            modal.classList.remove('hidden');
        }

        function closeQR() {
            document.getElementById('qrModal').classList.add('hidden');
        }

        async function toggleLink(id, enable) {
            try {
                const res = await fetch('api/url.php', {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id, isActive: enable })
                });
                const result = await res.json();

                if (result.success) {
                    location.reload();
                } else {
                    alert(result.error || 'Failed to update');
                }
            } catch (err) {
                alert('An error occurred');
            }
        }

        async function deleteLink(id) {
            if (!confirm('Are you sure you want to delete this link? This cannot be undone.')) return;

            try {
                const res = await fetch('api/url.php', {
                    method: 'DELETE',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id })
                });
                const result = await res.json();

                if (result.success) {
                    location.reload();
                } else {
                    alert(result.error || 'Failed to delete');
                }
            } catch (err) {
                alert('An error occurred');
            }
        }

        // Search functionality
        document.getElementById('searchLinks').addEventListener('input', function() {
            const search = this.value.toLowerCase();
            document.querySelectorAll('.link-row').forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(search) ? '' : 'none';
            });
        });
    </script>

    <?php require_once ROOT_PATH . '/components/cookie-consent.php'; ?>
</body>
</html>
