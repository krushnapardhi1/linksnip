﻿<?php
/**
 * FAQ Page - SEO Optimized
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

$user = current_user();
$pageTitle = "FAQ - Frequently Asked Questions | SnapLink Pro";
$pageDescription = "Find answers to common questions about SnapLink Pro URL shortener. Learn about features, pricing, analytics, custom domains, and more.";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?></title>
    
    <!-- SEO Meta Tags -->
    <meta name="description" content="<?= $pageDescription ?>">
    <meta name="keywords" content="url shortener faq, snaplink questions, free url shortener, custom domain url shortener">
    <link rel="canonical" href="https://snaplink.pro/faq.php">
    
    <!-- Open Graph -->
    <meta property="og:title" content="<?= $pageTitle ?>">
    <meta property="og:description" content="<?= $pageDescription ?>">
    <meta property="og:type" content="website">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <style>
        body { font-family: 'Inter', sans-serif; }
        .faq-item { cursor: pointer; }
        .faq-answer { max-height: 0; overflow: hidden; transition: max-height 0.3s ease; }
        .faq-answer.active { max-height: 500px; }
    </style>
</head>
<body class="bg-gray-50">

    <!-- Navbar -->
    <nav class="bg-white shadow-sm border-b sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <a href="index.php" class="flex items-center gap-2">
                    <div class="w-10 h-10 rounded-xl bg-purple-600 flex items-center justify-center text-white">
                        <i class="fas fa-link"></i>
                    </div>
                    <span class="text-xl font-bold">SnapLink Pro</span>
                </a>
                
                <div class="hidden md:flex items-center space-x-6">
                    <a href="index.php" class="text-gray-700 hover:text-purple-600">Home</a>
                    <a href="features.php" class="text-gray-700 hover:text-purple-600">Features</a>
                    <a href="how-it-works.php" class="text-gray-700 hover:text-purple-600">How It Works</a>
                    <a href="faq.php" class="text-purple-600 font-semibold">FAQ</a>
                    <a href="blog.php" class="text-gray-700 hover:text-purple-600">Blog</a>
                </div>
                
                <div class="flex items-center gap-4">
                    <?php if ($user): ?>
                        <a href="dashboard.php" class="px-4 py-2 bg-purple-600 text-white rounded-lg font-semibold">Dashboard</a>
                    <?php else: ?>
                        <a href="login.php" class="text-gray-700">Login</a>
                        <a href="register.php" class="px-4 py-2 bg-purple-600 text-white rounded-lg font-semibold">Get Started</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero -->
    <section class="py-16 bg-gradient-to-r from-purple-600 to-pink-600">
        <div class="max-w-5xl mx-auto px-4 text-center text-white">
            <h1 class="text-5xl font-extrabold mb-6">Frequently Asked Questions</h1>
            <p class="text-xl opacity-90">Everything you need to know about SnapLink Pro</p>
        </div>
    </section>

    <!-- FAQ Section -->
    <section class="py-20">
        <div class="max-w-4xl mx-auto px-4">
            
            <!-- General Questions -->
            <h2 class="text-2xl font-bold text-gray-900 mb-6">General Questions</h2>
            
            <div class="space-y-4 mb-12">
                <div class="bg-white rounded-lg shadow-sm border border-gray-200">
                    <div class="faq-item p-6 flex items-center justify-between" onclick="toggleFaq(this)">
                        <h3 class="font-bold text-lg text-gray-900">What is SnapLink Pro?</h3>
                        <i class="fas fa-chevron-down text-gray-400"></i>
                    </div>
                    <div class="faq-answer px-6 pb-0">
                        <p class="text-gray-600 pb-6">SnapLink Pro is a free URL shortener with custom domain & analytics. It's the best free URL shortener in 2026 for creating short links, tracking clicks, generating QR codes, and managing your online presence effectively.</p>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow-sm border border-gray-200">
                    <div class="faq-item p-6 flex items-center justify-between" onclick="toggleFaq(this)">
                        <h3 class="font-bold text-lg text-gray-900">Is SnapLink Pro really free?</h3>
                        <i class="fas fa-chevron-down text-gray-400"></i>
                    </div>
                    <div class="faq-answer px-6 pb-0">
                        <p class="text-gray-600 pb-6">Yes! SnapLink Pro offers a free plan with 25 links per month, basic analytics, and QR codes. You can upgrade to Pro or Enterprise plans for more features like unlimited links, custom domains, and advanced analytics.</p>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow-sm border border-gray-200">
                    <div class="faq-item p-6 flex items-center justify-between" onclick="toggleFaq(this)">
                        <h3 class="font-bold text-lg text-gray-900">How do I shorten a URL?</h3>
                        <i class="fas fa-chevron-down text-gray-400"></i>
                    </div>
                    <div class="faq-answer px-6 pb-0">
                        <p class="text-gray-600 pb-6">Simply paste your long URL into the input field on the homepage, click "Shorten," and get your shortened link instantly. You can also customize the link with a custom alias and add password protection if needed.</p>
                    </div>
                </div>
            </div>

            <!-- Features Questions -->
            <h2 class="text-2xl font-bold text-gray-900 mb-6">Features</h2>
            
            <div class="space-y-4 mb-12">
                <div class="bg-white rounded-lg shadow-sm border border-gray-200">
                    <div class="faq-item p-6 flex items-center justify-between" onclick="toggleFaq(this)">
                        <h3 class="font-bold text-lg text-gray-900">Can I use my own custom domain?</h3>
                        <i class="fas fa-chevron-down text-gray-400"></i>
                    </div>
                    <div class="faq-answer px-6 pb-0">
                        <p class="text-gray-600 pb-6">Yes! With our Pro and Enterprise plans, you can add your own custom domain (e.g., go.yourbrand.com) to create branded short links. This increases trust and improves click-through rates.</p>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow-sm border border-gray-200">
                    <div class="faq-item p-6 flex items-center justify-between" onclick="toggleFaq(this)">
                        <h3 class="font-bold text-lg text-gray-900">Does SnapLink Pro provide analytics?</h3>
                        <i class="fas fa-chevron-down text-gray-400"></i>
                    </div>
                    <div class="faq-answer px-6 pb-0">
                        <p class="text-gray-600 pb-6">Absolutely! Every shortened link comes with detailed analytics including click count, geographic location, device type, browser, operating system, and referrer sources. See exactly who's clicking your links and when.</p>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow-sm border border-gray-200">
                    <div class="faq-item p-6 flex items-center justify-between" onclick="toggleFaq(this)">
                        <h3 class="font-bold text-lg text-gray-900">Can I generate QR codes?</h3>
                        <i class="fas fa-chevron-down text-gray-400"></i>
                    </div>
                    <div class="faq-answer px-6 pb-0">
                        <p class="text-gray-600 pb-6">Yes! Every shortened link automatically gets a QR code that you can download and use in print materials, posters, flyers, or business cards. QR scans are tracked separately in your analytics.</p>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow-sm border border-gray-200">
                    <div class="faq-item p-6 flex items-center justify-between" onclick="toggleFaq(this)">
                        <h3 class="font-bold text-lg text-gray-900">Does SnapLink Pro have API access?</h3>
                        <i class="fas fa-chevron-down text-gray-400"></i>
                    </div>
                    <div class="faq-answer px-6 pb-0">
                        <p class="text-gray-600 pb-6">Yes! Our REST API allows you to integrate URL shortening into your own applications and workflows. API access is available on Pro and Enterprise plans with detailed documentation.</p>
                    </div>
                </div>
            </div>

            <!-- Security & Privacy -->
            <h2 class="text-2xl font-bold text-gray-900 mb-6">Security & Privacy</h2>
            
            <div class="space-y-4 mb-12">
                <div class="bg-white rounded-lg shadow-sm border border-gray-200">
                    <div class="faq-item p-6 flex items-center justify-between" onclick="toggleFaq(this)">
                        <h3 class="font-bold text-lg text-gray-900">Are SnapLink Pro links safe?</h3>
                        <i class="fas fa-chevron-down text-gray-400"></i>
                    </div>
                    <div class="faq-answer px-6 pb-0">
                        <p class="text-gray-600 pb-6">Yes! We have advanced spam and fraud protection systems in place. All links are scanned for malware and malicious content. Users can report abusive links, and we take immediate action.</p>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow-sm border border-gray-200">
                    <div class="faq-item p-6 flex items-center justify-between" onclick="toggleFaq(this)">
                        <h3 class="font-bold text-lg text-gray-900">Can I password-protect my links?</h3>
                        <i class="fas fa-chevron-down text-gray-400"></i>
                    </div>
                    <div class="faq-answer px-6 pb-0">
                        <p class="text-gray-600 pb-6">Yes! You can add password protection to any shortened link. This is perfect for sharing private or sensitive content with specific people.</p>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow-sm border border-gray-200">
                    <div class="faq-item p-6 flex items-center justify-between" onclick="toggleFaq(this)">
                        <h3 class="font-bold text-lg text-gray-900">Do you store my data securely?</h3>
                        <i class="fas fa-chevron-down text-gray-400"></i>
                    </div>
                    <div class="faq-answer px-6 pb-0">
                        <p class="text-gray-600 pb-6">Absolutely. We use industry-standard encryption (HTTPS/SSL) to protect all data in transit. Your passwords are hashed using bcrypt, and we never share your data with third parties.</p>
                    </div>
                </div>
            </div>

            <!-- Pricing -->
            <h2 class="text-2xl font-bold text-gray-900 mb-6">Pricing & Plans</h2>
            
            <div class="space-y-4">
                <div class="bg-white rounded-lg shadow-sm border border-gray-200">
                    <div class="faq-item p-6 flex items-center justify-between" onclick="toggleFaq(this)">
                        <h3 class="font-bold text-lg text-gray-900">What's included in the free plan?</h3>
                        <i class="fas fa-chevron-down text-gray-400"></i>
                    </div>
                    <div class="faq-answer px-6 pb-0">
                        <p class="text-gray-600 pb-6">The free plan includes 25 links per month, basic analytics, QR codes, link expiration, and password protection. It's perfect for personal use and small projects.</p>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow-sm border border-gray-200">
                    <div class="faq-item p-6 flex items-center justify-between" onclick="toggleFaq(this)">
                        <h3 class="font-bold text-lg text-gray-900">What is the best free URL shortener in 2026?</h3>
                        <i class="fas fa-chevron-down text-gray-400"></i>
                    </div>
                    <div class="faq-answer px-6 pb-0">
                        <p class="text-gray-600 pb-6">SnapLink Pro is considered one of the best free URL shorteners in 2026 because it offers robust features like detailed analytics, QR codes, custom domains (on paid plans), password protection, and spam-free links at zero cost for the basic tier.</p>
                    </div>
                </div>

                <div class="bg-white rounded-lg shadow-sm border border-gray-200">
                    <div class="faq-item p-6 flex items-center justify-between" onclick="toggleFaq(this)">
                        <h3 class="font-bold text-lg text-gray-900">How do I upgrade my plan?</h3>
                        <i class="fas fa-chevron-down text-gray-400"></i>
                    </div>
                    <div class="faq-answer px-6 pb-0">
                        <p class="text-gray-600 pb-6">You can upgrade to Pro ($9.99/mo) or Enterprise ($29.99/mo) plans from your dashboard. Click on "Billing" in the sidebar and choose your desired plan. Payment is processed securely via Stripe.</p>
                    </div>
                </div>
            </div>

        </div>
    </section>

    <!-- CTA -->
    <section class="py-16 bg-gradient-to-r from-purple-600 to-pink-600">
        <div class="max-w-4xl mx-auto px-4 text-center">
            <h2 class="text-4xl font-bold text-white mb-6">Still Have Questions?</h2>
            <p class="text-xl text-white/90 mb-8">Contact our support team for personalized assistance</p>
            <a href="support.php" class="inline-block px-8 py-4 bg-white text-purple-600 rounded-lg font-bold text-lg hover:bg-gray-100 transition">
                Contact Support
            </a>
        </div>
    </section>

    <!-- Footer -->
    <?php include ROOT_PATH . '/components/footer.php'; ?>

    <script>
        function toggleFaq(element) {
            const answer = element.nextElementSibling;
            const icon = element.querySelector('i');
            
            // Close all other FAQs
            document.querySelectorAll('.faq-answer').forEach(el => {
                if (el !== answer) {
                    el.classList.remove('active');
                }
            });
            document.querySelectorAll('.faq-item i').forEach(el => {
                if (el !== icon) {
                    el.classList.remove('fa-chevron-up');
                    el.classList.add('fa-chevron-down');
                }
            });
            
            // Toggle current FAQ
            answer.classList.toggle('active');
            icon.classList.toggle('fa-chevron-down');
            icon.classList.toggle('fa-chevron-up');
        }
    </script>

</body>
</html>
