﻿<?php
/**
 * Webhooks Management Page
 * Configure webhook notifications for link events
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

require_login();
$user = current_user();

$db = db()->getConnection();

// Fetch user's webhooks
$stmt = $db->prepare("SELECT w.*, u.short_code FROM webhooks w 
                      LEFT JOIN urls u ON w.url_id = u.id 
                      WHERE w.user_id = ? 
                      ORDER BY w.created_at DESC");
$stmt->execute([$user['id']]);
$webhooks = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch user's URLs for dropdown
$stmt = $db->prepare("SELECT id, short_code, long_url FROM urls WHERE user_id = ? ORDER BY created_at DESC LIMIT 50");
$stmt->execute([$user['id']]);
$urls = $stmt->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = "Webhooks - SnapLink Pro";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gray-50">

    <!-- Navbar -->
    <nav class="bg-white shadow-sm border-b sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <a href="index.php" class="flex items-center gap-2">
                    <div class="w-10 h-10 rounded-xl bg-purple-600 flex items-center justify-center text-white">
                        <i class="fas fa-link"></i>
                    </div>
                    <span class="text-xl font-bold">SnapLink Pro</span>
                </a>
                
                <div class="flex items-center gap-4">
                    <a href="dashboard.php" class="text-gray-700 hover:text-purple-600">
                        <i class="fas fa-arrow-left mr-2"></i>Back to Dashboard
                    </a>
                    <a href="logout.php" class="text-gray-500 hover:text-red-600">
                        <i class="fas fa-sign-out-alt"></i>
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="max-w-6xl mx-auto px-4 py-8">
        
        <!-- Header -->
        <div class="mb-8">
            <h1 class="text-3xl font-bold text-gray-900 mb-2">Webhooks</h1>
            <p class="text-gray-600">Get notified when events happen on your links</p>
        </div>

        <!-- Create Webhook Card -->
        <div class="bg-gradient-to-r from-purple-600 to-pink-600 rounded-2xl p-8 mb-8 text-white">
            <h2 class="text-2xl font-bold mb-6">Create New Webhook</h2>
            
            <form id="createWebhookForm" class="space-y-4">
                <div class="grid md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm font-medium mb-2">Event Type</label>
                        <select name="event_type" id="eventType" required
                                class="w-full px-4 py-3 rounded-lg text-gray-900 focus:ring-2 focus:ring-white">
                            <option value="">Select event...</option>
                            <option value="first_click">First Click</option>
                            <option value="milestone">Milestone (10, 50, 100, 500, 1000 clicks)</option>
                            <option value="expiry">Link Expiry</option>
                        </select>
                    </div>
                    
                    <div id="milestoneField" class="hidden">
                        <label class="block text-sm font-medium mb-2">Milestone</label>
                        <select name="milestone" id="milestone"
                                class="w-full px-4 py-3 rounded-lg text-gray-900 focus:ring-2 focus:ring-white">
                            <option value="10">10 clicks</option>
                            <option value="50">50 clicks</option>
                            <option value="100">100 clicks</option>
                            <option value="500">500 clicks</option>
                            <option value="1000">1,000 clicks</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium mb-2">Link (Optional)</label>
                        <select name="url_id" class="w-full px-4 py-3 rounded-lg text-gray-900 focus:ring-2 focus:ring-white">
                            <option value="">All links</option>
                            <?php foreach ($urls as $url): ?>
                                <option value="<?= $url['id'] ?>">
                                    <?= htmlspecialchars($url['short_code']) ?> - <?= htmlspecialchars(substr($url['long_url'], 0, 40)) ?>...
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div>
                    <label class="block text-sm font-medium mb-2">Webhook URL</label>
                    <input type="url" name="webhook_url" required placeholder="https://your-domain.com/webhook"
                           class="w-full px-4 py-3 rounded-lg text-gray-900 focus:ring-2 focus:ring-white">
                    <p class="text-xs opacity-90 mt-1">We'll send POST requests to this URL when the event occurs</p>
                </div>
                
                <button type="submit"
                        class="px-6 py-3 bg-white text-purple-600 rounded-lg font-bold hover:bg-gray-100 transition">
                    <i class="fas fa-plus mr-2"></i>Create Webhook
                </button>
            </form>
        </div>

        <!-- Webhooks List -->
        <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
            <div class="p-6 border-b">
                <h3 class="text-xl font-bold text-gray-900">Your Webhooks</h3>
                <p class="text-sm text-gray-500 mt-1"><?= count($webhooks) ?> webhook(s) configured</p>
            </div>
            
            <?php if (empty($webhooks)): ?>
                <div class="p-12 text-center">
                    <div class="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-bell text-3xl text-gray-400"></i>
                    </div>
                    <h3 class="text-lg font-semibold text-gray-900 mb-2">No Webhooks Yet</h3>
                    <p class="text-gray-500">Create your first webhook to get notified about link events</p>
                </div>
            <?php else: ?>
                <div class="divide-y">
                    <?php foreach ($webhooks as $webhook): ?>
                        <div class="p-6 hover:bg-gray-50 transition">
                            <div class="flex items-start justify-between">
                                <div class="flex-1">
                                    <div class="flex items-center gap-3 mb-3">
                                        <span class="px-3 py-1 bg-purple-100 text-purple-700 text-sm font-semibold rounded-full">
                                            <?= ucfirst(str_replace('_', ' ', $webhook['event_type'])) ?>
                                            <?php if ($webhook['milestone']): ?>
                                                - <?= $webhook['milestone'] ?> clicks
                                            <?php endif; ?>
                                        </span>
                                        <?php if ($webhook['is_active']): ?>
                                            <span class="px-3 py-1 bg-green-100 text-green-700 text-xs font-semibold rounded-full">
                                                Active
                                            </span>
                                        <?php else: ?>
                                            <span class="px-3 py-1 bg-gray-100 text-gray-700 text-xs font-semibold rounded-full">
                                                Disabled
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <p class="text-sm text-gray-500 mb-1">Webhook URL:</p>
                                        <code class="text-sm bg-gray-100 px-3 py-1 rounded">
                                            <?= htmlspecialchars($webhook['webhook_url']) ?>
                                        </code>
                                    </div>
                                    
                                    <?php if ($webhook['short_code']): ?>
                                        <p class="text-sm text-gray-600">
                                            <i class="fas fa-link mr-2"></i>
                                            Link: <span class="font-medium"><?= htmlspecialchars($webhook['short_code']) ?></span>
                                        </p>
                                    <?php else: ?>
                                        <p class="text-sm text-gray-600">
                                            <i class="fas fa-globe mr-2"></i>
                                            Applies to: <span class="font-medium">All links</span>
                                        </p>
                                    <?php endif; ?>
                                    
                                    <p class="text-xs text-gray-400 mt-2">
                                        Created <?= date('M d, Y', strtotime($webhook['created_at'])) ?>
                                    </p>
                                </div>
                                
                                <div class="flex items-center gap-2 ml-4">
                                    <button onclick="testWebhook(<?= $webhook['id'] ?>)" 
                                            class="px-4 py-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 font-semibold text-sm">
                                        <i class="fas fa-vial mr-2"></i>Test
                                    </button>
                                    <button onclick="toggleWebhook(<?= $webhook['id'] ?>, <?= $webhook['is_active'] ? 'false' : 'true' ?>)" 
                                            class="px-4 py-2 <?= $webhook['is_active'] ? 'bg-yellow-100 text-yellow-600 hover:bg-yellow-200' : 'bg-green-100 text-green-600 hover:bg-green-200' ?> rounded-lg font-semibold text-sm">
                                        <i class="fas <?= $webhook['is_active'] ? 'fa-pause' : 'fa-play' ?> mr-2"></i>
                                        <?= $webhook['is_active'] ? 'Disable' : 'Enable' ?>
                                    </button>
                                    <button onclick="deleteWebhook(<?= $webhook['id'] ?>)" 
                                            class="px-4 py-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 font-semibold text-sm">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Info Box -->
        <div class="mt-8 bg-blue-50 border border-blue-200 rounded-xl p-6">
            <div class="flex items-start gap-4">
                <div class="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <i class="fas fa-info-circle text-blue-600 text-xl"></i>
                </div>
                <div>
                    <h3 class="text-lg font-bold text-gray-900 mb-2">Webhook Payload</h3>
                    <p class="text-gray-600 mb-4">We send POST requests with this JSON payload:</p>
                    <pre class="bg-gray-900 text-green-400 p-4 rounded-lg text-sm overflow-x-auto"><code>{
  "event": "first_click" | "milestone" | "expiry",
  "link": {
    "short_code": "abc123",
    "long_url": "https://example.com",
    "clicks": 100
  },
  "timestamp": "2026-01-29T23:41:00Z"
}</code></pre>
                </div>
            </div>
        </div>

    </div>

    <!-- Toast Notification -->
    <div id="toast" class="hidden fixed top-4 right-4 bg-green-600 text-white px-6 py-4 rounded-lg shadow-lg z-50">
        <div class="flex items-center gap-3">
            <i class="fas fa-check-circle text-xl"></i>
            <span id="toast-message">Success!</span>
        </div>
    </div>

    <script>
        // Show milestone field when milestone event is selected
        document.getElementById('eventType').addEventListener('change', function() {
            const milestoneField = document.getElementById('milestoneField');
            const milestoneSelect = document.getElementById('milestone');
            
            if (this.value === 'milestone') {
                milestoneField.classList.remove('hidden');
                milestoneSelect.required = true;
            } else {
                milestoneField.classList.add('hidden');
                milestoneSelect.required = false;
            }
        });

        function showToast(message, type = 'success') {
            const toast = document.getElementById('toast');
            const toastMessage = document.getElementById('toast-message');
            
            toast.className = `fixed top-4 right-4 px-6 py-4 rounded-lg shadow-lg z-50 ${
                type === 'success' ? 'bg-green-600' : 'bg-red-600'
            } text-white`;
            
            toastMessage.textContent = message;
            toast.classList.remove('hidden');
            
            setTimeout(() => {
                toast.classList.add('hidden');
            }, 3000);
        }

        // Create webhook
        document.getElementById('createWebhookForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const data = {
                event_type: formData.get('event_type'),
                webhook_url: formData.get('webhook_url'),
                url_id: formData.get('url_id') || null,
                milestone: formData.get('event_type') === 'milestone' ? formData.get('milestone') : null
            };
            
            try {
                const response = await fetch('api/webhooks.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showToast('Webhook created successfully!');
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showToast(result.error || 'Failed to create webhook', 'error');
                }
            } catch (error) {
                showToast('An error occurred', 'error');
            }
        });

        async function toggleWebhook(id, enable) {
            try {
                const response = await fetch('api/webhooks.php', {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id, is_active: enable })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showToast(enable ? 'Webhook enabled!' : 'Webhook disabled!');
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showToast(result.error || 'Failed to update webhook', 'error');
                }
            } catch (error) {
                showToast('An error occurred', 'error');
            }
        }

        async function deleteWebhook(id) {
            if (!confirm('Are you sure you want to delete this webhook?')) return;
            
            try {
                const response = await fetch('api/webhooks.php', {
                    method: 'DELETE',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showToast('Webhook deleted successfully!');
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showToast(result.error || 'Failed to delete webhook', 'error');
                }
            } catch (error) {
                showToast('An error occurred', 'error');
            }
        }

        async function testWebhook(id) {
            try {
                const response = await fetch('api/test-webhook.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showToast('Test webhook sent! Check your endpoint.');
                } else {
                    showToast(result.error || 'Failed to send test webhook', 'error');
                }
            } catch (error) {
                showToast('An error occurred', 'error');
            }
        }
    </script>

</body>
</html>
