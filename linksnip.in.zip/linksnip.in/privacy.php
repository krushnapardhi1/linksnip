﻿<?php
/**
 * Privacy Policy Page
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

$user = current_user();

$content = 'Privacy Policy under maintenance.';
try {
    $setting = db()->fetchOne("SELECT value FROM site_settings WHERE key_name = 'privacy_policy'");
    if ($setting && $setting['value']) {
        $content = $setting['value'];
    }
} catch (Exception $e) {}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy - SnapLink Pro</title>
    <?php meta_canonical('php-version/privacy.php'); ?>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-50 min-h-screen">
    <!-- Navbar -->
    <nav class="bg-white border-b border-gray-200">
        <div class="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
            <a href="index.php" class="flex items-center gap-2">
                <div class="w-10 h-10 rounded-xl bg-purple-600 flex items-center justify-center text-white">
                    <i class="fas fa-link"></i>
                </div>
                <span class="text-xl font-bold text-gray-900">Link<span class="text-purple-600">Snip</span></span>
            </a>
            <?php if ($user): ?>
                <a href="dashboard.php" class="text-purple-600 font-medium hover:text-purple-700">Dashboard</a>
            <?php else: ?>
                <a href="login.php" class="text-purple-600 font-medium hover:text-purple-700">Login</a>
            <?php endif; ?>
        </div>
    </nav>

    <div class="max-w-4xl mx-auto px-4 py-12">
        <h1 class="text-3xl font-bold text-gray-900 mb-8">Privacy Policy</h1>
        <div class="bg-white rounded-2xl p-8 border border-gray-100 shadow-sm prose max-w-none">
            <?= nl2br(htmlspecialchars($content)) ?>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-gray-900 text-gray-400 py-8 mt-12">
        <div class="max-w-4xl mx-auto px-4 text-center">
            <p>&copy; <?= date('Y') ?> SnapLink Pro. All rights reserved.</p>
        </div>
    </footer>

    <?php require_once ROOT_PATH . '/components/cookie-consent.php'; ?>
</body>
</html>
