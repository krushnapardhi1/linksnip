﻿<?php
/**
 * Link Rotation Manager
 * Configure A/B testing with multiple destination URLs
 */
define('ROOT_PATH', __DIR__);
require_once ROOT_PATH . '/config/config.php';
require_once ROOT_PATH . '/config/database.php';

require_login();
$user = current_user();

$urlId = $_GET['id'] ?? null;

if (!$urlId) {
    redirect(base_url('dashboard.php'));
}

$db = db()->getConnection();

// Get URL info
$stmt = $db->prepare("SELECT * FROM urls WHERE id = ? AND user_id = ?");
$stmt->execute([$urlId, $user['id']]);
$url = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$url) {
    set_flash('error', 'URL not found');
    redirect(base_url('dashboard.php'));
}

// Get existing rotation URLs
$stmt = $db->prepare("SELECT * FROM link_rotations WHERE url_id = ? ORDER BY weight DESC, id");
$stmt->execute([$urlId]);
$rotations = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get rotation settings
$stmt = $db->prepare("SELECT rotation_enabled, rotation_mode FROM urls WHERE id = ?");
$stmt->execute([$urlId]);
$rotationSettings = $stmt->fetch(PDO::FETCH_ASSOC);
$rotationEnabled = $rotationSettings['rotation_enabled'] ?? 0;
$rotationMode = $rotationSettings['rotation_mode'] ?? 'random';

$baseUrl = APP_URL;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Link Rotation - <?= htmlspecialchars($url['short_code']) ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gray-50">

    <!-- Navbar -->
    <nav class="bg-white shadow-sm border-b sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <a href="index.php" class="flex items-center gap-2">
                    <div class="w-10 h-10 rounded-xl bg-purple-600 flex items-center justify-center text-white">
                        <i class="fas fa-link"></i>
                    </div>
                    <span class="text-xl font-bold">SnapLink Pro</span>
                </a>
                
                <div class="flex items-center gap-4">
                    <a href="analytics.php?id=<?= $url['id'] ?>" class="text-gray-700 hover:text-purple-600">
                        <i class="fas fa-chart-bar mr-2"></i>Analytics
                    </a>
                    <a href="dashboard.php" class="text-gray-700 hover:text-purple-600">
                        <i class="fas fa-arrow-left mr-2"></i>Dashboard
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="max-w-5xl mx-auto px-4 py-8">
        
        <!-- Header -->
        <div class="mb-8">
            <div class="flex items-center gap-3 mb-4">
                <a href="dashboard.php" class="text-gray-400 hover:text-gray-600">
                    <i class="fas fa-arrow-left"></i>
                </a>
                <div>
                    <h1 class="text-3xl font-bold text-gray-900">Link Rotation / A/B Testing</h1>
                    <p class="text-gray-600">Split traffic between multiple destination URLs</p>
                </div>
            </div>
            
            <div class="bg-white rounded-xl p-4 border">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-sm text-gray-500">Short URL</p>
                        <a href="<?= $baseUrl ?>/<?= $url['short_code'] ?>" target="_blank" 
                           class="text-purple-600 font-semibold hover:underline">
                            <?= $baseUrl ?>/<?= $url['short_code'] ?>
                        </a>
                    </div>
                    <div>
                        <p class="text-sm text-gray-500">Original Destination</p>
                        <p class="text-gray-900 font-medium truncate max-w-md"><?= htmlspecialchars($url['long_url']) ?></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Info Banner -->
        <div class="bg-blue-50 border border-blue-200 rounded-xl p-6 mb-8">
            <div class="flex gap-4">
                <i class="fas fa-info-circle text-2xl text-blue-600 flex-shrink-0"></i>
                <div>
                    <h3 class="font-bold text-blue-900 mb-2">How Link Rotation Works</h3>
                    <p class="text-sm text-blue-800 mb-3">
                        Each time someone clicks your link, they'll be sent to one of your destinations based on the rotation mode.
                        Perfect for A/B testing landing pages, comparing offers, or testing different products!
                    </p>
                    <div class="grid md:grid-cols-3 gap-4 text-sm">
                        <div class="bg-white rounded-lg p-3">
                            <strong class="text-blue-900">🎲 Random:</strong>
                            <p class="text-blue-700">Each visitor goes to a random URL</p>
                        </div>
                        <div class="bg-white rounded-lg p-3">
                            <strong class="text-blue-900">🔄 Sequential:</strong>
                            <p class="text-blue-700">Rotates URLs in order</p>
                        </div>
                        <div class="bg-white rounded-lg p-3">
                            <strong class="text-blue-900">⚖️ Weighted:</strong>
                            <p class="text-blue-700">Based on assigned weights</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Rotation Settings -->
        <div class="bg-white rounded-2xl shadow-lg p-6 mb-6">
            <h2 class="text-xl font-bold text-gray-900 mb-4">Rotation Settings</h2>
            
            <div class="flex items-center justify-between mb-6 p-4 bg-gray-50 rounded-xl">
                <div>
                    <h3 class="font-semibold text-gray-900">Enable Link Rotation</h3>
                    <p class="text-sm text-gray-600">Activate A/B testing for this link</p>
                </div>
                <label class="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" id="rotationToggle" <?= $rotationEnabled ? 'checked' : '' ?> 
                           onchange="toggleRotation()" class="sr-only peer">
                    <div class="w-14 h-8 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-1 after:left-1 after:bg-white after:border-gray-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-purple-600"></div>
                </label>
            </div>

            <div id="rotationOptions" class="<?= $rotationEnabled ? '' : 'hidden' ?>">
                <label class="block text-sm font-medium text-gray-700 mb-2">Rotation Mode</label>
                <div class="grid grid-cols-3 gap-4">
                    <button onclick="selectMode('random')" data-mode="random"
                            class="mode-btn p-4 border-2 rounded-xl hover:border-purple-500 transition <?= $rotationMode === 'random' ? 'border-purple-500 bg-purple-50' : 'border-gray-200' ?>">
                        <i class="fas fa-random text-2xl mb-2 text-purple-600"></i>
                        <h4 class="font-semibold">Random</h4>
                        <p class="text-xs text-gray-600">Equal chance</p>
                    </button>
                    <button onclick="selectMode('sequential')" data-mode="sequential"
                            class="mode-btn p-4 border-2 rounded-xl hover:border-purple-500 transition <?= $rotationMode === 'sequential' ? 'border-purple-500 bg-purple-50' : 'border-gray-200' ?>">
                        <i class="fas fa-sort-numeric-down text-2xl mb-2 text-purple-600"></i>
                        <h4 class="font-semibold">Sequential</h4>
                        <p class="text-xs text-gray-600">Round-robin</p>
                    </button>
                    <button onclick="selectMode('weighted')" data-mode="weighted"
                            class="mode-btn p-4 border-2 rounded-xl hover:border-purple-500 transition <?= $rotationMode === 'weighted' ? 'border-purple-500 bg-purple-50' : 'border-gray-200' ?>">
                        <i class="fas fa-balance-scale text-2xl mb-2 text-purple-600"></i>
                        <h4 class="font-semibold">Weighted</h4>
                        <p class="text-xs text-gray-600">By weight %</p>
                    </button>
                </div>
                <input type="hidden" id="selectedMode" value="<?= $rotationMode ?>">
            </div>
        </div>

        <!-- Rotation URLs -->
        <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
            <div class="p-6 border-b bg-gradient-to-r from-purple-50 to-pink-50">
                <div class="flex items-center justify-between">
                    <div>
                        <h2 class="text-xl font-bold text-gray-900">Destination URLs</h2>
                        <p class="text-sm text-gray-600">Add multiple URLs to rotate between</p>
                    </div>
                    <button onclick="openAddModal()" class="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 font-semibold">
                        <i class="fas fa-plus mr-2"></i>Add URL
                    </button>
                </div>
            </div>

            <div class="p-6">
                <?php if (empty($rotations)): ?>
                    <div class="text-center py-12">
                        <div class="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                            <i class="fas fa-route text-4xl text-gray-400"></i>
                        </div>
                        <h3 class="text-lg font-semibold text-gray-900 mb-2">No Rotation URLs Yet</h3>
                        <p class="text-gray-500 mb-6">Add at least 2 URLs to start A/B testing</p>
                        <button onclick="openAddModal()" class="px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 font-semibold">
                            <i class="fas fa-plus mr-2"></i>Add First URL
                        </button>
                    </div>
                <?php else: ?>
                    <div class="space-y-3">
                        <?php 
                        $totalWeight = array_sum(array_column($rotations, 'weight'));
                        foreach ($rotations as $index => $rotation): 
                            $percentage = $totalWeight > 0 ? round(($rotation['weight'] / $totalWeight) * 100, 1) : 0;
                        ?>
                            <div class="flex items-center gap-4 p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition">
                                <div class="flex-shrink-0 bg-purple-600 text-white w-10 h-10 rounded-full flex items-center justify-center font-bold">
                                    <?= chr(65 + $index) ?>
                                </div>
                                <div class="flex-1 min-w-0">
                                    <div class="flex items-center gap-2 mb-1">
                                        <?php if ($rotation['name']): ?>
                                            <h4 class="font-semibold text-gray-900"><?= htmlspecialchars($rotation['name']) ?></h4>
                                        <?php else: ?>
                                            <h4 class="font-semibold text-gray-900">Variant <?= chr(65 + $index) ?></h4>
                                        <?php endif; ?>
                                        <span class="text-xs px-2 py-1 bg-purple-100 text-purple-700 rounded-full">
                                            Weight: <?= $rotation['weight'] ?> (<?= $percentage ?>%)
                                        </span>
                                    </div>
                                    <p class="text-sm text-gray-600 truncate"><?= htmlspecialchars($rotation['destination_url']) ?></p>
                                    <p class="text-xs text-gray-500 mt-1">
                                        <i class="fas fa-mouse-pointer mr-1"></i><?= number_format($rotation['clicks']) ?> clicks
                                    </p>
                                </div>
                                <div class="flex items-center gap-2">
                                    <button onclick='editRotation(<?= json_encode($rotation) ?>)' 
                                            class="px-3 py-2 bg-blue-100 text-blue-600 rounded-lg hover:bg-blue-200 font-semibold text-sm">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button onclick="deleteRotation(<?= $rotation['id'] ?>)" 
                                            class="px-3 py-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 font-semibold text-sm">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <?php if (count($rotations) >= 2): ?>
                        <div class="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
                            <p class="text-green-800">
                                <i class="fas fa-check-circle mr-2"></i>
                                <strong>Ready to test!</strong> You have <?= count($rotations) ?> URLs configured.
                            </p>
                        </div>
                    <?php else: ?>
                        <div class="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                            <p class="text-yellow-800">
                                <i class="fas fa-exclamation-triangle mr-2"></i>
                                Add at least one more URL to enable rotation.
                            </p>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>

    </div>

    <!-- Add/Edit Modal -->
    <div id="rotationModal" class="hidden fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-2xl p-8 max-w-md w-full">
            <div class="flex items-center justify-between mb-6">
                <h3 class="text-2xl font-bold" id="modalTitle">Add Rotation URL</h3>
                <button onclick="closeModal()" class="text-gray-400 hover:text-gray-600">
                    <i class="fas fa-times text-xl"></i>
                </button>
            </div>
            
            <form id="rotationForm" class="space-y-4">
                <input type="hidden" id="rotationId" name="rotation_id">
                <input type="hidden" name="url_id" value="<?= $url['id'] ?>">
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Name (Optional)</label>
                    <input type="text" id="rotationName" name="name"
                           class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500"
                           placeholder="e.g., Landing Page A">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Destination URL</label>
                    <input type="url" id="destinationUrl" name="destination_url" required
                           class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500"
                           placeholder="https://example.com">
                </div>
                
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Weight</label>
                    <input type="number" id="weight" name="weight" value="100" min="1" max="1000"
                           class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-500">
                    <p class="text-xs text-gray-500 mt-1">Higher weight = more traffic. Used in weighted mode.</p>
                </div>
                
                <button type="submit" class="w-full px-6 py-3 bg-purple-600 text-white rounded-xl font-semibold hover:bg-purple-700">
                    <i class="fas fa-save mr-2"></i><span id="submitText">Save URL</span>
                </button>
            </form>
        </div>
    </div>

    <!-- Toast -->
    <div id="toast" class="hidden fixed top-4 right-4 bg-green-600 text-white px-6 py-4 rounded-lg shadow-lg z-50">
        <div class="flex items-center gap-3">
            <i class="fas fa-check-circle text-xl"></i>
            <span id="toast-message">Success!</span>
        </div>
    </div>

    <script>
        let isEditMode = false;
        let selectedMode = '<?= $rotationMode ?>';

        function showToast(message, type = 'success') {
            const toast = document.getElementById('toast');
            toast.className = `fixed top-4 right-4 px-6 py-4 rounded-lg shadow-lg z-50 ${
                type === 'success' ? 'bg-green-600' : 'bg-red-600'
            } text-white`;
            document.getElementById('toast-message').textContent = message;
            toast.classList.remove('hidden');
            setTimeout(() => toast.classList.add('hidden'), 3000);
        }

        async function toggleRotation() {
            const enabled = document.getElementById('rotationToggle').checked;
            document.getElementById('rotationOptions').classList.toggle('hidden', !enabled);
            
            try {
                const response = await fetch('api/link-rotation.php?action=toggle', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ 
                        url_id: <?= $url['id'] ?>, 
                        enabled: enabled,
                        mode: selectedMode
                    })
                });
                
                const result = await response.json();
                if (result.success) {
                    showToast(enabled ? 'Rotation enabled!' : 'Rotation disabled!');
                }
            } catch (error) {
                showToast('Failed to update rotation', 'error');
            }
        }

        function selectMode(mode) {
            selectedMode = mode;
            document.getElementById('selectedMode').value = mode;
            
            document.querySelectorAll('.mode-btn').forEach(btn => {
                if (btn.dataset.mode === mode) {
                    btn.classList.add('border-purple-500', 'bg-purple-50');
                    btn.classList.remove('border-gray-200');
                } else {
                    btn.classList.remove('border-purple-500', 'bg-purple-50');
                    btn.classList.add('border-gray-200');
                }
            });
            
            toggleRotation();
        }

        function openAddModal() {
            isEditMode = false;
            document.getElementById('modalTitle').textContent = 'Add Rotation URL';
            document.getElementById('submitText').textContent = 'Save URL';
            document.getElementById('rotationForm').reset();
            document.getElementById('rotationId').value = '';
            document.getElementById('rotationModal').classList.remove('hidden');
        }

        function editRotation(rotation) {
            isEditMode = true;
            document.getElementById('modalTitle').textContent = 'Edit Rotation URL';
            document.getElementById('submitText').textContent = 'Update URL';
            document.getElementById('rotationId').value = rotation.id;
            document.getElementById('rotationName').value = rotation.name || '';
            document.getElementById('destinationUrl').value = rotation.destination_url;
            document.getElementById('weight').value = rotation.weight;
            document.getElementById('rotationModal').classList.remove('hidden');
        }

        function closeModal() {
            document.getElementById('rotationModal').classList.add('hidden');
        }

        document.getElementById('rotationForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const data = {
                url_id: formData.get('url_id'),
                name: formData.get('name'),
                destination_url: formData.get('destination_url'),
                weight: formData.get('weight')
            };
            
            if (isEditMode) {
                data.id = formData.get('rotation_id');
            }
            
            const url = isEditMode ? 'api/link-rotation.php?action=update' : 'api/link-rotation.php?action=create';
            
            try {
                const response = await fetch(url, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showToast(isEditMode ? 'URL updated!' : 'URL added!');
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showToast(result.error || 'Failed to save URL', 'error');
                }
            } catch (error) {
                showToast('An error occurred', 'error');
            }
        });

        async function deleteRotation(id) {
            if (!confirm('Delete this rotation URL?')) return;
            
            try {
                const response = await fetch('api/link-rotation.php?action=delete', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showToast('URL deleted!');
                    setTimeout(() => location.reload(), 1500);
                } else {
                    showToast(result.error || 'Failed to delete URL', 'error');
                }
            } catch (error) {
                showToast('An error occurred', 'error');
            }
        }
    </script>

</body>
</html>
